/*************************************************************************
 *
 * UniRPCConnection.java
 * 
 *       IBM Confidential
 *       OCO Source Materials
 *       Copyright (C) IBM Corp.  1993, 2008
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 04/10/08 10544 JFM fixed the NLS initialization problem in SSLmode/Proxy
 * 04/07/08 10544 JFM fixed the NLS initialization problem in SSLmode
 * 09/14/05 32898 CUI in espconnect() added conditional assignment for response.
 *	Now 7.1/10.2 server returns two parameters instead of 1.
 * 09/08/05 E32898  RKK For Proxy Server serverid is not required.
 * 08/09/05 E33964,E7815 JFM modified isServerAlive() to always call socket.isServerAlive() because we changed the way to check the existence of server
 * 08/04/05 E33964 JFM modify isServerAlive() to act according to server id
 * 05/26/05 E7815  RKK  Socket alive for connection pooling
 * 12/14/04 e32565 JFM fixed a bug in CP related handshaking
 * 11/18/04 e32565 RKK Connection Pooling
 * 10/11/01 J.Mao for connecting to UCI server (JDBC)
 * 05/16/00 27344 JFM fix applet security in proxy connection
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.unirpc;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import asjava.uniobjects.UniObjectsTokens;
import asjava.uniobjects.UniSSLDescriptor;

/**
 * UniRPCConnection is the primary class used for client/server communication
 * with UniVerse. UniRPC is an implementation of a Remote Procedure
 * Call(RPC) facility. UniRPC is based on the original PI/Open RPC
 * definition. Currently UniVerse supports version 1.0 of this protocol.
 *
 * Important note. All packets that are used with this object should be
 * obtained from the packet() method or constructed with this connection
 * object. The only exception is on the server side where the first packet
 * will be a boot strap packet and after one use it will be destroyed.
 *
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIRPC 1.0
 */

public class UniRPCConnection extends UniRPC
{
	/**
	 * Constructs a UniRPCConnection object but does NOT open any connections to any hosts.
	 * Sets up all the default parameters for the connect method.
	 *
	 * @see #UniRPCConnection(asjava.unirpc.UniRPCConnection)
	 * @since	UniRPC1.0
	 */
	public UniRPCConnection()
	{
		isActive = false;
		isConnected = false;
		isProxyConnection = false;
		isMultiplexed = false;
		currentTimeoutSeconds = UNIRPC_DEFAULT_TIMEOUT;
		currentPort = UniRPCTokens.UNIRPC_DEFAULT_PORT;
		currentTransportType = UniRPCTokens.UNIRPC_TRANSPORT_TCPIP;
		currentEncryptionType = UniRPCTokens.UNIRPC_ENCRYPTION_NONE;
		currentProxyToken = "";
		currentProxyConnectionID = UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID;
	}

  /**
   * Constructs UniRPCConnection object but does NOT open any connections to any hosts.
   * Sets up all the default parameters for the connect method.
   * sslflag flag tells if the connection secure
	 *
	 * @see #UniRPCConnection(asjava.unirpc.UniRPCConnection)
	 * @since	UniRPC1.0
	 */
	public UniRPCConnection(int sslmode)
	{
    this.sslMode = sslmode;
		isActive = false;
		isConnected = false;		
		isProxyConnection = false;
		isMultiplexed = false;
		currentTimeoutSeconds = UNIRPC_DEFAULT_TIMEOUT;
		currentPort = UniRPCTokens.UNIRPC_DEFAULT_PORT;
		currentTransportType = UniRPCTokens.UNIRPC_TRANSPORT_TCPIP;
		currentEncryptionType = UniRPCTokens.UNIRPC_ENCRYPTION_NONE;
		currentProxyToken = "";
		currentProxyConnectionID = UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID;
		if (sslMode == UniObjectsTokens.EXTERNALLY_SECURE_PROXY_SESSION)
		{
			currentProxyPort = UniRPCTokens.UNIRPC_DEFAULT_SSL_PROXY_PORT;
		}
		else
		{
			currentProxyPort = UniRPCTokens.UNIRPC_DEFAULT_PROXY_PORT;
		}
	}


	/**
	 * Constructs a UniRPCConnection object but uses all the connection
	 * information from the connection passed in. You still need to call the
	 * connect method because a connection is not established by default.
	 * Sets up all the default parameters for the connect method.
	 * An exception will be thrown if the connection is not a proxy connection.
	 *
   * @param		aConnection   A previously established connection.
   * @exception  UniRPCConnectionException if any errors occur when creating this
   *             connection.
	 * @see #UniRPCConnection()
	 * @since	UniRPC1.0
	 */
	public UniRPCConnection( UniRPCConnection aConnection ) throws UniRPCConnectionException
	{
		if ( (aConnection == null) || !aConnection.isConnected()  )
		{
			throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION );
		}
		else if ( !aConnection.isProxyConnection() )
		{
			throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_MULTIPLEX_SUPPORT );
		}
    else if (( aConnection.getSSLMode() == UniObjectsTokens.SECURE_SESSION )
            ||
            (aConnection.getSSLMode() == UniObjectsTokens.SECURE_PROXY_SESSION))
    {
    	throw  new  UniRPCConnectionException(UniRPCTokens.UNIRPC_NO_MULTIPLEX_SUPPORT);
    }
		/* the follow code SHOULD pass references because we want to reuse
		 * the objects from the previous connection. If the user overrides any of
		 * the settings, new objects will be allocated at that time.
		 */

		isActive = false;
		isConnected = false;
		isProxyConnection = true;
		isMultiplexed = true;
		aConnection.isMultiplexed = true;
		currentCompressionThreshold = aConnection.currentCompressionThreshold;
		currentHost = aConnection.currentHost;
		currentHostAddress = aConnection.currentHostAddress;
		currentPort = UniRPCTokens.UNIRPC_DEFAULT_PORT;
		currentProxyHost = aConnection.currentProxyHost;
		currentProxyAddress = aConnection.currentProxyAddress;		
		currentProxyPort = aConnection.currentProxyPort;
		currentProxyToken = aConnection.currentProxyToken;
		currentService = aConnection.currentService;
		currentTimeoutSeconds = aConnection.currentTimeoutSeconds;
		currentTransportType = aConnection.currentTransportType;
		currentEncryptionType = aConnection.currentEncryptionType;
		currentProxyConnectionID = UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID;
		socket = aConnection.socket.multiplex();
		dataIn = aConnection.dataIn;
		dataOut = aConnection.dataOut;
		debugLevel = aConnection.debugLevel;
		debugWriter = aConnection.debugWriter;
	}

	/**
	 * Accepts a connection request from another RPC library.
	 * If this method completes, the connection is alive and ready for use.
	 *
	 * @param		aSocket		active socket
   * @exception  UniRPCConnectionException if any errors occur when establishing this
   *               connection.
	 * @see #connect
	 * @since	UniRPC1.0
	 */
	public void acceptConnect( UniRPCSocket aSocket ) throws UniRPCConnectionException
	{
		try
		{

			// this line should be changed when we have a constructor that will take a socket
			// casting bypasses our UniRPCSocket reference counting features.
			socket = aSocket;
			socket.setSoTimeout( currentTimeoutSeconds * 1000 );
			socket.setSoLinger( true, currentTimeoutSeconds );
			socket.setTcpNoDelay( true );
			dataOut = new DataOutputStream(socket.getOutputStream());
			dataIn = new DataInputStream(socket.getInputStream());
			currentPort = aSocket.getPort();
			currentTransportType = UniRPCTokens.UNIRPC_TRANSPORT_TCPIP;
		}
		catch (SocketException e)
		{
			throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION);
		}
		catch (IOException e)
		{
			throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION);
		}

		isActive = true;
		isConnected = true;
		isProxyConnection = false;
		isMultiplexed = false;
		isClient = false;
		lastEncryptionType = UniRPCTokens.UNIRPC_ENCRYPTION_NONE;
	}

	/**
	 * Sends one UniRPCPacket to the server and waits for a packet in response.
	 * If the method does not recieve a full response within the current time-out
	 * period then it will throw an exception. This method is syncronized.
	 * If encryption is enabled then encryption will be used for this transmission.
	 *
	 * @param		anOutPacket		a data packet to be sent to the remote connection.
	 * @param		anInPacket		a data packet to receive from the remote connection.
   * @exception  UniRPCConnectionException if any errors occur when transmitting
   *             these packets.
	 * @see #writePacket
	 * @see #readPacket
	 * @since	UniRPC1.0
	 */
	public void call( UniRPCPacket anOutPacket, UniRPCPacket anInPacket ) throws UniRPCConnectionException
	{
		if (isEncryptionEnabled)
		{
			call( anOutPacket, anInPacket, currentEncryptionType, currentProxyConnectionID);
		}
		else
		{
			call( anOutPacket, anInPacket, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, currentProxyConnectionID);
		}
	}

	/**
	 * Sends one UniRPCPacket to the server and waits for a packet in response.
	 * If the method does not recieve a full response within the current time-out
	 * period then it will throw an exception. This method is syncronized.
	 * If encryption is enabled then encryption will be used for this transmission.
	 *
	 * @param		anOutPacket		a data packet to be sent to the remote connection.
	 * @param		anInPacket		a data packet to receive from the remote connection.
	 * @param		aConnectionID	the remote connection to talk with.
   * @exception  UniRPCConnectionException if any errors occur when transmitting
   *             these packets.
	 * @see #writePacket
	 * @see #readPacket
	 * @since	UniRPC1.0
	 */
	public void call( UniRPCPacket anOutPacket, UniRPCPacket anInPacket, byte anEncryptionType ) throws UniRPCConnectionException
	{
		call( anOutPacket, anInPacket, anEncryptionType, currentProxyConnectionID);
	}

	/**
	 * Sends one UniRPCPacket to the server and waits for a packet in response.
	 * If the method does not recieve a full response within the current time-out
	 * period then it will throw an exception. This method is syncronized.
	 * The specified encryption will be used, overriding any default encryption.
	 *
	 * @param		anOutPacket		a data packet to be sent to the remote connection.
	 * @param		anInPacket		a data packet to receive from the remote connection.
	 * @param		anEncryptionType		the type of encryption to encrypt these
	 *						data packets with.
   * @exception  UniRPCConnectionException if any errors occur when transmitting
   *             these packets.
	 * @see #writePacket
	 * @see #readPacket
	 * @since	UniRPC1.0
	 */
	public void call( UniRPCPacket anOutPacket, UniRPCPacket anInPacket, byte anEncryptionType, int aConnectionID ) throws UniRPCConnectionException
	{
		// make sure this is a valid packet
		if( !(this.equals(anOutPacket.getConnection())
			&& this.equals(anInPacket.getConnection())) )
		{
			throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_CONNECTION);
		}
		synchronized(socket)
		{
			writePacketInternal( anOutPacket, anEncryptionType, aConnectionID );
			readPacketInternal( anInPacket );
		}
	}

	/**
	 * Closes the current UniRPC socket connection with the server.
	 * This does not necessarly remove references to allocated objects.
	 *
   * @exception  UniRPCConnectionException if any errors occur when closing
   *             the connection.
	 * @see #connect
	 * @since	UniRPC1.0
	 */
	public void close() throws UniRPCConnectionException
	{
		// decrement socket reference count
		try
		{
			socket.close();
		}
		catch (IOException e)
		{
			throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_BAD_CONNECTION );
		}
		isConnected = false;
	}
  /**
   * Opens the secure connection to the specifiled host and service
   * @exception  UniRPCConnectionException if any errors occur when establishing this
   *               connection.
	 * @see #close
	 * @since	UniRPC1???
   */
  public void sconnect(UniSSLDescriptor ussld) throws UniRPCConnectionException
  {
    UniRPCPacket outPacket;
		UniRPCPacket inPacket;
        
    try
		{
      if ( !isProxyConnection )
      {
        socket = new UniRPCSocket( currentHostAddress, currentPort);
      }
      else
      {
        socket = new UniRPCSocket( currentProxyAddress, currentProxyPort);
      }
      // set the network wait timeout for this socket
      socket.setSoTimeout( currentTimeoutSeconds * 1000 );
      // keep socket open this number of seconds on close() if all data not delivered
      socket.setSoLinger( true, currentTimeoutSeconds );
      // send packets immediatly instead of buffering, buffering slows performance
      socket.setTcpNoDelay( true );
      dataOut = new DataOutputStream(socket.getOutputStream());
      dataIn = new DataInputStream(socket.getInputStream());

      isClient = true;
			outPacket = new UniRPCPacket();
			inPacket = new UniRPCPacket();
			// with a proxy connection we need to set the packets to be proxy packets
			if ( isProxyConnection )
			{
				outPacket.setProxyHeader( new UniRPCPProxyHeader() );
				inPacket.setProxyHeader( new UniRPCPProxyHeader() );
			}
    	outPacket.setDebugLevel( debugLevel );
			inPacket.setDebugLevel( debugLevel );
	  	outPacket.setDebugWriter( debugWriter );
	  	inPacket.setDebugWriter( debugWriter );

      // for a proxy connection we need to first login to the proxy server
      if ( isProxyConnection )
      {
        //enable encryption for proxy server communication
        setVersionCurrent(UniRPC.UNIRPC_VERSION);
        // outPacket.setVersion(UniRPC.UNIRPC_VERSION);
        // inPacket.setVersion(UniRPC.UNIRPC_VERSION);
        outPacket.write( 0, currentHost );
        outPacket.write( 1, currentPort );
        outPacket.write( 2, currentProxyToken );
        // request ssl session
        outPacket.write( 3, UniRPCTokens.UNIRPC_SECURE_SESSION);
        // we can't use call() here because call requires an active connection object.
        // we need to add encryption here so that our access token is encrypted.
        writePacketInternal(outPacket, UniRPCTokens.UNIRPC_ENCRYPTION_XOR, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
        readPacketInternal(inPacket);
        try
        {
          
          int response = inPacket.readInteger( 0 );  
          if (response != 0)
          {
            if ( response == UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN
                || response == UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_AUTH
								|| response == UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSIONS
								|| response == UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSION_CONNECTIONS )
            {
              throw new UniRPCConnectionException( "The proxy server login failed!", response );
            }
            else
            {
              throw new UniRPCConnectionException( "The proxy server login failed! The returned error code=" + response + ".", UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN );
            }
          }
        }
        catch (UniRPCPacketException e)
        {
          throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION );
        }
        //disable encryption for rest of login process
        setVersionCurrent(UniRPC.UNIRPC_VERSION_LOWEST);
        // because we need to redo version promotion when we connect to UniVerse
        // we have to reset version promotion flag
        versionPromotion = true;
      }

      // in case of proxy connection we don't need headers any more
      if (isProxyConnection())
      {
        inPacket.unsetProxyHeader();
        outPacket.unsetProxyHeader();
      }
      outPacket.write( 0, currentService );
      // reqiure a secure connection
      outPacket.write( 1, 1);
      // we can't use call() here because call requires an active connection object.
      writePacketInternal(outPacket, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, currentProxyConnectionID);
      readPacketInternal(inPacket);
      // check server response
      try
      {        
          int response;
          if (inPacket.getArgumentCount() == 2) {
              response = inPacket.readInteger(1);
          serverId = inPacket.readString(0);
          } else
              response = inPacket.readInteger(0);       
        if (response == 0)
        {
          isConnected = true;
          isActive = true;
        }
        else
        {
          throw new UniRPCConnectionException( "UniRPCConnection failed to establish a connection with the remote host. The returned error code=" + response + ".", UniRPCTokens.UNIRPC_NO_CONNECTION );
        }
      }
      catch (UniRPCPacketException e)
      {
        throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION );
      }

//      //disable encryption for rest of login process
//      setVersionCurrent(UniRPC.UNIRPC_VERSION_LOWEST);
//      // because we need to redo version promotion when we connect to UniVerse
//      // we have to reset version promotion flag
//      versionPromotion = true;

      // convert the existing connection into a secure connection
      // create a secure socket
      if ( !isProxyConnection )
      {
        socket.makeSecure(this.currentHost, this.currentPort, ussld);
      }
      else
      {
        socket.makeSecure(this.currentProxyHost, this.currentProxyPort, ussld);
      }
       // do we need to do it again???
      dataOut = new DataOutputStream(socket.getOutputStream());
      dataIn = new DataInputStream(socket.getInputStream());
    }
    catch (IOException e)
    {
			throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_BAD_CONNECTION );
    }
    catch (UniRPCPacketException e)
		{
			throw new UniRPCConnectionException(  UniRPCTokens.UNIRPC_NO_CONNECTION );
		}

  }


  /**
   * Opens the secure connection to proxy server
   * @exception  UniRPCConnectionException if any errors occur when establishing this
   *               connection.
	 * @see #close
	 * @since	UniRPC1???
   */
	public void espconnect(UniSSLDescriptor ussld, boolean intsslflag)
	throws UniRPCConnectionException
  {
  	UniRPCPacket outPacket;
		UniRPCPacket inPacket;
		// connect to RPC server and spawn service we want to communicate with.
		try
		{
			// if not multiplexed, then create new socket and streams
			if ( !isMultiplexed)
			{
				if ( !isProxyConnection )
				{
					throw new UniRPCConnectionException(UniRPCTokens.UNIRPC_NOT_PROXY_CONNECTION);
				}
				else
				{
          // create secure socket and do the handshake
					socket = new UniRPCSocket( currentProxyAddress, currentProxyPort, ussld, true);
				}
				// set the network wait timeout for this socket
				socket.setSoTimeout( currentTimeoutSeconds * 1000 );
				// keep socket open this number of seconds on close() if all data not delivered
				socket.setSoLinger( true, currentTimeoutSeconds );
				// send packets immediatly instead of buffering, buffering slows performance
				socket.setTcpNoDelay( true );
				dataOut = new DataOutputStream(socket.getOutputStream());
				dataIn = new DataInputStream(socket.getInputStream());
			}
			isClient = true;
			outPacket = new UniRPCPacket();
			inPacket = new UniRPCPacket();

			// with a proxy connection we need to set the packets to be proxy packets
      outPacket.setProxyHeader( new UniRPCPProxyHeader() );
      inPacket.setProxyHeader( new UniRPCPProxyHeader() );

			outPacket.setDebugLevel( debugLevel );
			inPacket.setDebugLevel( debugLevel );
			outPacket.setDebugWriter( debugWriter );
			inPacket.setDebugWriter( debugWriter );

			// the entire login process must be synchronized for multiplexed connections
			synchronized(socket)
			{
				// for a proxy connection we need to first login to the proxy server
       	//enable encryption for proxy server communication
       	setVersionCurrent(UniRPC.UNIRPC_VERSION);
       	// outPacket.setVersion(UniRPC.UNIRPC_VERSION);
       	// inPacket.setVersion(UniRPC.UNIRPC_VERSION);
       	outPacket.write( 0, currentHost );
       	outPacket.write( 1, currentPort );
       	outPacket.write( 2, currentProxyToken );
       	if (intsslflag == false)
        {
        	outPacket.write( 3, UniRPCTokens.UNIRPC_NONSECURE_SESSION);
        }
        else
        {
        	outPacket.write( 3, UniRPCTokens.UNIRPC_SECURE_SESSION);
        }
        // we can't use call() here because call requires an active connection object.
        // we need to add encryption here so that our access token is encrypted.
        writePacketInternal(outPacket, UniRPCTokens.UNIRPC_ENCRYPTION_XOR, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
        readPacketInternal(inPacket);
        try
        {
        	int response = inPacket.readInteger(0);
         	if (response == 0)
         	{
         		isConnected = true;
         		isActive = true;
         		int connectionID = inPacket.readInteger(1);
            currentProxyConnectionID = connectionID;
          }
          else
          {
          	if ( response == UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN
              || response==UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_AUTH
							|| response==UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSIONS
							|| response==UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSION_CONNECTIONS
					   )
            {
            	throw new UniRPCConnectionException( "The proxy server login failed!", response );
            }
           	else
           	{
           		throw new UniRPCConnectionException( "The proxy server login failed! The returned error code=" + response + ".", UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN );
           	}
          }
        }
       	catch (UniRPCPacketException e)
        {
        	throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION );
				}
        //disable encryption for rest of login process
        setVersionCurrent(UniRPC.UNIRPC_VERSION_LOWEST);
        // because we need to redo version promotion when we connect to UniVerse
        // we have to reset version promotion flag
        versionPromotion = true;

				outPacket.write( 0, currentService );
				// we can't use call() here because call requires an active connection object.
				writePacketInternal(outPacket, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, currentProxyConnectionID);
				readPacketInternal(inPacket);
			}
			// check server response
			try
			{
				// E32898 09/14/05
  			    	int response;
		            	if (inPacket.getArgumentCount() == 2)
		            	    response = inPacket.readInteger(1);
         		    	else
                		    response = inPacket.readInteger(0);     

				if (response == 0)
				{
					isConnected = true;
					isActive = true;
				}
				else
				{
					throw new UniRPCConnectionException( "UniRPCConnection failed to establish a connection with the remote host. The returned error code=" + response + ".", UniRPCTokens.UNIRPC_NO_CONNECTION );
				}
			}
			catch (UniRPCPacketException e)
			{
				throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION );
			}
		}
		catch (IOException e)
		{
			throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION);
		}
		catch (UniRPCPacketException e)
		{
			throw new UniRPCConnectionException(  UniRPCTokens.UNIRPC_NO_CONNECTION );
		}
	}

	/**
	 * Opens a connection to the specified host and service.
	 * Uses the current port value and current time-out value for
	 * the connection.
	 *
   * @exception  UniRPCConnectionException if any errors occur when establishing this
   *               connection.
	 * @see #close
	 * @since	UniRPC1.0
	 */

	public void connectInternal(int responseIndex) throws UniRPCConnectionException
	{
		UniRPCPacket outPacket;
		UniRPCPacket inPacket;
		// connect to RPC server and spawn service we want to communicate with.
		try
		{
			// if not multiplexed, then create new socket and streams
			if ( !isMultiplexed)
			{
				if ( !isProxyConnection )
				{
			  	socket = new UniRPCSocket( currentHostAddress, currentPort);
				}
				else
				{
					socket = new UniRPCSocket( currentProxyAddress, currentProxyPort);
				}
				// set the network wait timeout for this socket
				socket.setSoTimeout( currentTimeoutSeconds * 1000 );
				// keep socket open this number of seconds on close() if all data not delivered
				socket.setSoLinger( true, currentTimeoutSeconds );
				// send packets immediatly instead of buffering, buffering slows performance
				socket.setTcpNoDelay( true );
				dataOut = new DataOutputStream(socket.getOutputStream());
				dataIn = new DataInputStream(socket.getInputStream());
			}
			isClient = true;
			outPacket = new UniRPCPacket();
			inPacket = new UniRPCPacket();
			// with a proxy connection we need to set the packets to be proxy packets
			if ( isProxyConnection )
			{
				outPacket.setProxyHeader( new UniRPCPProxyHeader() );
				inPacket.setProxyHeader( new UniRPCPProxyHeader() );
			}
			outPacket.setDebugLevel( debugLevel );
			inPacket.setDebugLevel( debugLevel );
			outPacket.setDebugWriter( debugWriter );
			inPacket.setDebugWriter( debugWriter );

			// the entire login process must be synchronized for multiplexed connections
			synchronized(socket)
			{
				// for a proxy connection we need to first login to the proxy server
				if ( isProxyConnection )
				{
					//enable encryption for proxy server communication
					setVersionCurrent(UniRPC.UNIRPC_VERSION);
					// outPacket.setVersion(UniRPC.UNIRPC_VERSION);
					// inPacket.setVersion(UniRPC.UNIRPC_VERSION);
					outPacket.write( 0, currentHost );
					outPacket.write( 1, currentPort );
					outPacket.write( 2, currentProxyToken );
          // request non-secure session
          outPacket.write( 3, UniRPCTokens.UNIRPC_NONSECURE_SESSION);
					// we can't use call() here because call requires an active connection object.
					// we need to add encryption here so that our access token is encrypted.
					writePacketInternal(outPacket, UniRPCTokens.UNIRPC_ENCRYPTION_XOR, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
					readPacketInternal(inPacket);
					try
					{
						
						int response = inPacket.readInteger( 0 );
						if (response == 0)
						{
							isConnected = true;
							isActive = true;
							int connectionID = inPacket.readInteger(1);
							currentProxyConnectionID = connectionID;
						}
						else
						{
							if ( response == UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN
								|| response == UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_AUTH
								|| response == UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSIONS
								|| response == UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSION_CONNECTIONS )
							{
								throw new UniRPCConnectionException( "The proxy server login failed!", response );
							}
							else
							{
								throw new UniRPCConnectionException( "The proxy server login failed! The returned error code=" + response + ".", UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN );
							}
						}
					}
					catch (UniRPCPacketException e)
					{
							throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION );
					}
					//disable encryption for rest of login process
					setVersionCurrent(UniRPC.UNIRPC_VERSION_LOWEST);
					// because we need to redo version promotion when we connect to UniVerse
					// we have to reset version promotion flag
					versionPromotion = true;
				}

				outPacket.write( 0, currentService );
				// we can't use call() here because call requires an active connection object.
				writePacketInternal(outPacket, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, currentProxyConnectionID);
				readPacketInternal(inPacket);
			}
			// check server response
			try
			{
				// J.Mao, for JDBC, UCI server returns two
				// arguments which api server only one
				int response;

				if (inPacket.getArgumentCount() == 2) {
					response = inPacket.readInteger(1);
					serverId = inPacket.readString(0);
				} else
					response = inPacket.readInteger( responseIndex );

				if (response == 0)
				{
					isConnected = true;
					isActive = true;
				}
				else
				{
					throw new UniRPCConnectionException( "UniRPCConnection failed to establish a connection with the remote host. The returned error code=" + response + ".", UniRPCTokens.UNIRPC_NO_CONNECTION );
				}
			}
			catch (UniRPCPacketException e)
			{
					throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION );
			}
		}
		catch (IOException e)
		{
			throw new UniRPCConnectionException( UniRPCTokens.UNIRPC_NO_CONNECTION);
		}
		catch (UniRPCPacketException e)
		{
			throw new UniRPCConnectionException(  UniRPCTokens.UNIRPC_NO_CONNECTION );
		}
	} /* connect() */

	public void connect() throws UniRPCConnectionException
	{
		connectInternal(0);
	}
	public void connect(int responseIndex) throws UniRPCConnectionException
	{
		connectInternal(responseIndex);
	}
	

	/**
	 * Turns off encryption for this connection so that all new packet
	 * transmissions will NOT be encrypted until <code>enableEncryption()</code>
	 * is called.

	 * @see #enableEncryption()
	 * @since	UniRPC1.0
	 */
	public void disableEncryption()
	{
		isEncryptionEnabled = false;
	}

	/**
	* Find out Socket is Alive or not
	*/
	public boolean  isServerAlive() 
	{
        
        /* important: because we have changed to using non-blocking read to check
         * whether server is still alive, we don't need to check the server versions
         * anymore, but have decided to keep the serverId content as it is for 
         * possible future backwards compatiblities issues
         */
        /* check if the server is capable of handling out-of-band data
         * before calling socket.isServerAlive(). if the server is not,
         * always return true
         * 
         *  serverId right now can have 5 possible values
         *  1) uvsrv  ---- universe uci server
         *      always have
         *  2) udsrv  ---- unidata uci server
         *  3) udapi:UD_RELEASE  --- unidata api server + ud release number
         *      always
         *     starting in UD71
         *  4) uvapi:UVRELEASE --- univserse api server + uv release number
         *      starting in UV101B
         *  5) "" -- for api servers, ud earlier than 71, uv earlier than 10.1.15
         *  
         *  UD_RELEASE is defined in udtversion.h,it contains major, minor, patch
         *  for example "7.1.1"
         *  UVRELEASE is defined in UVERSION.h, it contains similar versioning numbers
         *  for example, "10.1.14"
         */
		return this.socket.isServerAlive();
	}

	/**
	 * Turns on encryption for this connection so that all new packet
	 * transmissions will be encrypted until <code>disableEncryption()</code>
	 * is called.
	 *
   * @exception  UniRPCConnectionException if encryption is not supported
	 * @see #disableEncryption()
	 * @since	UniRPC1.0
	 */
	public void enableEncryption() throws UniRPCConnectionException
	{
		if ( isEncryptionSupported() )
		{
			isEncryptionEnabled = true;
		}
		else
		{
			throw new UniRPCConnectionException(  UniRPCTokens.UNIRPC_NO_ENCRYPTION_SUPPORT );
		}
	}

	/**
	 * Returns the threshold in bytes, beyond which all packets will be
	 * compressed. This feature not supported in UniRPC 1.0.
	 *
	 * @return	the compression threshold
	 * @see #setCompressionThreshold
	 * @since	UniRPC1.0
	 */
	public int getCompressionThreshold()
	{
		return currentCompressionThreshold;
	}

	/**
	 * Returns the type of encryption used to encrypt outgoing packets.
	 *
	 * @return	the encryption type
	 * @see #setEncryptionType
	 * @since	UniRPC1.0
	 */
	public byte getEncryptionType()
	{
		return currentEncryptionType;
	}

	/**
	 * Returns the current host for this connection.
	 * This is the current UniVerse server we are connected to.
	 *
	 * @return	the remote system
	 * @see #setHost
	 * @since	UniRPC1.0
	 */
	public String getHost()
	{
		// we want to always return the english description even
		// if we were passed an IP address
		return currentHostAddress.getHostName();
		// return currentHost;
	}

	/**
	 * Returns the <code>InetAddress</code> of the current host for this connection.
	 * This is the current UniVerse server we are connected to.
	 *
	 * @return	the remote host address
	 * @since	UniRPC1.0
	 */
	public InetAddress getHostAddress()
	{
		return currentHostAddress;
	}

	/**
	 * Gets the current port for this connection.
	 * This is the host port that we are currently connected to the server on.
	 *
	 * @return	port on the remote host
	 * @see #setPort
	 * @since	UniRPC1.0
	 */
	public int getPort()
	{
		return currentPort;
	}

	/**
	 * Gets the current proxy server for this connection.
	 * This is the proxy server that we are currently connected to provided
	 * that both the proxy server and proxy port are set.
	 * Used for the client side of the connection only.
	 *
	 * @return	the proxy server
	 * @see #setProxyHost
	 * @since	UniRPC1.0
	 */
	public String getProxyHost()
	{
		// we want to always return the english description even
		// if we were passed an IP address
		return currentProxyAddress.getHostName();
	}

	/**
	 * Returns the <code>InetAddress</code> of the current proxy server for this connection.
	 * This is the current proxy server we are connected to.
	 * Used for the client side of the connection only.
	 *
	 * @return	the proxy server address
	 * @since	UniRPC1.0
	 */
	public InetAddress getProxyAddress()
	{
		return currentProxyAddress;
	}

	/**
	 * Gets the current connection ID for this proxy connection.
	 * This is the connection ID that assures all packets are routed to the 
	 * correct server on their way through the proxy server.
	 *
	 * @return	proxy connection ID
	 * @see #setProxyConnectionID
	 * @since	UniRPC1.0
	 */
	public int getProxyConnectionID()
	{
		return currentProxyConnectionID;
	}

	/**
	 * Gets the current port for this proxy connection.
	 * This is the port that we connected to the proxy server on.
	 * Used for the client side of the connection only.
	 *
	 * @return	port of the proxy server
	 * @see #setProxyPort
	 * @since	UniRPC1.0
	 */
	public int getProxyPort()
	{
		return currentProxyPort;
	}

	/**
	 * Gets the current access token for this proxy connection.
	 * This proxy token is used to gain access to the proxy server.
	 * Used for the client side of a connection only.
	 *
	 * @return	proxy access token
	 * @see #setProxyToken
	 * @since	UniRPC1.0
	 */
	public String getProxyToken()
	{
		return currentProxyToken;
	}
	
	/**
	 * Returns the current service for this connection.
	 * This is the current UniVerse service we are connected to.
	 * Used for the client side of the connection only.
	 *
	 * @return	UniVerse service we are connecting too.
	 * @see #setService
	 * @since	UniRPC1.0
	 */
	public String getService()
	{
		return new String(currentService);
	}

	/**
	 * Gets the current second time-out value for this connection.
	 * This determines how long we will wait for a responce to a request
	 * from the remote connection.
	 *
	 * @return	number of seconds.
	 * @see #setTimeoutSeconds
	 * @since	UniRPC1.0
	 */
	public int getTimeoutSeconds()
	{
		return currentTimeoutSeconds;
	}

	/**
	 * Gets the current network Transport for this connection.
	 * This determines what network protocol will be used for communications
	 * with the remote connection.
	 *
	 * @return	a transport type
	 * @see #setTransportType
	 * @since	UniRPC1.0
	 */
	public int getTransportType()
	{
		return currentTransportType;
	}
	
	/**
	 * Returns TRUE if connection is alive.
	 * Returns FALSE if the connection has been droped for some reason or a 
	 * connection was never established.
	 * The value returned is independent of what is returned by
	 * <code>isConnected()</code>.
	 *
	 * @return	<code>true</code> if the connection is active or <code>false</code>
	 *					if not active.
	 * @see #isConnected
	 * @since	UniRPC1.0
	 */
	public boolean isActive()
	{
		return isActive;
	}
		
	/**
	 * Returns TRUE if connection has been established.
	 * Returns FALSE if the connection has not been established.
	 * The value returned is independent of what is returned by
	 * <code>isAlive()</code>.
	 *
	 * @return	<code>true</code> if the connection is connected or <code>false</code>
	 *					if not connected.
	 * @see #isActive
	 * @since	UniRPC1.0
	 */
	public boolean isConnected()
	{
		return isConnected;
	}

	/**
	 * Returns TRUE if the proxy connection has been established.
	 * Returns FALSE if the established connection is not a proxy connection
	 * or has not been established yet.
	 *
	 * @return	<code>true</code> with a proxy connection connected or <code>false</code>
	 *					if not connected or not proxy connection.
	 * @since	UniRPC1.0
	 */
	public boolean isProxyConnection()
	{
		return isProxyConnection;
	}

  public int getSSLMode()
  {
    return sslMode;
  }

	/**
	 * Returns a <code>UniRPCPacket</code> that is constructed using this connection
	 *
   * @exception  UniRPCConnectionException if any errors occur when creating the
   *             new packet
	 * @return	a new packet object
	 * @see asjava.unirpc.UniRPCPacket
	 * @since	UniRPC1.0
	 */
	public UniRPCPacket packet() throws UniRPCConnectionException
	{
		try
		{
			return new UniRPCPacket(this);
		}
		catch( UniRPCPacketException e)
		{
			throw new UniRPCConnectionException( e.getErrorCode() );
		}
	}

	/**
	 * Read one <code>UniRPCPacket</code> from the remote UniRPC connection.
	 * The <code>readPacket</code> method can't be called directly when using a
	 * multiplexed connection. The reason is that there is no support for
	 * routing of incomming packets to the correct connection.
	 *
	 * @param		anInPacket		a data packet to receive from the remote connection.
   * @exception  UniRPCConnectionException if any errors occur when receiving
   *             a packet from the remote connection
	 * @see #writePacket
	 * @since	UniRPC1.0
	 */
	public void readPacket( UniRPCPacket anInPacket ) throws UniRPCConnectionException
	{
		// we don't support the readPacket() method on multiplexed connections
		if ( isMultiplexed )
		{
			throw new UniRPCConnectionException( "You can't use readPacket() on a multiplexed connection.",
				UniRPCTokens.UNIRPC_NO_MULTIPLEX_SUPPORT );
		}
		// make sure this is a valid packet
		if( !this.equals(anInPacket.getConnection()) )
		{
			throw new UniRPCConnectionException( "This packet was created with a different connection.",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		synchronized(socket)
		{
			readPacketInternal(anInPacket);
		}
	}

	/**
	 * Read one <code>UniRPCPacket</code> from the remote UniRPC connection.
	 * This is a special method that is only used in the case where we are reading
	 * a packet from the server when we didn't first send a packet to the server.
	 * If this method is called on a non proxy connection, then its functionality
	 * defaults to that of the standard <code>readPacket()</code> method.
	 * What this method does is send a standalone special proxy header that
	 * tells the proxy server to read a packet from the server for this client even
	 * though no data packet has been sent to the server.
	 *
	 * @param		anInPacket		a data packet to receive from the remote connection.
   * @exception  UniRPCConnectionException if any errors occur when receiving
   *             a packet from the remote connection
	 * @see #writePacket
	 * @see #readPacket
	 * @since	UniRPC1.0
	 */
	public void readPacketSpoofProxy( UniRPCPacket anInPacket ) throws UniRPCConnectionException
	{
		// make sure this is a valid packet
		if( !this.equals(anInPacket.getConnection()) )
		{
			throw new UniRPCConnectionException( "This packets was created with a different connection.",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		// The readPacket() method was not designed to be used with proxy or multiplexed connections.
		// This method is a bit of a hack to get around the issues with readPacket().
		// We need this method because the api server/slave uses a write
		// packet when it shouldn't and we need to support the current api server.
		if ( isProxyConnection && sslMode !=  UniObjectsTokens.SECURE_SESSION && sslMode != UniObjectsTokens.SECURE_PROXY_SESSION)
		{
			// build proxy header and send it
			UniRPCPProxyHeader proxyHeader = new UniRPCPProxyHeader();
			proxyHeader.writeHeaderType(UniRPCTokens.UNIRPC_PROXY_HEADER_TYPE_SPOOF);
			proxyHeader.writeConnection(currentProxyConnectionID);
			proxyHeader.setLength(0);
			try
			{
				synchronized(socket)
				{
					proxyHeader.send(dataOut);
					readPacketInternal(anInPacket);
				}
			}
			catch ( UniRPCPacketException e )
			{
				throw new UniRPCConnectionException( e.getMessage(),
					UniRPCTokens.UNIRPC_CONNECTION);
			}
		}
		else // default case
		{
			synchronized(socket)
			{
				readPacketInternal(anInPacket);
			}
		}
	}

	/**
	 * Sets the threshold in bytes, beyond which all packets will be
	 * compressed. This change will only take effect on newly constructed
	 * packets. All existing packets need to be individualy updated.
	 * This feature not supported in UniRPC 1.0.
	 *
	 * @param		aThreshold		compression threshold.
	 * @see #getCompressionThreshold
	 * @since	UniRPC1.0
	 */
	public void setCompressionThreshold( int aThreshold )
	{
		currentCompressionThreshold = aThreshold;
	}
	
	/**
	 * Returns the type of encryption used to encrypt outgoing packets.
	 *
	 * @param		aType		a type of supported encryption
   * @exception  UniRPCConnectionException if an unsupported encryption type
   * 							is used.
	 * @see #getEncryptionType()
	 * @since	UniRPC1.0
	 */
	public void setEncryptionType( byte aType ) throws UniRPCConnectionException
	{
		if ( (aType == UniRPCTokens.UNIRPC_ENCRYPTION_NONE) ||
		     (aType == UniRPCTokens.UNIRPC_ENCRYPTION_XOR) )
		{
			currentEncryptionType = aType;
		}
		else
		{
			throw new UniRPCConnectionException( "This type of encryption is not supported on this connection",
				UniRPCTokens.UNIRPC_NO_ENCRYPTION_SUPPORT);
		}
	}
	
	/**
	 * Sets the current host for this connection.
	 * This is the UniVerse server we want to connect with.
	 * Throw exception if the connection is active.
	 * Used for the client side of the connection only.
	 *
	 * @param		aHost		remote system name
   * @exception  UniRPCConnectionException if any errors occur when building
   *             a network address for the remote system
	 * @see #getHost
	 * @since	UniRPC1.0
	 */
	public void setHost( String aHost ) throws UniRPCConnectionException
	{
		if ( isConnected() )
		{
			throw new UniRPCConnectionException( "This method can't be used on a connected connection",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		currentHost = new String(aHost);
		// J.Mao if proxy is on, don't do this
		if (!isProxyConnection) {
			try
			{
				currentHostAddress = InetAddress.getByName( currentHost );
			}
			catch( UnknownHostException e )
			{
				throw new UniRPCConnectionException( e.getMessage(), UniRPCTokens.UNIRPC_UNKNOWN_HOST);
			}
		}
	}

	/**
	 * Sets the current port for this connection.
	 * This is the host port that we want to connect to the next time we build
	 * a connection.
	 * Used for the client side of the connection only.
	 *
	 * @param		aPort		remote system port
   * @exception  UniRPCConnectionException if this method is called on a
   *             connected connection.
	 * @see #getPort
	 * @since	UniRPC1.0
	 */
	public void setPort( int aPort ) throws UniRPCConnectionException
	{
		if ( isConnected() )
		{
			throw new UniRPCConnectionException( "This method can't be used on a connected connection",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		currentPort = aPort;
	}

	/**
	 * Sets the current connection ID for this proxy connection.
	 * This is the connection ID that assures all packets are routed to the 
	 * correct server on their way through the proxy server.
	 *
	 * @param		aConnectionID		proxy connection ID
   * @exception  UniRPCConnectionException if this method is called on a
   *             non proxy connection
	 * @see #getProxyConnectionID
	 * @since	UniRPC1.0
	 */
	public void setProxyConnectionID( int aConnectionID) throws UniRPCConnectionException
	{
		if ( !isProxyConnection() )
		{
			throw new UniRPCConnectionException( "This method has no effect when used with a non proxy connection.",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		currentProxyConnectionID = aConnectionID;
	}

	/**
	 * Sets the current proxy server for this connection.
	 * This is the proxy server that we will use for a connection provided
	 * that both the proxy server and proxy port are set.
	 * If eather the proxy server or port are not set then a normal connection
	 * is made. If both are set, then a proxy connection is made on a connect.
	 * Used for the client side of the connection only.
	 *
	 * @param		aProxyServer		remote proxy server
   * @exception  UniRPCConnectionException if this method is called on a
   *             connected connection or there is an error building the address.
	 * @see #getProxyHost
	 * @since	UniRPC1.0
	 */
	public void setProxyHost( String aProxyServer) throws UniRPCConnectionException
	{
		if ( isConnected() )
		{
			throw new UniRPCConnectionException( "This method can't be used on a connected connection",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		currentProxyHost = aProxyServer;
		try
		{
			currentProxyAddress = InetAddress.getByName( currentProxyHost );
		}
		catch( UnknownHostException e )
		{
			isProxyConnection = false;
			throw new UniRPCConnectionException( e.getMessage(), UniRPCTokens.UNIRPC_UNKNOWN_HOST);
		}
		if ( currentProxyPort > -1 )
		{
			isProxyConnection = true;
		}
	}

	/**
	 * Sets the current port for this proxy connection.
	 * This is the proxy port that we will connect to the proxy server on
	 * provided that both the proxy server and proxy port are set.
	 * If eather the proxy server or port are not set than a normal connection
	 * is made. If both are set, then a proxy connection is made on a connect.
	 * Used for the client side of the connection only.
	 *
	 * @param		aProxyPort		remote proxy server port
   * @exception  UniRPCConnectionException if this method is called on a
   *             connected connection
	 * @see #getProxyPort
	 * @since	UniRPC1.0
	 */
	public void setProxyPort( int aProxyPort) throws UniRPCConnectionException
	{
		if ( isConnected() )
		{
			throw new UniRPCConnectionException( "This method can't be used on a connected connection",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		currentProxyPort = aProxyPort;
		
		if ( (currentProxyHost != "") && (aProxyPort > -1))
		{
			isProxyConnection = true;
		}
	}
	
	/**
	 * Sets the current access token for this proxy connection.
	 * This proxy token must match a proxy token that is specified in the
	 * proxy server configuration file. In addition, if hosts are paired with
	 * this token in the config file, then the host set with setProxyHost() must 
	 * match one of them.
	 *
	 * @param		aProxyToken		security authentication token
   * @exception  UniRPCConnectionException if this method is called on a
   *             connected connection
	 * @see #getProxyToken
	 * @since	UniRPC1.0
	 */
	public void setProxyToken( String aProxyToken) throws UniRPCConnectionException
	{
		if ( isConnected() )
		{
			throw new UniRPCConnectionException( "This method can't be used on a connected connection",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		currentProxyToken = aProxyToken;		
	}

	/**
	 * Sets the current service for this connection.
	 * This is the UniVerse service we want to connect to the next time we build
	 * a connection.
	 * Used for the client side of the connection only.
	 *
	 * @param		aService		UniVerse service
   * @exception  UniRPCConnectionException if this method is called on a
   *             connected connection
	 * @see #getService
	 * @since	UniRPC1.0
	 */
	public void setService( String aService ) throws UniRPCConnectionException
	{
		if ( isConnected() )
		{
			throw new UniRPCConnectionException( "This method can't be used on a connected connection",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		currentService = aService.toCharArray();
	}

	/**
	 * Sets the current second time-out value for this connection.
	 * This determines how long we will wait for a response to a request
	 * from the server.
	 *
	 * @param		aTimeout		network timeout for the connection
   * @exception  UniRPCConnectionException if setting the timeout fails
	 * @see #getTimeoutSeconds
	 * @since	UniRPC1.0
	 */
    public void setTimeoutSeconds(int aTimeout) throws UniRPCConnectionException
    {
        currentTimeoutSeconds = aTimeout;
        try
        {
            if ( socket != null )
                socket.setSoTimeout( currentTimeoutSeconds * 1000 );
        }
        catch (SocketException e)
        {          
            throw new UniRPCConnectionException( e.getMessage(), UniRPCTokens.UNIRPC_FAILED);
        }
    }

	/**
	 * Sets the current network Transport for this connection.
	 * This determines what network protocol we will use for communications
	 * with the server.
	 *
	 * @param		aTransportType		type of network transport
   * @exception  UniRPCConnectionException if this method is called on a
   *             connected connection
	 * @see #getTransportType
	 * @since	UniRPC1.0
	 */
	public void setTransportType(int aTransportType) throws UniRPCConnectionException
	{

		if ( isConnected() )
		{
			throw new UniRPCConnectionException( "This method can't be used on a connected connection",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		currentTransportType = aTransportType;
	}

	/**
	 * Writes one UniRPCPacket to the remote UniRPC connection.
	 * The <code>writePacket</code> method can't be called directly when using a
	 * multiplexed connection. The reason is that we can't support
	 * <code>readPacket</code> for this case and want this method to function as
	 * <code>readPacket</code> does.
	 *
	 * @param		anOutPacket		outgoing packet
   * @exception  UniRPCConnectionException if this method is called on a
   *             multiplexed connection
	 * @see #readPacket
	 * @since	UniRPC1.0
	 */
	public void writePacket( UniRPCPacket anOutPacket ) throws UniRPCConnectionException
	{
		if ( isClient )
		{
			writePacket(anOutPacket, currentEncryptionType);
		}
		else
		{
			// if we are a server then we must be replying to a request.
			writePacket(anOutPacket, lastEncryptionType);
		}
	}

	/**
	 * Writes one UniRPCPacket to the remote UniRPC connection.
	 * The <code>writePacket</code> method can't be called directly when using a
	 * multiplexed connection. The reason is that we can't support 
	 * <code>readPacket</code> for this case and want this method to function as
	 * <code>readPacket</code> does.
	 *
	 * @param		anOutPacket		outgoing packet
	 * @param		anEncryption		type of encryption to use
   * @exception  UniRPCConnectionException if this method is called on a
   *             multiplexed connection
	 * @see #readPacket
	 * @since	UniRPC1.0
	 */
	public void writePacket( UniRPCPacket anOutPacket, byte anEncryptionType ) throws UniRPCConnectionException
	{
		// can't use this method if this connection multiplexed.
		if ( isMultiplexed )
		{
			throw new UniRPCConnectionException( "You can't use writePacket() on a multiplexed connection.",
				UniRPCTokens.UNIRPC_NO_MULTIPLEX_SUPPORT );
		}
		// make sure this is a valid packet
		if( !this.equals(anOutPacket.getConnection()) )
		{
			throw new UniRPCConnectionException( "This packets was created with a different connection.",
				UniRPCTokens.UNIRPC_CONNECTION);
		}
		
		synchronized(socket)
		{
			writePacketInternal(anOutPacket, anEncryptionType, currentProxyConnectionID);
		}
	}

	// private methods

	/**
	 * Read one <code>UniRPCPacket</code> from the remote UniRPC connection.
	 * This private <code>readPacket</code> method exists so that we easily
	 * stop the user from using readPacket on a multiplexed connection.
	 *
	 * @since	UniRPC1.0
	 */
	private void readPacketInternal( UniRPCPacket anInPacket ) throws UniRPCConnectionException
	{
		try
		{
			anInPacket.receive( dataIn );
			if ( !isClient )
			{
				// we are a server so get type of encryption to use for return packet
				lastEncryptionType = anInPacket.getEncryptionType();
			}
			// we query version support information here and set
			// our internal version so that from now on all packets
			// talk to the remote library in this version.
			// This works for the client side.
			// This works for the server side. The server will have to throw away
			// the first packet used by the server.
			// JFM, for Ecase 10544, if (versionPromotion && sslMode != UniObjectsTokens.SECURE_SESSION && sslMode != UniObjectsTokens.SECURE_PROXY_SESSION)
            if (versionPromotion)
			{
				// get version of the packet we received.
				int tmpVersion = anInPacket.getMessage().readHeaderVersion();
				// get highest version of the packet we received.
				int tmpHighVersion = anInPacket.getMessage().readHeaderVersionHighest();
				// set RPC version to use for the life of this UniRPCConnection object
				if ( UNIRPC_VERSION <= tmpHighVersion )
				{	// talking with a current or newer transport layer
					if ( UNIRPC_VERSION >= tmpVersion )
					{
						currentVersion = UNIRPC_VERSION;
					}
					else
					{
						throw new UniRPCConnectionException( "Incompatible RPC transport layers",
							UniRPCTokens.UNIRPC_WRONG_VERSION);
					}
				}
				else
				{	// talking with an old transport layer
					if ( UNIRPC_VERSION_LOWEST <= tmpHighVersion )
					{
						currentVersion = tmpHighVersion;
					}
					else
					{
						// this is a hack to support the version 1 RPC layer.
						// logicly we should throw an exception here.
						currentVersion = UNIRPC_VERSION_LOWEST;
					}
				}
				if ( isProxyConnection && sslMode != UniObjectsTokens.SECURE_SESSION && sslMode != UniObjectsTokens.SECURE_PROXY_SESSION)
				{
					// get version of the proxy header we received.
					tmpVersion = anInPacket.getProxyHeader().readHeaderVersion();
					// get highest version of the proxy header we received.
					tmpHighVersion = anInPacket.getProxyHeader().readHeaderVersionHighest();
					if ( UNIRPC_VERSION <= tmpHighVersion )
					{	// talking with a current or newer transport layer
						if ( UNIRPC_VERSION >= tmpVersion )
						{
							currentVersionProxy = UNIRPC_VERSION;
						}
						else
						{
							throw new UniRPCConnectionException( "Incompatible RPC transport layers",
								UniRPCTokens.UNIRPC_WRONG_VERSION);
						}
					}
					else
					{	// talking with an old transport layer
						if ( UNIRPC_VERSION_LOWEST <= tmpHighVersion )
						{
							currentVersionProxy = tmpHighVersion;
						}
						else
						{
							throw new UniRPCConnectionException( "Incompatible RPC transport layers",
								UniRPCTokens.UNIRPC_WRONG_VERSION);
						}
					}
				}
				// turn off version promotion because it is a one time operation
				versionPromotion = false;
			}
		}
		catch ( UniRPCPacketException e)
		{
			throw new UniRPCConnectionException( e.getMessage(), e.getErrorCode());
		}
	}

	/**
	 * Writes one <code>UniRPCPacket</code> to the remote UniRPC connection.
	 * This private <code>writePacketInternal</code> method exists so that we
	 * can easily stop the user from using writePacket on a multiplexed
	 * connection.
	 *
	 * @since	UniRPC1.0
	 */
	private void writePacketInternal( UniRPCPacket anOutPacket, byte anEncryptionType, int aConnectionID ) throws UniRPCConnectionException
	{
		if ( (anEncryptionType != UniRPCTokens.UNIRPC_ENCRYPTION_NONE) &&
			(!isEncryptionSupported() || (anEncryptionType != UniRPCTokens.UNIRPC_ENCRYPTION_XOR)) )
		{
			throw new UniRPCConnectionException( "Encryption or this type of encryption is not supported on this connection.",
				UniRPCTokens.UNIRPC_NO_ENCRYPTION_SUPPORT);
		}

		try
		{
			anOutPacket.send( dataOut, anEncryptionType, aConnectionID );
		}
		catch ( UniRPCPacketException e)
		{
			throw new UniRPCConnectionException( e.getMessage(), e.getErrorCode());
		}
	}

	/**
	 * @return Returns the serverId.
	 */
	public String getServerId() 
	{
		return serverId;
	}

	// private properties.

	// Default UniRPCConnection time-out. Currently defined as <code>300</code>seconds.
	private final static int UNIRPC_DEFAULT_TIMEOUT = 300;

	private boolean versionPromotion = true;
	private String currentHost;
	private String currentProxyHost;
	private String currentProxyToken;
	private InetAddress currentHostAddress;
	private InetAddress currentProxyAddress;
	private int currentPort = -1;
	private int currentProxyPort = -1;
	private int currentTransportType;
	private char[] currentService;
	private int currentTimeoutSeconds = 0;
	private int currentCompressionThreshold = 0;
	private byte currentEncryptionType;
	private byte lastEncryptionType;
	private int currentProxyConnectionID;
	private boolean isActive = false;
	private boolean isConnected = false;
	private boolean isProxyConnection = false;
	private boolean isMultiplexed = false;
	private boolean isClient = true;
	private boolean isEncryptionEnabled = false;
	private UniRPCSocket socket;	// the TCP/IP socket for this instance of the library
	private DataInputStream dataIn;
	private DataOutputStream dataOut;
	private int sslMode = UniObjectsTokens.NON_SECURE_SESSION;
	private  String  serverId="";
	
	
	
} /* UniRPCConnection class */
