/*************************************************************************
 *
 * UniRPCSocket.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/15/10 12535 JFM set SSL socket blocking mode before calling close()
 * 09/09/05 34030 CUI do not call shutdownOutput() for SSLSocket (workaround
 *	"unsupported" exception problem when SSL socket closes).
 * 08/24/05 E7815,33964 JFM  changed close()
 * 08/09/05 E7815,33964 JFM  previous isServerAlive() doesn't work against
 *                         Unix machines, modified to use non-blocking read
 * 05/26/05 E7815  RKK  Socket alive for connection pooling
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.unirpc;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import asjava.uniobjects.UniSSLDescriptor;

/**
 * UniRPCSocket is the TCP/IP socket wrapper class for the asjava.unirpc package.
 * The primary purpose of this class is to provide an abstraction layer around the
 * socket class so we can implement reference counts and using different types of
 * socket objects in the future.
 * Although we currently derive from the Socket class, if we start using more than
 * one type of socket we will have to go to a different model such as deriving from
 * Object and having a socket instance maintained within the class.
 *
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIRPC 1.0
 */

public class UniRPCSocket extends Object
{

  /**
   * Creates a stream socket and connects it to the specified port
   * number on the named host.
   * <p>
   * If the application has specified a server socket factory, that
   * factory's <code>createSocketImpl</code> method is called to create
   * the actual socket implementation. Otherwise a "plain" socket is created.
   *
   * @param      host   the host name.
   * @param      port   the port number.
   * @exception  IOException  if an I/O error occurs when creating the socket.
   * @see        java.net.Socket#setSocketImplFactory(java.net.SocketImplFactory)
   * @see        java.net.SocketImpl
   * @see        java.net.SocketImplFactory#createSocketImpl()
   * @since      UniRPC1.0
   */
	public UniRPCSocket(String host, int port) throws UnknownHostException, IOException
	{
    this.socket = new Socket(host, port);
		referenceCount++;
	}


   /**
   * Creates a stream normal socket or SSL socket and connects it to the specified port
   * number on the named host.
   * if parameter sslmode have its value true then SSL socket is created
   * <p>

   *
   * @param      host   the host name.
   * @param      port   the port number.
   * @exception  IOException  if an I/O error occurs when creating the socket.
   * @see        java.net.Socket#setSocketImplFactory(java.net.SocketImplFactory)
   * @see        java.net.SocketImpl
   * @see        java.net.SocketImplFactory#createSocketImpl()
   * @since      UniRPC1.0
   */
	public UniRPCSocket(InetAddress host, int port, UniSSLDescriptor ussld, boolean sslflag) throws UnknownHostException, IOException
	{
    if (sslflag == false)
    {
      this.socket = new Socket(host, port);
		  referenceCount++;
    }
    else
    {
      this.socket = UniRPCSSLSocket.createSSLSocket(host, port, ussld);
      referenceCount++;
      isSSLSocket = true;
    }
	}


	/**
	 * Creates a stream socket and connects it to the specified port
	 * number at the specified IP address.
	 * <p>
	 * If the application has specified a socket factory, that factory's
	 * <code>createSocketImpl</code> method is called to create the
	 * actual socket implementation. Otherwise a "plain" socket is created.
	 *
	 * @param      address   the IP address.
	 * @param      port      the port number.
	 * @exception  IOException  if an I/O error occurs when creating the socket.
	 * @see        java.net.Socket#setSocketImplFactory(java.net.SocketImplFactory)
	 * @see        java.net.SocketImpl
	 * @see        java.net.SocketImplFactory#createSocketImpl()
	 * @since      UniRPC1.0
	 */
	public UniRPCSocket(InetAddress address, int port) throws IOException
	{
 //   this.socket = new Socket(address, port);
        this.socket = getSocketFromChannel(address, port);
		referenceCount++;

	}

	/**
	 * Creates a socket and connects it to the specified remote host on
	 * the specified remote port. The Socket will also bind() to the local
	 * address and port supplied.
	 * @param host the name of the remote host
	 * @param port the remote port
	 * @param localAddr the local address the socket is bound to
	 * @param localPort the local port the socket is bound to
	 * @since   UniRPC1.0
	 */
	public UniRPCSocket(String host, int port, InetAddress localAddr, int localPort) throws IOException
	{
		this.socket = new Socket(host, port, localAddr, localPort);
		referenceCount++;
	}

	/**
	 * Creates a socket and connects it to the specified remote address on
	 * the specified remote port. The Socket will also bind() to the local
	 * address and port supplied.
	 * @param address the remote address
	 * @param port the remote port
	 * @param localAddr the local address the socket is bound to
	 * @param localPort the local port the socket is bound to
	 * @since   UniRPC1.0
	 */
	public UniRPCSocket(InetAddress address, int port, InetAddress localAddr,
		  int localPort) throws IOException
	{
		this.socket = new Socket(address, port, localAddr, localPort);
		referenceCount++;
	};
  /*
   * Converts normal UniRPCSocket to a secure socket
  */

  public void makeSecure(String host, int port, UniSSLDescriptor ussld)
  throws IOException
  {
    socket = UniRPCSSLSocket.makeSecure(socket, host, port, ussld);
    /* E34030 */
    isSSLSocket = true;
  }



	/**
	 * Closes this socket. A hard close only occurs if the reference count has reached zero.
	 *
	 * @return	the reference count.
	 * @since	UniRPC1.0
	 */
	public synchronized void close() throws IOException
	{
		referenceCount--;
		if( referenceCount < 1 )
		{
		  /* E34030 */
		  if (!isSSLSocket) {
		    this.socket.shutdownOutput();
		    this.socket.shutdownInput();
		  } else {
		      SocketChannel channel = this.socket.getChannel();
		      if (channel != null)
		             channel.configureBlocking(true);
		  }
			this.socket.close();
		}
	}

	/**
	 * The current reference count for this class.
	 *
	 * @return	the reference count.
	 * @since	UniRPC1.0
	 */
	public int getCount()
	{
		return referenceCount;
	}

	/**
	 * Obtain a reference to this socket for use with multiplexed connections.
	 *
	 * @return	reference to a <code>UniRPCSocket</code>.
	 * @since	UniRPC1.0
	 */
	public synchronized UniRPCSocket multiplex()
	{

		referenceCount++;
		return this;
	}

  public int getPort()
  {
    return this.socket.getPort();
  }

  public int getSoLinger() throws SocketException
  {
    return this.socket.getSoLinger();

  }

  public boolean getTcpNoDelay() throws SocketException
  {
    return this.socket.getTcpNoDelay();
  }

  public int getSoTimeout() throws SocketException
  {
    return this.getSoTimeout();
  }

  public void setSoLinger(boolean on, int val) throws SocketException
  {
    this.socket.setSoLinger(on, val);
  }

  public void setTcpNoDelay(boolean on) throws SocketException
  {
    this.socket.setTcpNoDelay(on);
  }

  public void setSoTimeout(int timeout) throws SocketException
  {
    this.socket.setSoTimeout(timeout);
  }

  public InputStream getInputStream() throws IOException
  {
    return this.socket.getInputStream();
  }

  public OutputStream getOutputStream() throws IOException
  {
    return this.socket.getOutputStream();
  }

  public boolean isSSLSocket()
  {
    return isSSLSocket;
  }

  /**
   * Find out Socket is Alive or not
   */
  public boolean isServerAlive() {
      /*
       * After UD71 Release,Now we are compiling with JDK 1.4 so we can take out the comment
       */
      /*
       try {
       this.socket.sendUrgentData(0);
       } catch (Exception e) {
       return false;
       }
       */
      /* note: test against Unix machines showed that by sending OOB data to the server
       * which is gone already doesn't throw exception, so we decided  to use non-blocking
       * read to accomplish the this function 
       */
      SocketChannel channel = this.socket.getChannel();
      
      // if the socket is not created by a socketchannel
      if (channel == null)
          return true;
      ByteBuffer buf = ByteBuffer.allocate(1);
      int r = 0;
      try {
          channel.configureBlocking(false);
          r = channel.read(buf);
          channel.configureBlocking(true);
      } catch (IOException e1) {
          
          return false;
      }
      
      if (r == -1)
          return false;
      return true;
  }


  
  /*
   * create a socket throught SocketChannel so that we can
   * later on switch between blocking and non-blocking for 
   * checking server's existence
   */
  Socket getSocketFromChannel(InetAddress address, int port) throws IOException
  {
      InetSocketAddress isa = new InetSocketAddress(address, port );
      SocketChannel channel = SocketChannel.open(isa);
      channel.configureBlocking(true);
      return channel.socket();
  }
  
  
  private int referenceCount = 0;	// the current socket reference count
  private Socket socket = null;
  private boolean isSSLSocket = false;

} /* UniRPCSocket class */
