/*************************************************************************
 *
 * UniRPCTokens.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.unirpc;
 

/**
 * <code>UniProxyTokens</code> is the primary class used for holding UniVerse 
 * RPC define tokens.
 * 
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIRPC 1.0
 */

public class UniRPCTokens
{
	UniRPCTokens()
	{
	}
	
	// public properties.
	
	/**
	 * Initial connection id that is used when opening a new connection with a
	 * proxy server.
	 *
	 * @see asjava.unirpc.UniRPCConnection#connect()
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_INITIAL_PROXY_CONNECTIONID = 0;

  /**
   * Secure and nonsecure session tokens
   * @since UniRPC???
   */
  public final static int UNIRPC_SECURE_SESSION = 1;
  public final static int UNIRPC_NONSECURE_SESSION = 0;

	/**
	 * Default RPC transport type(TCP/IP). TCP/IP is the only transport type we support.
	 *
	 * @see asjava.unirpc.UniRPCConnection#setTransportType()
	 * @see asjava.unirpc.UniRPCConnection#getTransportType()
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_TRANSPORT_TCPIP = 1;
	
	/**
	 * Default RPC proxy daemon port. Currently defined as <code>31448</code>
	 *
	 * @see asjava.unirpc.UniRPCConnection#setProxyPort()
	 * @see asjava.unirpc.UniRPCConnection#getProxyPort()
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_DEFAULT_PROXY_PORT = 31448;
	public final static int UNIRPC_DEFAULT_SSL_PROXY_PORT = 31452;
	
	/**
	 * Default RPC daemon port. Currently defined as <code>31438</code>
	 *
	 * @see asjava.unirpc.UniRPCConnection#setPort()
	 * @see asjava.unirpc.UniRPCConnection#getPort()
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_DEFAULT_PORT = 31438;
	
	/**
	 * Encryption type for when no encryption is desired.
	 *
	 * @see asjava.unirpc.UniRPCConnection#setEncryptionType()
	 * @see asjava.unirpc.UniRPCConnection#getEncryptionType()
	 * @since UniRPC1.0
	 */
	public static final byte UNIRPC_ENCRYPTION_NONE = 0x00;
	
	/**
	 * Encryption type for when XOR encryption is desired.
	 *
	 * @see asjava.unirpc.UniRPCConnection#setEncryptionType()
	 * @see asjava.unirpc.UniRPCConnection#getEncryptionType()
	 * @since UniRPC1.0
	 */
	public static final byte UNIRPC_ENCRYPTION_XOR = 0x01;
	
	/**
	 * Proxy header type that is used when the client wants to tell the proxy 
	 * server to read a packet even though a packet has not been sent.
	 *
	 * @see asjava.unirpc.UniRPCPProxyHeader#writeHeaderType()
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_PROXY_HEADER_TYPE_SPOOF = 10000;
	
	/**
	 * Proxy header type that is used for all standard packets sent to and from
	 * the proxy server.
	 *
	 * @see asjava.unirpc.UniRPCPProxyHeader#writeHeaderType()
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_PROXY_HEADER_TYPE_DEFAULT = 0;
				
	/**
	 * The current connection is no longer active or alive.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_BAD_CONNECTION = 81001;
	
	/**
	 * The method called can't complete when the connection is in
	 * the disconnected state.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_NO_CONNECTION = 81002;
	
	/**
	 * An argument of a perticular type was requested but that argument
	 * was NOT of the requested type.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_INVALID_ARG_TYPE = 81004;
	
	/**
	 * A connection was attempted with a UniRPC library of a version that
	 * this library does not support.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_WRONG_VERSION = 81005;
	
	/**
	 * A method in the UniRPC package was given an invalid parameter.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_BAD_PARAMETER = 81008; // bad parameter 
	
	/**
	 * A non specific error occured while executing this method.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_FAILED = 81009;
	
	/**
	 * The specified argument was used out of order in a write statement or
	 * has exceeded the maximum number of arguments allowed.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_ARG_COUNT = 81010; // argument count 
	
	/**
	 * The specified host was NOT found.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_UNKNOWN_HOST = 81011; // unknown host 
	
	/**
	 * This RPC package can't use the specified transport type.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_BAD_TRANSPORT = 81019;
	
	// New UniRPC error states
	/**
	 * The method called can't complete when the connection is in
	 * the connected state.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_CONNECTION = 81023;
	
	/**
	 * The method called dosn't or can't support use with or as a multiplexed connection.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_NO_MULTIPLEX_SUPPORT = 81024;
	
	/**
	 * The method called dosn't or can't support encryption.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_NO_ENCRYPTION_SUPPORT = 81025;
	
	/**
	 * The method called dosn't or can't support compression.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_NO_COMPRESSION_SUPPORT = 81026;
	
	/**
	 * The proxy server login procedure failed.
	 *
	 * @since UniRPC1.0
	 */
	// error code apply to client/proxy only, us 83xxx */
	public static final int UNIRPC_FAILED_PROXY_LOGIN = 83000;
	
	/**
	 * The proxy server login procedure failed with bad authorization.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_FAILED_PROXY_LOGIN_AUTH = 83001;
	
	/**
	 * The proxy server login procedure failed with exceeded max sessions.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSIONS = 83002;
	
	/**
	 * The proxy server login procedure failed with exceeded max session connections.
	 *
	 * @since UniRPC1.0
	 */
	public static final int UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSION_CONNECTIONS = 83003;

	public static final int UNIRPC_NOT_PROXY_CONNECTION=83004;
	
// UniRPC exception/error numbers that the UniRPC-Java package doesn't use.
//	public static final int UVRPC_NOT_INITED = 81003; // Not inited 
//	public static final int UVRPC_BAD_SEQNO = 81006; // bad sequence number 
//	public static final int UVRPC_NO_MORE_CONNECTIONS = 81007; // no more connections 
//	public static final int UVRPC_BAD_PARAMETER = 81008; // bad parameter 
//	public static final int UVRPC_FORK_FAILED = 81012; // fork failed
//	public static final int UVRPC_CANT_OPEN_SERV_FILE = 81013; // can't open service file 
//	public static final int UVRPC_CANT_FIND_SERVICE = 81014; // can't find service
//	public static final int UVRPC_TIMEOUT = 81015; // timeout 
//	public static final int UVRPC_REFUSED = 81016; // refused 
//	public static final int UVRPC_SOCKET_INIT_FAILED = 81017; // socket init failed 
//	public static final int UVRPC_SERVICE_PAUSED = 81018; // service paused 
	// private properties.
}
