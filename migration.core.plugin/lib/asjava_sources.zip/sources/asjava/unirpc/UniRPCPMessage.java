/*************************************************************************
 *
 * UniRPCPMessage.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * ? Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 01/20/06 E8316 JFM when data from server is too large, read them
 *                    in smaller pieces to avoid overwhelm Java socket
 * 02/06/04 E3912 JFM replace GB18030 env var with clientencoding 
 * 12/05/03 E3912 JFM GB18030 changes
 * 05/15/02 L.QIANG added write( int, byte[] )
 * 10/11/01 J.Mao added readBytes( ) for JDBC 
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/
 
package asjava.unirpc;
 
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import asjava.uniclientlibs.UniString;
import asjava.uniclientlibs.UniTokens;

/**
 * UniRPCPMessage is a class which builds and transfers the message information 
 * for a UniRPC data packet.
 * <p>
 * <pre>
 * Version 2, UniRPC Message Packet structure.
 * |--------16 Bits---------|
 * |--------------------32 Bits----------------------|
 * ===================================================
 * |-------Version----------|--------SeqNo-----------|\
 * |---------------------Length----------------------| \
 * |----------------------Type-----------------------|  \ Message Header - 24 Bytes
 * |-High Ver.--|--C. Mask--|--E. Mask--|---Future---|  /
 * |-------------------Return code-------------------| /
 * |-------Arg Count--------|------Proc Length-------|/
 * ===================================================
 * |----------Procedure name (unformated)------------|\
 * |-------------------::::::::::--------------------| \
 * |------------------Arg 1 Length-------------------|  \
 * |-------------------Arg 1 Type--------------------|   \
 * |-------------------::::::::::--------------------|    \ Message Body - (Length) Bytes
 * |------------------Arg n Length-------------------|    /
 * |-------------------Arg n Type--------------------|   /
 * |---------------Arg 1 Data (unformated)-----------|  /
 * |-------------------::::::::::--------------------| /
 * |---------------Arg n Data (unformated)-----------|/
 * ===================================================
 * </pre>
 * <pre>
 * Important notes about how different data types are stored.
 * 1)Arg Length contains the number of data items or the length of a data item.
 *   For integers and integer arrays, the number.
 *   For doubles and double arrays, the number.
 *   For char*'s, UniString's and Procedure name's, the length.
 * 2)For all encrypted data items, only the data itself is encrypted. The 
 *   length and argument type are not encrypted.
 * 3)Procedure names are not currently supported. 
 * </pre>
 *
 * @version	1.0
 * @author	Occhio Orsini
 * @see	UniRPCPacket
 * @see	UniRPCPProxyHeader
 * @since	UNIRPC 1.0
 */

class UniRPCPMessage extends UniRPC
{	
	/**
	 * Constructs a message for use in transmitting data
	 * through UniRPC with a UniRPCPacket Object.
	 *
	 * @since	UniRPC1.0
	 */
	public UniRPCPMessage()
	{
		headerBuffer = new byte[UNIRPC_HEADER_SIZE];
		dataInfoBuffer = new byte[UNIRPC_MAX_PACKET_ARGS * 8];
		dataBuffer = new byte[UNIRPC_DEFAULT_DATA_SIZE];
		// initialize the header info
		resetHeader();
		// initialize the data info
		resetData();
		currentCompressionThreshold = 0;
	}	/* UniRPCPMessage() */
	
	/**
	 * Writes the entire message contents out to a <code>PrintStream</code> 
	 * formated in english. This method uses the read() methods to read the 
	 * arguments out of the message buffer.
	 *
	 * @since	UniRPC1.0
	 */
	public void dump()
	{
		if (debugLevel > 5)
		{
			// message header
			debugWriter.println("Packet Header Detail:");
			if (debugLevel > 7)
			{
				debugWriter.print(" headerBuffer=0x");
				for ( int i = 0; i < headerBuffer.length; i++)
				{
					String temp = Integer.toHexString((int) headerBuffer[i] & 0xFF);
					if ( temp.length() == 1 )
					{
						debugWriter.print("0" + temp);
					}
					else
					{
						debugWriter.print(temp);				
					}
					if( (((i+1)%4) == 0) )
					{
						debugWriter.print(" ");
					}
				}
				debugWriter.println();
			}
			debugWriter.println(" Version=" + ( (int) 
				(((int) headerBuffer[1] & 0xFF) <<  0) ) );
			debugWriter.println(" Sequence=" + ( (int) (
				(((int) headerBuffer[2] & 0xFF) <<  8) +
				(((int) headerBuffer[3] & 0xFF) <<  0) ) ) );
			if ( isEncrypted && isCompressed )
			{
				debugWriter.print(" Encrypted & Compressed Length=");
			}
			else if ( isEncrypted )
			{
				debugWriter.print(" Encrypted Length=");
			}
			else
			{
				debugWriter.print(" Data Length=");	
			}
			debugWriter.println( ( (int) (
				(((int) headerBuffer[4] & 0xFF) << 24) +
				(((int) headerBuffer[5] & 0xFF) << 16) +
				(((int) headerBuffer[6] & 0xFF) <<  8) +
				(((int) headerBuffer[7] & 0xFF) <<  0) ) ) );
			debugWriter.println(" Type=" + ( (int) (
				(((int) headerBuffer[8] & 0xFF) << 24) +
				(((int) headerBuffer[9] & 0xFF) << 16) +
				(((int) headerBuffer[10] & 0xFF) <<  8) +
				(((int) headerBuffer[11] & 0xFF) <<  0) ) ) );
			debugWriter.println(" Highest Supported Version=" + ( (int)
				(((int) headerBuffer[12] & 0xFF) << 0) ) );
			debugWriter.println(" Compression Mask=0x" + 
				( Integer.toHexString((int) headerBuffer[13] & 0xFF) ) );
			debugWriter.println(" Encryption Mask=0x" + 
				( Integer.toHexString((int) headerBuffer[14] & 0xFF) ) );
			debugWriter.println(" Return Code=" + ( (int) (
				(((int) headerBuffer[16] & 0xFF) << 24) +
				(((int) headerBuffer[17] & 0xFF) << 16) +
				(((int) headerBuffer[18] & 0xFF) <<  8) +
				(((int) headerBuffer[19] & 0xFF) <<  0) ) ) );
			debugWriter.println(" Argument Count=" + ( (int) (
				(((int) headerBuffer[20] & 0xFF) <<  8) +
				(((int) headerBuffer[21] & 0xFF) <<  0) ) ) );
			debugWriter.println(" Proc Length=" + ( (int) (
				(((int) headerBuffer[22] & 0xFF) <<  8) +
			(((int) headerBuffer[23] & 0xFF) <<  0) ) ) );
		} /* debug > 5 */
		if (debugLevel > 3)
		{
			// message data
			debugWriter.println("Packet Data Detail:");
			if (debugLevel > 7)
			{
				debugWriter.print(" dataInfoBuffer=0x");
				for ( int i = 0; i < (currentArgumentCount * 8); i++)
				{
					String temp = Integer.toHexString((int) dataInfoBuffer[i] & 0xFF);
					if ( temp.length() == 1 )
					{
						debugWriter.print("0" + temp);
					}
					else
					{
						debugWriter.print(temp);				
					}
					if( (((i+1)%4) == 0) )
					{
						if( (((i+1)%24) == 0) && ((i+1)<(currentArgumentCount * 8)) )
						{
							debugWriter.println();
							debugWriter.print("                0x");
						}
						else
						{
							debugWriter.print(" ");
						}
					}
				}
				debugWriter.println();
				debugWriter.print(" dataBuffer=0x");
				for ( int i = 0; i < dataOffset; i++)
				{
					String temp = Integer.toHexString((int) dataBuffer[i] & 0xFF);
					if ( temp.length() == 1 )
					{
						debugWriter.print("0" + temp);
					}
					else if ( temp.length() == 2 )
					{
						debugWriter.print(temp);				
					}
					else
					{
						debugWriter.print("(" + temp + ")");				
					}
					if( (((i+1)%4) == 0) )
					{
						if( (((i+1)%24) == 0) )
						{
							debugWriter.println();
							debugWriter.print("            0x");
						}
						else
						{
							debugWriter.print(" ");
						}
					}
				}
				debugWriter.println();
				if (debugLevel > 8)
				{
					debugWriter.print(" dataBufferEncrypted=0x");
					if (dataBufferEncrypted != null)
					for ( int i = 0; i < dataBufferEncrypted.length; i++)
					{
						String temp = Integer.toHexString((int) dataBufferEncrypted[i] & 0xFF);
						if ( temp.length() == 1 )
						{
							debugWriter.print("0" + temp);
						}
						else if ( temp.length() == 2 )
						{
							debugWriter.print(temp);				
						}
						else
						{
							debugWriter.print("(" + temp + ")");				
						}
						if( (((i+1)%4) == 0) )
						{
							if( (((i+1)%24) == 0) )
							{
								debugWriter.println();
								debugWriter.print("                     0x");
							}
							else
							{
								debugWriter.print(" ");
							}
						}
					}
					debugWriter.println();
					debugWriter.print(" dataBufferCompressed=0x");
					for ( int i = 0; i < dataBufferCompressed.length; i++)
					{
						String temp = Integer.toHexString((int) dataBufferCompressed[i] & 0xFF);
						if ( temp.length() == 1 )
						{
							debugWriter.print("0" + temp);
						}
						else if ( temp.length() == 2 )
						{
							debugWriter.print(temp);				
						}
						else
						{
							debugWriter.print("(" + temp + ")");				
						}
						if( (((i+1)%4) == 0) )
						{
							if( (((i+1)%24) == 0) )
							{
								debugWriter.println();
								debugWriter.print("                      0x");
							}
							else
							{
								debugWriter.print(" ");
							}
						}
					}
					debugWriter.println();
				}
			} /* debug > 7*/
			int tmpType;
			int tmpLength;
			int tmpDataOffset = 0;
			for ( int i = 0; i < currentArgumentCount; i++)
			{
				debugWriter.print(" Argument[" + (i) + "]");
				tmpLength = ( (int)	(
					(((int) dataInfoBuffer[(i * 8) + 0] & 0xFF) << 24) +
					(((int) dataInfoBuffer[(i * 8) + 1] & 0xFF) << 16) +
					(((int) dataInfoBuffer[(i * 8) + 2] & 0xFF) <<  8) +
					(((int) dataInfoBuffer[(i * 8) + 3] & 0xFF) <<  0) ) );
				debugWriter.print("=Length=" + tmpLength );
				tmpType = ( (int)	(
					(((int) dataInfoBuffer[(i * 8) + 4] & 0xFF) << 24) +
					(((int) dataInfoBuffer[(i * 8) + 5] & 0xFF) << 16) +
					(((int) dataInfoBuffer[(i * 8) + 6] & 0xFF) <<  8) +
					(((int) dataInfoBuffer[(i * 8) + 7] & 0xFF) <<  0) ) );
				debugWriter.print("=Type=" + tmpType );
				debugWriter.print("=Value=");
				try
				{
					switch(tmpType)
					{
						case UniRPCPacket.UNIRPC_INT:
							debugWriter.print( readInteger(i) );
							break;
						case UniRPCPacket.UNIRPC_DOUBLE:
							debugWriter.print( readDouble(i) );
							break;
						case UniRPCPacket.UNIRPC_CHAR:
							debugWriter.print( readCharArray(i) );
							break;
						case UniRPCPacket.UNIRPC_INT_PTR:
							int[] intArray = readIntegerArray(i);
							for ( int j = 0; j < intArray.length; j++)
							{
								debugWriter.print( intArray[j] + "," );
							}
							break;
						case UniRPCPacket.UNIRPC_DOUBLE_PTR:
							double[] doubleArray = readDoubleArray(i);
							for ( int j = 0; j < doubleArray.length; j++)
							{
								debugWriter.print( doubleArray[j] + "," );
							}
							break;
						case UniRPCPacket.UNIRPC_STRING:
							debugWriter.print( readString(i) );
							break;
						default:
							debugWriter.print( "Unrecognized Data Type" );
							break;
					} /* switch */
				}
				catch (UniRPCPacketException e)
				{				
					debugWriter.print( "UniRPCMessage.dump():PacketException:" + e.getMessage() );			
				}
				debugWriter.println();			
			}
			debugWriter.println();
		} /* debug > 3 */
	} /* dump() */
	
	/**
	 * Get the number of arguments currently stored in this message Object.
	 * 
	 * @since	UniRPC1.0
	 */
	public int getArgumentCount( )
	{
		return currentArgumentCount;
	}
		
	/**
	 * Returns the threshold in bytes, beyond which this object will write 
	 * to the output stream in compressed format. This feature not supported 
	 * in UniRPC 1.0.
	 *
	 * @see #setCompressionThreshold
	 * @since	UniRPC1.0
	 */
	public int getCompressionThreshold()
	{
		return currentCompressionThreshold;
	}
	
	/**
	 * Get the total number of bytes to be transmitted by this message Object.
	 * This value reflects any data encryption and compression that is to be
	 * performed.
	 * It is very important that this method is only called immediately before
	 * calling the <code>send()</code> method. If arguments are written to this message
	 * after calling <code>getLength()</code>, those arguments will be lost and never
	 * transmitted to the remote RPC library. There also may be other 
	 * undesirable side affects. 
	 *
	 * @since	UniRPC1.0
	 */
	public int getLength( byte anEncryptionType )
	{
		// this has to reflect encryption and compression so that the packet object
		// can feed the proxy header object the correct length.
		if( !isEncrypted )
		{
			encrypt( anEncryptionType );
			isEncrypted = true;
		}
		if ( !isCompressed )
		{
			compress();
			isCompressed = true;
		}			
		return (UNIRPC_HEADER_SIZE + dataBufferCompressed.length);
	}
	
	/**
	 * Returns the size in bytes of this message. The network size of
	 * the message before encryption or compression are applied. 
	 *
	 * @return	the size of this message
	 * @since	UniRPC1.0
	 */
	public int getSize()
	{
		// return size of message
		return (UNIRPC_HEADER_SIZE + (currentArgumentCount * 8) + dataOffset);
	}
	
	/**
	 * Read a character string data item from the message at the specified index.
	 * This method returns a <code>char[]</code> object 
	 *
	 * @since	UniRPC1.0
	 */
	public char[] readCharArray( int anIndex ) throws UniRPCPacketException
	{
		// make sure index is in range
		if ( anIndex >= currentArgumentCount )
		{
			throw new UniRPCPacketException( "The requested item does NOT exist.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		// get the data buffer offset for the argument requested
		int tmpDataOffset = dataItemOffset( anIndex );
		// get length of requested item		
		int itemLength = ( (int) (
			(((int) dataInfoBuffer[(anIndex * 8) + 0] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 1] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 2] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 3] & 0xFF) <<  0) ) );			
		// read type
		int	itemType = ( (int)	(
			(((int) dataInfoBuffer[(anIndex * 8) + 4] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 5] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 6] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 7] & 0xFF) <<  0) ) );
		// return the data item that was requested.
		char[] charArray;
		if ( itemType == UniRPCPacket.UNIRPC_CHAR )
		{
			charArray = (new String(dataBuffer,tmpDataOffset,itemLength)).toCharArray();
		}
		else
		{
			throw new UniRPCPacketException( "The requested item is NOT a character array.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		return charArray;
	}
	
	/**
	 * Return the compression mask used on this message.
	 *
	 * @since	UniRPC1.0
	 */
	public byte readCompressionMask()
	{
		// return the compression mask
		return ( (byte) headerBuffer[13] );
	}
	
	/**
	 * Read double data item from the message at the specified index.
	 *
	 * @since	UniRPC1.0
	 */
	public double readDouble( int anIndex ) throws UniRPCPacketException
	{
		// make sure index is in range
		if ( anIndex >= currentArgumentCount )
		{
			throw new UniRPCPacketException( "The requested item does NOT exist.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		// get the data buffer offset for the argument requested
		int tmpDataOffset = dataItemOffset( anIndex );
		// read type
		int	itemType = ( (int)	(
			(((int) dataInfoBuffer[(anIndex * 8) + 4] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 5] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 6] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 7] & 0xFF) <<  0) ) );
		// read the data item that was requested.
		int highLong;
		int lowLong;
		if ( itemType == UniRPCPacket.UNIRPC_DOUBLE )
		{
			// read first part of long representation of the double value
			highLong = ( (int) (
				((((int) dataBuffer[tmpDataOffset++]) & 0xFF) << 24) +
				((((int) dataBuffer[tmpDataOffset++]) & 0xFF) << 16) +
				((((int) dataBuffer[tmpDataOffset++]) & 0xFF) <<  8) +
				((((int) dataBuffer[tmpDataOffset++]) & 0xFF) <<  0) ) );
			// read second part of long representation of the double value
			lowLong = ( (int) (
				((((int) dataBuffer[tmpDataOffset++]) & 0xFF) << 24) +
				((((int) dataBuffer[tmpDataOffset++]) & 0xFF) << 16) +
				((((int) dataBuffer[tmpDataOffset++]) & 0xFF) <<  8) +
				((((int) dataBuffer[tmpDataOffset++]) & 0xFF) <<  0) ) );
		}
		else
		{
			throw new UniRPCPacketException( "The requested item is NOT a double.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}		
		// return the data item that was requested.
		return Double.longBitsToDouble((((long) highLong) << 32) + (long) (lowLong & 0xFFFFFFFFL));
	}

	/**
	 * Read double array data item from the message at the specified index.
	 *
	 * @since	UniRPC1.0
	 */
	public double[] readDoubleArray( int anIndex ) throws UniRPCPacketException
	{
		// make sure index is in range
		if ( anIndex >= currentArgumentCount )
		{
			throw new UniRPCPacketException( "The requested item does NOT exist.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		// get the data buffer offset for the argument requested
		int tmpDataOffset = dataItemOffset( anIndex );
		// get length of requested item		
		int itemLength = ( (int) (
			(((int) dataInfoBuffer[(anIndex * 8) + 0] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 1] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 2] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 3] & 0xFF) <<  0) ) );
		// read type
		int	itemType = ( (int)	(
			(((int) dataInfoBuffer[(anIndex * 8) + 4] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 5] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 6] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 7] & 0xFF) <<  0) ) );
		// build array of doubles to return.
		double[] doubleArray = new double[itemLength];
		int highLong;
		int lowLong;
		if ( itemType == UniRPCPacket.UNIRPC_DOUBLE_PTR )
		{
			for ( int i = 0; i < itemLength; i++)
			{
				// read first part of long representation of the double value
				highLong = ( (int) (
					((((int) dataBuffer[tmpDataOffset++]) & 0xFF) << 24) +
					((((int) dataBuffer[tmpDataOffset++]) & 0xFF) << 16) +
					((((int) dataBuffer[tmpDataOffset++]) & 0xFF) <<  8) +
					((((int) dataBuffer[tmpDataOffset++]) & 0xFF) <<  0) ) );
				// read second part of long representation of the double value
				lowLong = ( (int) (
					((((int) dataBuffer[tmpDataOffset++]) & 0xFF) << 24) +
					((((int) dataBuffer[tmpDataOffset++]) & 0xFF) << 16) +
					((((int) dataBuffer[tmpDataOffset++]) & 0xFF) <<  8) +
					((((int) dataBuffer[tmpDataOffset++]) & 0xFF) <<  0) ) );			
				doubleArray[i] = Double.longBitsToDouble((((long) highLong) << 32) + (long)(lowLong & 0xFFFFFFFFL));
			}
		}
		else
		{
			throw new UniRPCPacketException( "The requested item is NOT a double array.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}		
		// return the data item that was requested.
		return doubleArray;
	}
	
	/**
	 * Return the encryption mask used on this message.
	 *
	 * @since	UniRPC1.0
	 */
	public byte readEncryptionMask()
	{
		// return the encryption mask
		return ( (byte) headerBuffer[14] );
	}
	
	/**
	 * Return the message header version.
	 *
	 * @since	UniRPC1.0
	 */
	public int readHeaderVersion()
	{ 
		return ( (int) (((int) headerBuffer[1] & 0xFF) <<  0) );
	}
	
	/**
	 * Return the highest message version supported.
	 *
	 * @since	UniRPC1.0
	 */
	public int readHeaderVersionHighest()
	{
		// return the high version for this packet
		return ( (int) (((int) headerBuffer[12] & 0xFF) <<  0) );
	}

	/**
	 * Read integer data item from the message at the specified index.
	 *
	 * @since	UniRPC1.0
	 */
	public int readInteger( int anIndex ) throws UniRPCPacketException
	{
		// make sure index is in range
		if ( anIndex >= currentArgumentCount )
		{
			throw new UniRPCPacketException( "The requested item does NOT exist.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		// get the data buffer offset for the argument requested
		int tmpDataOffset = dataItemOffset( anIndex );
		// read type
		int	itemType = ( (int)	(
			(((int) dataInfoBuffer[(anIndex * 8) + 4] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 5] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 6] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 7] & 0xFF) <<  0) ) );
		// return the data item that was requested.
		int itemValue;
		if ( itemType == UniRPCPacket.UNIRPC_INT )
		{
			itemValue = ( (int) (
				(((int) dataBuffer[tmpDataOffset++] & 0xFF) << 24) +
				(((int) dataBuffer[tmpDataOffset++] & 0xFF) << 16) +
				(((int) dataBuffer[tmpDataOffset++] & 0xFF) <<  8) +
				(((int) dataBuffer[tmpDataOffset++] & 0xFF) <<  0) ) );
		}
		else
		{
			throw new UniRPCPacketException( "The requested item is NOT an integer.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}		
		return itemValue;
	}
			
	/**
	 * Read integer array data item from the message at the specified index.
	 *
	 * @since	UniRPC1.0
	 */
	public int[] readIntegerArray( int anIndex ) throws UniRPCPacketException
	{
		// make sure index is in range
		if ( anIndex >= currentArgumentCount )
		{
			throw new UniRPCPacketException( "The requested item does NOT exist.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		// get the data buffer offset for the argument requested
		int tmpDataOffset = dataItemOffset( anIndex );
		// get length of requested item		
		int itemLength = ( (int) (
			(((int) dataInfoBuffer[(anIndex * 8) + 0] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 1] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 2] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 3] & 0xFF) <<  0) ) );
		int	itemType = ( (int)	(
			(((int) dataInfoBuffer[(anIndex * 8) + 4] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 5] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 6] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 7] & 0xFF) <<  0) ) );			
		int[] integerArray = new int[itemLength];
		// build array of integers to return.
		if ( itemType == UniRPCPacket.UNIRPC_INT_PTR )
		{
			for ( int i = 0; i < itemLength; i++)
			{
				integerArray[i] = ( (int) (
					(((int) dataBuffer[tmpDataOffset++] & 0xFF) << 24) +
					(((int) dataBuffer[tmpDataOffset++] & 0xFF) << 16) +
					(((int) dataBuffer[tmpDataOffset++] & 0xFF) <<  8) +
					(((int) dataBuffer[tmpDataOffset++] & 0xFF) <<  0) ) );				
			}
		}
		else
		{
			throw new UniRPCPacketException( "The requested item is NOT an integer array.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}		
		// return the data item that was requested.
		return integerArray;
	}
	
	/**
	 * Return the type of this message.
	 *
	 * @since	UniRPC1.0
	 */
	public int readMessageType()
	{
		// return the message type
		return ( (int) (
			(((int) headerBuffer[8] & 0xFF) << 24) +
			(((int) headerBuffer[9] & 0xFF) << 16) +
			(((int) headerBuffer[10] & 0xFF) <<  8) +
			(((int) headerBuffer[11] & 0xFF) <<  0) ) );
	}
		
	/**
	 * Get the return code for this message.
	 *
	 * @since	UniRPC1.0
	 */
	public int readReturnCode()
	{
		// return the message return code
		return ( (int) (
			(((int) headerBuffer[16] & 0xFF) << 24) +
			(((int) headerBuffer[17] & 0xFF) << 16) +
			(((int) headerBuffer[18] & 0xFF) <<  8) +
			(((int) headerBuffer[19] & 0xFF) <<  0) ) );
	}
			
	public byte[] readBytes( int anIndex ) throws UniRPCPacketException
	{
		// make sure index is in range
		if ( anIndex >= currentArgumentCount )
		{
			throw new UniRPCPacketException( "The requested item does NOT exist.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		// get the data buffer offset for the argument requested
		int tmpDataOffset = dataItemOffset( anIndex );		
		// get length of requested item		
		int itemLength = ( (int) (
			(((int) dataInfoBuffer[(anIndex * 8) + 0] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 1] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 2] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 3] & 0xFF) <<  0) ) );			
		// read type
		int	itemType = ( (int)	(
			(((int) dataInfoBuffer[(anIndex * 8) + 4] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 5] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 6] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 7] & 0xFF) <<  0) ) );
		// return the data item that was requested.	
		String itemValue;
		// J.Mao added check for UNIRPC_CHAR type for JDBC
		if ( itemType == UniRPCPacket.UNIRPC_STRING 
				||itemType == UniRPCPacket.UNIRPC_CHAR )
		{
			byte[] bArray = new byte[itemLength];
			System.arraycopy(dataBuffer,tmpDataOffset,bArray,0,itemLength);
			return bArray;
		}
		else
		{
			throw new UniRPCPacketException( "The requested item is NOT a UniVerse string.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
	}
	
	/**
	 * Read String data item from the message at the specified index.
	 * Returns a <code>String</code> object 
	 *
	 * @since	UniRPC1.0
	 */
	public String readString( int anIndex ) throws UniRPCPacketException
	{
		// make sure index is in range
		if ( anIndex >= currentArgumentCount )
		{
			throw new UniRPCPacketException( "The requested item does NOT exist.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		// get the data buffer offset for the argument requested
		int tmpDataOffset = dataItemOffset( anIndex );		
		// get length of requested item		
		int itemLength = ( (int) (
			(((int) dataInfoBuffer[(anIndex * 8) + 0] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 1] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 2] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 3] & 0xFF) <<  0) ) );			
		// read type
		int	itemType = ( (int)	(
			(((int) dataInfoBuffer[(anIndex * 8) + 4] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 5] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 6] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 7] & 0xFF) <<  0) ) );
		// return the data item that was requested.	
		String itemValue;
		// J.Mao added check for UNIRPC_CHAR type for JDBC
		if ( itemType == UniRPCPacket.UNIRPC_STRING 
				||itemType == UniRPCPacket.UNIRPC_CHAR )
		{
			if (clientEncoding == null) {
				itemValue = new String(dataBuffer,tmpDataOffset,itemLength);
			} else {

				try {
					itemValue = new String(dataBuffer,tmpDataOffset,itemLength,clientEncoding);
				} catch (Exception e) {
					throw new UniRPCPacketException("In write, encoding conversion error"+ e.getMessage(),UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
				}
			}
		}
		else
		{
			throw new UniRPCPacketException( "The requested item is NOT a UniVerse string.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		
		return itemValue;
	}
	
	/**
	 * Get the data type of the item at this index in this message Object.
	 *
	 * @since	UniRPC1.0
	 */
	public int readType( int anIndex ) throws UniRPCPacketException
	{
		// make sure index is in range
		if ( anIndex >= currentArgumentCount )
		{
			throw new UniRPCPacketException( "The requested item does NOT exist.",
				UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
		}
		return ( (int) (
			(((int) dataInfoBuffer[(anIndex * 8) + 4] & 0xFF) << 24) +
			(((int) dataInfoBuffer[(anIndex * 8) + 5] & 0xFF) << 16) +
			(((int) dataInfoBuffer[(anIndex * 8) + 6] & 0xFF) <<  8) +
			(((int) dataInfoBuffer[(anIndex * 8) + 7] & 0xFF) <<  0) ) );
	}
	
	/**
	 * Read UniString data item from the message at the specified index.
	 * This method is equivalent to <code>readString()</code> but
	 * returns a <code>UniString</code> object 
	 *
	 * @since	UniRPC1.0
	 */
	public UniString readUniString( int anIndex ) throws UniRPCPacketException
	{
		// return the data item that was requested.
		// a UniString data item is exactly the same as a String data item at the 
		// packet level.
		return new UniString( readString(anIndex) );
	}
	
	/**
	 * Reads a message from the given data stream.
	 * Will throw an exception if there is any network problem or if the packet 
	 * is not complete.
	 *
	 * @since	UniRPC1.0
	 */
	public void receive( DataInputStream aDataIn ) throws UniRPCPacketException
	{
		if ( aDataIn == null )
		{
			throw new UniRPCPacketException( "The DataInputStream is dead.", UniRPCTokens.UNIRPC_NO_CONNECTION);
		}
		try
		{
			aDataIn.readFully( headerBuffer );
			// get the length of the incomming data buffer
			int dataLength = readHeaderLength();			
			// get the number of incomming arguments
			currentArgumentCount = readArgumentCount();
			dataBufferCompressed = new byte[dataLength];

            int maxreadsize = UniTokens.UNIRPC_SOCKETREAD_MAX_SIZE;
            if (dataLength > maxreadsize)
            {
                int offset = 0;
                byte[] sBA = new byte[maxreadsize];
                int loop = dataLength / (maxreadsize);
                for (int i = 0; i < loop; i++)
                {
                    aDataIn.readFully(sBA);
                    for (int j = offset; j < offset+ maxreadsize; j++)
                        dataBufferCompressed[j] = sBA[j-offset];
                    offset += maxreadsize;
                }
                int left = dataLength - offset;
                if (left > 0) {
                    sBA = new byte[left];
                    aDataIn.readFully(sBA);
                    for (int j = offset;j < offset+ left; j++)
                        dataBufferCompressed[j] = sBA[j-offset];
                }
            } else {
                aDataIn.readFully( dataBufferCompressed );
            }

			decompress();
			decrypt();
		}
		catch ( IOException e )
		{
			throw new UniRPCPacketException( e.getMessage(), UniRPCTokens.UNIRPC_FAILED);
		}		
		if (debugLevel > 3)
		{
			dump();
		}
	} /* receive() */

	/**
	 * Writes this message out to the given data stream.
	 * Will throw an exception if there is any network problem or if the packet 
	 * is not completely written.
	 *
	 * @since	UniRPC1.0
	 */
	public void send( DataOutputStream aDataOut, byte anEncryptionMask ) throws UniRPCPacketException
	{
		if ( aDataOut == null )
		{
			throw new UniRPCPacketException( "The DataOutputStream is dead.", UniRPCTokens.UNIRPC_NO_CONNECTION);
		}
		try
		{
			// encrypt the data message before sending.
			// if the mask is null then no encryption is done
			if( !isEncrypted )
			{
				encrypt( anEncryptionMask );
				isEncrypted = true;
			}
			// compress the data message before sending.
			// if we havn't exceeded the compression threshold then no compression is done
			if ( !isCompressed )
			{
				compress();
				isCompressed = true;
			}			
			if (debugLevel > 3)
			{
				dump();
			}
			// send the data to the remote RPC library
			aDataOut.write( headerBuffer );				
			aDataOut.write( dataBufferCompressed );
			isEncrypted = false;
			isCompressed = false;
		}
		catch (IOException e )
		{
			throw new UniRPCPacketException( e.getMessage(), UniRPCTokens.UNIRPC_FAILED);			
		}
	}	/* send() */
		
	/**
	 * Sets the threshold in bytes, beyond which this object will write 
	 * to the output stream in compressed format. This feature not supported 
	 * in UniRPC 1.0.
	 *
	 * @see #getCompressionThreshold
	 * @since	UniRPC1.0
	 */
	public void setCompressionThreshold( int aThreshold ) throws UniRPCPacketException
	{
		if ( isCompressionSupported() || aThreshold == 0 )
		{
			/* ogo round compression up by 4 */
			currentCompressionThreshold = aThreshold;
		}
		else
		{
			throw new UniRPCPacketException( "Compression is not supported on this connection.",
				UniRPCTokens.UNIRPC_NO_COMPRESSION_SUPPORT);
		}
	}
	
	/**
	 * Set the current version of the message.
	 *
	 * @since	UniRPC1.0
	 */
	public void setVersionCurrent( int aVersion )
	{
		// set version number
		super.setVersionCurrent( aVersion );
		headerBuffer[0] = UNIRPC_PATT_CHECK; // Version number leading bit pattern,
										// used to verify this is really for PI+(UniVerse).
		headerBuffer[1] = (byte) ((currentVersion >>> 0) & 0xFF);
	}
	
	/**
	 * Write character array into the message at the specified index.
	 * If the encryption boolean is true then the data portion of this argument
	 * will be encrypted.
	 *
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, char[] aCharArray ) throws UniRPCPacketException
	{
		if ( anIndex == 0 )
		{
			resetData();
		}
		else if ( anIndex != currentArgumentCount )
		{
			throw new UniRPCPacketException( "All packet arguments must be inserted in order, starting with zero.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		else if ( anIndex >= UNIRPC_MAX_PACKET_ARGS )
		{
			throw new UniRPCPacketException( "A maximum of " + UNIRPC_MAX_PACKET_ARGS + " packet arguments are supported.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
	
	 /*
		// convert data to byte array
		byte[] bArray = new byte[aCharArray.length + 1];
		for ( int i = 0; i < aCharArray.length; i++)
		{
			// throw away the high byte because we want an ascii character
			bArray[i] = (byte) (aCharArray[i] & 0xFF);		
		}		
		// null terminate the character array
		bArray[aCharArray.length] = 0x00;
		
	*/
		byte[] tmpbArray;
		String aString = new String(aCharArray);
		if (clientEncoding!=null) {
			try {
				tmpbArray = aString.getBytes(clientEncoding);
			} catch (Exception e) {
				throw new UniRPCPacketException("In write, encoding conversion error",UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
			};
		} else {
			tmpbArray = aString.getBytes();
		}
		byte[] bArray = new byte[tmpbArray.length + 1];
		for ( int i = 0; i < tmpbArray.length; i++)
		{
			// throw away the high byte because we want an ascii character
			bArray[i] = tmpbArray[i];		
		}		
		// null terminate the character array
		bArray[tmpbArray.length] = 0x00;
	
		// we do something strange here, version one RPC layer always adds null
		// termination to a char array but does NOT include that null termination
		// in the character count for the argument.
		// store data length		
	
		dataInfoBuffer[(anIndex * 8) + 0] = (byte) (((bArray.length-1)>>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 1] = (byte) (((bArray.length-1)>>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 2] = (byte) (((bArray.length-1)>>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 3] = (byte) (((bArray.length-1)>>>  0) & 0xFF);
	
		// store data type
		dataInfoBuffer[(anIndex * 8) + 4] = (byte) ((UniRPCPacket.UNIRPC_CHAR >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 5] = (byte) ((UniRPCPacket.UNIRPC_CHAR >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 6] = (byte) ((UniRPCPacket.UNIRPC_CHAR >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 7] = (byte) ((UniRPCPacket.UNIRPC_CHAR >>>  0) & 0xFF);
		currentArgumentCount++;
		// adjust data buffer if to small
		if ( (bArray.length + 3) > (dataBuffer.length - dataOffset) )
		{
			increaseDataBuffer( (bArray.length + 3) );
		}
		// store data
		for ( int i = 0; i < bArray.length; i++)
		{
			dataBuffer[dataOffset++] = bArray[i];		
		}
		// align buffer pointer on integer boundary for next data item
		dataOffset += (((bArray.length) + 3) & ~3) - (bArray.length);		
	}
		
	/**
	 * Write double data item into the message at the specified index.
	 * If the encryption boolean is true then the data portion of this argument
	 * will be encrypted.
	 *
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, double aDouble ) throws UniRPCPacketException
	{
		if ( anIndex == 0 )
		{
			resetData();
		}
		else if ( anIndex != currentArgumentCount )
		{
			throw new UniRPCPacketException( "All packet arguments must be inserted in order, starting with zero.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		else if ( anIndex >= UNIRPC_MAX_PACKET_ARGS )
		{
			throw new UniRPCPacketException( "A maximum of " + UNIRPC_MAX_PACKET_ARGS + " packet arguments are supported.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		// store data length		
		dataInfoBuffer[(anIndex * 8) + 0] = (byte) ((UNIRPC_DOUBLE_LENGTH >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 1] = (byte) ((UNIRPC_DOUBLE_LENGTH >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 2] = (byte) ((UNIRPC_DOUBLE_LENGTH >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 3] = (byte) ((UNIRPC_DOUBLE_LENGTH >>>  0) & 0xFF);
		// store data type
		dataInfoBuffer[(anIndex * 8) + 4] = (byte) ((UniRPCPacket.UNIRPC_DOUBLE >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 5] = (byte) ((UniRPCPacket.UNIRPC_DOUBLE >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 6] = (byte) ((UniRPCPacket.UNIRPC_DOUBLE >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 7] = (byte) ((UniRPCPacket.UNIRPC_DOUBLE >>>  0) & 0xFF);
		currentArgumentCount++;
		// adjust data buffer if too small
		if ( 8 > (dataBuffer.length - dataOffset) )
		{
			increaseDataBuffer( 8 );
		}
		// store data
		long longDouble = Double.doubleToLongBits(aDouble);
		dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 56)) & 0xFF);
		dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 48)) & 0xFF);
		dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 40)) & 0xFF);
		dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 32)) & 0xFF);
		dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 24)) & 0xFF);
		dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 16)) & 0xFF);
		dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>>  8)) & 0xFF);
		dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>>  0)) & 0xFF);
	}
	
	/**
	 * Write double array item into the message at the specified index.
	 * If the encryption boolean is true then the data portion of this argument
	 * will be encrypted.
	 *
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, double[] aDouble ) throws UniRPCPacketException
	{
		if ( anIndex == 0 )
		{
			resetData();
		}
		else if ( anIndex != currentArgumentCount )
		{
			throw new UniRPCPacketException( "All packet arguments must be inserted in order, starting with zero.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		else if ( anIndex >= UNIRPC_MAX_PACKET_ARGS )
		{
			throw new UniRPCPacketException( "A maximum of " + UNIRPC_MAX_PACKET_ARGS + " packet arguments are supported.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		// store data length		
		dataInfoBuffer[(anIndex * 8) + 0] = (byte) (((aDouble.length) >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 1] = (byte) (((aDouble.length) >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 2] = (byte) (((aDouble.length) >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 3] = (byte) (((aDouble.length) >>>  0) & 0xFF);
		// store data type
		dataInfoBuffer[(anIndex * 8) + 4] = (byte) ((UniRPCPacket.UNIRPC_DOUBLE_PTR >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 5] = (byte) ((UniRPCPacket.UNIRPC_DOUBLE_PTR >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 6] = (byte) ((UniRPCPacket.UNIRPC_DOUBLE_PTR >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 7] = (byte) ((UniRPCPacket.UNIRPC_DOUBLE_PTR >>>  0) & 0xFF);
		currentArgumentCount++;
		// adjust data buffer if too small
		if ( (aDouble.length * 8) > (dataBuffer.length - dataOffset) )
		{
			increaseDataBuffer( (aDouble.length * 8) );
		}
		// store data
		long longDouble;
		for ( int i = 0; i < aDouble.length; i++)
		{
			longDouble = Double.doubleToLongBits(aDouble[i]);
			dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 56)) & 0xFF);
			dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 48)) & 0xFF);
			dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 40)) & 0xFF);
			dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 32)) & 0xFF);
			dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 24)) & 0xFF);
			dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>> 16)) & 0xFF);
			dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>>  8)) & 0xFF);
			dataBuffer[dataOffset++] = (byte) (((int)(longDouble >>>  0)) & 0xFF);
		}
	}
		 		
	/**
	 * Write integer data item into the message at the specified index.
	 * If the encryption boolean is true then the data portion of this argument
	 * will be encrypted.
	 *
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, int anInteger ) throws UniRPCPacketException
	{
		if ( anIndex == 0 )
		{
			resetData();
		}
		else if ( anIndex != currentArgumentCount )
		{
			throw new UniRPCPacketException( "All packet arguments must be inserted in order, starting with zero.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		else if ( anIndex >= UNIRPC_MAX_PACKET_ARGS )
		{
			throw new UniRPCPacketException( "A maximum of " + UNIRPC_MAX_PACKET_ARGS + " packet arguments are supported.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		// store data length		
		dataInfoBuffer[(anIndex * 8) + 0] = (byte) ((UNIRPC_INT_LENGTH >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 1] = (byte) ((UNIRPC_INT_LENGTH >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 2] = (byte) ((UNIRPC_INT_LENGTH >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 3] = (byte) ((UNIRPC_INT_LENGTH >>>  0) & 0xFF);
		// store data type
		dataInfoBuffer[(anIndex * 8) + 4] = (byte) ((UniRPCPacket.UNIRPC_INT >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 5] = (byte) ((UniRPCPacket.UNIRPC_INT >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 6] = (byte) ((UniRPCPacket.UNIRPC_INT >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 7] = (byte) ((UniRPCPacket.UNIRPC_INT >>>  0) & 0xFF);
		currentArgumentCount++;
		// increase data buffer if too small
		if ( 4 > (dataBuffer.length - dataOffset) )
		{
			increaseDataBuffer( 4 );
		}
		// store data
		dataBuffer[dataOffset++] = (byte) ((anInteger >>> 24) & 0xFF);
		dataBuffer[dataOffset++] = (byte) ((anInteger >>> 16) & 0xFF);
		dataBuffer[dataOffset++] = (byte) ((anInteger >>>  8) & 0xFF);
		dataBuffer[dataOffset++] = (byte) ((anInteger >>>  0) & 0xFF);
	}
		 		
	/**
	 * Write integer array item into the message at the specified index.
	 * If the encryption boolean is true then the data portion of this argument
	 * will be encrypted.
	 *
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, int[] anInteger ) throws UniRPCPacketException
	{
		if ( anIndex == 0 )
		{
			resetData();
		}
		else if ( anIndex != currentArgumentCount )
		{
			throw new UniRPCPacketException( "All packet arguments must be inserted in order, starting with zero.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		else if ( anIndex >= UNIRPC_MAX_PACKET_ARGS )
		{
			throw new UniRPCPacketException( "A maximum of " + UNIRPC_MAX_PACKET_ARGS + " packet arguments are supported.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		// store data length		
		dataInfoBuffer[(anIndex * 8) + 0] = (byte) (((anInteger.length) >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 1] = (byte) (((anInteger.length) >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 2] = (byte) (((anInteger.length) >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 3] = (byte) (((anInteger.length) >>>  0) & 0xFF);
		// store data type
		dataInfoBuffer[(anIndex * 8) + 4] = (byte) ((UniRPCPacket.UNIRPC_INT_PTR >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 5] = (byte) ((UniRPCPacket.UNIRPC_INT_PTR >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 6] = (byte) ((UniRPCPacket.UNIRPC_INT_PTR >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 7] = (byte) ((UniRPCPacket.UNIRPC_INT_PTR >>>  0) & 0xFF);
		currentArgumentCount++;
		// adjust data buffer if too small
		if ( (anInteger.length * 4) > (dataBuffer.length - dataOffset) )
		{
			increaseDataBuffer( (anInteger.length * 4) );
		}
		// store data
		for ( int i = 0; i < anInteger.length; i++)
		{
			dataBuffer[dataOffset++] = (byte) ((anInteger[i] >>> 24) & 0xFF);
			dataBuffer[dataOffset++] = (byte) ((anInteger[i] >>> 16) & 0xFF);
			dataBuffer[dataOffset++] = (byte) ((anInteger[i] >>>  8) & 0xFF);
			dataBuffer[dataOffset++] = (byte) ((anInteger[i] >>>  0) & 0xFF);
		}
	}
		 		
	/**
	 * Write String data item into the message at the specified index.
	 * If the encryption boolean is true then the data portion of this argument
	 * will be encrypted.
	 *
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, String aString ) throws UniRPCPacketException
	{
		if ( anIndex == 0 )
		{
			resetData();
		}			
		else if ( anIndex != currentArgumentCount )
		{
			throw new UniRPCPacketException( "All packet arguments must be inserted in order, starting with zero.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		else if ( anIndex >= UNIRPC_MAX_PACKET_ARGS )
		{
			throw new UniRPCPacketException( "A maximum of " + UNIRPC_MAX_PACKET_ARGS + " packet arguments are supported.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		// get the platform default character encoding byte representation
		// of this String.
		byte[] bArray;
		if (clientEncoding != null) {
			try {
				bArray = aString.getBytes(clientEncoding);
			} catch (Exception e) {
				throw new UniRPCPacketException("In write, encoding conversion error",UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
			};
		} else {
			bArray = aString.getBytes();
		}
		
		// store data length		
		dataInfoBuffer[(anIndex * 8) + 0] = (byte) ((bArray.length >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 1] = (byte) ((bArray.length >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 2] = (byte) ((bArray.length >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 3] = (byte) ((bArray.length >>>  0) & 0xFF);
		// store data type
		dataInfoBuffer[(anIndex * 8) + 4] = (byte) ((UniRPCPacket.UNIRPC_STRING >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 5] = (byte) ((UniRPCPacket.UNIRPC_STRING >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 6] = (byte) ((UniRPCPacket.UNIRPC_STRING >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 7] = (byte) ((UniRPCPacket.UNIRPC_STRING >>>  0) & 0xFF);
		currentArgumentCount++;
		// adjust data buffer if too small
		if ( (bArray.length + 3) > (dataBuffer.length - dataOffset) )
		{
			increaseDataBuffer( (bArray.length + 3) );
		}
		// store data
		for ( int i = 0; i < bArray.length; i++)
		{
			dataBuffer[dataOffset++] = bArray[i];		
		}
		// align buffer pointer on integer boundary for next data item
		dataOffset += (((bArray.length) + 3) & ~3) - (bArray.length);		
	}
		
	/**
	 * Write UniString data item into the message at the specified index.
	 * If the encryption boolean is true then the data portion of this argument
	 * will be encrypted.
	 *
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, UniString aString ) throws UniRPCPacketException
	{
		// get the platform default character encoding byte representation
		// of this UniString.
		byte[] bArray;
		if (clientEncoding != null)
			try {
			bArray = aString.getBytes();
			} catch (Exception e) {
				throw new UniRPCPacketException("In write, encoding conversion error",UniRPCTokens.UNIRPC_INVALID_ARG_TYPE);
			}
		else
			bArray = aString.getBytes();
        write( anIndex, bArray ) ;
	}
/**
	 * Writes a byte array data item into the message at the specfied index.
     	 * @since UniRPC1.2
	 */
	public void write( int anIndex, byte[] bArray ) throws UniRPCPacketException
	{
		// we could call write() for a standard String object instead.
		if ( anIndex == 0 )
		{
			resetData();
		}			
		else if ( anIndex != currentArgumentCount )
		{
			throw new UniRPCPacketException( "All packet arguments must be inserted in order, starting with zero.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		else if ( anIndex >= UNIRPC_MAX_PACKET_ARGS )
		{
			throw new UniRPCPacketException( "A maximum of " + UNIRPC_MAX_PACKET_ARGS + " packet arguments are supported.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}

		// store data length		
		dataInfoBuffer[(anIndex * 8) + 0] = (byte) ((bArray.length >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 1] = (byte) ((bArray.length >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 2] = (byte) ((bArray.length >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 3] = (byte) ((bArray.length >>>  0) & 0xFF);
		// store data type


		dataInfoBuffer[(anIndex * 8) + 4] = (byte) ((UniRPCPacket.UNIRPC_STRING >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 5] = (byte) ((UniRPCPacket.UNIRPC_STRING >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 6] = (byte) ((UniRPCPacket.UNIRPC_STRING >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 7] = (byte) ((UniRPCPacket.UNIRPC_STRING >>>  0) & 0xFF);

		currentArgumentCount++;
		// adjust data buffer if too small
		if ( (bArray.length + 3) > (dataBuffer.length - dataOffset) )
		{
			increaseDataBuffer( (bArray.length + 3) );
		}
		// store data
		for ( int i = 0; i < bArray.length; i++)
		{
			dataBuffer[dataOffset++] = bArray[i];		
		}
		// align buffer pointer on integer boundary for next data item
		dataOffset += (((bArray.length) + 3) & ~3) - (bArray.length);		
	}
	
	/**
	 * Writes a byte array data item into the message at the specfied index.
     	 * @since UniRPC1.2
	 */
	public void writeChars(int anIndex, byte[] bArray) throws UniRPCPacketException
	{
		
		// we could call write() for a standard String object instead.
		if ( anIndex == 0 )
		{
			resetData();
		}			
		else if ( anIndex != currentArgumentCount )
		{
			throw new UniRPCPacketException( "All packet arguments must be inserted in order, starting with zero.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}
		else if ( anIndex >= UNIRPC_MAX_PACKET_ARGS )
		{
			throw new UniRPCPacketException( "A maximum of " + UNIRPC_MAX_PACKET_ARGS + " packet arguments are supported.",
				UniRPCTokens.UNIRPC_ARG_COUNT);
		}

		// store data length		
		dataInfoBuffer[(anIndex * 8) + 0] = (byte) ((bArray.length >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 1] = (byte) ((bArray.length >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 2] = (byte) ((bArray.length >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 3] = (byte) ((bArray.length >>>  0) & 0xFF);
		// store data type

		dataInfoBuffer[(anIndex * 8) + 4] = (byte) ((UniRPCPacket.UNIRPC_CHAR >>> 24) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 5] = (byte) ((UniRPCPacket.UNIRPC_CHAR >>> 16) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 6] = (byte) ((UniRPCPacket.UNIRPC_CHAR >>>  8) & 0xFF);
		dataInfoBuffer[(anIndex * 8) + 7] = (byte) ((UniRPCPacket.UNIRPC_CHAR >>>  0) & 0xFF);

		currentArgumentCount++;
		// adjust data buffer if too small
		if ( (bArray.length + 4) > (dataBuffer.length - dataOffset) )
		{
			increaseDataBuffer( (bArray.length + 4) );
		}
		// store data
		for ( int i = 0; i < bArray.length; i++)
		{
			dataBuffer[dataOffset++] = bArray[i];		
		}
		dataBuffer[dataOffset++] = 0;
		
		// align buffer pointer on integer boundary for next data item
		dataOffset += (((bArray.length+1) + 3) & ~3) - (bArray.length+1);		
	}
	
	/**
	 * Set the packet type for this message.
	 *
	 * @since	UniRPC1.0
	 */
	public void writeMessageType( int aType )
	{
		// set the packet type
		headerBuffer[8]  = (byte) ((aType >>> 24) & 0xFF);
		headerBuffer[9]  = (byte) ((aType >>> 16) & 0xFF);
		headerBuffer[10] = (byte) ((aType >>>  8) & 0xFF);
		headerBuffer[11] = (byte) ((aType >>>  0) & 0xFF);
	}

 	/**
	 * Set the return code for this message.
	 *
	 * @since	UniRPC1.0
	 */
	public void writeReturnCode( int aReturnCode )
	{
		// set Data Length
		headerBuffer[16] = (byte) ((aReturnCode >>> 24) & 0xFF);
		headerBuffer[17] = (byte) ((aReturnCode >>> 16) & 0xFF);
		headerBuffer[18] = (byte) ((aReturnCode >>>  8) & 0xFF);
		headerBuffer[19] = (byte) ((aReturnCode >>>  0) & 0xFF);
	}
	
	// private methods	
	
	/**
	 * Compress the data portion of this message object.
	 * This option is currently unsupported.
	 *
	 * @since	UniRPC1.0
	 */
	private void compress()
	{
		// no compression support at this time.
		// we just trasfer buffer references in both cases.
		if ( (currentCompressionThreshold > 0 && 
			((currentArgumentCount * 8) + dataOffset) >= currentCompressionThreshold) )
		{	// compress
			// no compression being done here, this is just a stub for now.
			dataBufferCompressed = dataBufferEncrypted;
			writeHeaderLength( dataBufferCompressed.length );
			writeCompressionMask(UNIRPC_COMPRESSED);
		}
		else
		{	// don't compress
			dataBufferCompressed = dataBufferEncrypted;
			writeHeaderLength( dataBufferCompressed.length );
			writeCompressionMask(UNIRPC_UNCOMPRESSED);
		}
	}

	/**
	 * <code>dataItemOffset</code> calculates the byte offset into the data 
	 * buffer at which the data item specified by the given index is located.
	 *
	 * @since	UniRPC1.0
	 */
	private int dataItemOffset( int anIndex )
	{
		// loop through the dataInfoBuffer pulling out the length of each argument
		// before the one we are looking for. Advance the temporary dataBuffer
		// pointer until it points at the data value we are looking for.
		int tmpType;
		int tmpLength;
		int tmpDataOffset = 0;
		for ( int i = 0; i < anIndex; i++)
		{
			// get the data type of this argument
			tmpType = ( (int)	(
				(((int) dataInfoBuffer[(i * 8) + 4] & 0xFF) << 24) +
				(((int) dataInfoBuffer[(i * 8) + 5] & 0xFF) << 16) +
				(((int) dataInfoBuffer[(i * 8) + 6] & 0xFF) <<  8) +
				(((int) dataInfoBuffer[(i * 8) + 7] & 0xFF) <<  0) ) );
			// advance buffer correctly based on the data type
			switch(tmpType)
			{
				case UniRPCPacket.UNIRPC_INT:
					tmpDataOffset += 4;
					break;
				case UniRPCPacket.UNIRPC_DOUBLE:
					tmpDataOffset += 8;
					break;
				case UniRPCPacket.UNIRPC_CHAR:
				case UniRPCPacket.UNIRPC_FUNCNAME:
					// find length of char*
					tmpLength = ( (int)	(
						(((int) dataInfoBuffer[(i * 8) + 0] & 0xFF) << 24) +
						(((int) dataInfoBuffer[(i * 8) + 1] & 0xFF) << 16) +
						(((int) dataInfoBuffer[(i * 8) + 2] & 0xFF) <<  8) +
						(((int) dataInfoBuffer[(i * 8) + 3] & 0xFF) <<  0) ) );
					// add length of char* to data buffer offset
					// add 1 to adjust for the null terminator
					int tmpLengthPlusOne = tmpLength + 1;
					tmpDataOffset += tmpLengthPlusOne;
					// add buffer alignment offset
					// align buffer pointer on integer boundary for next data item
					tmpDataOffset += ((tmpLengthPlusOne + 3) & ~3) - tmpLengthPlusOne;					
					break;
				case UniRPCPacket.UNIRPC_INT_PTR:
					// find length of integer array
					tmpLength = ( (int)	(
						(((int) dataInfoBuffer[(i * 8) + 0] & 0xFF) << 24) +
						(((int) dataInfoBuffer[(i * 8) + 1] & 0xFF) << 16) +
						(((int) dataInfoBuffer[(i * 8) + 2] & 0xFF) <<  8) +
						(((int) dataInfoBuffer[(i * 8) + 3] & 0xFF) <<  0) ) );
					tmpDataOffset += 4 * tmpLength;
					break;
				case UniRPCPacket.UNIRPC_DOUBLE_PTR:
					// find length of double array
					tmpLength = ( (int)	(
						(((int) dataInfoBuffer[(i * 8) + 0] & 0xFF) << 24) +
						(((int) dataInfoBuffer[(i * 8) + 1] & 0xFF) << 16) +
						(((int) dataInfoBuffer[(i * 8) + 2] & 0xFF) <<  8) +
						(((int) dataInfoBuffer[(i * 8) + 3] & 0xFF) <<  0) ) );
					tmpDataOffset += 8 * tmpLength;
					break;
				case UniRPCPacket.UNIRPC_STRING:
					// find length of string char*
					tmpLength = ( (int)	(
						(((int) dataInfoBuffer[(i * 8) + 0] & 0xFF) << 24) +
						(((int) dataInfoBuffer[(i * 8) + 1] & 0xFF) << 16) +
						(((int) dataInfoBuffer[(i * 8) + 2] & 0xFF) <<  8) +
						(((int) dataInfoBuffer[(i * 8) + 3] & 0xFF) <<  0) ) );
					// add length of string char* to data buffer offset
					tmpDataOffset += tmpLength;
					// add buffer alignment offset
					// align buffer pointer on integer boundary for next data item
					tmpDataOffset += ((tmpLength + 3) & ~3) - tmpLength;					
					break;
				default:
					// find length of unknown type and assume it is a byte length
					tmpLength = ( (int)	(
						(((int) dataInfoBuffer[(i * 8) + 0] & 0xFF) << 24) +
						(((int) dataInfoBuffer[(i * 8) + 1] & 0xFF) << 16) +
						(((int) dataInfoBuffer[(i * 8) + 2] & 0xFF) <<  8) +
						(((int) dataInfoBuffer[(i * 8) + 3] & 0xFF) <<  0) ) );
					// add length of unknown type to data buffer offset
					tmpDataOffset += tmpLength;
					// add buffer alignment offset
					// align buffer pointer on integer boundary for next data item
					tmpDataOffset += ((tmpLength + 3) & ~3) - tmpLength;					
					break;
			}
		}
		return tmpDataOffset;
	}
						
	/**
	 * Decompress the data portion of this message object and return the number
	 * of bytes decompressed.
	 * This option is currently unsupported.
	 *
	 * @since	UniRPC1.0
	 */
	private void decompress()
	{
		// no decompression being done here, this is just a stub for now.
		if ( headerBuffer[13] == UNIRPC_COMPRESSED )
		{
			dataBufferEncrypted = dataBufferCompressed;
		}
		else
		{
			dataBufferEncrypted = dataBufferCompressed;
		}

 		dataBufferCompressed = null;
	}
						
	/**
	 * Decrypt the data message we just received.
	 * The decrypt method must be called before we can access the message
	 * arguments just received.
	 *
	 * @since	UniRPC1.0
	 */
	private void decrypt()
	{		
		byte encryptionType = readEncryptionMask();		
		int dataBufferLength = (dataBufferEncrypted.length - (currentArgumentCount * 8));
		resizeDataBuffer(dataBufferLength);
		dataOffset = dataBufferLength;

		if ( encryptionType == UniRPCTokens.UNIRPC_ENCRYPTION_XOR )
		{
			// decrypt message data
			int i = 0;
			for ( i = 0; i < (currentArgumentCount * 8); i++)
			{
				dataInfoBuffer[i] = (byte) (dataBufferEncrypted[i] ^ ((byte) currentVersion));
			}
			for ( int j = 0; j < dataOffset; j++, i++)
			{
				dataBuffer[j] = (byte) (dataBufferEncrypted[i] ^ ((byte) currentVersion));
			}
		}
		else
		{
			// no decryption performed
			System.arraycopy( dataBufferEncrypted, 0, dataInfoBuffer, 0, (currentArgumentCount * 8) );
			System.arraycopy( dataBufferEncrypted, (currentArgumentCount * 8), dataBuffer, 0, dataOffset );
		}		
		writeHeaderLength( (currentArgumentCount * 8) + dataOffset );

        // J.Mao release the temparory buffer immediately
        // if the data is very large
        dataBufferEncrypted = null;
        if (dataBufferLength > UniTokens.UNIRPC_SOCKETREAD_MAX_SIZE)
        {
            System.gc();
        }
	}
						
	/**
	 * Encrypt the data message about to be transmitted.
	 * The compress method must also be called before you transmit
	 * this message because the header length is set there
	 *
	 * @since	UniRPC1.0
	 */
	private void encrypt( byte anEncryptionType )
	{
		// size encryption buffer, this works fine as long as we used fixed length
		// encryption that matches our original data buffer length
		dataBufferEncrypted = new byte[(currentArgumentCount * 8) + dataOffset];
		if ( anEncryptionType == UniRPCTokens.UNIRPC_ENCRYPTION_XOR )
		{
			// encrypt message data
			int i = 0;
			for ( i = 0; i < (currentArgumentCount * 8); i++)
			{
				dataBufferEncrypted[i] = (byte) (dataInfoBuffer[i] ^ ((byte) currentVersion));
			}
			for ( int j = 0; j < dataOffset; j++, i++)
			{
				dataBufferEncrypted[i] = (byte) (dataBuffer[j] ^ ((byte) currentVersion));
			}
		}
		else
		{
			// no encryption specified
			System.arraycopy( dataInfoBuffer, 0, dataBufferEncrypted, 0, (currentArgumentCount * 8) );
			System.arraycopy( dataBuffer, 0, dataBufferEncrypted, (currentArgumentCount * 8), dataOffset );
		}
		// set message header encryption mask, and argument count
		writeEncryptionMask( anEncryptionType );
		writeArgumentCount( currentArgumentCount );
	}
	
	/**
	 * <code>increaseDataBuffer</code> expands the current data buffer so that
	 * it can hold an additional <code>length</code> bytes. The data buffer is
	 * expanded in 32K increments.
	 *
	 * @since	UniRPC1.0
	 */
	private void increaseDataBuffer(int length)
	{
		// inlarge data buffer
		byte[] newDataBuffer = new byte[dataBuffer.length + (((length / UNIRPC_DEFAULT_DATA_SIZE) + 1) * UNIRPC_DEFAULT_DATA_SIZE)];
		System.arraycopy( dataBuffer, 0, newDataBuffer, 0, dataBuffer.length );
		dataBuffer = newDataBuffer;
	}
	
	/**
	 * Returns the number of arguments included in the data portion of this message.
	 *
	 * @since	UniRPC1.0
	 */
	private int readArgumentCount()
	{
		return ( (int) (
				(((int) headerBuffer[20] & 0xFF) <<  8) +
				(((int) headerBuffer[21] & 0xFF) <<  0) ) );
	}
	
	/**
	 * Returns the size in bytes of the data portion of this message.
	 *
	 * @since	UniRPC1.0
	 */
	private int readHeaderLength()
	{
		return ( (int) (
				(((int) headerBuffer[4] & 0xFF) << 24) +
				(((int) headerBuffer[5] & 0xFF) << 16) +
				(((int) headerBuffer[6] & 0xFF) <<  8) +
				(((int) headerBuffer[7] & 0xFF) <<  0) ) );
	}
	
	/**
	 * Clear the data portion of this message to be reused.
	 * This should be called whenever we start building a new data Object
	 * to be sent.
	 *
	 * @since	UniRPC1.0
	 */
	private void resetData()
	{
		dataOffset = 0;
		currentArgumentCount = 0;
		isCompressed = false;
		isEncrypted = false;
		if ( dataBuffer.length > UNIRPC_DEFAULT_DATA_SIZE )
		{
			dataBuffer = new byte[UNIRPC_DEFAULT_DATA_SIZE];
		}
	}
						
	/**
	 * Reset the entire header buffer to its original state.
	 *
	 * @since	UniRPC1.0
	 */
	private void resetHeader()
	{
		// initialize the header buffer and set version number.
		for ( int i = 0; i < headerBuffer.length; i++)
		{
			headerBuffer[i] = 0x0;
		}
		// set message version number			
		headerBuffer[0] = UNIRPC_PATT_CHECK; // Version number leading bit pattern,
										// used to verify this is really for PI+(UniVerse).
		headerBuffer[1] = (byte) ((currentVersion >>> 0) & 0xFF);
		// set default message type
		headerBuffer[8] = (byte) ((UNIRPC_DEFAULT_PACKET_TYPE >>> 24) & 0xFF);
		headerBuffer[9] = (byte) ((UNIRPC_DEFAULT_PACKET_TYPE >>> 16) & 0xFF);
		headerBuffer[10] = (byte) ((UNIRPC_DEFAULT_PACKET_TYPE >>> 8) & 0xFF);
		headerBuffer[11] = (byte) ((UNIRPC_DEFAULT_PACKET_TYPE >>> 0) & 0xFF);
		// set highest supported version number
		headerBuffer[12] = (byte) ((UNIRPC_VERSION >>> 0) & 0xFF);
		// set the compression bit mask, always zero to start with.
		// It is only set if the packet is compressed
		headerBuffer[13] = UNIRPC_UNCOMPRESSED; 
		// set the default encryption bit mask
		headerBuffer[14] = UniRPCTokens.UNIRPC_ENCRYPTION_NONE; 
	}
	
	/**
	 * <code>resizeDataBuffer</code> expands the current data buffer so that
	 * it can hold the incomming <code>aLength</code> bytes. The data buffer is
	 * expanded in 32K increments.
	 *
	 * @since	UniRPC1.0
	 */
	private void resizeDataBuffer(int aLength)
	{
		// dynamicly adjust dataBuffer[] size		
		if ( aLength <= dataBuffer.length && dataBuffer.length == UNIRPC_DEFAULT_DATA_SIZE )
		{
			// default case requires no action
		}
		else if ( aLength <= dataBuffer.length)
		{
			// packet still large, just reuse buffer
		}
		else if ( aLength > dataBuffer.length)
		{
			// reset buffer because this packet is larger than last packet
			dataBuffer = new byte[(((aLength / UNIRPC_DEFAULT_DATA_SIZE) + 1) * UNIRPC_DEFAULT_DATA_SIZE)];
		}
		else
		{
			// reset buffer because last packet was large and this packet is small
			dataBuffer = new byte[UNIRPC_DEFAULT_DATA_SIZE];	
		}
	}
	
	/**
	 * Set the total number of arguments to be included with this packet.
	 *
	 * @since	UniRPC1.0
	 */
	private void writeArgumentCount( int aArgumentCount )
	{
		// set Argument Count;
		headerBuffer[20] = (byte) ((aArgumentCount >>> 8) & 0xFF);
		headerBuffer[21] = (byte) ((aArgumentCount >>> 0) & 0xFF);
	}
	
	/**
	 * Sets the compression mask used for this packet.
	 *
	 * @since	UniRPC1.0
	 */
	private void writeCompressionMask( byte aMask)
	{
		// set the compression mask for this packet
		headerBuffer[13] = aMask;
	}
	
	/**
	 * Sets the encryption mask used for this packet.
	 *
	 * @since	UniRPC1.0
	 */
	private void writeEncryptionMask( byte aMask)
	{
		// set the encryption mask for this packet
		headerBuffer[14] = aMask;
	}
	
	/**
	 * Set the total length of the data to be included with this message.
	 *
	 * @since	UniRPC1.0
	 */
	private void writeHeaderLength( int aLength )
	{
		// set Data Length
		headerBuffer[4] = (byte) ((aLength >>> 24) & 0xFF);
		headerBuffer[5] = (byte) ((aLength >>> 16) & 0xFF);
		headerBuffer[6] = (byte) ((aLength >>>  8) & 0xFF);
		headerBuffer[7] = (byte) ((aLength >>>  0) & 0xFF);
	}
								
	// Public properties
	// Private properties
	private byte[] headerBuffer;	
	private byte[] dataInfoBuffer;
	private byte[] dataBuffer;
	private byte[] dataBufferEncrypted;
	private byte[] dataBufferCompressed;
	// sequence numbers not currently used.
	// this is the general formula ( SequenceNumber + 1 ) % 8		
//	private int hdrSequenceNumber;	
	private int dataOffset; // next empty byte in dataBuffer
	// number of data arguments written to the data buffer	
	private int currentArgumentCount; 
	private int currentCompressionThreshold;
	private boolean isCompressed; 
	private boolean isEncrypted; 
	
	// We use a bit pattern in the top of the version number to check that
	// it looks like the message really is for PI+ (uniVerse).
	private final static byte UNIRPC_PATT_CHECK = 0x6c;	// equal to 01101100
	private final static int UNIRPC_HEADER_SIZE = 24; // packet header size
	// Default Packet type( currently this header field is not used)
	private final static int UNIRPC_DEFAULT_PACKET_TYPE = 0; 
	// Maximum number of arguments allowed per packet
	private final static int UNIRPC_MAX_PACKET_ARGS = 2048; 
	// default byte size of the data portion of a UniRPC packet.	
	private final static int UNIRPC_DEFAULT_DATA_SIZE = 32768; 
 	private final static int UNIRPC_INT_LENGTH = 1; // integer argument length
	private final static int UNIRPC_DOUBLE_LENGTH = 1; // double argument length
	private final static byte UNIRPC_UNCOMPRESSED = 0x00; // compression NOT used
	private final static byte UNIRPC_COMPRESSED = 0x01; // compression used
}	/* UniRPCPMessage class */

 
