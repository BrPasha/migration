/*************************************************************************
 *
 * UniRPCPacketException.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.unirpc;
 

/**
 * <code>UniRPCPacketException</code> is the primary class used for handling UniVerse RPC 
 * exceptions and errors for the UniRPCPacket class.
 * This exception class is derived from the UniVerse RPC exception 
 * class, <code>UniRPCException</code>.
 * 
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIRPC 1.0
 */

public class UniRPCPacketException extends UniRPCException
{
	/**
	 * Constructs a UniRPCPacketException object. Calls its super class constructor.
	 *
	 * @since	UniRPC1.0
	 */
	UniRPCPacketException()
	{
		super();
	}

	/**
	 * Constructs a UniRPCPacketException object. Calls its super class constructor.
	 *
   * @param		aErrorNumber   UniVerse error number
	 * @since	UniRPC1.0
	 */
	UniRPCPacketException( int aErrorNumber )
	{
		super( aErrorNumber );
	}
	/**
	 * Constructs a UniRPCPacketException object. Calls its super class constructor.
	 *
   * @param		aError   English error description
   * @param		aErrorNumber   UniVerse error number
	 * @since	UniRPC1.0
	 */
	UniRPCPacketException(String aError, int aErrorNumber)
	{
		super(aError, aErrorNumber);
	}	
}