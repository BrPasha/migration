/*************************************************************************
 *
 * UniRPC.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * ? Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 02/06/04 E3912 JFM changed the GB18030 flag to clientencoding
 * 12/05/03 E3912 JFM add GB18030 flag
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.unirpc;
 
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Writer;

/**
 * UniRPC is the base class for all the asjava.unirpc package classes.
 * The primary purpose of this class is to provide a location for generic
 * package information used by all the sub classes. Currently this class 
 * contains version and debug information.
 * 
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIRPC 1.0
 */
public class UniRPC extends Object
{	
	public static final String clientEncoding=System.getProperty("clientencoding");
	
	/**
	 * Constructs a UniRPC object.
	 *
	 * @since	UniRPC1.0
	 */
	public UniRPC()
	{
		debugLevel = 0;
		debugWriter = null;
		currentVersion = UNIRPC_VERSION_LOWEST;
		currentVersionProxy = UNIRPC_VERSION_LOWEST;
		if ( System.out != null )
		{
			debugWriter = new PrintWriter( System.out, true );
		}
		else
		{
			debugWriter = null;
		}
	}
	
	/**
	 * The current debug level for this class.
	 *
	 * @return	the debug level.
	 * @see	#setDebugLevel
	 * @since	UniRPC1.0
	 */
	public int getDebugLevel()
	{
		return debugLevel;
	}
	
	/**
	 * Returns the current debug writer that all debug output is written
	 * to for this class.
	 *
	 * @return	the debug <code>PrintWriter</code>
	 * @see	#setDebugWriter(java.io.PrintStream)
	 * @see	#setDebugWriter(java.io.Writer)
	 * @since	UniRPC1.0
	 */
	public PrintWriter getDebugWriter()
	{
		return debugWriter;
	}
	
	/**
	 * Returns the highest RPC version supported by this package.
	 *
	 * @return	the version
	 * @see	#UNIRPC_VERSION
	 * @since	UniRPC1.0
	 */
	public int getVersion()
	{
		return UNIRPC_VERSION;
	}
	
	/**
	 * Returns the current RPC version set for this object.
	 *
	 * @return	the current version
	 * @see #setVersionCurrent
	 * @since	UniRPC1.0
	 */
	public int getVersionCurrent()
	{
		return currentVersion;
	}
	
	/**
	 * Returns the current proxy RPC version set for this object.
	 *
	 * @return	the current proxy version
	 * @see #setVersionCurrentProxy
	 * @since	UniRPC1.0
	 */
	public int getVersionCurrentProxy()
	{
		return currentVersionProxy;
	}
	
	/**
	 * Returns the lowest RPC version supported by this package.
	 *
	 * @return	the base version
	 * @see	#UNIRPC_VERSION_LOWEST
	 * @since	UniRPC1.0
	 */
	public int getVersionLowest()
	{
		return UNIRPC_VERSION_LOWEST;
	}
		
	/**
	 * Returns TRUE if compression is supported.
	 * Returns FALSE if compression is NOT supported.
	 *
	 * @return	<code>true</code> if compression supported or
	 *					<code>false</code> if not supported.
	 * @since	UniRPC1.0
	 */
	public boolean isCompressionSupported()
	{
		// currently compression is NOT supported.
		return false;
	}
		
	/**
	 * Returns TRUE if encryption is supported.
	 * Returns FALSE if encryption is NOT supported.
	 *
	 * @return	<code>true</code> if encryption supported or
	 *					<code>false</code> if not supported.
	 * @since	UniRPC1.0
	 */
	public boolean isEncryptionSupported()
	{
		if (currentVersion > 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * Sets the debug level for this class.
	 *
	 * @param aLevel	the new debug level
	 * @see	#getDebugLevel
	 * @since	UniRPC1.0
	 */
	public void setDebugLevel( int aLevel )
	{
		debugLevel = aLevel;
	}
	
	/**
	 * The debug print stream that all debug output is written
	 * to for this class.
	 *
	 * @param aPrintStream	the new debug output stream
	 * @see	#getDebugWriter()
	 * @since	UniRPC1.0
	 */
	public void setDebugWriter( PrintStream aPrintStream )
	{
		debugWriter = new PrintWriter(aPrintStream, true);
	}
	
	/**
	 * Sets the debug writer that all debug output is written
	 * to for this class.
	 *
	 * @see #getDebugWriter()
	 * @since	UniRPC1.0
	 */
	public void setDebugWriter( Writer aWriter )
	{
		debugWriter = new PrintWriter( aWriter, true );
	}
	
	/**
	 * The current Version for this object.
	 *
	 * @param aVersion	the new version for this object
	 * @see #getVersionCurrent
	 * @since	UniRPC1.0
	 */
	public void setVersionCurrent( int aVersion )
	{
		currentVersion = aVersion;
	}
	
	/**
	 * The current proxy version for this object.
	 *
	 * @param aVersion	the new proxy version for this object
	 * @see #getVersionCurrentProxy
	 * @since	UniRPC1.0
	 */
	public void setVersionCurrentProxy( int aVersion )
	{
		currentVersionProxy = aVersion;
	}
		
	// protected properties.	
	/**
	 * Default(highest) RPC package version. Currently defined as version <code>2</code>.
	 *
	 * @see #getVersion()
	 * @since UniRPC1.0
	 */
	protected final static int UNIRPC_VERSION = 2;
	
	/**
	 * Lowest RPC package version. Currently defined as version <code>1</code>.
	 *
	 * @see #getVersionLowest()
	 * @since UniRPC1.0
	 */
	protected final static int UNIRPC_VERSION_LOWEST = 1;
	protected int currentVersion;	// the RPC version we are operating under
	protected int currentVersionProxy;	// the RPC version the proxy server is operating under
	protected int debugLevel;	// the current debug level
	protected PrintWriter debugWriter;	// the output stream for all debug output
} /* UniRPC class */
