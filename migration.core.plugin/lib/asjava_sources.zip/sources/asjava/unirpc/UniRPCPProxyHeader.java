/*************************************************************************
 *
 * UniRPCPProxyHeader.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/
 
package asjava.unirpc;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InterruptedIOException;

import asjava.uniclientlibs.UniTokens;

/**
 * UniRPCPProxyHeader is a packet class which wraps a standard UniRPC data packet so that 
 * the packet in question can be routed through a proxy server.  
 * <p>
 * <pre>
 * Version 2, UniRPC Message Proxy Header data structure.
 * |--------16 Bits---------|
 * |--------------------32 Bits----------------------|
 * ===================================================
 * |----Version-------------|--------SeqNo-----------|\
 * |-High Ver.--|--Future---|--Proxy Header Length---| \
 * |--------------------Header Type------------------|  | Message Proxy Header - 24 Bytes
 * |---------------Connection Number-----------------|  |
 * |-----------------Packet Length-------------------| /
 * |-------------------Future Use--------------------|/
 * ===================================================
 * </pre>
 *
 * @version	1.0
 * @author	Occhio Orsini
 * @see	UniRPCPPacket
 * @see	UniRPCPProxyHeader
 * @see	UniRPCPMessage
 * @since	UNIRPC 1.0
 */

public class UniRPCPProxyHeader extends UniRPC
{	
	/**
	 * Constructs a packet proxy header for use in transmitting data
	 * through UniRPC with a UniRPCPacket Object.
	 *
	 * @since	UniRPC1.0
	 */
	public UniRPCPProxyHeader()
	{
		proxyHeaderBuffer = new byte[UNIRPC_PROXY_HEADER_SIZE];
		hdrSequenceNumber	= 0;	// sequence numbers not currently used.
							// this is the general formula ( SequenceNumber + 1 ) % 8
	// initialize the header buffer
		for ( int i = 0; i < UNIRPC_PROXY_HEADER_SIZE; i++ )
		{
			proxyHeaderBuffer[i] = 0x0;			
		}
		// set proxy header version number			
		proxyHeaderBuffer[0] = UNIRPC_PATT_CHECK; // Version number leading bit pattern,
										// used to verify this is really for PI+(UniVerse).
		proxyHeaderBuffer[1] = (byte) ((currentVersion >>> 0) & 0xFF);
		// set highest supported version number
		proxyHeaderBuffer[4] = (byte) ((UNIRPC_VERSION >>> 0) & 0xFF);
		// set proxy header size			
		proxyHeaderBuffer[6] = (byte) ((UNIRPC_PROXY_HEADER_SIZE >>> 8) & 0xFF);
		proxyHeaderBuffer[7] = (byte) ((UNIRPC_PROXY_HEADER_SIZE >>> 0) & 0xFF);		
		writeHeaderType(UniRPCTokens.UNIRPC_PROXY_HEADER_TYPE_DEFAULT);
}	/* UniRPCPProxyHeader() */
	
	/**
	 * Writes the entire packet contents out to a <code>PrintStream</code> 
	 * formated in english.
	 *
	 * @since	UniRPC1.0
	 */
	public void dump( )
	{
		if (debugLevel > 5)
		{
			debugWriter.println("Proxy Packet Header Detail:");
			if (debugLevel > 7)
			{
				debugWriter.print(" proxyHeaderBuffer=0x");
				for ( int i = 0; i < proxyHeaderBuffer.length; i++)
				{
					String temp = Integer.toHexString((int) proxyHeaderBuffer[i] & 0xFF);
					if ( temp.length() == 1 )
					{
						debugWriter.print("0" + temp);
					}
					else if ( temp.length() == 2 )
					{
						debugWriter.print(temp);				
					}
					else
					{
						debugWriter.print("(" + temp + ")");				
					}
					if( (((i+1)%4) == 0) )
					{
						debugWriter.print(" ");
					}
				}
				debugWriter.println();
			} /* debug > 7 */
			debugWriter.print(" VersionInHex=0x");
			for ( int i = 0; i < 2; i++)
			{
				String temp = Integer.toHexString((int) proxyHeaderBuffer[i] & 0xFF);
				if ( temp.length() == 1 )
				{
					debugWriter.print("0" + temp);
				}
				else
				{
					debugWriter.print(temp);				
				}
				if( (((i+1)%4) == 0) )
				{
					debugWriter.print(" ");
				}
			}
			debugWriter.println();
			debugWriter.println(" Sequence=" + ( (int) (
				(((int) proxyHeaderBuffer[2] & 0xFF) <<  8) +
				(((int) proxyHeaderBuffer[3] & 0xFF) <<  0) ) ) );
			debugWriter.println(" Highest Supported Version=" + ( (int)
				(((int) proxyHeaderBuffer[4] & 0xFF) << 0) ) );
			debugWriter.println(" Future Use=0x" + 
				( Integer.toHexString((int) proxyHeaderBuffer[5] & 0xFF) ) );
			debugWriter.println(" Proxy Header length=" + ( (int) (
				(((int) proxyHeaderBuffer[6] & 0xFF) <<  8) +
				(((int) proxyHeaderBuffer[7] & 0xFF) <<  0) ) ) );
			debugWriter.println(" Header Type=" + ( (int) (
				(((int) proxyHeaderBuffer[8] & 0xFF) << 24) +
				(((int) proxyHeaderBuffer[9] & 0xFF) << 16) +
				(((int) proxyHeaderBuffer[10] & 0xFF) <<  8) +
				(((int) proxyHeaderBuffer[11] & 0xFF) <<  0) ) ) );
			debugWriter.println(" ConnectionID=" + ( (int) (
				(((int) proxyHeaderBuffer[12] & 0xFF) << 24) +
				(((int) proxyHeaderBuffer[13] & 0xFF) << 16) +
				(((int) proxyHeaderBuffer[14] & 0xFF) <<  8) +
				(((int) proxyHeaderBuffer[15] & 0xFF) <<  0) ) ) );
			debugWriter.println(" Length=" + ( (int) (
				(((int) proxyHeaderBuffer[16] & 0xFF) << 24) +
				(((int) proxyHeaderBuffer[17] & 0xFF) << 16) +
				(((int) proxyHeaderBuffer[18] & 0xFF) <<  8) +
				(((int) proxyHeaderBuffer[19] & 0xFF) <<  0) ) ) );
		} /* debug > 5 */			
	} /* dump() */
		
	/**
	 * Get the total length of the data packet following this proxy header.
	 *
	 * @since	UniRPC1.0
	 */
	public int getLength()
	{
		// return the data length
		return ( (int) (
			(((int) proxyHeaderBuffer[16] & 0xFF) << 24) +
			(((int) proxyHeaderBuffer[17] & 0xFF) << 16) +
			(((int) proxyHeaderBuffer[18] & 0xFF) <<  8) +
			(((int) proxyHeaderBuffer[19] & 0xFF) <<  0) ) ); 
	}
	
	/**
	 * Returns the size in bytes of this proxy header.
	 * The size is the network size of the proxy header.
	 *
	 * @return	the size of this proxy header
	 * @since	UniRPC1.0
	 */
	public int getSize()
	{
		// return size of proxy header
		return UNIRPC_PROXY_HEADER_SIZE;
	}
	
	/**
	 * Get the connection ID of this packet.
	 *
	 * @since	UniRPC1.0
	 */
	public int readConnection( )
	{
		// return the connection;
		return ( (int) (
			(((int) proxyHeaderBuffer[12] & 0xFF) << 24) +
			(((int) proxyHeaderBuffer[13] & 0xFF) << 16) +
			(((int) proxyHeaderBuffer[14] & 0xFF) <<  8) +
			(((int) proxyHeaderBuffer[15] & 0xFF) <<  0) ) );
	}
	
	/**
	 * Return the type of this proxy header.
	 *
	 * @since	UniRPC1.0
	 */
	public int readHeaderType()
	{
		// return the header type
		return ( (int) (
			(((int) proxyHeaderBuffer[8] & 0xFF) << 24) +
			(((int) proxyHeaderBuffer[9] & 0xFF) << 16) +
			(((int) proxyHeaderBuffer[10] & 0xFF) <<  8) +
			(((int) proxyHeaderBuffer[11] & 0xFF) <<  0) ) );
	}
	
	/**
	 * Return the proxy header version.
	 *
	 * @since	UniRPC1.0
	 */
	public int readHeaderVersion()
	{
		// proxy RPC version
		return ( ( (int) 
				(((int) proxyHeaderBuffer[1] & 0xFF) <<  0) ) );
	}
	
	/**
	 * Return the highest proxy header version supported.
	 *
	 * @since	UniRPC1.0
	 */
	public int readHeaderVersionHighest()
	{
		// this method needs completion
		return ( ( (int) 
				(((int) proxyHeaderBuffer[4] & 0xFF) <<  0) ) );
	}
		
	/**
	 * Reads the proxy header portion of this packet from the given data stream.
	 * Will throw an exception if there is any network problem or if the packet 
	 * is not complete.
	 *
   * @exception  UniRPCPacketException if any errors occur when receiving
   *             a proxy header.
	 * @since	UniRPC1.0
	 */
	public void receive( DataInputStream aDataIn ) throws UniRPCPacketException
	{
		if ( aDataIn == null )
		{
			throw new UniRPCPacketException( "The DataInputStream is dead.", UniRPCTokens.UNIRPC_NO_CONNECTION);
		}
		try
		{
			aDataIn.readFully( proxyHeaderBuffer );
			if (debugLevel > 3)
			{
				dump();
			}		
		}
		catch ( InterruptedIOException e )
		{
			throw new UniRPCPacketException( e.getMessage(), UniTokens.UNIRPC_TIMEOUT);
		}
		catch ( IOException e )
		{
			throw new UniRPCPacketException( e.getMessage(), UniRPCTokens.UNIRPC_FAILED);
		}
	} /* receive()*/
		
	/**
	 * Writes the proxy header portion of this packet out to the given data stream.
	 * Will throw an exception if there is any network problem or if the packet 
	 * is not complete.
	 *
   * @exception  UniRPCPacketException if any errors occur when sending
   *             this proxy header.
	 * @since	UniRPC1.0
	 */
	public void send( DataOutputStream aDataOut ) throws UniRPCPacketException
	{
		if ( aDataOut == null )
		{
			throw new UniRPCPacketException( "The DataOutputStream is dead.", UniRPCTokens.UNIRPC_NO_CONNECTION);
		}
		if (debugLevel > 3)
		{
			dump();
		}				
		try
		{
			aDataOut.write( proxyHeaderBuffer );
		}
		catch ( IOException e)
		{
			throw new UniRPCPacketException( e.getMessage(), UniRPCTokens.UNIRPC_FAILED);			
		}
	} /* send() */
	
	/**
	 * Set the total length of the data to be included with this packet.
	 *
	 * @since	UniRPC1.0
	 */
	public void setLength( int aLength )
	{
		// set Data Length
		proxyHeaderBuffer[16] = (byte) ((aLength >>> 24) & 0xFF);
		proxyHeaderBuffer[17] = (byte) ((aLength >>> 16) & 0xFF);
		proxyHeaderBuffer[18] = (byte) ((aLength >>>  8) & 0xFF);
		proxyHeaderBuffer[19] = (byte) ((aLength >>>  0) & 0xFF);
	}
	
	/**
	 * Set the destination host for this packet.
	 *
	 * @since	UniRPC1.0
	 */
	public void writeConnection( int aHost )
	{
		// set host
		proxyHeaderBuffer[12] = (byte) ((aHost >>> 24) & 0xFF);
		proxyHeaderBuffer[13] = (byte) ((aHost >>> 16) & 0xFF);
		proxyHeaderBuffer[14] = (byte) ((aHost >>>  8) & 0xFF);
		proxyHeaderBuffer[15] = (byte) ((aHost >>>  0) & 0xFF);
	}
	
	/**
	 * Set the proxy header type.
	 *
	 * @since	UniRPC1.0
	 */
	public void writeHeaderType( int aType )
	{
		// set the header type
		proxyHeaderBuffer[8]  = (byte) ((aType >>> 24) & 0xFF);
		proxyHeaderBuffer[9]  = (byte) ((aType >>> 16) & 0xFF);
		proxyHeaderBuffer[10] = (byte) ((aType >>>  8) & 0xFF);
		proxyHeaderBuffer[11] = (byte) ((aType >>>  0) & 0xFF);
	}
	
	// private methods
	
	/**
	 * Clear entire header buffer, reset version numbers.
	 *
	 * @since	UniRPC1.0
	 */
	private void clear()
	{
		// reset header buffer and set version number.
		for ( int i = 0; i < proxyHeaderBuffer.length; i++)
		{
			proxyHeaderBuffer[i] = 0x0;
		}
		// set proxy header version number			
		proxyHeaderBuffer[0] = UNIRPC_PATT_CHECK; // Version number leading bit pattern,
										// used to verify this is really for PI+(UniVerse).
		proxyHeaderBuffer[1] = (byte) ((currentVersion >>> 0) & 0xFF);
		// set highest supported version number
		proxyHeaderBuffer[4] = (byte) ((UNIRPC_VERSION >>> 0) & 0xFF);
		// set proxy header size			
		proxyHeaderBuffer[6] = (byte) ((UNIRPC_PROXY_HEADER_SIZE >>> 8) & 0xFF);
		proxyHeaderBuffer[7] = (byte) ((UNIRPC_PROXY_HEADER_SIZE >>> 0) & 0xFF);
		writeHeaderType(UniRPCTokens.UNIRPC_PROXY_HEADER_TYPE_DEFAULT);
	}
								
	// Private properties
	private byte[] proxyHeaderBuffer;
	private int hdrSequenceNumber;	
	// UniRPC static attributes
	// We use a bit pattern in the top of the version number to check that
	// it looks like the message really is for PI+ (uniVerse).
	private final static byte UNIRPC_PATT_CHECK = 0x6c;	// equal to 01101100
	private final static int UNIRPC_PROXY_HEADER_SIZE = 24; // packet header size
}	/* UniRPCPacket class */

 