/*************************************************************************
 *
 * UniRPCPacket.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * ? Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 12/05/03 E3912 JFM added writeChars() for JDBC Gb18030
 * 05/15/02 L.Qiang added write( int, byte[]), also enabled DataOutputStream.flush() 
 * 10/11/01 J.Mao added getArgumentCount(),readBytes( ) for JDBC
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.unirpc;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Writer;

import asjava.uniclientlibs.UniString;
import asjava.uniobjects.UniObjectsTokens;

/**
 * UniRPCPacket is the container class for data transfered with UniRPC.
 * An instance of this class can contain and be used for the transport
 * of any type of data supported by Version 1 or 2 of UniRPC.
 * <p>
 * <pre>
 * Version 1, UniRPC Packet structure.
 * |--------16 Bits---------|
 * |--------------------32 Bits----------------------|
 * ===================================================
 * |-------Version----------|--------SeqNo-----------|\
 * |---------------------Length----------------------| \
 * |----------------------Type-----------------------|  \ Message Header - 24 Bytes
 * |--------------------Timestamp--------------------|  /
 * |-------------------Return code-------------------| /
 * |-------Arg Count--------|------Proc Length-------|/
 * ===================================================
 * |----------Procedure name (unformated)------------|\
 * |-------------------::::::::::--------------------| \
 * |------------------Arg 1 Length-------------------|  \
 * |-------------------Arg 1 Type--------------------|   \
 * |-------------------::::::::::--------------------|    \ Message Body - (Length) Bytes
 * |------------------Arg n Length-------------------|    /
 * |-------------------Arg n Type--------------------|   /
 * |---------------Arg 1 Data (unformated)-----------|  /
 * |-------------------::::::::::--------------------| /
 * |---------------Arg n Data (unformated)-----------|/
 * ===================================================
 * </pre>
 * <p>
 * <pre>
 * Version 2, UniRPC Packet structure.
 * |--------16 Bits---------|
 * |--------------------32 Bits----------------------|
 * ===================================================
 * |----Version-------------|--------SeqNo-----------|\
 * |-High Ver.--|--Future---|--Proxy Header Length---| \
 * |--------------------Header Type------------------|  | Message Proxy Header - 24 Bytes
 * |---------------Connection Number-----------------|  |
 * |-----------------Packet Length-------------------| /
 * |-------------------Future Use--------------------|/
 * ===================================================
 * |-------Version----------|--------SeqNo-----------|\
 * |---------------------Length----------------------| \
 * |----------------------Type-----------------------|  \ Message Header - 24 Bytes
 * |-High Ver.--|--C. Mask--|--E. Mask--|---Future---|  /
 * |-------------------Return code-------------------| /
 * |-------Arg Count--------|------Proc Length-------|/
 * ===================================================
 * |----------Procedure name (unformated)------------|\
 * |-------------------::::::::::--------------------| \
 * |------------------Arg 1 Length-------------------|  \
 * |-------------------Arg 1 Type--------------------|   \
 * |-------------------::::::::::--------------------|    \ Message Body - (Length) Bytes
 * |------------------Arg n Length-------------------|    /
 * |-------------------Arg n Type--------------------|   /
 * |---------------Arg 1 Data (unformated)-----------|  /
 * |-------------------::::::::::--------------------| /
 * |---------------Arg n Data (unformated)-----------|/
 * ===================================================
 * </pre>
 *
 * NOTE:Version 1 of UniRPC does not officially support Procedure names.
 * It also does not support packet sequencing or packet timestamping.
 * Currently this Java client only supports the TCP/IP transport type.
 * The C version of UniRPC supports LAN pipes transport type as well.
 * <p>
 * NOTE:Version 2 of UniRPC does not officially support Procedure names.
 * It also does not support packet sequencing or packet timestamping.
 * The timestamp data field will be removed and the 4 bytes reused as layed
 * out in the version 2 diagram. Currently this Java client only supports
 * the TCP/IP transport type.
 * The C version of UniRPC supports LAN pipes transport type as well.
 *
 * @version	1.0
 * @author	Occhio Orsini
 * @see asjava.unirpc.UniRPCConnection
 * @since	UNIRPC 1.0
 */

public class UniRPCPacket extends UniRPC
{
	/**
	 * Constructs an empty packet for future use in transmitting data
	 * through UniRPC.
	 *
	 * @see	#UniRPCPacket(asjava.unirpc.UniRPCConnection)
	 * @since	UniRPC1.0
	 */
	public UniRPCPacket()
	{
		// this constructor is primarily for use as a bootstrap
		// packet for initialization and version support
		isProxyPacket = false;
		messageObject = new UniRPCPMessage();
	}	/* UniRPCPacket() */

	/**
	 * Constructs an empty packet for future use in transmitting data
	 * through UniRPC. The connection object gives us access to information
	 * about the connection that we need.
	 *
   * @param		aConnection   a connected connection.
   * @exception  UniRPCPacketException if any errors occur when creating this
   *             packet.
	 * @see	#UniRPCPacket()
	 * @since	UniRPC1.0
	 */
	public UniRPCPacket( UniRPCConnection aConnection) throws UniRPCPacketException
	{
		// we require that the connection is valid,
		// this way, we know what version we are supporting
		if ( (aConnection == null) || !aConnection.isConnected() )
		{
			throw new UniRPCPacketException( "An open connection is required for this constructor.",
				UniRPCTokens.UNIRPC_NO_CONNECTION);
		}
		currentConnection = aConnection;
		debugLevel = aConnection.getDebugLevel();
		debugWriter = aConnection.getDebugWriter();
		currentVersion = aConnection.getVersionCurrent();
		currentVersionProxy = aConnection.getVersionCurrentProxy();
		if ( aConnection.isProxyConnection() &&
       (aConnection.getSSLMode() != UniObjectsTokens.SECURE_SESSION) &&
       (aConnection.getSSLMode() != UniObjectsTokens.SECURE_PROXY_SESSION)
       )
		{
			proxyHeaderObject = new UniRPCPProxyHeader();
			proxyHeaderObject.setDebugLevel( debugLevel );
			proxyHeaderObject.setDebugWriter( debugWriter );
			proxyHeaderObject.setVersionCurrentProxy( currentVersionProxy );
			isProxyPacket = true;
		}
		else
		{
			isProxyPacket = false;
		}
		messageObject = new UniRPCPMessage();
		messageObject.setDebugLevel( debugLevel );
		messageObject.setDebugWriter( debugWriter );
		messageObject.setVersionCurrent( currentVersion );
		setCompressionThreshold( aConnection.getCompressionThreshold() );
	}	/* UniRPCPacket( UniRPCConnection ) */

	// public methods

	/**
	 * Writes the entire packet contents out to the debug <code>PrintStream</code>
	 * formated in human readable form. This method is ment to be used for debugging.
	 *
	 * @since	UniRPC1.0
	 */
	public void dump()
	{
		if ( isProxyPacket )
		{
			proxyHeaderObject.dump();
		}
		messageObject.dump();
	}

    public int getArgumentCount()
    {
        return messageObject.getArgumentCount();
    }

	/**
	 * Returns the threshold in bytes, beyond which all packets will be
	 * compressed. This feature not supported in UniRPC 1.0.
	 *
	 * @return	the compression threshold
	 * @see #setCompressionThreshold(int)
	 * @since	UniRPC1.0
	 */
	public int getCompressionThreshold()
	{
		return messageObject.getCompressionThreshold();
	}

	/**
	 * Get a reference to the connection used when constructing this packet.
	 *
	 * @return	a connection reference
	 * @see	#UniRPCPacket
	 * @since	UniRPC1.0
	 */
	public UniRPCConnection getConnection()
	{
		return currentConnection;
	}

	/**
	 * Get the encryption type used on this packet.
	 *
	 * @return	the encryption type
	 * @since	UniRPC1.0
	 */
	public byte getEncryptionType()
	{
		return messageObject.readEncryptionMask();
	}

	/**
	 * Get a reference to the message object.
	 *
	 * @return	the message object
	 * @see	#setMessage
	 * @since	UniRPC1.0
	 */
	public UniRPCPMessage getMessage()
	{
		return messageObject;
	}

	/**
	 * Get the message type of this packet.
	 *
	 * @return	the message type
	 * @see	#setMessageType(int)
	 * @since	UniRPC1.0
	 */
	public int getMessageType()
	{
		return messageObject.readMessageType();
	}

	/**
	 * Get a reference to the packet proxy header object.
	 *
	 * @return	the proxy header object
	 * @see	#setProxyHeader
	 * @since	UniRPC1.0
	 */
	public UniRPCPProxyHeader getProxyHeader()
	{
		return proxyHeaderObject;
	}

	/**
	 * Returns the size in bytes of this packet. The size includes the network
	 * size of the proxy header if this is a proxy packet. The network size of
	 * the message before encryption or compression are applied.
	 *
	 * @return	the size of this packet
	 * @since	UniRPC1.0
	 */
	public int getSize()
	{
		int size = 0;
		if ( isProxyPacket )
		{
			size += proxyHeaderObject.getSize();
		}
		size += messageObject.getSize();
		return size;
	}

	/**
	 * Read char array data item from the packet at the specified index.
	 *
	 * @param		anIndex		the argument index
	 * @return	a char array argument
   * @exception  UniRPCPacketException if any errors occur when reading the
   *             specified argument.
	 * @see	#write(int, char[])
	 * @since	UniRPC1.0
	 */
	public char[] readCharArray( int anIndex ) throws UniRPCPacketException
	{
		return messageObject.readCharArray( anIndex );
	}

	/**
	 * Read double data item from the packet at the specified index.
	 *
	 * @param		anIndex		the argument index
	 * @return	a double argument
   * @exception  UniRPCPacketException if any errors occur when reading the
   *             specified argument.
	 * @see	#write(int, double)
	 * @since	UniRPC1.0
	 */
	public double readDouble( int anIndex ) throws UniRPCPacketException
	{
		return messageObject.readDouble( anIndex );
	}

	/**
	 * Read double array data item from the packet at the specified index.
	 *
	 * @param		anIndex		the argument index
	 * @return	a double array argument
   * @exception  UniRPCPacketException if any errors occur when reading the
   *             specified argument.
	 * @see	#write(int, double[])
	 * @since	UniRPC1.0
	 */
	public double[] readDoubleArray( int anIndex ) throws UniRPCPacketException
	{
		return messageObject.readDoubleArray( anIndex );
	}

	/**
	 * Read integer data item from the packet at the specified index.
	 *
	 * @param		anIndex		the argument index
	 * @return	an integer argument
   * @exception  UniRPCPacketException if any errors occur when reading the
   *             specified argument.
	 * @see	#write(int, int)
	 * @since	UniRPC1.0
	 */
	public int readInteger( int anIndex ) throws UniRPCPacketException
	{
		return messageObject.readInteger( anIndex );
	}

	/**
	 * Read integer array data item from the packet at the specified index.
	 *
	 * @param		anIndex		the argument index
	 * @return	an integer array argument
   * @exception  UniRPCPacketException if any errors occur when reading the
   *             specified argument.
	 * @see	#write(int, int[])
	 * @since	UniRPC1.0
	 */
	public int[] readIntegerArray( int anIndex ) throws UniRPCPacketException
	{
		return messageObject.readIntegerArray( anIndex );
	}

	/**
	 * Read String data item from the packet at the specified index.
	 *
	 * @param		anIndex		the argument index
	 * @return	a <code>String</code> argument
   * @exception  UniRPCPacketException if any errors occur when reading the
   *             specified argument.
	 * @see	#write(int, java.lang.String)
	 * @since	UniRPC1.0
	 */
	public String readString( int anIndex ) throws UniRPCPacketException
	{
		return messageObject.readString( anIndex );
	}

    public byte[] readBytes( int anIndex ) throws UniRPCPacketException
    {
        return messageObject.readBytes( anIndex );
    }
    
	/**
	 * Read the data type of the item at the specified index.
	 *
	 * @param		anIndex		the argument index
	 * @return	the argument type
   * @exception  UniRPCPacketException if any errors occur when reading the
   *             specified argument.
	 * @since	UniRPC1.0
	 */
	public int readType( int anIndex ) throws UniRPCPacketException
	{
		return messageObject.readType( anIndex );
	}

	/**
	 * Reads this packet in from the given data stream. Will throw an
	 * exception if there is any network problem or if the packet can
	 * not be built correctly.
	 *
	 * @param		aDataIn		the data input stream
   * @exception  UniRPCPacketException if any errors occur when receiving
   *             a new packet.
	 * @see	#send(java.io.DataInputStream)
	 * @since	UniRPC1.0
	 */
	public void receive( DataInputStream aDataIn ) throws UniRPCPacketException
	{
		if (debugLevel > 3)
		{
			debugWriter.println("INCOMING PACKET:");
		}
		if ( isProxyPacket )
		{
			proxyHeaderObject.receive( aDataIn );
		}
		messageObject.receive( aDataIn );
	}

	/**
	 * Writes this packet out to the given data stream. Will throw an
	 * exception if there is any network problem or if the packet is
	 * not complete.
	 *
	 * @param		aDataOut		the data output stream
   * @exception  UniRPCPacketException if any errors occur when sending
   *             this packet.
	 * @see	#receive(java.io.DataInputStream)
	 * @since	UniRPC1.0
	 */
	public void send( DataOutputStream aDataOut, byte anEncryptionMask, int aConnectionID ) throws UniRPCPacketException
	{
		if (debugLevel > 3)
		{
			debugWriter.println("OUTGOING PACKET:");
		}

		if ( isProxyPacket )
		{
			proxyHeaderObject.setLength( messageObject.getLength( anEncryptionMask ) );
			proxyHeaderObject.writeConnection( aConnectionID );
			proxyHeaderObject.send( aDataOut );
		}
		messageObject.send( aDataOut, anEncryptionMask );
		/* we do not need to call flush() for a standard data stream with this version of the jdk
		 * because flush is not implemented; Now it is implemented.Qiang
		 */
		try
		{
			aDataOut.flush();
		}
		catch (IOException e)
		{
			throw new UniRPCPacketException( e.getMessage(), UniRPCTokens.UNIRPC_FAILED);
		}
	}

	/**
	 * Sets the threshold in bytes, beyond which all packets will be
	 * compressed. This change will only take effect on newly constructed
	 * packets. All existing packets need to be individualy updated.
	 * This feature not supported in UniRPC 1.0.
	 *
	 * @param		aThreshold		compression threshold.
   * @exception  UniRPCPacketException if any errors occur when resetting
   *             the compression threshold for this packet.
	 * @see #getCompressionThreshold()
	 * @since	UniRPC1.0
	 */
	public void setCompressionThreshold( int aThreshold ) throws UniRPCPacketException
	{
		messageObject.setCompressionThreshold(aThreshold);
	}

	/**
	 * Sets the debug level for this object and all the objects it contains.
	 *
	 * @param aLevel	the new debug level
	 * @see asjava.unirpc.UniRPC#getDebugLevel()
	 * @since	UniRPC1.0
	 */
	public void setDebugLevel( int aLevel )
	{
		super.setDebugLevel( aLevel );
		if ( isProxyPacket )
		{
			proxyHeaderObject.setDebugLevel( aLevel );
		}
		messageObject.setDebugLevel( aLevel );
	}

	/**
	 * Sets the debug writer that all debug output is written
	 * to for this object and all the objects it contains.
	 *
	 * @param aWriter	the new debug writer
	 * @see asjava.unirpc.UniRPC#getDebugWriter()
	 * @since	UniRPC1.0
	 */
	public void setDebugWriter( Writer aWriter )
	{
		super.setDebugWriter( aWriter );
		if ( isProxyPacket )
		{
			proxyHeaderObject.setDebugWriter( aWriter );
		}
		messageObject.setDebugWriter( aWriter );
	}

	/**
	 * Set a new packet message object.
	 *
	 * @param aMessage	a new message object
	 * @see #getMessage()
	 * @since	UniRPC1.0
	 */
	public void setMessage( UniRPCPMessage aMessage )
	{
		messageObject = aMessage;
		// set version, debug for new message object
		messageObject.setDebugLevel( debugLevel );
		messageObject.setDebugWriter( debugWriter );
		messageObject.setVersionCurrent( currentVersion );
	}

	/**
	 * Set the message type of this packet.
	 *
	 * @param		aType		the new message type
	 * @see	#getMessageType()
	 * @since	UniRPC1.0
	 */
	public void setMessageType( int aType )
	{
		messageObject.writeMessageType(aType);
	}

	/**
	 * Set a new packet proxy header object.
	 *
	 * @param aProxyHeader	a new proxy header object
	 * @see #getProxyHeader()
	 * @since	UniRPC1.0
	 */
	public void setProxyHeader( UniRPCPProxyHeader aProxyHeader )
	{
		proxyHeaderObject = aProxyHeader;
		// set version, debug for new proxy header
		proxyHeaderObject.setDebugLevel( debugLevel );
		proxyHeaderObject.setDebugWriter( debugWriter );
		proxyHeaderObject.setVersionCurrentProxy( currentVersionProxy );
		isProxyPacket = true;
	}

  public void unsetProxyHeader()
  {
    isProxyPacket = false;
    proxyHeaderObject = null;
  }

	/**
	 * Write a character array into the packet at the specified index.
	 * No data encryption.
	 *
	 * @param		anIndex		the argument index
	 * @param		aCharArray	an array of character
   * @exception  UniRPCPacketException if any errors occur when writing
   *             this argument to the packet.
	 * @see #readCharArray
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, char[] aCharArray ) throws UniRPCPacketException
	{
		messageObject.write( anIndex, aCharArray );
	}

	/**
	 * Write double data item into the packet at the specified index.
	 * No data encryption.
	 *
	 * @param		anIndex		the argument index
	 * @param		aDouble		a double value
   * @exception  UniRPCPacketException if any errors occur when writing
   *             this argument to the packet.
	 * @see #readDouble
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, double aDouble ) throws UniRPCPacketException
	{
		messageObject.write( anIndex, aDouble );
	}

	/**
	 * Write double array item into the packet at the specified index.
	 * If the encryption boolean is true then the data portion of this argument
	 * will be encrypted.
	 *
	 * @param		anIndex		the argument index
	 * @param		aDouble		an array of double values
	 * @param		anEncrypt		if <code>true</code> encrypt, otherwise don't
   * @exception  UniRPCPacketException if any errors occur when writing
   *             this argument to the packet.
	 * @see #readDoubleArray
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, double[] aDouble ) throws UniRPCPacketException
	{
		messageObject.write( anIndex, aDouble );
	}

	/**
	 * Write integer data item into the packet at the specified index.
	 * No data encryption.
	 *
	 * @param		anIndex		the argument index
	 * @param		anInteger		an integer value
   * @exception  UniRPCPacketException if any errors occur when writing
   *             this argument to the packet.
	 * @see #readInteger
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, int anInteger ) throws UniRPCPacketException
	{
		messageObject.write( anIndex, anInteger );
	}

	/**
	 * Write Integer data item into the packet at the specified index.
	 * No data encryption.
	 *
	 * @param		anIndex		the argument index
	 * @param		anInteger		an <code>Integer</code> value
   * @exception  UniRPCPacketException if any errors occur when writing
   *             this argument to the packet.
	 * @see #readInteger
 	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, Integer anInteger ) throws UniRPCPacketException
	{
		messageObject.write( anIndex, anInteger.intValue() );
	}

	/**
	 * Write integer array item into the packet at the specified index.
	 * If the encryption boolean is true then the data portion of this argument
	 * will be encrypted.
	 *
	 * @param		anIndex		the argument index
	 * @param		anInteger		an array of intger values
	 * @param		anEncrypt		if <code>true</code> encrypt, otherwise don't
   * @exception  UniRPCPacketException if any errors occur when writing
   *             this argument to the packet.
	 * @see #readIntegerArray
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, int[] anInteger ) throws UniRPCPacketException
	{
		messageObject.write( anIndex, anInteger );
	}

	/**
	 * Write String data item into the packet at the specified index.
	 * No data encryption.
	 *
	 * @param		anIndex		the argument index
	 * @param		aString		a <code>String</code> object
   * @exception  UniRPCPacketException if any errors occur when writing
   *             this argument to the packet.
	 * @see #readString
	 * @since	UniRPC1.0
	 */
	public void write( int anIndex, String aString ) throws UniRPCPacketException
	{
		messageObject.write( anIndex, aString );
	}

	/**
	 * Writes a byte array (represents a String) data item into the packet at
	 * the specified index.
	 * No data encryption.
	 *
	 * @param		anIndex		the argument index
	 * @param		bArray		a <code>byte</code> array
	 * @exception  UniRPCPacketException if any errors occur when writing
	 *             this argument to the packet.
	 * @see #write(int, String)
	 * @since	UniRPC1.2
	 */
	public void write( int anIndex, byte[] bArray) throws UniRPCPacketException
	{
		messageObject.write( anIndex, bArray) ;
	}

	public void writeChars(int anIndex, byte[] bArray) throws UniRPCPacketException
	{
		messageObject.writeChars(anIndex, bArray) ;
	}

	/**
	 * Write UniString data item into the packet at the specified index.
	 * No data encryption.
	 *
	 * @param		anIndex		the argument index
	 * @param		aString		a <code>UniString</code> object
   * @exception  UniRPCPacketException if any errors occur when writing
   *             this argument to the packet.
	 * @see #readUniString
	 * @since	UniRPC1.0
	 */
	protected void write( int anIndex, UniString aString ) throws UniRPCPacketException
	{
		messageObject.write( anIndex, aString );
	}

	// Public properties

	/**
	 * Integer arguments use this argument type.
	 *
	 * @see #readType(int)
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_INT = 0;

	/**
	 * Double arguments use this argument type.
	 *
	 * @see #readType(int)
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_DOUBLE = 1;

	/**
	 * Character array arguments use this argument type.
	 *
	 * @see #readType(int)
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_CHAR = 2;

	/**
	 * UniVerse string arguments use this argument type.
	 *
	 * @see #readType(int)
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_STRING = 3;

	/**
	 * Integer array arguments use this argument type.
	 *
	 * @see #readType(int)
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_INT_PTR = 4; // integer pointer argument type

	/**
	 * Double array arguments use this argument type.
	 *
	 * @see #readType(int)
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_DOUBLE_PTR = 5; // double pointer argument type

	/**
	 * Function name arguments use this argument type.
	 *
	 * @see #readType(int)
	 * @since UniRPC1.0
	 */
	public final static int UNIRPC_FUNCNAME = 6; // function name argument type

	// Private properties
	private boolean isProxyPacket;	// does this
	private int currentVersionProxy = UNIRPC_VERSION_LOWEST;
	// the connection this packet was initialized with
	private UniRPCConnection currentConnection;
	private UniRPCPProxyHeader proxyHeaderObject; // packet proxy header
	private UniRPCPMessage messageObject;	// packet message
}	/* UniRPCPacket class */


