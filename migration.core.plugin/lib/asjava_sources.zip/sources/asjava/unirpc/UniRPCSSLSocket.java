/*************************************************************************
 *
 * UniRPCSSLSocket.java
 * 
 *       IBM Confidential
 *       OCO Source Materials
 *       Copyright (C) IBM Corp.  1993, 2005
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 04/12/10 12737 CUI removed the 32898 work-around. Server changed.
 * 09/14/05 32898 CUI added setEnabledProtocols() in makeSecure() to work
 *	around OpenSSL 0.9.7e bug that make SUN JRE 1.4.2 failure in SSL.
 *	No we force to use only SSLv3.
*************************************************************************/
package asjava.unirpc;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import asjava.uniobjects.UniSSLDescriptor;

public class UniRPCSSLSocket extends Object {


  public static Socket  createSSLSocket(InetAddress host, int port, UniSSLDescriptor ussld)
  throws IOException
  {

      SSLSocketFactory sf;
      SSLSocket ss;
      Socket socket = null;
      if (ussld == null || ussld.getSSLSocketFactory() == null)
      {
        // create a default socket factory

        sf = (SSLSocketFactory)SSLSocketFactory.getDefault();
      }
      else
      {
        // create a factory out of SSLContext
        sf = ussld.getSSLSocketFactory();
      }

      socket = sf.createSocket(host, port);

      // set enabled cipher suites

      if ((ussld == null) || (ussld.getEnabledCipherSuites() == null))
      {
        ss = (SSLSocket) socket;
        ss.setEnabledCipherSuites(sf.getSupportedCipherSuites());
      }
      else
      {
        ss = (SSLSocket) socket;
        ss.setEnabledCipherSuites(ussld.getEnabledCipherSuites());
      }
      // start handshake ???
      ss.startHandshake();

      return socket;

  }

   /*
   * Converts normal UniRPCSocket to a secure socket
  */

  public static Socket makeSecure(Socket sock, String host, int port, UniSSLDescriptor ussld)
  throws IOException
  {
    SSLSocketFactory sf;
    SSLSocket ss;
    Socket socket = null;
    if (ussld == null || ussld.getSSLSocketFactory() == null)
    {
      // create a default socket factory
      sf = (SSLSocketFactory)SSLSocketFactory.getDefault();
    }
    else
    {
      // create a factory out of SSLContext
      sf = ussld.getSSLSocketFactory();
    }
    socket = sf.createSocket(sock, host, port, true);

    // set enabled cipher suites

    if ((ussld == null) || (ussld.getEnabledCipherSuites() == null))
    {
      ss = (SSLSocket) socket;
      ss.setEnabledCipherSuites(sf.getSupportedCipherSuites());
    }
    else
    {
      ss = (SSLSocket) socket;
      ss.setEnabledCipherSuites(ussld.getEnabledCipherSuites());
    }

	// E32898 09/14/05 SUN JRE default TLSv1 won't work with OpenSSL0.9.7e
	// E12737 04/12/10 A change has been put into U2 server that solved the 
	// TLSv1 problem the following code was to work-around. Now U2 servers
	// should be able to handle SUN JRE TLSv1 handshake (which was flawed
	// but OpenSSL can work-around it with certain flags). 
	// String prots[];
	// prots = new String[1];

	// prots[0] = new String("SSLv3");
	// ss.setEnabledProtocols(prots);

    // start handshake ???
    ss.startHandshake();
    return socket;
  }
}

