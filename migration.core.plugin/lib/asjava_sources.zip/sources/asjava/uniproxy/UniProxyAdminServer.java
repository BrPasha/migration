/*************************************************************************
 *
 * UniProxyAdminServer.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.uniproxy;

import asjava.unirpc.*; 
import java.net.*;
import java.io.*;
import java.util.*;
import java.text.*;
 
/**
 * The <code>UniProxyAdminServer</code> class listens for and receives proxy 
 * administrative commands. Once a command is received, the administrative server
 * manages the proxy server execution of that command and send the results back to 
 * the administrative client that submitted the command. This class is designed to run
 * as a seperate thread within the same java virtual machine as and launched by the 
 * proxy server.
 *
 * Notes: This administrative server is single threaded and will only process one
 *        administrative request at a time.
 *
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIPROXY 1.0
 */ 
public class UniProxyAdminServer extends java.lang.Thread
{	
	/**
	 * Base constructor for <code>UniProxyAdminServer</code>.
	 *
	 * @since	UniProxy1.0
	 */
 	private UniProxyAdminServer()
 	{
 	}
 	
	/**
	 * Constructor for <code>UniProxyAdminServer</code>. Takes as an argument a
	 * reference to a proxy server instance within this Java VM.
	 *
	 * @param		aProxyServer		reference to a proxy server
	 * @since	UniProxy1.0
	 */
 	public UniProxyAdminServer(UniProxyServer aProxyServer) throws UniProxyException
 	{
 		// check validity of server reference
 		if ( aProxyServer == null )
 		{
			throw new UniProxyException( "A valid UniProxyServer reference is required.",UniProxyTokens.UNIPROXY_ERROR_NULL_REFERENCE);
		}
 		// maintain link to proxy server here
		proxyServer = aProxyServer;
		debugLevel = proxyServer.getConfiguration().getDebugLevel();
		adminListenPort = proxyServer.getConfiguration().getAdminPort();
 		// set time format for logging code
 		logTime = new SimpleDateFormat("yy.MM.dd-HH.mm.ss");
 	}
	
	/**
	 * Sets up the socket connection with the administrative client.
	 *
	 * @param		aSocket		admin. client socket
   * @exception  UniProxyException if any network errors occur.
	 * @since	UniProxy1.0
	 */
	public void connectAdminClient(Socket aSocket) throws UniProxyException
	{
		if (debugLevel > 2)
		{
			writeLog("Connecting to proxy admin client...");
		}
		try
		{
			// configure socket and set references to it
			proxyAdminClient = aSocket;
			proxyAdminClient.setSoTimeout( currentTimeoutSeconds * 1000);
			proxyAdminClient.setSoLinger( false, -1 );
			proxyAdminClient.setTcpNoDelay( true );				
			proxyAdminDataOut = new DataOutputStream(proxyAdminClient.getOutputStream());
			proxyAdminDataIn = new DataInputStream(proxyAdminClient.getInputStream());
		}
		catch( Exception e)
		{
			throw new UniProxyException( e.getMessage(),UniProxyTokens.UNIPROXY_ERROR_NETWORK_IO);
		}
	} /* connectAdminClient() */
	
	/**
	 * Terminates the socket connection with the administrative client.
	 *
   * @exception  UniProxyException if any network errors occur.
	 * @since	UniProxy1.0
	 */
	public void disconnectAdminClient() throws UniProxyException
	{
		if (debugLevel > 2)
		{
			writeLog("Disconnecting from proxy admin client...");
		}
		try
		{
			// close socket and IO streams
			if ( proxyAdminDataOut != null )
			{
				proxyAdminDataOut.close();
				proxyAdminDataOut = null;
			}
			if ( proxyAdminDataIn != null )
			{
				proxyAdminDataIn.close();
				proxyAdminDataIn = null;
			}
			if ( proxyAdminClient != null )
			{
				proxyAdminClient.close();
				proxyAdminClient = null;
			}
		}
		catch( IOException e)
		{
			throw new UniProxyException( e.toString(), UniProxyTokens.UNIPROXY_ERROR_NETWORK_IO);
		}
	} /* disconnectAdminClient() */

	/**
	 * Returns the proxy admin server port for this <code>UniProxyAdminServer</code> object.
	 * This is the TCP/IP port that <code>UniProxyAdminServer</code> listens for incomming client 
	 * connections on.
	 *
	 * @return	TCP/IP port 
	 * @see #setPort()
	 * @since	UniProxy1.0
	 */
	public int getPort()
	{
		return adminListenPort;
	}
	
	/**
	 * Receive and process one proxy administration command from the administrative client.
	 *
   * @exception  UniProxyException if any network errors occur or if the proxy server
   *               command fails to successfully complete.
	 * @since	UniProxy1.0
	 */
	public void processCommand() throws UniProxyException
	{
		if (debugLevel > 2)
		{
			writeLog("Processing the current administrative command.");
		}
		outPacket = new UniRPCPacket();
		inPacket = new UniRPCPacket();
		try
		{
			// get command from admin client
	  	inPacket.receive(proxyAdminDataIn);
	  	int resultVer = verifyVersion(inPacket.readInteger(0));
	  	int resultAuth = proxyServer.getConfiguration().authenticateAdmin(inPacket.readString(1));
	  	if ( (resultAuth == 0) && (resultVer == 0) )
	  	{
		  	currentCommandCode = inPacket.readInteger(2);
		  	currentCommandText = inPacket.readString(3);	  	
	  		try
	  		{
			 		// run requested command
 					switch( currentCommandCode )
					{
 						case UniProxyTokens.UNIPROXY_COMMAND_SUSPEND:
 							proxyServer.suspendServer();
 							break;
			 			case UniProxyTokens.UNIPROXY_COMMAND_RESTART:
 							proxyServer.restart();
				 			break;
	 					case UniProxyTokens.UNIPROXY_COMMAND_SHUTDOWN:
 							proxyServer.shutdown();
 							isShutdown = true;
 							break;
		 				case UniProxyTokens.UNIPROXY_COMMAND_SHUTDOWNFAST:
 							proxyServer.shutdownFast();
 							isShutdown = true;
	 						break;
	 					case UniProxyTokens.UNIPROXY_COMMAND_RECONFIGURE:
 							proxyServer.reconfigure();
 							break;
		 				case UniProxyTokens.UNIPROXY_COMMAND_STATUS:
 							proxyServer.status();
 							break;
	 					default:
 							// unsupported command
 							throw new UniProxyException("This administrative command is not supported", UniProxyTokens.UNIPROXY_ERROR_ADMIN);
			 		}
			 		// command successful
					outPacket.write(0, 0);	
		 		}
		 		catch (UniProxyException e)
	 			{
	 				// command failed
					outPacket.write(0, e.getErrorCode()); 
					outPacket.write(1, e.getMessage()); // exception message
		 		}
			}
			else
			{
 				// version unsupported or access denied
 				if (resultVer != 0)
 				{
 					// version unsupported response
					outPacket.write(0, UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN); 
					outPacket.write(1, "Unsupported proxy administration client version!");
					writeLog("Error: Unsupported proxy administration client version!");
 				}
 				else
 				{
 					// access denied response
					outPacket.write(0, UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN); 
					outPacket.write(1, "Invalid proxy administration access token!");
					writeLog("Error: Invalid proxy administration access token!");
 				}
			}
	  	
	  	outPacket.send(proxyAdminDataOut, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
	  }
	  catch (UniRPCPacketException e)
	  {
			throw new UniProxyException( e.getMessage(), e.getErrorCode());
	  }
	} /* processCommand() */
		
	/**
	 * Run the proxy administrative server thread.
	 *
	 * @since	UniProxy1.0
	 */
	public void run()
	{
		ServerSocket adminServer;
		
		try
		{
			if (debugLevel > 2)
			{
				writeLog("Starting proxy admin server.");
			}
			adminServer = new ServerSocket(adminListenPort);
			if (debugLevel > 4)
			{
				writeLog("Accepting proxy admin connections on port "
					+ adminServer.getLocalPort());
			}
								
			while (true && !isShutdown) 
			{
				// receive administrative command, process it, and send response to
				// the client
				connectAdminClient(adminServer.accept());
				processCommand();
				disconnectAdminClient();
				if (currentCommandCode == 1)
				{
					writeLog( "***I was wondering if the code path went here!!!" );
					break;
				}
			}
			// we must have received a shutdown command so lets shutdown the admin server
			try
			{
				adminServer.close();
			}
			catch(IOException e)
			{
				// let it go
			}
		}
		catch (IOException e)
		{
			writeLog( e.toString() );
			writeLog( "Proxy admin server exception! All administrative features disabled!" );
			writeLog( "Shutting down proxy server!!!" );
			proxyServer.shutdown();
		}
		catch (UniProxyException e)
		{
			writeLog( e.getMessage() );
			writeLog( "Proxy admin server exception! All administrative features disabled!" );
			writeLog( "Shutting down proxy server!!!" );
			proxyServer.shutdown();
		}
	} /* run() */
	
	/**
	 * Sets the proxy admin server port for this <code>UniProxyAdminServer</code> object.
	 * This is the TCP/IP port that <code>UniProxyAdminServer</code> listens for incomming client 
	 * connections on.
	 *
	 * @param		aPort		TCP/IP port
	 * @see #getPort()
	 * @since	UniProxy1.0
	 */
	public void setPort(int aPort)
	{
		adminListenPort = aPort;
	}
	
	/**
	 * Verify that the admin client version is supported by this proxy admin server.
	 *
	 * @param		aVersion		proxy admin client version
	 * @since	UniProxy1.0
	 */
	public int verifyVersion(int aVersion)
	{
		// make sure this client version is supported
		if ( aVersion > UniProxyTokens.UNIPROXY_ADMIN_VERSION)
		{
			// we do NOT support this version
			return -1;
		}
		else
		{
			// we support this version
			return 0;
		}
	}
			
	/**
	 * Write the specified ASCII text to the proxy server log file. 
	 * Prepend the text with the time, date and an "-A" to designate that this message 
	 * was generated by <code>UniProxyAdminServer</code>.
	 *
	 * @param		aLogEntry		ASCII log message
	 * @since	UniProxy1.0
	 */
	public void writeLog(String aLogEntry)
	{
		proxyServer.writeLogRaw( logTime.format(new Date(System.currentTimeMillis())) 
			+ "-A" + " " + aLogEntry);
	}

	// these variables are for instances of the UniProxyAdminServer class
	private boolean isShutdown = false;
	private int debugLevel;
	private SimpleDateFormat logTime;
	private UniProxyServer proxyServer;
	private Socket proxyAdminClient;
	private DataOutputStream proxyAdminDataOut;
	private DataInputStream proxyAdminDataIn;
	private UniRPCPacket outPacket, inPacket;
	private int adminListenPort = -1;
	private int currentTimeoutSeconds = 0;	
	private int currentCommandCode = 0;	
	private String currentCommandText = "";
}