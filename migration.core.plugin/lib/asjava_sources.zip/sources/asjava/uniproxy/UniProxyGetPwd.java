package asjava.uniproxy;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;


public class UniProxyGetPwd
{
	private Dialog d;
	public String pwd;
	private boolean okFlag;
	private TextField tf1, tf2;
  private Label lem1, lem2;

	public  UniProxyGetPwd(String title, String message, String fldVal, Point loc)
	{
    Frame frame;
    GridLayout grlm;

    grlm = new GridLayout(4, 2);

    frame = new Frame();

		okFlag = false;

		d = new Dialog (frame, title);
		d.setResizable(true);
    d.setModal(true);
    d.setLayout(grlm);


		// Another event listener, this one to handle window close
//		d.addWindowListener(new WindowAdapter() {
//		public void windowClosing(WindowEvent e)
//		{
//			d.hide();
//			d.dispose();
//		}

//		});

		if (loc != null)
		{
			d.setLocation(loc.x, loc.y);
		}
		else
		{

		}

		grlm.setHgap(5);
		grlm.setVgap(5);

    lem1 = new Label("              ");
    d.add(lem1);

    lem2 = new Label("              ");
    d.add(lem2);


		Label l1;
		l1 = new Label("Enter " + message + " password:");
		d.add(l1);





		tf1 = new TextField();
		tf1.setText(fldVal);
    tf1.setEchoCharacter('X');
		d.add(tf1);

    Label l2;
		l2 = new Label("Reenter password:");
		d.add(l2);





		tf2 = new TextField();
		tf2.setText(fldVal);
    tf2.setEchoCharacter('X');
		d.add(tf2);



		Button bOk = new Button("Ok");

		bOk.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				// get the source object
				Button b = (Button)e.getSource();
        String pwd1;
        String pwd2;

				d.hide();
				pwd1 = tf1.getText();
        pwd2 = tf2.getText();
        if ((pwd1 != null) && (pwd2 != null))
        {
          if (pwd1.equals(pwd2) == true)
          {
            d.dispose();
            pwd = tf1.getText();
            okFlag = true;
          }
          else
          {
            tf1.setText("");
            tf2.setText("");
            lem1.setForeground(Color.red);
            lem1.setText("Error, please enter again!");
            d.show();
          }
        }

			}
		}
		);
		d.add(bOk);
		d.pack();
		d.show();
    // loop untill a user enters password
    while (this.okFlag == false)
    {
        try
        {
            java.lang.Thread.sleep(500);
        }
        catch (java.lang.InterruptedException e)
        {
            ;
        }

    }
    // write the password into the file
    try
    {
        FileWriter fw = new FileWriter(UniProxyTokens.UNIPROXY_TMP_PFNAME); 
        fw.write(pwd, 0, pwd.length());
        fw.close();
    }
    catch (java.io.IOException e)
    {
        ;
    }
    System.exit(0);


}

public static void main (String [] args)
{
    UniProxyGetPwd upgp = new UniProxyGetPwd("keyfile", "keyfile", 
"", new Point(200, 200));

}
}

