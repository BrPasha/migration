/*************************************************************************
 *
 * UniProxyConfiguration.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 10/15/01 955026 JFM authentication should succeed when ACCESS_SERVER and
 *                 ACCESS_TOKEN_SERVER are missing, because it means
 *                 ACCESS_TOKEN applies to any server
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.uniproxy ;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.util.Vector;

import asjava.unirpc.UniRPCTokens;

/**
 * The <code>UniProxyConfiguration</code> class stores and manages one proxy configuration.
 * The class was designed to be used by one instance of the <code>UniProxyServer</code> class
 * and all its companion classes. At this time the class is read only. That means
 * that the class reads its configuration information from an ASCII text file but
 * you can't use this class to modify or serialize the proxy server configuration.
 *
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIPROXY 1.0
 */

public class UniProxyConfiguration extends java.lang.Object
{
	/**
	 * Constructs a <code>UniProxyConfiguration</code> object with default settings.
	 *
	 * @since	UniProxy1.0
	 */
	public UniProxyConfiguration()
	{
		configLocation = "uniproxy.config";
		accessServer = new Vector();
		accessTokenServer = new Object[0][0];
	}

	/**
	 * Verifies that the specified access token is the one specified in the
	 * loaded proxy configuration. This method is used by the <code>UniProxyAdminClient</code> and
	 * <code>UniProxyAdminServer</code> classes to verify if an admin client is allowed to
	 * execute administrative commands.
	 *
	 * @param		aAdminAccessToken		an access token
	 * @return	"0" if passed. "-1" if failed
   * @exception  UniProxyException if any errors occur when verifying the access
   *               token. Failing authentication is NOT an error.
	 * @since	UniProxy1.0
	 */
	public int authenticateAdmin(String aAdminAccessToken) throws UniProxyException
	{
		if( adminAccessToken.equals(aAdminAccessToken) )
		{
			// authentication successful
			return 0;
		}
		else
		{
			// authentication failed
			return -1;
		}
	}

	/**
	 * Verifies that the specified access token is one specified in the
	 * loaded proxy configuration. This method is used by the <code>UniProxyConnection</code>
	 * class to verify if a client has authorized access to
	 * this proxy server as well as the systems it protects.
	 *
	 * @param		aAccessToken		an access token
	 * @param		aServer			a Universe server
	 * @return	"0" if passed. "-1" if failed
   * @exception  UniProxyException if any errors occur when verifying the access
   *               token. Failing authentication is NOT an error.
	 * @since	UniProxy1.0
	 */
	public int authenticateClient(String aAccessToken, String aServer) throws UniProxyException
	{
		int result = -1;
		boolean isServerAuth = true;
		// basic check to see if we need to authenticate
		if( accessTokenServer.length == 0 && accessServer.size() == 0 )
		{
			return 0;
		}
		if ( aAccessToken != null)
		{
			// lookup token
			for(int i = 0; i < accessTokenServer.length;i++)
			{
				if( ((String)accessTokenServer[i][0]).equals(aAccessToken) )
				{
					// passed access token check
					result = 0;
					// lookup paired server
					if( ((Vector)accessTokenServer[i][1]).size() > 0 )
					{
						if( ((Vector)accessTokenServer[i][1]).contains(aServer) )
						{
				    	// passed server check
							result = 0;
						}
						else
						{
							// failed accessToken & server authentication
							result = -1;
						}
						isServerAuth = false;
					}
					break;
				}
			}
			// failed accessToken authentication
		}
		if ( aServer != null && result == 0 && isServerAuth)
		{
			// lookup server
			// 955026 fixed to courtesy of Double Xia
			if (accessServer.size() == 0 || accessServer.contains(aServer))
			{
	    	// passed server check
				result = 0;
			}
			else
			{
				// failed server authentication
				result = -1;
			}
		}
		return result;
	}

	/**
	 * Writes the entire proxy configuration out to the <code>UniProxyServer</code>
	 * log file in human readable form.
	 *
	 * @since	UniProxy1.0
	 */
	public void dump(UniProxyServer aServer)
	{
		// write out the contents of this configuration object
		if ( aServer != null )
		{
			aServer.writeLog("Proxy server configuration:");
			aServer.writeLog("   Configuration Path:" + configLocation);
			aServer.writeLog("   ACCESS_TOKEN_SERVER=");
			for( int i = 0; i < accessTokenServer.length; i++)
			{
				aServer.writeLog("      Token:" + (String)accessTokenServer[i][0] + " Server:" + (Vector)accessTokenServer[i][1]);
			}
			aServer.writeLog("   ACCESS_SERVER=" + accessServer);
			aServer.writeLog("   ADMIN_ACCESS_TOKEN=" + adminAccessToken);
			aServer.writeLog("   ADMIN_PORT=" + adminPort);
			aServer.writeLog("   BUFFER_SIZE=" + bufferSize);
			aServer.writeLog("   DEBUG_LEVEL=" + debugLevel);
      aServer.writeLog("   KEYSTORE_TYPE = " + this.kstype);
			aServer.writeLog("   MAX_CONNECTIONS=" + maxConnections);
			aServer.writeLog("   MAX_MULTIPLEXED_SERVERS=" + maxMultiplexedServers);
			aServer.writeLog("   NAME_LOG=" + logFileName);
			aServer.writeLog("   NETWORK_TIMEOUT=" + networkTimeout);
			aServer.writeLog("   PATH_LOG=" + logFilePath);
			aServer.writeLog("   PROXY_PORT=" + serverPort);
      aServer.writeLog("   PROXY_SSL_FLAG=" + this.proxySSLFlag);
      aServer.writeLog("   PROXY_SSL_PORT=" + serverSSLPort);
      aServer.writeLog("   SSL_KEY_FILE=" + proxySSLKeyFile);
      aServer.writeLog("   SSL_TRUST_FILE= " + proxySSLTrustFile);
      aServer.writeLog("   SSL_CLIENT_AUTHENTICATION = " + this.proxySSLClientAuthentication);
      aServer.writeLog("   TRUSTSTORE_TYPE = " + this.tstype);
      aServer.writeLog("   PWD_METHOD = " + this.pwdmethod);

		}
		else
		{
			System.out.println("A null UniProxyServer reference was passed into UniProxyConfiguration.dump().");
		}
	} /* dump() */

	/**
	 * Gets the admin port for this configuration.
	 * This is the TCP/IP port that <code>UniProxyAdminServer</code> listens for admin requests on.
	 *
	 * @return	TCP/IP port
	 * @see asjava.uniproxy.UniProxyAdminServer#setPort()
	 * @see asjava.uniproxy.UniProxyAdminServer#getPort()
	 * @since	UniProxy1.0
	 */
	public int getAdminPort()
	{
		return adminPort;
	}

	/**
	 * Gets the admin access token for this configuration.
	 *
	 * @return	admin access token
	 * @see #authenticateAdmin()
	 * @since	UniProxy1.0
	 */
	public String getAdminAccessToken()
	{
		return adminAccessToken;
	}

	/**
	 * Gets the client connection buffer size in bytes.
	 *
	 * @return	buffer size
	 * @since	UniProxy1.0
	 */
	public int getBufferSize()
	{
		return bufferSize;
	}

	/**
	 * Gets the debug level for this configuration.
	 *
	 * @return	debug level
	 * @since	UniProxy1.0
	 */
	public int getDebugLevel()
	{
		return debugLevel;
	}

	/**
	 * Gets the maximum number of connections that a <code>UniProxyServer</code> instance
	 * using this configuration will simultaniously support.
	 *
	 * @return	number of connections
	 * @since	UniProxy1.0
	 */
	public int getMaxConnections()
	{
		return maxConnections;
	}

	/**
	 * Gets the maximum number of servers that a <code>UniProxyConnection</code> instance
	 * using this configuration will simultaniously multiplex connections to.
	 *
	 * @return	number of server connections
	 * @since	UniProxy1.0
	 */
	public int getMaxMultiplexedServers()
	{
		return maxMultiplexedServers;
	}

	/**
	 * Gets the currently defined location of this configuration.
	 *
	 * @return	file path
	 * @see #setLocation()
	 * @since	UniProxy1.0
	 */
	public String getLocation()
	{
		return configLocation;
	}

	/**
	 * Gets the name to be used for the <code>UniProxyServer</code> log file.
	 *
	 * @return	file name
	 * @since	UniProxy1.0
	 */
	public String getNameLog()
	{
		return logFileName;
	}

	/**
	 * Gets the network timeout to use for all network connections maintained by
	 * <code>UniProxyConnection</code> and UniProxyAdminServer instances.
	 *
	 * @return	network timeout in milliseconds
	 * @since	UniProxy1.0
	 */
	public int getNetworkTimeout()
	{
		return networkTimeout;
	}

	/**
	 * Gets the path under which the <code>UniProxyServer</code> log file should
	 * be stored.
	 *
	 * @return	file system path
	 * @since	UniProxy1.0
	 */
	public String getPathLog()
	{
		return logFilePath;
	}

	/**
	 * Gets the proxy server port for this configuration.
	 * This is the TCP/IP port that <code>UniProxyServer</code> listens for incomming client
	 * connections on.
	 *
	 * @return	TCP/IP port
	 * @since	UniProxy1.0
	 */
	public int getPort()
	{
		return serverPort;
	}

  public boolean getProxySSLFlag()
  {
    return (proxySSLFlag);
  }

  public boolean getProxySSLOnlyFlag()
  {
    return (proxySSLOnlyFlag);
  }

  public int getSSLPort()
	{
		return(serverSSLPort);
	}

  public String getProxySSLKeyFile()
  {
    return(this.proxySSLKeyFile);
  }

  public String getProxySSLKeyFilePwd()
  {
    return(this.proxySSLKeyFilePwd);
  }

  public String getProxySSLTrustFile()
  {
    return(this.proxySSLTrustFile);
  }

  public boolean getProxySSLClientAuthentication()
  {
    return(this.proxySSLClientAuthentication);
  }

  public String getProxyKeystoreType()
  {
    return(this.kstype);
  }

  public String getProxyTruststoreType()
  {
    return(this.tstype);
  }

  public String getProxyPwdMethod()
  {
    return (this.pwdmethod);
  }






	/**
	 * Uses the location specified by setLocation to load a proxy configuration from.
	 *
   * @exception  UniProxyException if the load process fails for some catastrophic reason.
	 * @since	UniProxy1.0
	 */
	public void load() throws UniProxyException
	{
		// IMPORTANT, WE NEED TO ADD SUPPORT FOR PARSING NAMES WITH
		// NO VALUES. TO DO THIS ADD EOL AS TOKEN AND TRAP FOR IT

		// this method opens a configuration file and parses and loads the configuration.
		StreamTokenizer parser;
		FileReader configIOStream;

		// open configuration file
		try
		{
			configIOStream = new FileReader(configLocation);
			parser = new StreamTokenizer(configIOStream);
		}
		catch (FileNotFoundException e)
		{
			throw new UniProxyException(e.toString(),UniProxyTokens.UNIPROXY_ERROR_LOADING_CONFIGURATION);
		}
		catch (IOException e)
		{
			throw new UniProxyException(e.toString(),UniProxyTokens.UNIPROXY_ERROR_LOADING_CONFIGURATION);
		}
		
		// configure StreamTokenizer
		parser.commentChar('#');
		parser.slashSlashComments(false);
		parser.slashStarComments(false);
		parser.whitespaceChars('=','=');
		parser.quoteChar('"');
		parser.wordChars('.','.');
        parser.wordChars('\\', '\\');
        parser.wordChars('/', '/');
        parser.wordChars(':', ':');
        parser.wordChars('_', '_');

		// parse proxy configuration file
		try
		{
			int status;
			String tokenName;
			
			for(status = parser.nextToken();
				status != StreamTokenizer.TT_EOF;
				status = parser.nextToken())
			{
				// store tokens here
				if ( parser.ttype == StreamTokenizer.TT_WORD )
				{
					tokenName = parser.sval;
				}
				else
				{
					throw new UniProxyException("Parsed a number when a word was expected.",1);
				}
				if(tokenName.equals("ACCESS_TOKEN"))
				{
					// read an access token
					status = parser.nextToken();
					Object[][] newAccessTokenServer = new Object[accessTokenServer.length + 1][2];

					System.arraycopy(accessTokenServer,0,newAccessTokenServer,0,accessTokenServer.length);
					
					accessTokenServer = newAccessTokenServer;
					if ( parser.ttype == StreamTokenizer.TT_WORD )
					{
						accessTokenServer[accessTokenServer.length - 1][0] = new String(parser.sval);
						accessTokenServer[accessTokenServer.length - 1][1] = new Vector();
					}
					else
					{
						accessTokenServer[accessTokenServer.length - 1][0] = new String(Double.toString(parser.nval));
						accessTokenServer[accessTokenServer.length - 1][1] = new Vector();
					}
				}
				else if(tokenName.equals("ACCESS_TOKEN_SERVER"))
				{
					// read an access token server
					// this server will be paired with whatever the previous access token
					// parsed was.
					status = parser.nextToken();
					// check to make sure we have already parsed an access token
					if ( accessTokenServer.length > 0 )
					{
						if ( parser.ttype == StreamTokenizer.TT_WORD )
						{
							((Vector)accessTokenServer[accessTokenServer.length - 1][1]).addElement(parser.sval);
						}
						else
						{
							((Vector)accessTokenServer[accessTokenServer.length - 1][1]).addElement(Double.toString(parser.nval));
						}
					}
				}
				else if(tokenName.equals("ACCESS_SERVER"))
				{
					// read an access server
					status = parser.nextToken();
					if ( parser.ttype == StreamTokenizer.TT_WORD )
					{
						accessServer.addElement(parser.sval);
					}
					else
					{
						accessServer.addElement(Double.toString(parser.nval));
					}
				}
				else if(tokenName.equals("ADMIN_ACCESS_TOKEN"))
				{
					// read the admin access token
					status = parser.nextToken();
					if ( parser.ttype == StreamTokenizer.TT_WORD )
					{
						adminAccessToken = parser.sval;
					}
					else
					{
						adminAccessToken = Double.toString(parser.nval);
					}
				}
				else if(tokenName.equals("ADMIN_PORT"))
				{
					// read the admin port
					status = parser.nextToken();
					adminPort = (new Integer((int)parser.nval)).intValue();
				}
				else if(tokenName.equals("BUFFER_SIZE"))
				{
					// read the connection buffer size
					status = parser.nextToken();
					int j = (new Integer((int)parser.nval)).intValue();
					if (j >= UniProxyTokens.UNIPROXY_DEFAULT_BUFFER_SIZE)
					{
						bufferSize = j;
					}
					else
					{
						// specified value is invalid, fill in with default
						bufferSize = UniProxyTokens.UNIPROXY_DEFAULT_BUFFER_SIZE;
					}
				}
				else if(tokenName.equals("DEBUG_LEVEL"))
				{
					// read the debug level
					status = parser.nextToken();
					int j = (new Integer((int)parser.nval)).intValue();
					if (j >= 0 && j <= 9)
					{
						debugLevel = j;
					}
					else
					{
						// specified value is invalid, fill in with default
						debugLevel = 0;
					}
				}
				else if(tokenName.equals("MAX_CONNECTIONS"))
				{
					// read the maximum number of allowed connections per server instance
					status = parser.nextToken();
					maxConnections = (new Integer((int)parser.nval)).intValue();
				}
				else if(tokenName.equals("MAX_MULTIPLEXED_SERVERS"))
				{
					// read the maximum number of allowed multiplexed servers per connection.
					status = parser.nextToken();
					maxMultiplexedServers = (new Integer((int)parser.nval)).intValue();
				}
				else if(tokenName.equals("NAME_LOG"))
				{
					// read the name for the logging file
					status = parser.nextToken();
					if ( parser.ttype == StreamTokenizer.TT_WORD )
					{
						logFileName = parser.sval;
					}
					else
					{
						logFileName = Double.toString(parser.nval);
					}
				}
				else if(tokenName.equals("NETWORK_TIMEOUT"))
				{
					// read the network timeout to use for network connections
					status = parser.nextToken();
					networkTimeout = (new Integer((int)parser.nval)).intValue();
				}
				else if(tokenName.equals("PATH_LOG"))
				{
					// read the path for the logging file
					status = parser.nextToken();
					logFilePath = parser.sval;
				}
				else if(tokenName.equals("PROXY_PORT"))
				{
					// read the proxy server port
					status = parser.nextToken();
					serverPort = (new Integer((int)parser.nval)).intValue();
				}
        else if (tokenName.equals("PROXY_SSL_FLAG"))
        {
          // read proxy SSL flag
          String tmpstr;
          status = parser.nextToken();
          if ( parser.ttype == StreamTokenizer.TT_WORD )
          {
            tmpstr = parser.sval;
          }
          else
          {
            tmpstr = Double.toString(parser.nval);
          }
          if (tmpstr.equals("true") == true)
          {
            this.proxySSLFlag = true;
          }
          else
          {
            this.proxySSLFlag = false;
          }
        }
        else if(tokenName.equals("PROXY_SSL_ONLY_FLAG"))
        {
           // read proxy SSL flag
          String tmpstr;
          status = parser.nextToken();
          if ( parser.ttype == StreamTokenizer.TT_WORD )
          {
            tmpstr = parser.sval;
          }
          else
          {
            tmpstr = Double.toString(parser.nval);
          }
          if (tmpstr.equals("true") == true)
          {
            this.proxySSLOnlyFlag = true;
          }
          else
          {
            this.proxySSLOnlyFlag = false;
          }
        }

        else if(tokenName.equals("PROXY_SSL_PORT"))
				{
					// read the proxy server port
					status = parser.nextToken();
					serverSSLPort = (new Integer((int)parser.nval)).intValue();
				}
				else if(tokenName.equals("SSL_KEY_FILE"))
				{
					// read the admin access token
					status = parser.nextToken();
					if ( parser.ttype == StreamTokenizer.TT_WORD )
					{
						this.proxySSLKeyFile = parser.sval;
					}
					else
					{
						this.proxySSLKeyFile = Double.toString(parser.nval);
					}
				}
        else if(tokenName.equals("SSL_KEY_FILE_PWD"))
				{
					// read the admin access token
					status = parser.nextToken();
					if ( parser.ttype == StreamTokenizer.TT_WORD )
					{
						this.proxySSLKeyFilePwd = parser.sval;
					}
					else
					{
						this.proxySSLKeyFilePwd = Double.toString(parser.nval);
					}
				}
        else if(tokenName.equals("SSL_TRUST_FILE"))
				{
					// read the admin access token
					status = parser.nextToken();
					if ( parser.ttype == StreamTokenizer.TT_WORD )
					{
						this.proxySSLTrustFile = parser.sval;
					}
					else
					{
						this.proxySSLTrustFile = Double.toString(parser.nval);
					}
			  }

        else if (tokenName.equals("SSL_CLIENT_AUTHENTICATION"))
        {
          // read ssl client authentication mode
          String tmpstr;
          status = parser.nextToken();
          if ( parser.ttype == StreamTokenizer.TT_WORD )
          {
            tmpstr = parser.sval;
          }
          else
          {
            tmpstr = Double.toString(parser.nval);
          }
          if (tmpstr.equals("true") == true)
          {
            this.proxySSLClientAuthentication = true;
          }
          else
          {
            this.proxySSLClientAuthentication = false;
          }
        }
        else if (tokenName.equals("SSL_KEY_FILE_TYPE"))
        {
          status = parser.nextToken();
					if ( parser.ttype == StreamTokenizer.TT_WORD )
					{
						this.kstype = parser.sval;
					}
					else
					{
						this.kstype = Double.toString(parser.nval);
					}
        }
        else if (tokenName.equals("SSL_TRUST_FILE_TYPE"))
        {
          status = parser.nextToken();
					if ( parser.ttype == StreamTokenizer.TT_WORD )
					{
						this.tstype = parser.sval;
					}
					else
					{
						this.tstype = Double.toString(parser.nval);
					}
        }
        else if (tokenName.equals("SSL_PWD_METHOD"))
        {
          status = parser.nextToken();
          if (parser.ttype == StreamTokenizer.TT_WORD )
          {
            this.pwdmethod = parser.sval;
          }
          else
          {
            this.pwdmethod = Double.toString(parser.nval);
          }
        }



				if (status == StreamTokenizer.TT_EOF)
					// we have reached the end of file so lets get out of here
					break;
			} /* loop until no more tokens */
		}
		catch (IOException e)
		{
			throw new UniProxyException(e.toString(),UniProxyTokens.UNIPROXY_ERROR_LOADING_CONFIGURATION);
		}
		catch (NullPointerException e)
		{
			throw new UniProxyException("proxy server configuration file formatted incorrectly.",UniProxyTokens.UNIPROXY_ERROR_LOADING_CONFIGURATION);
		}
	} /* load() */

	/**
	 * Sets the currently defined location of this configuration.
	 *
	 * @param		aLocation		path of configuration file
	 * @see #getLocation()
	 * @since	UniProxy1.0
	 */
	public void setLocation(String aLocation)
	{
		configLocation = aLocation;
	}

	// instance variables for this class
	private int bufferSize = UniProxyTokens.UNIPROXY_DEFAULT_BUFFER_SIZE;
	private int debugLevel = 0;
	private int maxConnections = UniProxyTokens.UNIPROXY_DEFAULT_MAX_CONNECTIONS;
	private int maxMultiplexedServers = UniProxyTokens.UNIPROXY_DEFAULT_MAX_MULTIPLEXED_SERVERS;
	private int networkTimeout = UniProxyTokens.UNIPROXY_DEFAULT_NETWORK_TIMEOUT;
	private String configLocation = "";
	private String logFilePath = "";
	private String logFileName = "";
	private int serverPort = UniRPCTokens.UNIRPC_DEFAULT_PROXY_PORT;
  private boolean proxySSLFlag = UniProxyTokens.UNIPROXY_DEFAULT_SSL_FLAG;
  private boolean proxySSLOnlyFlag = UniProxyTokens.UNIPROXY_DEFAULT_SSL_ONLY_FLAG;
	private int serverSSLPort = UniRPCTokens.UNIRPC_DEFAULT_SSL_PROXY_PORT;
  private String proxySSLKeyFile = UniProxyTokens.UNIPROXY_DEFAULT_SSL_KEY_FILE;
  private String proxySSLKeyFilePwd = UniProxyTokens.UNIPROXY_DEFAULT_SSL_KEY_FILE_PWD;
  private String proxySSLTrustFile = UniProxyTokens.UNIPROXY_DEFAULT_SSL_TRUST_FILE;
  private boolean proxySSLClientAuthentication = UniProxyTokens.UNIPROXY_DEFAULT_SSL_CLIENT_AUTHENTICATION;
  private String kstype = UniProxyTokens.UNIPROXY_DEFAULT_KEYSTORE_TYPE;
  private String tstype = UniProxyTokens.UNIPROXY_DEFAULT_TRUSTSTORE_TYPE;
  private String pwdmethod = UniProxyTokens.UNIPROXY_DEFAULT_PWD_METHOD;
	private int adminPort = UniProxyTokens.UNIPROXY_DEFAULT_ADMIN_PORT;
	private String adminAccessToken = "";
	private Vector accessServer;
	private Object[][] accessTokenServer;

}
