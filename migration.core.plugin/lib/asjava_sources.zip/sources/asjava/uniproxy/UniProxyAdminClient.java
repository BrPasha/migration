/*************************************************************************
 *
 * UniProxyAdminClient.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.uniproxy;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.Socket;

import asjava.unirpc.UniRPCPacket;
import asjava.unirpc.UniRPCPacketException;
import asjava.unirpc.UniRPCTokens;

/**
 * The <code>UniProxyAdminClient</code> class executes proxy administrative commands.
 * At this time the class is run from the command line only but in the future we
 * may make it available as a class that can be put in another application or
 * as a standalone applet.
 * Usage Examples:
 * <pre>
 *
 *    To shutdown the proxy server.
 *      c:\\proxy\\java.exe UniProxyAdminClient -port=31458 -command=shutdown -server=web_host
 *
 *    To start the proxy server.
 *      c:\\proxy\\java.exe UniProxyAdminClient -config=C:\\proxy\\uniproxy.config -command=start -access_token=password
 *
 *</pre>
 *
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIPROXY 1.0
 */ 
public class UniProxyAdminClient extends java.lang.Object
{
	/**
	 * Constructs a <code>UniProxyAdminClient</code>.
	 *
	 * @since	UniProxy1.0
	 */
 	public UniProxyAdminClient()
 	{
 		// all this code is here to support the use of this class by other classes
 		// in the future 
		debugWriter = null;
		if ( System.out != null )
		{
			debugWriter = new PrintWriter( System.out, true );
		}
		else
		{
			debugWriter = null;
		}
 	}
 	
	/**
	 * Current entry point into the <code>UniProxyAdminClient</code> class. All of the parameters
	 * for <code>UniProxyAdminClient are specified as arguments to <code>main()</code>. The method 
	 * <code>main()</code> parses these arguments and then creates an instance of <code>UniProxyAdminClient</code>
	 * and uses that instance to execute the specified proxy server command. 
	 *
	 * @param		args		command line parameters
	 * @since	UniProxy1.0
	 */
 	public static void main(String[] args)
 	{ 		
 		// parse the command line. If the parse fails, then it never returns.
 		parseCommandLine(args);
 		 		
 		// create an instance of the administrative client
 		UniProxyAdminClient adminClient = new UniProxyAdminClient(); 		

 		try
 		{
 		  // if command is start, start an instance of the proxy server 
	 		if (currentCommand == UniProxyTokens.UNIPROXY_COMMAND_START)
 			{
 				adminClient.startProxy();
	 		}
 			else
 			{
 				// for all other commands, open connection to proxy admin server;
	 			adminClient.connectProxy();
	 			// run requested command
 				switch( currentCommand )
				{
 					case UniProxyTokens.UNIPROXY_COMMAND_SUSPEND:
 						adminClient.suspendProxy();
 						break;
	 				case UniProxyTokens.UNIPROXY_COMMAND_RESTART:
 						adminClient.restartProxy();
		 				break;
 					case UniProxyTokens.UNIPROXY_COMMAND_SHUTDOWN:
 						adminClient.shutdownProxy();
 						break;
	 				case UniProxyTokens.UNIPROXY_COMMAND_SHUTDOWNFAST:
 						adminClient.shutdownProxyFast();
	 					break;
 					case UniProxyTokens.UNIPROXY_COMMAND_RECONFIGURE:
 						adminClient.reconfigureProxy();
 						break;
 					case UniProxyTokens.UNIPROXY_COMMAND_STATUS:
 						adminClient.statusProxy();
 						break;
	 				default:
 						// unsupported command
	 					break;
	 			}
 				// close connection to proxy admin server;
 				adminClient.disconnectProxy();
 			}
 		}
		catch (UniProxyException e)
		{
			System.out.println( e.getMessage() );
 			System.exit(0);
		}
	} /* main() */
	
	/**
	 * Establishes a connection to the proxy administrative server that was specified
	 * on the command line.
	 *
   * @exception  UniProxyException if any errors occur when establishing a connection
   *               to the proxy administration server.
	 * @since	UniProxy1.0
	 */
	public void connectProxy() throws UniProxyException
	{
		debugWriter.println("Connecting to proxy admin server.");
		try
		{
			// establish a socket connection to admin server
			proxyAdminConnection = new Socket( currentServer, currentPort);
			proxyAdminConnection.setSoTimeout( currentTimeoutSeconds * 1000);
			proxyAdminConnection.setSoLinger( false, -1 );
			proxyAdminConnection.setTcpNoDelay( true );				
			proxyAdminDataOut = new DataOutputStream(proxyAdminConnection.getOutputStream());
			proxyAdminDataIn = new DataInputStream(proxyAdminConnection.getInputStream());
		}
		catch( IOException e)
		{
			throw new UniProxyException( e.toString(), UniProxyTokens.UNIPROXY_ERROR_NETWORK_IO);
		}
	}
	
	/**
	 * Terminates the current connection to a proxy administrative server.
	 *
   * @exception  UniProxyException if any errors occur when terminating the connection
   *               to a proxy administration server.
	 * @since	UniProxy1.0
	 */
	public void disconnectProxy() throws UniProxyException
	{
		debugWriter.println("Disconnecting from proxy adminserver.");
		try
		{
			// terminate the socket connection to the admin server
			proxyAdminDataOut.close();
			proxyAdminDataOut = null;
			proxyAdminDataIn.close();
			proxyAdminDataIn = null;
			proxyAdminConnection.close();
			proxyAdminConnection = null;
		}
		catch( IOException e)
		{
			throw new UniProxyException( e.toString(), UniProxyTokens.UNIPROXY_ERROR_NETWORK_IO);
		}
	}
	
	/**
	 * Returns the current debug stream that all debug output is written
	 * to for this class.
	 *
	 * @see #setDebugWriter()
	 * @since	UniRPC1.0
	 */
	public PrintWriter getDebugWriter()
	{
		return debugWriter;
	}
	
	/**
	 * Send the reconfiguration message to the proxy administration server.
	 *
   * @exception  UniProxyException if any network errors occur or if the proxy server
   *               command fails to successfully complete.
	 * @since	UniProxy1.0
	 */
	public void reconfigureProxy() throws UniProxyException
	{
		debugWriter.println("Reconfiguring proxy server...");
		outPacket = new UniRPCPacket();
		inPacket = new UniRPCPacket();
		try
		{
			// build packet
			outPacket.write(0, UniProxyTokens.UNIPROXY_ADMIN_VERSION);
			outPacket.write(1, currentAccessToken);
			outPacket.write(2, currentCommand);
			outPacket.write(3, currentCommandText);
			// send command
	  	outPacket.send(proxyAdminDataOut, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
	  	inPacket.receive(proxyAdminDataIn);
	  	// process command results
			if( inPacket.readInteger(0) == 0 )
			{
				debugWriter.println("Proxy server successfully reconfigured.");		
			}
			else
			{
				debugWriter.println("Command Failed!!!");		
				debugWriter.println("   " + inPacket.readString(1));		
			}	  
	  }
	  catch (UniRPCPacketException e)
	  {
			throw new UniProxyException( e.getMessage(), e.getErrorCode());
	  }
	}
	
	/**
	 * Send the restart message to the proxy administration server. This command will 
	 * only complete when the server is in the suspended state
	 *
   * @exception  UniProxyException if any network errors occur or if the proxy server
   *               command fails to successfully complete.
	 * @since	UniProxy1.0
	 */
	public void restartProxy() throws UniProxyException
	{
		// signal server to restart.
		// this may only work if server is in a suspend state
		debugWriter.println("Restarting proxy server...");
		outPacket = new UniRPCPacket();
		inPacket = new UniRPCPacket();
		try
		{
			// build packet
			outPacket.write(0, UniProxyTokens.UNIPROXY_ADMIN_VERSION);
			outPacket.write(1, currentAccessToken);
			outPacket.write(2, currentCommand);
			outPacket.write(3, currentCommandText);
			// send command
	  	outPacket.send(proxyAdminDataOut, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
	  	inPacket.receive(proxyAdminDataIn);
	  	// process command results
			if( inPacket.readInteger(0) == 0 )
			{
				debugWriter.println("Proxy server successfully restarted.");		
			}
			else
			{
				debugWriter.println("Command Failed!!!");		
				debugWriter.println("   " + inPacket.readString(1));		
			}	  
	  }
	  catch (UniRPCPacketException e)
	  {
			throw new UniProxyException( e.getMessage(), e.getErrorCode());
	  }
	}
			
	/**
	 * Sets the debug stream that all debug output is written
	 * to for this class.
	 *
	 * @see #getDebugWriter()
	 * @since	UniRPC1.0
	 */
	public void setDebugWriter( PrintStream aPrintStream)
	{
		debugWriter = new PrintWriter(aPrintStream, true);
	}
	
	/**
	 * Sets the debug stream that all debug output is written
	 * to for this class.
	 *
	 * @see #getDebugWriter()
	 * @since	UniRPC1.0
	 */
	public void setDebugWriter( FileOutputStream aFileStream)
	{
		debugWriter = new PrintWriter( aFileStream, true );
	}
	
	/**
	 * Sets the debug stream that all debug output is written
	 * to for this class.
	 *
	 * @see #getDebugWriter()
	 * @since	UniRPC1.0
	 */
	public void setDebugWriter( Writer aWriter)
	{
		debugWriter = new PrintWriter( aWriter, true );
	}
	
	/**
	 * Send the shutdown message to the proxy administration server. This command will 
	 * stop the proxy server from accepting any new connections and will shut it down when
	 * all existing connections have terminated on their own.
	 *
   * @exception  UniProxyException if any network errors occur or if the proxy server
   *               command fails to successfully complete.
	 * @since	UniProxy1.0
	 */
	public void shutdownProxy() throws UniProxyException
	{
		debugWriter.println("Shutting down proxy server...");
		outPacket = new UniRPCPacket();
		inPacket = new UniRPCPacket();
		try
		{
			// build packet
			outPacket.write(0, UniProxyTokens.UNIPROXY_ADMIN_VERSION);
			outPacket.write(1, currentAccessToken);
			outPacket.write(2, currentCommand);
			outPacket.write(3, currentCommandText);
			// send command
	  	outPacket.send(proxyAdminDataOut, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
	  	inPacket.receive(proxyAdminDataIn);
	  	// process command results
			if( inPacket.readInteger(0) == 0 )
			{
				debugWriter.println("Proxy server completing shutdown.");		
			}
			else
			{
				debugWriter.println("Command Failed!!!");		
				debugWriter.println("   " + inPacket.readString(1));		
			}	  
	  }
	  catch (UniRPCPacketException e)
	  {
			throw new UniProxyException( e.getMessage(), e.getErrorCode());
	  }
	}
	
	/**
	 * Send the shutdown:fast message to the proxy administration server. This command will 
	 * shutdown the proxy server as fast as possible without data loss. It stops the proxy
	 * server from accepting any new connections and terminates all connections as soon
	 * as their current packet exchange has finished.
	 *
   * @exception  UniProxyException if any network errors occur or if the proxy server
   *               command fails to successfully complete.
	 * @since	UniProxy1.0
	 */
	public void shutdownProxyFast() throws UniProxyException
	{
		debugWriter.println("Shutting down proxy server immediately...");
		outPacket = new UniRPCPacket();
		inPacket = new UniRPCPacket();
		try
		{
			// build packet
			outPacket.write(0, UniProxyTokens.UNIPROXY_ADMIN_VERSION);
			outPacket.write(1, currentAccessToken);
			outPacket.write(2, currentCommand);
			outPacket.write(3, currentCommandText);
			// send command
	  	outPacket.send(proxyAdminDataOut, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
	  	inPacket.receive(proxyAdminDataIn);
	  	// process command results
			if( inPacket.readInteger(0) == 0 )
			{
				debugWriter.println("Proxy server completing shutdown.");		
			}
			else
			{
				debugWriter.println("Command Failed!!!");		
				debugWriter.println("   " + inPacket.readString(1));		
			}	  
	  }
	  catch (UniRPCPacketException e)
	  {
			throw new UniProxyException( e.getMessage(), e.getErrorCode());
	  }
	}
	
	/**
	 * Start a new instance of the proxy server on your current machine. This command will 
	 * start the proxy server using the specified proxy configuration.
	 *
   * @exception  UniProxyException if any errors occur while launchine the proxy server.
	 * @since	UniProxy1.0
	 */
	public void startProxy() throws UniProxyException
	{
		debugWriter.println("Starting proxy server...");
	  UniProxyConfiguration proxyConfiguration = new UniProxyConfiguration();
		try
		{
			// load the configuration file
			proxyConfiguration.setLocation(currentConfigLocation);
			proxyConfiguration.load();
			// authenticate the admin client
			int result = proxyConfiguration.authenticateAdmin(currentAccessToken);
			if ( result == 0)
			{
				// launch proxy server
 				Runtime.getRuntime().exec("java asjava.uniproxy.UniProxyServer -config=" + currentConfigLocation);
 				// a future enhancement would be to check and make sure that the server came up.
 				// this may involve two checks, one if process exits, two if admin server is up.
 				// to check on server we would send a status request tot he admin server.
				debugWriter.println("Proxy server started.");
 			}
 			else
 			{
				debugWriter.println("Error: Proxy server administration authentication failed.");
 			}
		}
		catch (UniProxyException e)
		{
			debugWriter.println("Error: failed to load Proxy server configuration:" + e.getMessage());
			System.exit(0);
		}
		catch (IOException e)
		{
			debugWriter.println("Error: failed to launch the Proxy server process:" + e.toString());
			System.exit(0);
		}
	}	
	
	/**
	 * Send the status message to the proxy administration server. This command will 
	 * tell the proxy server to print out its current state to the logging file.
	 *
   * @exception  UniProxyException if any network errors occur or if the proxy server
   *               command fails to successfully complete.
	 * @since	UniProxy1.0
	 */
	public void statusProxy() throws UniProxyException
	{
		debugWriter.println("Dumping status of proxy server to log file...");
		outPacket = new UniRPCPacket();
		inPacket = new UniRPCPacket();
		try
		{
			// build packet
			outPacket.write(0, UniProxyTokens.UNIPROXY_ADMIN_VERSION);
			outPacket.write(1, currentAccessToken);
			outPacket.write(2, currentCommand);
			outPacket.write(3, currentCommandText);
			// send command
	  	outPacket.send(proxyAdminDataOut, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
	  	inPacket.receive(proxyAdminDataIn);
	  	// process command results
			if( inPacket.readInteger(0) == 0 )
			{
				debugWriter.println("Proxy server status successfully output.");		
			}
			else
			{
				debugWriter.println("Command Failed!!!");		
				debugWriter.println("   " + inPacket.readString(1));		
			}	  
	  }
	  catch (UniRPCPacketException e)
	  {
			throw new UniProxyException( e.getMessage(), e.getErrorCode());
	  }
	}
	
	/**
	 * Send the suspend message to the proxy administration server. This command will 
	 * tell the proxy server to stop accepting any new connections. The current connections
	 * are not affected.
	 *
   * @exception  UniProxyException if any network errors occur or if the proxy server
   *               command fails to successfully complete.
	 * @since	UniProxy1.0
	 */
	public void suspendProxy() throws UniProxyException
	{
		// signal server to stop accepting requests
		debugWriter.println("Suspending proxy server...");
		outPacket = new UniRPCPacket();
		inPacket = new UniRPCPacket();
		try
		{
			// build packet
			outPacket.write(0, UniProxyTokens.UNIPROXY_ADMIN_VERSION);
			outPacket.write(1, currentAccessToken);
			outPacket.write(2, currentCommand);
			outPacket.write(3, currentCommandText);
			// send command
	  	outPacket.send(proxyAdminDataOut, UniRPCTokens.UNIRPC_ENCRYPTION_NONE, UniRPCTokens.UNIRPC_INITIAL_PROXY_CONNECTIONID);
	  	inPacket.receive(proxyAdminDataIn);
	  	// process command results
			if( inPacket.readInteger(0) == 0 )
			{
				debugWriter.println("Proxy server successfully suspended.");		
			}
			else
			{
				debugWriter.println("Command Failed!!!");		
				debugWriter.println("   " + inPacket.readString(1));		
			}	  
	  }
	  catch (UniRPCPacketException e)
	  {
			throw new UniProxyException( e.getMessage(), e.getErrorCode());
	  }
	}	
	
	/**
 	 * Parse the command line to get the necessary information to complete the 
 	 * proxy administrative command.
	 *
	 * @param		args		command line parameters
	 * @since	UniProxy1.0
	 */ 	 
 	private static void parseCommandLine(String[] args)
 	{
 		// default settings
 		boolean gotConfig = false;
 		boolean gotPort = false;
		currentServer = "localhost";
		currentPort = UniProxyTokens.UNIPROXY_DEFAULT_ADMIN_PORT;
		currentConfigLocation = "";
		currentAccessToken = "";		
		currentCommandText = "";
		currentCommand = 0;
		
 		// parse command line
		try
		{
			for ( int i = 0; i < args.length; i++)
			{
				// proxy configuration location
				if (args[i].toLowerCase().startsWith("-config="))
				{
					gotConfig = true;
	 				currentConfigLocation = args[i].substring(8);
				}
				// proxy admistrative server port
				else if ( args[i].toLowerCase().startsWith("-port="))
				{
					gotPort = true;
	 				currentPort = (Integer.valueOf(args[i].substring(6))).intValue();
				}
				// proxy admistrative server
				else if ( args[i].toLowerCase().startsWith("-server="))
				{
	 				currentServer = args[i].substring(8);
				}
				// proxy admistrative server access token
				else if ( args[i].toLowerCase().startsWith("-access_token="))
				{
	 				currentAccessToken = args[i].substring(14);
				}
				// command to execute on the proxy server
				else if ( args[i].toLowerCase().startsWith("-command="))
				{
	 				currentCommandText = args[i].substring(9).toLowerCase();
	 				if ( currentCommandText.equals("suspend") )
	 				{
	 					currentCommand = UniProxyTokens.UNIPROXY_COMMAND_SUSPEND;
	 				}
	 				else if ( currentCommandText.equals("start") )
	 				{
	 					currentCommand = UniProxyTokens.UNIPROXY_COMMAND_START;
	 				}
	 				else if ( currentCommandText.equals("shutdown") )
	 				{
	 					currentCommand = UniProxyTokens.UNIPROXY_COMMAND_SHUTDOWN;
	 				}
	 				else if ( currentCommandText.equals("shutdown:fast") )
	 				{
	 					currentCommand = UniProxyTokens.UNIPROXY_COMMAND_SHUTDOWNFAST;
	 				}
	 				else if ( currentCommandText.equals("restart") )
	 				{
	 					currentCommand = UniProxyTokens.UNIPROXY_COMMAND_RESTART;
	 				}
	 				else if ( currentCommandText.equals("reconfigure") )
	 				{
	 					currentCommand = UniProxyTokens.UNIPROXY_COMMAND_RECONFIGURE;
	 				}
	 				else if ( currentCommandText.equals("status") )
	 				{
	 					currentCommand = UniProxyTokens.UNIPROXY_COMMAND_STATUS;
	 				}
	 				else
	 				{
						System.out.println("Error: Unsupported command: " + args[i]);
						printUsage();
 						System.exit(0);
	 				}
				}
				// print out command line usage
				else if ( args[i].toLowerCase().startsWith("-help"))
				{
					printUsage();
 					System.exit(0);
				}
				// unsupported options
				else
				{
					System.out.println("Error: Unsupported option: " + args[i]);
					printUsage();
 					System.exit(0);
				}
			}
			// check proper usage
			if ( (gotConfig && (currentCommand != UniProxyTokens.UNIPROXY_COMMAND_START)) ||
				(gotPort && gotConfig) || (!gotPort && !gotConfig) ||
				(!gotConfig && (currentCommand == UniProxyTokens.UNIPROXY_COMMAND_START)) )
			{
				System.out.println("Error: Invalid combination of -port, -config and -command.");
				printUsage();
				System.exit(0);
			}
		}
		catch ( Exception e)
		{
			System.out.println(e.getMessage());
			printUsage();
 			System.exit(0);
		}
 	} /* parseCommandLine() */
 		
	/**
 	 * Prints the usage of UniProxyAdminClient when instantiated from the command line.
 	 * This method is executed when invalid options or "-help" are specified on the command line.
	 *
	 * @since	UniProxy1.0
	 */ 	 
	private static void printUsage()
	{
 		// print the usage for this class
	 	System.out.println("Usage: UniProxyAdminClient -config=configPath -command=start [-access_token=xxxxxx]");
	 	System.out.println("       UniProxyAdminClient -port=xxxxx -command=xxxxxx [-server=xxxxxx] [-access_token=xxxxxx]");
	 	System.out.println("       UniProxyAdminClient -help");
	 	System.out.println();
	 	System.out.println("Currently supported commands are:");
	 	System.out.println("   start, suspend, restart, shutdown, shutdown:fast, reconfigure, status");
	} /* printUsage() */ 		
	
	// these variables are for instances of the UniProxyAdminClient class
	private PrintWriter debugWriter;
	private Socket proxyAdminConnection;
	private UniRPCPacket outPacket, inPacket;
	private DataOutputStream proxyAdminDataOut;
	private DataInputStream proxyAdminDataIn;
	private int currentTimeoutSeconds = 0;
	// these variables are only for the command line static instantiation of 
	// UniProxyAdminClient class via the main() method
	private static String currentAccessToken = "";
	private static String currentCommandText = "";
	private static int currentCommand = UniProxyTokens.UNIPROXY_COMMAND_NONE;
	private static String currentConfigLocation = "";
	private static int currentPort = 0;
	private static String currentServer = "";
}