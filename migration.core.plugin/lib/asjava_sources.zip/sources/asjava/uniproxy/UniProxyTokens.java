/*************************************************************************
 *
 * UniProxyTokens.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.uniproxy;
 

/**
 * <code>UniProxyTokens</code> is the primary class used for holding UniVerse 
 * proxy define tokens.
 * 
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIPROXY 1.0
 */

public class UniProxyTokens
{
	UniProxyTokens()
	{
	}
	
	/**
	 * Proxy administration communication version.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_ADMIN_VERSION = 1;
	
	/**
	 * Proxy administration server no-op command.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_COMMAND_NONE = 0;
	
	/**
	 * Proxy administration server start command.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_COMMAND_START = 1;
	
	/**
	 * Proxy administration server suspend command.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_COMMAND_SUSPEND = 2;
	
	/**
	 * Proxy administration server restart command.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_COMMAND_RESTART = 3;
	
	/**
	 * Proxy administration server shutdown command.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_COMMAND_SHUTDOWN = 4;
	
	/**
	 * Proxy administration server shutdown fast command.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_COMMAND_SHUTDOWNFAST = 5;
	
	/**
	 * Proxy administration server reconfigure command.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_COMMAND_RECONFIGURE = 6;
	
	/**
	 * Proxy administration server reconfigure command.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_COMMAND_STATUS = 7;
	
	/**
	 * Default connection buffer size. Currently defined as <code>4096</code> bytes.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_DEFAULT_BUFFER_SIZE = 4096;	
	
	/**
	 * Default connection buffer size. Currently defined as <code>4096</code> bytes.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_DEFAULT_MAX_CONNECTIONS = 128;	
	
	/**
	 * Default connection buffer size. Currently defined as <code>4096</code> bytes.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_DEFAULT_MAX_MULTIPLEXED_SERVERS = 4;	
	
	/**
	 * Default network timeout. Currently defined as 5 minutes or <code>300000</code> milliseconds.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_DEFAULT_NETWORK_TIMEOUT = 300000;	
	
	/**
	 * Default proxy server port. Currently defined as <code>31448</code>
	 *
	 * @since UniProxy1.0
	 */
	
  public final static boolean UNIPROXY_DEFAULT_SSL_FLAG = false;
  public final static boolean UNIPROXY_DEFAULT_SSL_ONLY_FLAG=false;
  public final static String UNIPROXY_DEFAULT_SSL_KEY_FILE = "testkeys";
  public final static String UNIPROXY_DEFAULT_SSL_KEY_FILE_PWD = "new.pass";
  //"passphrase";

  public final static String UNIPROXY_DEFAULT_SSL_TRUST_FILE = "testtrust";
 // public final static String UNIPROXY_DEFAULT_SSL_TRUST_FILE_PWD = "new.pass";

  public final static String UNIPROXY_TMP_PFNAME = "tmp0967";

  public final static boolean UNIPROXY_DEFAULT_SSL_CLIENT_AUTHENTICATION = false;
  public final static String UNIPROXY_DEFAULT_KEYSTORE_TYPE = "JKS";
  public final static String UNIPROXY_DEFAULT_TRUSTSTORE_TYPE = "JKS";
  public final static String UNIPROXY_INTERACTIVE_PWD_METHOD  = "INTERACTIVE";
  public final static String UNIPROXY_DIRECT_PWD_METHOD = "DIRECT";
  public final static String UNIPROXY_USER_DEFINED_PWD_METHOD = "USER_DEFINED";
  public final static String UNIPROXY_DEFAULT_PWD_METHOD = UNIPROXY_INTERACTIVE_PWD_METHOD;

	/**
	 * Default proxy administration server port. Currently defined as <code>31458</code>
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_DEFAULT_ADMIN_PORT = 31458;

	/**
	 * Internal signaling timeout. Currently defined as 5 seconds or <code>5000</code> milliseconds.
	 *
	 * @since UniProxy1.0
	 */


	public final static int UNIPROXY_INTERNAL_SIGNALING_TIMEOUT = 5000;

	/**
	 * A general proxy server error.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_ERROR_GENERAL = 10000;

	/**
	 * UniProxyConfiguration failed to load configuration for some reason.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_ERROR_LOADING_CONFIGURATION = 10001;

	/**
	 * A general non-recoverable network error has occured.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_ERROR_NETWORK_IO = 10002;

	/**
	 * An error has occured while processing an administrative request.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_ERROR_ADMIN = 10003;

	/**
	 * A NULL reference has been passed.
	 *
	 * @since UniProxy1.0
	 */
	public final static int UNIPROXY_ERROR_NULL_REFERENCE = 10004;

  /*
   * Wrong SSL paramters. Could be wrong passwords definitions for key/trust stores
   */
  public final static int UNIPROXY_WRONG_SSL_PARAMETERS = 10005;




		
}