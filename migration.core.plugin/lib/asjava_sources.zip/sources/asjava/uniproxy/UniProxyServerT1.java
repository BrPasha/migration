
// Copyright (c) 2000 Informix Software Pty Ltd
package asjava.uniproxy;
import java.awt.Frame;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;

//import javax.net.ssl.SSLContext;
//import javax.net.ssl.TrustManagerFactory;
//import javax.net.ssl.KeyManagerFactory;

//import com.ibm.net.ssl.TrustManagerFactory;
//import com.ibm.net.ssl.KeyManagerFactory;
//import com.ibm.net.ssl.SSLContext;
//import com.ibm.jsse.JSSEProvider;

/**
 * A Class class.
 * <P>
 * @author Systems Admin
 */
public class UniProxyServerT1 extends Thread
{

  /**
   * Constructor
   */
  int port;
  UniProxyServer parent;
	private Hashtable clientConnectTable;
  private boolean isSuspended = false;
  private int debugLevel;
  private int maxConnections;
	private ServerSocket socketServer;
  private SSLServerSocket sslSocketServer;
	private Socket newConnection;
  private ThreadGroup tg;
  private boolean externalSSLType;
  private String kstype;
  private String tstype;

  private static char pwdDelim = '_';

  public UniProxyServerT1(int port,
                          UniProxyServer ups,
                          ThreadGroup tg,
                          boolean externalSSLType)
  {
 		// initialize instance variables
 		clientConnectTable = new Hashtable();
    this.port = port;
    this.parent = ups;
    this.debugLevel = parent.getDebugLevel();
    this.maxConnections = parent.getMaxConnections();
    this.tg = tg;
    this.externalSSLType = externalSSLType;
  }

  public void SuspendT1Server()
  {
    isSuspended = true;
  }

  public void restartT1Server()
  {
    if (isSuspended == true)
    {
			if (debugLevel > 0)
			{
				parent.writeLog("Restarting proxy server.");
			}
			isSuspended = false;
			synchronized(this)
			{
				notify();
			}
		}
		else
		{
			// server not in suspended state, can't restart it
			parent.writeLog("Error: Proxy server Thread T1 not in suspended state, can't restart it.");
		}
  }

  public void run()
  {
    UniProxyConnection proxyConnection;
    Frame frame;

		try
		{
      frame = new Frame();
			if (debugLevel > 0)
			{
				parent.writeLog("Starting SSL proxy server.");
			}

      // if this is an SSL thread then we create an SSLServerSocket
      // otherwise create normal socket
      if (this.externalSSLType)
      {
        String sslKeyFile = parent.getConfiguration().getProxySSLKeyFile();
        String sslKeyFilePwd = parent.getConfiguration().getProxySSLKeyFilePwd();
        String sslTrustFile = parent.getConfiguration().getProxySSLTrustFile();
        String sslPwdMethod = parent.getConfiguration().getProxyPwdMethod();
        boolean sslClientAuthentication = parent.getConfiguration().getProxySSLClientAuthentication();
        kstype = parent.getConfiguration().getProxyKeystoreType();
        tstype = parent.getConfiguration().getProxyTruststoreType();
        String class_name;
        String method_name;
        String arg;
        int indf, indl;


        // check if we need to get passwords interactively


        if (sslPwdMethod.equals(UniProxyTokens.UNIPROXY_INTERACTIVE_PWD_METHOD) == true)
        {
          //sslKeyFilePwd = "";
          // input the password interactively
          if (debugLevel > 0)
          {
            parent.writeLog("getting keystore password interactively");
          }

          try
          {

            Runtime r = Runtime.getRuntime();
            Process p = r.exec("java asjava.uniproxy.UniProxyGetPwd");
            p.waitFor();

            File f = new File(UniProxyTokens.UNIPROXY_TMP_PFNAME);
            int n;
            n = (int)f.length();
            char cbuf[] = new char [n];
            FileReader fr = new FileReader(UniProxyTokens.UNIPROXY_TMP_PFNAME);
            n = fr.read(cbuf);
            fr.close();
            String password = new String(cbuf);
            System.out.println(password);
            sslKeyFilePwd = password;

            f.delete();


          }
          catch (FileNotFoundException e)
          {
          }
          catch (IOException e)
          {
          }
          catch (InterruptedException e)
          {
          }

                   // input the password interactively
           if (debugLevel > 0)
          {
            parent.writeLog("getting truststore password interactively");
          }



        }
        // check if we have to call user defined class using the reflection api
        else if (sslPwdMethod.equals(UniProxyTokens.UNIPROXY_USER_DEFINED_PWD_METHOD)== true)
        {
          // it means that we have to call user defined method
          if (debugLevel > 0)
          {
            parent.writeLog("calling user defined method");
          }
          indf = sslKeyFilePwd.indexOf(pwdDelim);
          if (indf != -1)
          {
            // extract the argument as the first field
            arg = sslKeyFilePwd.substring(0, indf);
            indl = sslKeyFilePwd.lastIndexOf(pwdDelim);
            if (indf != indl)
            {
              // extract method name as the second field
              method_name = sslKeyFilePwd.substring(indf + 1, indl);
              if (debugLevel > 0)
              {
                parent.writeLog("method="+method_name);
              }
            }
            else
            {
              // this is an error
              throw (new UniProxyException(UniProxyTokens.UNIPROXY_WRONG_SSL_PARAMETERS));
            }
            // extract class name as the third field
            class_name = sslKeyFilePwd.substring(indl + 1);
            if (debugLevel > 0)
            {
              parent.writeLog("class="+class_name);
            }
            try
            {
              Class c = Class.forName(class_name);

              // the static method should have one parameter of String type
              Class parsDef[] = new Class[] {arg.getClass()};

              Method m = c.getMethod(method_name,parsDef);

              Object pars[] = new Object[] { arg };
              // invoke statid method
              sslKeyFilePwd = (String)m.invoke(null, pars);

            }
            catch (ClassNotFoundException e)
            {
              throw new UniProxyException(UniProxyTokens.UNIPROXY_WRONG_SSL_PARAMETERS);
            }
            catch (NoSuchMethodException e)
            {
              throw new UniProxyException(UniProxyTokens.UNIPROXY_WRONG_SSL_PARAMETERS);
            }
            catch (InvocationTargetException e)
            {
              throw new UniProxyException(UniProxyTokens.UNIPROXY_WRONG_SSL_PARAMETERS);
            }
            catch (IllegalAccessException e)
            {
              throw new UniProxyException(UniProxyTokens.UNIPROXY_WRONG_SSL_PARAMETERS);
            }

          }
          else
          {
            // this is an error
            throw (new UniProxyException(UniProxyTokens.UNIPROXY_WRONG_SSL_PARAMETERS));
          }


        }
        else
        {
          // the password is kept in clear text in uniproxy.config
          ;
        }
        System.setProperty("javax.net.ssl.trustStore", sslTrustFile);
        System.setProperty("javax.net.ssl.keyStore", sslKeyFile);
        System.setProperty("javax.net.ssl.keyStorePassword", sslKeyFilePwd);

//      initContext(sslKeyFile, sslKeyFilePwd, sslTrustFile, sslTrustFilePwd, kstype, tstype);
//        SSLServerSocketFactory factory = sslContext.getServerSocketFactory();
//
        SSLServerSocketFactory factory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        sslSocketServer = (SSLServerSocket)factory.createServerSocket(port);
        if (sslClientAuthentication == true)
        {
          sslSocketServer.setNeedClientAuth(true);
        }
        else
        {
          sslSocketServer.setNeedClientAuth(false);
        }
        sslSocketServer.setSoTimeout(UniProxyTokens.UNIPROXY_INTERNAL_SIGNALING_TIMEOUT);
        if (debugLevel > 2)
	  		{
		  		parent.writeLog("Accepting proxy connections on port "
			  		+ sslSocketServer.getLocalPort());
  			}



      }
      else
      {
			// setup proxy server, server socket
  			socketServer = new ServerSocket(port);
			// set server listen timeout to 5 seconds
	  		socketServer.setSoTimeout(UniProxyTokens.UNIPROXY_INTERNAL_SIGNALING_TIMEOUT);
  			if (debugLevel > 2)
	  		{
		  		parent.writeLog("Accepting proxy connections on port "
			  		+ socketServer.getLocalPort());
  			}
      }


			while ( !parent.getisShutdown() )
			{
				// For right now we poll the server state ever few seconds to determine if we have
				// been givin a signal to shutdown or suspend.
				try
				{
					// wait for a new incoming connection request
          if (this.externalSSLType)
          {
					  newConnection = sslSocketServer.accept();
          }
          else
          {
					  newConnection = socketServer.accept();
          }
				}
				catch (InterruptedIOException e)
				{
					// server socket listen timed out so check proxy server status
					if (this.isSuspended == true)
					{
						// server is in the suspended state
						try
						{
							// wait until server is notified to start again
							synchronized(this)
							{
								wait();
							}
						}
						catch (InterruptedException ex)
						{
							// server has been signaled to start accepting connections again
						}
					}
					// right now for all conditions we continue.
					continue;
				}
				// before we process the new connection request we have to make sure that the
				// proxy server is still in the enabled state.
				if (this.isSuspended == true)
				{
					// server is in the suspended state
					try
					{
						// wait until server is notified to start again
						synchronized(this)
						{
							wait();
						}
					}
					catch (InterruptedException ex)
					{
						// server has been signaled to start accepting connections again
					}
					continue;
				}

				// instantiate new UniProxyConnection. If we have problem with new connection
				// object, just drop this connection and try to accept the next connnection.
				try
				{
					proxyConnection = new UniProxyConnection( tg,
                                                    this.parent,
                                                    newConnection, externalSSLType);
				}
				catch (UniProxyException e)
				{
					continue;
				}
				// if no more connection slots open, then sleep a few seconds to give
				// existing connections time to disconnect, then start accepting more connections
				// during login process, if no connection slots are available,
				// an error message is returned to the client.
				if ( clientConnectTable.size() >= maxConnections )
				{
					//clean up the connection table so we have room for new connections
					syncConnectionTable();
					if ( clientConnectTable.size() >= maxConnections )
					{
						if (debugLevel > 2)
						{
							parent.writeLog("Connection limit reached, pausing " + UniProxyTokens.UNIPROXY_INTERNAL_SIGNALING_TIMEOUT
								+ " seconds for connection slots to be freed up.");
						}
						try
						{
							// sleep for few second to give connections an opportunity to finish up
							// at some point we want to give this parameter its own configurable timeout.
							Thread.sleep(UniProxyTokens.UNIPROXY_INTERNAL_SIGNALING_TIMEOUT);
						}
						catch( InterruptedException e )
						{
						}
						syncConnectionTable();
						// if still no room then mark this connection as over the limit
						if ( clientConnectTable.size() >= maxConnections )
						{
							proxyConnection.setExceedMaxSessions();
						}
					}
				}
				proxyConnection.start();
				if (debugLevel > 2)
				{
					parent.writeLog("A new client connection thread started.");
				}
				clientConnectTable.put(proxyConnection, proxyConnection);
			}
		}
		catch (IOException e)
		{
			parent.writeLog("UniProxyServerT1 thread Error: " + e.toString() );
		}
    catch (UniProxyException e)
    {
      parent.writeLog("UniProxyServerT1 thread Error: " + e.toString() );
    }

    shutdown();
    try
    {
      parent.notifyMe();
    }
    catch (InterruptedException e)
    {
      // Do nothing
    }
  }

	public void shutdown()
	{
		if (debugLevel > 0)
		{
			parent.writeLog("Shutting down proxy server.");
		}
		// stop accepting any new client connections
		SuspendT1Server();
		syncConnectionTable();
		UniProxyConnection item;

		for (Enumeration enum1 = clientConnectTable.elements();enum1.hasMoreElements();)
		{
			item = (UniProxyConnection)enum1.nextElement();
			if (debugLevel > 5)
			{
				parent.writeLog("   waiting on client connection " + item.hashCode() +" to finish.");
			}
			try
			{
				// wait for this connection thread to finish
				item.join();
				if (debugLevel > 5)
				{
					parent.writeLog("   client connection " + item.hashCode() +" has finished.");
				}
			}
			catch(InterruptedException e)
			{
				parent.writeLog( e.toString() );
			}
		}

		// let server process shutdown
		isSuspended = false;
		synchronized(this)
		{
			notify();
		}
	} /* shutdown() */


	public void shutdownFast()
	{
		UniProxyConnection item;
		if (debugLevel > 0)
		{
			parent.writeLog("Shutting down proxy server immediately.");
		}
		// stop accepting any new connections
		SuspendT1Server();
		syncConnectionTable();
		// walk connection table terminating each connection.
		// at the end of next packet exchange.
		if (debugLevel > 5)
		{
			parent.writeLog("Signal all open client connection threads to terminate.");
		}

		for (Enumeration enum1 = clientConnectTable.elements();enum1.hasMoreElements();)
		{
			item = (UniProxyConnection)enum1.nextElement();
			if (debugLevel > 5)
			{
				parent.writeLog("   sending shutdown fast signal to client connection "
				  + item.hashCode() +".");
			}
			// tell this connection thread to finish after the current packet exchange is complete.
			item.stopFast();
		}
		// walk connection table waiting for each connection to finish
		if (debugLevel > 5)
		{
			parent.writeLog("Wait on all open client connection threads to finish.");
		}
		for (Enumeration enum1 = clientConnectTable.elements();enum1.hasMoreElements();)
		{
			item = (UniProxyConnection)enum1.nextElement();
			if (debugLevel > 5)
			{
				parent.writeLog("   waiting on client connection " + item.hashCode() +" to finish.");
			}
			try
			{
				// wait 60 seconds for this connection thread to finish
				item.join(60000);
				if( item.isAlive() )
				{
					item.stop();
					parent.writeLog("Error: client connection " + item.hashCode() +" did not finish and has been killed.");
				}
				else
				{
					if (debugLevel > 5)
					{
						parent.writeLog("   client connection " + item.hashCode() +" has finished.");
					}
				}
			}
			catch(InterruptedException e)
			{
				parent.writeLog( e.toString() );
			}
		}
		// let server process shutdown

		isSuspended = false;
		synchronized(this)
		{
			notify();
		}
	} /* shutdownFast() */

	public void status()
	{

			if (debugLevel > -1)
			{
				parent.writeLog("Dumping current status of proxy server to log file.");
				parent.writeLog("   Updating the connection table.");
			}
			syncConnectionTable();
			// dump a list of all connections and their states.
			if (debugLevel >= 8)
			{
				parent.writeLog("Connection Table Details:");
				parent.writeLog("   Maximum available connections=" + maxConnections);
				parent.writeLog("   Currently open client connections=" + clientConnectTable.size());
				parent.writeLog("   Current 'CLIENT' ThreadGroup active count=" + tg.activeCount());
			}
			UniProxyConnection item;
			// print out details of each connection
			parent.writeLog("   Connection List:");
			for (Enumeration enum1 = clientConnectTable.elements();enum1.hasMoreElements();)
			{
				item = (UniProxyConnection)enum1.nextElement();
				parent.writeLog("       ClientID:" + item.hashCode());
				item.status();
			}
			// print server configuration
	} /* status() */



  private void syncConnectionTable()
	{
		// a future inhancement idea would be to add a function to UniProxyConnection
		// that cleaned up its connection table for each connection.
		// right now, stale server ID's may exist and stay around for the life of a
		// connection.
		if (debugLevel > 8)
		{
			parent.writeLog("Synchronizing Connection Table, cleaning up stale connections.");
		}
		// clean up stale client connections
		UniProxyConnection item;
		for (Enumeration enum1 = clientConnectTable.elements();enum1.hasMoreElements();)
		{
			item = (UniProxyConnection)enum1.nextElement();
			// check if UniProxyConnection thread is still alive
			if( !item.isAlive() )
			{
				clientConnectTable.remove(item);
				if (debugLevel > 8)
				{
					parent.writeLog("removing connection " + item.toString() +" because it is no longer alive.");
				}
			}
		}
		if (debugLevel > 8)
		{
			parent.writeLog("Connection Table Details:");
			parent.writeLog("   Maximum available connections=" + maxConnections);
			parent.writeLog("   Currently open client connections=" + clientConnectTable.size());
			parent.writeLog("   Current 'CLIENT' ThreadGroup active count=" + tg.activeCount());
		}
	} /* syncConnectionTable() */
/*
  private static void initContext(String ikeyFileName, String ikeypwd, String itrustFileName, String itrustpwd, String kstype, String tstype)
  throws UniProxyException
  {
    try
    {
      JSSEProvider ibmJSSEprovider = new com.ibm.jsse.JSSEProvider();
      Security.addProvider(ibmJSSEprovider);

      KeyStore ks = KeyStore.getInstance(kstype);
      KeyStore ts = KeyStore.getInstance(tstype);

      ks.load(new FileInputStream(ikeyFileName), ikeypwd.toCharArray());
      ts.load(new FileInputStream(itrustFileName), itrustpwd.toCharArray());
//      KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
      KeyManagerFactory kmf = KeyManagerFactory.getInstance("IbmX509");
      kmf.init(ks, ikeypwd.toCharArray());

      TrustManagerFactory tmf = TrustManagerFactory.getInstance("IbmX509");
//      TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
      tmf.init(ts);
      sslContext = SSLContext.getInstance("TLS", ibmJSSEprovider.getName());
//      sslContext = SSLContext.getInstance("SSL");
      sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
    } catch (Throwable e)
    {
      throw new UniProxyException(UniProxyTokens.UNIPROXY_WRONG_SSL_PARAMETERS);
    }
  }
*/

}

