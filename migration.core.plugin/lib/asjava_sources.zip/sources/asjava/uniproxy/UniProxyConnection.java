/*************************************************************************
 *
 * UniProxyConnection.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.uniproxy;

import asjava.uniclientlibs.*;
import asjava.unirpc.*; 
import java.net.*;
import java.io.*;
import java.util.*;
import java.text.*;

/**
 * The <code>UniProxyConnection</code> constructor takes a new client socket 
 * connection from UniProxyServer and manages that client connection for its
 * remaining existance. Once a socket connection is received, <code>UniProxyConnection</code>
 * performs the proxy login process and then forwards all data packets that are
 * sent from the client to the server and vic-versa. Any additional new multiplexed
 * client connections are handled by <code>UniProxyConnection</code>.
 *
 * Notes: <code>UniProxyConnection</code> is a single thread and the server 
 * multiplexing is done by switching the server context for each packet exchange.
 *
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIPROXY 1.0
 */
public class UniProxyConnection extends java.lang.Thread
{
	/**
	 * Constructor for <code>UniProxyConnection</code>. Takes as arguments a
	 * reference to a proxy server instance, a client socket and a thread group instance.
	 *
	 * @param		aThreadGroup		reference to a thread group
	 * @param		aServer		reference to a proxy server
	 * @param		aSocket		reference to a client socket connection
	 * @since	UniProxy1.0
	 */
	public UniProxyConnection(ThreadGroup aThreadGroup, UniProxyServer aServer, Socket aSocket, boolean externalSSLType) throws UniProxyException
	{
		super(aThreadGroup,"UniProxyConnection");
		// initialize instance variables
		serverConnectTable = new Hashtable();
		if ( aServer == null )
		{
			throw new UniProxyException("A valid UniProxyServer reference is required.", UniProxyTokens.UNIPROXY_ERROR_NULL_REFERENCE);
		}
		if ( aSocket == null )
		{
			throw new UniProxyException("A valid Socket reference is required.", UniProxyTokens.UNIPROXY_ERROR_NULL_REFERENCE);
		}
		proxyServer = aServer;
		clientSocket = aSocket;
		// maintain our own pointer to the proxy server configuration
		proxyConfiguration = proxyServer.getConfiguration();
		debugLevel = proxyConfiguration.getDebugLevel();
		// allocate our network buffer
		buffer = new byte[proxyConfiguration.getBufferSize()];
		networkTimeout = proxyConfiguration.getNetworkTimeout();
 		// set time format for logging code
 		logTime = new SimpleDateFormat("yy.MM.dd'-'HH.mm.ss");
    this.externalSSLType = externalSSLType;
	}

  public synchronized void waitMe() throws InterruptedException
  {
    if (!this.waitForSSLThreads)
    {
      this.waitForSSLThreads = true;
      this.wait();
    }
  }

  public synchronized void notifyMe() throws InterruptedException
  {
    if (this.waitForSSLThreads)
    {
      this.waitForSSLThreads = false;
      this.notify();
    }
  }

	/**
	 * Run the proxy connection thread. This method runs until the client connection
	 * is terminated for some reason. First a new server connection is built. Then an infinite loop
	 * is started where all incoming packets are forwarded to a server and all responses are
	 * forwarded to the client. If any new connection requests are received, then another
	 * new server connection is added to our table of server connections.
	 *
	 * @since	UniProxy1.0
	 */
	public void run()
	{
		// We need to trap for IO exceptions on client and server seperatly because
		// We need to know that for a client exception we close the thread down
		// but for a server exception we only remove the server vector. and hopefully
		// keep working.
		int timeoutAccumulator = 0;

		if (debugLevel > 0)
		{
			writeLog("Running a client connection thread.");
		}
		try
		{
			UniRPCPProxyHeader proxyHeader = new UniRPCPProxyHeader();
			// set up the client socket
			clientSocket.setSoLinger( true, networkTimeout );
			clientSocket.setTcpNoDelay( true );
			clientInStream = new DataInputStream(clientSocket.getInputStream());
			clientOutStream = new DataOutputStream(clientSocket.getOutputStream());
			// do client connection & authentication
      UniConnectionDetails conObject = new UniConnectionDetails();
      int returnCode = addConnection(PROXY_HEADER, conObject);
      if ((sslFlag) && (returnCode == 0))
      {
        /* Now we create 2 threads and pass sockets to them */
        clientSocket.setSoTimeout(this.networkTimeout);
        conObject.serverSocket.setSoTimeout(this.networkTimeout);
        try
        {
          UniProxySSLio io1 = new UniProxySSLio(clientInStream,
                                                conObject.serverOutStream,
                                                this,
                                                "client_thread");

          UniProxySSLio io2 = new UniProxySSLio(conObject.serverInStream,
                                                clientOutStream,
                                                this,
                                                "server_thread");

          io1.start();
          io2.start();

          this.waitMe();
          if (debugLevel > 0)
          {
            writeLog("One of SSL Thread finished Main Thread is Exiting");
          }
        }
        catch (InterruptedException e)
        {
          writeLog("Main SSL ThreaD Interrupted Exception. Exiting");
        }
      }
      else if (!sslFlag)
      {
  			if ( debugLevel > 2 && returnCode == 0 )
	  		{
		  		writeLog("Entering packet pass-through mode.");
			  }
  			while (true && returnCode == 0)
	  		{
		  		int bytesToRead = 0;
			  	int bytesRead = 0;
				// we will most likely need to trap exceptions because when one socket
				// of a set of multiplexed sockets goes away, we can't crash.
				  if (isStopFast)
  				{
	  				break;
		  		}
				// we need to implement timeouts so that we can detect a stop signal.
			  	if (debugLevel > 6 && !inIOLoop)
				  {
					  writeLog("Waiting on next client packet...");
  				}

  				try
	  			{
					// set socket timeout(polling time) so we can detect the stop signal.
		  			clientSocket.setSoTimeout(UniProxyTokens.UNIPROXY_INTERNAL_SIGNALING_TIMEOUT);
					// we may be able to avoid using a 5 second timeout if we
					// syncronize the entire packet exchange and use a close socket
					// interupt the read. To synchronize we can use synchronize or use
					// a state variable.
			  		proxyHeader.receive(clientInStream);
				  }
  				catch (UniRPCPacketException e)
	  			{
		  			if (e.getErrorCode() == UniTokens.UNIRPC_TIMEOUT)
			  		{
				  		inIOLoop = true;
						// unless we change our polling method we need to
						// count up the timeout times so that we can timeout once
						// the networkTimeout is reached
					  	timeoutAccumulator += UniProxyTokens.UNIPROXY_INTERNAL_SIGNALING_TIMEOUT;
						  if ( timeoutAccumulator < networkTimeout)
  						{
	  						continue;
		  				}
			  			else
				  		{
					  		if (debugLevel > 4)
						  	{
							  	writeLog("Client connection closed, proxy server network timeout.");
  							}
	  					}
		  			}
			  		else
				  	{
					  	inIOLoop = false;
  						if (debugLevel > 4)
	  					{
		  					writeLog("Client connection closed by the client.");
			  			}
				  	}
					// at this point we are assuming that this connection has been closed
					// and we are going to let this thread finish.
					  break;
  				}
	  			inIOLoop = false;
		  		timeoutAccumulator = 0;
				// set socket timeout to configuration.
  				clientSocket.setSoTimeout(networkTimeout);

  				Integer connectionID = new Integer(proxyHeader.readConnection());
	  			if (debugLevel > 6)
		  		{
			  		writeLog("   Server connection ID=" + connectionID);
				  }
				// look up connection in connection table
  				UniConnectionDetails connectionObject = (UniConnectionDetails) serverConnectTable.get(connectionID);
				// if connection not found then create a new one
	  			if( connectionObject == null && connectionID.intValue() == 0)
		  		{
			  		if (debugLevel > 4)
				  	{
					  	writeLog("   Multiplexing an additional server connection into");
						  writeLog("      the current client proxy connection.");
  					}
					// we need to tell addConnection() to use the proxy header that was allready read.
            connectionObject = new UniConnectionDetails();
		  			addConnection(NO_PROXY_HEADER, connectionObject);
			  		continue;
				  }
				// catch server side network exception or timeout and handle appropriately
  				try
	  			{
					// if not spoof packet, then read and forward
		  			if( proxyHeader.readHeaderType() != UniRPCTokens.UNIRPC_PROXY_HEADER_TYPE_SPOOF )
			  		{
						// get length of client data packet
				  		bytesToRead = proxyHeader.getLength();
						// forward incoming packet
					  	while( bytesToRead > 0 )
						  {
							  bytesRead = (bytesToRead < buffer.length ? bytesToRead : buffer.length);
  							clientInStream.readFully(buffer, 0, bytesRead);
	  						connectionObject.serverOutStream.write(buffer, 0,bytesRead);
		  					bytesToRead -= bytesRead;
			  			}
				  		if (debugLevel > 6)
					  	{
						  	writeLog("   Finished forwarding client packet.");
							  writeLog("   Waiting on server packet...");
  						}
	  				}
		  			else
			  		{
						// this is proxy spoof header so there is no packet to read from client
				  		if (debugLevel > 6)
					  	{
						  	writeLog("   Proxy spoofing header received from client.");
  							writeLog("   Waiting on server packet...");
	  					}
		  			}
					// we want to read the incoming message header from the server
			  		connectionObject.serverInStream.readFully(buffer, 0, 24);
					// read and forward first part of outgoing message to the client
				  	bytesToRead = ( (int) (
					  	(((int) buffer[4] & 0xFF) << 24) +
  						(((int) buffer[5] & 0xFF) << 16) +
	  					(((int) buffer[6] & 0xFF) <<  8) +
		  				(((int) buffer[7] & 0xFF) <<  0) ) );
			  		proxyHeader.setLength(bytesToRead + 24);
				  	bytesRead = (bytesToRead < (buffer.length - 24) ? bytesToRead : (buffer.length - 24));
					  connectionObject.serverInStream.readFully(buffer, 24, bytesRead);
  					bytesToRead -= bytesRead;
	  				proxyHeader.send(clientOutStream);
		  			clientOutStream.write(buffer, 0,bytesRead + 24);
			  		// if more data to send,
				  	// finish reading and forwarding outgoing message to the client
					  while( bytesToRead > 0 )
  					{
	  					bytesRead = (bytesToRead < buffer.length ? bytesToRead : buffer.length);
		  				connectionObject.serverInStream.readFully(buffer, 0, bytesRead);
			  			bytesToRead -= bytesRead;
				  		clientOutStream.write(buffer, 0,bytesRead);
					  }
  					if (debugLevel > 6)
	  				{
		  				writeLog("   Finished forwarding server packet.");
			  		}
				  }
  				catch (IOException e)
	  			{
		  			writeLog("Error: Server side of client connection was dropped!:" + e.toString());
					// remove server connection. if this is the last connection
					// then get out of here, otherwise continue
			  		connectionObject.serverInStream.close();
				  	connectionObject.serverOutStream.close();
					  connectionObject.serverSocket.close();
  					serverConnectTable.remove(connectionObject);
	  				if ( serverConnectTable.size() > 0 )
		  			{
			  			continue;
				  	}
  					else
	  				{
		  				break;
			  		}
				  }
  			} /* END - while packets need to be forwarded */
      } /* if !sslFlag */
		}
		catch (IOException e)
		{
			writeLog("Error: " + e.toString());
		}
		catch (UniRPCPacketException e)
		{
			writeLog("Error: An error has occured during a data packet exchange:" + e.toString());
		}
		// for some reason this thread is exiting.
		// we are cleaning up the thread before it exits.
		try
		{
			// close server connections
			for (Enumeration enum1 = serverConnectTable.elements();enum1.hasMoreElements();)
			{
				UniConnectionDetails serverConnTemp = (UniConnectionDetails)enum1.nextElement();
				serverConnTemp.serverInStream.close();
				serverConnTemp.serverOutStream.close();
				serverConnTemp.serverSocket.close();
			}
			serverConnectTable.clear();
			// close client connection
      clientOutStream.close();
      clientInStream.close();
			clientSocket.close();
		}
		catch (IOException e)
		{
			writeLog(e.toString());
			writeLog("Error: failed to clean up connection when shutting down.");
		}
	} /* run() */

	/**
	 * Sets the flag designating that this session has exceeded the maximum number of
	 * supported client sessions. What this means is that the client will fail the
	 * proxy login with this error.
	 *
	 * @since	UniProxy1.0
	 */
	public void setExceedMaxSessions()
	{
		// set the internal flag designating that we have exceeded the
		// maximum number of supported sessions.
		isExceedMaxSessions = true;
	} /* setExceedMaxSessions() */

	/**
	 * Write the current status of this proxy connection to the log file. The
	 * status consists of a detailed listing of all the servers this client
	 * connection is currently connected to. This method is designed to be
	 * called from within the status() method of <code>UniProxyServer</code>.
	 *
	 * @since	UniProxy1.0
	 */
	public void status()
	{
		UniConnectionDetails item;
		// print out details of this client connection
		for (Enumeration enum1 = serverConnectTable.elements();enum1.hasMoreElements();)
		{
			item = (UniConnectionDetails)enum1.nextElement();
			writeLog("   ServerID:" + item.hashCode());
		}
	} /* status() */

	/**
	 * Stop this connection as soon as possible. The proxy server has stoped
	 * and signaled all connections to stop as soon as possible. As soon as the current
	 * packet exchange is complete, this thread will exit.
	 *
	 * @since	UniProxy1.0
	 */
	public void stopFast()
	{
		// For some reason this thread needs to be stoped as soon as possible
		// signal for termination
		isStopFast = true;
	} /* stopFast() */

	/**
	 * Write the specified ASCII text to the proxy server log file.
	 * Prepend the text with the time, date and a "-C" to designate that this message
	 * was generated by a <code>UniProxyConnection</code> instance. In addition, a
	 * unique numeric identifier for each <code>UniProxyConnection</code> instance
	 * follows the "-C".
	 *
	 * @param		aLogEntry		ASCII log message
	 * @since	UniProxy1.0
	 */
	public void writeLog(String aLogEntry)
	{
		proxyServer.writeLogRaw( logTime.format(new Date(System.currentTimeMillis()))
			+ "-C" + new Integer(this.hashCode()) + " " + aLogEntry);
	}


  public boolean getIsStopFast()
  {
    return(this.isStopFast);
  }

	/**
	 * Authenticates the client connection and builds a connection with the specified server.
	 * After that is complete, the <code>run()</code> method takes over maintaining the connection again.
	 * Both original and multiplexed connections are handled by this method.
	 * When the <code>aFlag</code> parameter is set to <code>PROXY_HEADER</code> then this is
	 * a new connection but if it is set to <code>NO_PROXY_HEADER</code> then this is an additional server multiplex request.
	 *
	 * @param		aFlag		proxy header flag
	 * @return	"0" if successful. "-1" if failed
	 * @since	UniProxy1.0
	 */
	private int addConnection(int aFlag,
                            UniConnectionDetails connectionObject)
	{
    // read login packet from client, verify its contents,
    // send responding packet, then return so that we enter
    // the packet pass-through mode.

		int returnCode = 0;
		// add new server connection
		if (debugLevel > 4)
		{
			writeLog("Adding a new server connection.");
		}

    returnCode = GetLoginPacketAndSetConnectionObject(aFlag, connectionObject);
    if (returnCode != 0)
    {
      return(returnCode);
    }

    if (this.sslFlag && aFlag == NO_PROXY_HEADER)
    {
			writeLog("We cannot come here since we are multiplexing with ssl connection ");
      return(-1);
    }

    if ((this.sslFlag == true)
        &&
        (proxyConfiguration.getProxySSLFlag() == false))
    {
      return UniRPCTokens.UNIRPC_BAD_CONNECTION;
    }

    if ((this.sslFlag == false && this.externalSSLType == false)
        &&
        (proxyConfiguration.getProxySSLOnlyFlag() == true))
    {
      return UniRPCTokens.UNIRPC_BAD_CONNECTION;
    }

    returnCode = AuthenticateClient(connectionObject);

		// check that the maximum session or connection limits have not been exceeded.
		if (returnCode == 0)
		{
			if ( isExceedMaxSessions && aFlag == PROXY_HEADER /*means new client session*/)
			{
				returnCode = UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSIONS;
			}
			else if (serverConnectTable.size() >= proxyConfiguration.getMaxMultiplexedServers()
				&& aFlag == NO_PROXY_HEADER /*means additional server connection*/)
			{
				returnCode = UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSION_CONNECTIONS;
			}
		}

	  // get new connection ID for this connection
    Integer  connectionIDObject = buildLoginReplyAndSend( connectionObject,
                                                          returnCode);
  		// if we failed login procedure, then we exit here
    if (returnCode != 0)
    {
      return -1;
    }
  		// we have finished the login procedure now lets build our server connection
    returnCode = establishServerConnection(connectionObject);

    if (returnCode != 0)
    {
      writeLog("   Error: Failed server connect to " + connectionObject.serverName);
      return -1;
    }
  		// use hashcode of socket for connection id and vector id
	  	// connection is established, lets put it in our hash table

    // if it is ssl we do not want to put into a table since the connection
    // cannot be multiplexed anyway.

    serverConnectTable.put(connectionIDObject, connectionObject);

  		// we are done with proxy login so lets get on with it.
    if (debugLevel > 4)
    {
      writeLog("   New connection successfully completed!!!");
    }
		return 0;
	}

private int GetLoginPacketAndSetConnectionObject
(
  int aFlag,
  UniConnectionDetails connectionObject
)
{
		int returnCode = 0;
		if (debugLevel > 4)
		{
			writeLog("Adding a new server connection.");
		}

		UniRPCPacket loginPacketIn = new UniRPCPacket();
		if (aFlag == PROXY_HEADER)
		{
			loginPacketIn.setProxyHeader(new UniRPCPProxyHeader());
		}

		try
		{
			if (debugLevel > 4)
			{
				writeLog("   receiving proxy login packet.");
			}
			loginPacketIn.receive(clientInStream);

			if (debugLevel > 6)
			{
				writeLog("   look at proxy login packet values.");
			}
			// read host and port from inPacket
			connectionObject.serverName = loginPacketIn.readString(0);
			connectionObject.serverPort = loginPacketIn.readInteger(1);
			connectionObject.accessToken = loginPacketIn.readString(2);

      int sslFlagInt = loginPacketIn.readInteger(3);
      if (sslFlagInt > 0)
      {
        this.sslFlag = true;
      }
		}
		catch (UniRPCPacketException e)
		{
			writeLog("   Error: addConnection() " + e.getMessage());
			returnCode = -1;
		}
    return(returnCode);
}

private int AuthenticateClient(UniConnectionDetails connectionObject)
{
    int returnCode = 0;
		try
		{
			// check to see if this client is authorized to connect to this server.
      returnCode = proxyConfiguration.authenticateClient(connectionObject.accessToken, connectionObject.serverName);
			if( returnCode == 0 )
			{
				if (debugLevel > 4)
				{
					writeLog("   Client successfully authenticated.");
				}
			}
			else
			{
				returnCode = UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_AUTH;
				writeLog("   Warning: Client authentication failed! Try another access token and server.");
			}
		}
		catch( UniProxyException e)
		{
			writeLog("   Error: addConnection() " + e.getMessage());
      returnCode = UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_AUTH;
		}
    return(returnCode);
}


private Integer buildLoginReplyAndSend( UniConnectionDetails  connectionObject,
                                        int returnCode)
{
  		UniRPCPacket loginPacketOut = new UniRPCPacket();
	  	loginPacketOut.setProxyHeader(new UniRPCPProxyHeader());
		// get new connection ID for this connection
  		Integer connectionIDObject = new Integer(connectionObject.hashCode());

	  	try
		  {
			  // build reply packet for proxy login
  			loginPacketOut.getProxyHeader().writeConnection(connectionIDObject.hashCode());
	  		loginPacketOut.write(0, returnCode);
		  	loginPacketOut.write(1, connectionIDObject.hashCode());
			  loginPacketOut.send(clientOutStream, (byte)1, connectionIDObject.hashCode());
  			if (debugLevel > 4)
	  		{
		  		writeLog("   Reply to proxy login packet sent.");
			  }
		  }
  		catch (UniRPCPacketException e)
	  	{
		  	writeLog("   Error: " + e.getMessage());
        connectionIDObject = null;
		  }
      return(connectionIDObject);
}

private int establishServerConnection(UniConnectionDetails connectionObject)
{
		// lets look up the DNS entry for this server in our Cache
		InetAddress netAddress = proxyServer.lookupInetAddress(connectionObject.serverName);
		// open connection to server
		try
		{
			// connect to the RPC daemon on the desired server
			connectionObject.serverSocket = new Socket(netAddress, connectionObject.serverPort);
			connectionObject.serverSocket.setSoLinger( true, networkTimeout );
			connectionObject.serverSocket.setTcpNoDelay( true );
			connectionObject.serverOutStream = new DataOutputStream(connectionObject.serverSocket.getOutputStream());
			connectionObject.serverInStream = new DataInputStream(connectionObject.serverSocket.getInputStream());
			if (debugLevel > 4)
			{
				writeLog("   Connection to the requested server established!");
			}
		}
		catch (Exception e)
		{
			return -1;
		}
    return(0);
}


	// instance variables
 	private boolean isMultiplexed = false;
 	private boolean isStopFast = false;
 	private boolean inIOLoop = false;
	private	boolean isExceedMaxSessions = false;
	private int debugLevel;
	private int networkTimeout;
	private byte[] buffer;
 	private Socket clientSocket;
	private DataInputStream clientInStream;
	private DataOutputStream clientOutStream;
	private UniProxyServer proxyServer;
	private UniProxyConfiguration proxyConfiguration;
	private Hashtable serverConnectTable;
	private SimpleDateFormat logTime;
	private final static int PROXY_HEADER = 0;
	private final static int NO_PROXY_HEADER = 1;
  private boolean sslFlag = false;
  private boolean waitForSSLThreads = false;
  private boolean externalSSLType = false;
}

/**
 * The <code>ConnectionDetails</code> class contains all the details for one server
 * connection. The <code>UniProxyConnection</code> class maintains a hash table of
 * <code>ConnectionDetails</code> objects. <code>UniProxyConnection</code> then switches
 * context by switching between <code>ConnectionDetails</code> instances.
 *
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UniProxy1.0
 */
class UniConnectionDetails extends Object
{
	// the access token that was supplied by the client for this connection
	public String accessToken = "";
	// the server name for this instance
	public String serverName = "";
  public int serverPort = 0;
	// the socket connected to this server
	public Socket serverSocket;
	// the data output stream for this server
	public DataOutputStream serverOutStream;
	// the data input stream for this server
	public DataInputStream serverInStream;
}