package asjava.uniproxy;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


/**
 * A Class class.
 * <P>
 * @author Systems Admin
 */
public class UniProxySSLio extends Thread {

    InputStream in;
    OutputStream out;
    byte[] inbuffer;
    UniProxyConnection parent;
    String ident;

    static final int ARRAY_SIZE = 5000;
  /**
   * Constructor
   */

  public UniProxySSLio(InputStream iin,
                OutputStream iout,
                UniProxyConnection upc,
                String id)
  {
      in = iin;
      out = iout;
      inbuffer = new byte[ARRAY_SIZE];
      parent = upc;
      ident = id;
  }

  public void run()
  {
    int i = 0;

    try
    {
        this.sleep(50);
        while(!parent.getIsStopFast())
        {
          i = in.read(inbuffer);
          if (i < 0)
          {
            break;
          }

          out.write(inbuffer, 0, i);
          this.yield();
        }
    }
    catch (IOException e)
    {
        parent.writeLog("IOException in SSL Thread " + ident);
    }
    catch (Exception e)
    {
        parent.writeLog("Excpetion in Thread " + ident);
    }

    try
    {
      parent.notifyMe();
    }
    catch (InterruptedException e)
    {
      parent.writeLog("InterruptedExcpetion in Thread " + ident);
    }
  }
}

