/*************************************************************************
 *
 * UniProxyServer.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 OGO Initial Creation
 *************************************************************************/

package asjava.uniproxy;

import java.net.*;
import java.io.*;
import java.util.*;
import java.text.*;

/**
 * The <code>UniProxyServer</code> class listens for and receives client connections.
 * Once a connection is received, the proxy server
 * creates and instance of <code>UniProxyConnection</code> ands passes of the client connection
 * to the new <code>UniProxyConnection</code> thread. The <code>UniProxyServer</code> then continues
 * listening for more incomming client connection requests.
 *
 * Notes: The proxy server is multithreaded and can handle an unlimited number of connections
 *        simultaniously. However, the <code>UniProxyServer</code> class will only launch one new connection
 *        at a time.
 *
 * @version	Version 1.0
 * @author	Occhio Orsini
 * @since	UNIPROXY 1.0
 */
public class UniProxyServer extends java.lang.Object
{
	/**
	 * Constructs a <code>UniProxyServer</code> instance.
	 *
	 * @since	UniProxy1.0
	 */
 	public UniProxyServer()
 	{
		dnsCache = new Hashtable();
 		clientThreadGroup = new ThreadGroup("CLIENT");
 		proxyConfiguration = new UniProxyConfiguration();
 		// set time format for logging code
 		logTime = new SimpleDateFormat("yy.MM.dd-HH.mm.ss");
 	}

	/**
	 * Current entry point into the <code>UniProxyServer</code> class. 
	 * One and only one parameter is specified on the command line.
	 * This parameter is the path to a valid configuration for this proxy server.
	 *
	 * @param		args		command line parameters
	 * @since	UniProxy1.0
	 */
 	public static void main(String[] args)
 	{ 		
 		// print out command usage if command line is wrong
 		if( args.length != 1 || !(args[0].toLowerCase().startsWith("-config=")) )
 		{
 			System.out.println("Error: Incorrect or wrong number of arguments!");
 			printUsage();
 			System.exit(0);
 		}
 		// create an instance of the proxy server and configuration
 		UniProxyServer proxyServer = new UniProxyServer();
 		UniProxyConfiguration newProxyConfiguration = new UniProxyConfiguration();
		try
		{
			// load the configuration file
			newProxyConfiguration.setLocation(args[0].substring(8));
			newProxyConfiguration.load();
			proxyServer.setConfiguration(newProxyConfiguration);
			proxyServer.writeLog("---------------NEW SERVER INSTANCE---------------");
			if ( newProxyConfiguration.getDebugLevel() > 0 )
			{
				proxyServer.writeLog("Finished loading server configuration.");
				newProxyConfiguration.dump(proxyServer);
			}
		}
		catch (UniProxyException e)
		{
			proxyServer.writeLog("Failed to set proxy server configuration because:" + e.getMessage());
			System.exit(0);
		}
		try
		{
			// run the proxy server. When this method returns, the proxy server has terminated.
			proxyServer.runServer();
		}
		catch (UniProxyException e)
		{
			// a fatal exception has occured in the proxy server
			System.out.println("Error: Proxy server exiting, error=" + e.getMessage());
			proxyServer.writeLog("Error: Proxy server exiting, error=" + e.getMessage());
			System.exit(0);
		}
		proxyServer.writeLog("-------------SERVER EXITING NORMALLY-------------");
		// A system exit is used here because if we don't and a uvapi_server
		// hangs, the proxy server won't exit.
		System.exit(0);
	} /* main() */

	/**
	 * Gets the currently defined <code>UniProxyConfiguration</code> for this <code>UniProxyServer</code> instance.
	 *
	 * @return	<code>UniProxyConfiguration</code> reference 
	 * @since	UniProxy1.0
	 */
	public UniProxyConfiguration getConfiguration()
	{
		// sync code on configuration to protect against sourcing configuration while
		// it is being set
		synchronized(proxyConfiguration)
		{
			return proxyConfiguration;
		}
	}

	/**
	 * Looks up the InetAddress of the specified server in our DNS Cache.
	 *
	 * @param		aServerName		a server name
	 * @return	<code>InetAddress</code> reference
	 * @since	UniProxy1.0
	 */
	public InetAddress lookupInetAddress(String aServerName)
	{
		// lets lookup the DNS entry for this server in our DNS Cache
		// cache access is synchronized because HashTable is probably not thread safe
		InetAddress netAddress;
		synchronized(this)
		{
			// lookup the requested server address
			netAddress = (InetAddress) dnsCache.get(aServerName);
		}
		if( netAddress == null )
		{
			try
			{
				netAddress = InetAddress.getByName(aServerName);
				synchronized(this)
				{
					// add this new InetAddress to our cache
					dnsCache.put(aServerName, netAddress);
				}
			}
			catch (UnknownHostException e)
			{
				netAddress = null;
			}
		}
		return netAddress;
	}	
	
	/**
	 * Reload the configuration file. This method is used when you want to change the
	 * proxy server configuration without shutting down the server.
	 *
	 * @since	UniProxy1.0
	 */
	public void reconfigure()
	{
		// we need to add support for continuing to append to log file unless a new
		// one is created.
		if (debugLevel > 0)
		{
			writeLog("Reconfiguring proxy server.");
		}
		UniProxyConfiguration newProxyConfiguration = new UniProxyConfiguration();
		newProxyConfiguration.setLocation(proxyConfiguration.getLocation());
		try
		{
			// load new configuration
			newProxyConfiguration.load();
			setConfiguration(newProxyConfiguration);
			synchronized(proxyConfiguration)
			{
				writeLog("This is the new proxy configuration.");
				newProxyConfiguration.dump(this);
			}
		}
		catch(UniProxyException e)
		{
			writeLog("Error: Failed to reload proxy server configuration with error=" + e.toString());
		}
		// update client connection table
//		syncConnectionTable();
		// reset DNS Cache
		synchronized(this)
		{
			dnsCache.clear();
		}
	}

	/**
	 * Restart the proxy server once it has been suspended. The proxy server can only be suspended in 
	 * one way. The command "suspend" will put the proxy server in a state where it can be restarted.
	 *
	 * @since	UniProxy1.0
	 */
	public void restart()
	{
		// signal server to restart.
		if (isSuspendServer == true)
		{
			if (debugLevel > 0)
			{
				writeLog("Restarting proxy server.");
			}
      this.upst1.restartT1Server();
      if (this.upst2 != null)
      {
        this.upst2.restartT1Server();
      }
			isSuspendServer = false;
		}
		else
		{
			// server not in suspended state, can't restart it
			writeLog("Error: Proxy server not in suspended state, can't restart it.");
		}
	}

	/**
	 * Run this instance of <code>UniProxyServer</code>. <code>UniProxyServer</code> stays in this method until
	 * it terminates under normal or abnormal conditions.
	 *
   * @exception  UniProxyException if a catastrophic error occurs which causes the proxy
   *             server to terminate.
	 * @since	UniProxy1.0
	 */
	public void runServer() throws UniProxyException
	{
		try
		{
			if (debugLevel > 0)
			{
				writeLog("Starting proxy server.");
			}

      /* Start 2 threads 1 - for Ccomplete S and non-secure connections and
                         2 - External Secure Connection.
      */
      upst1 = new UniProxyServerT1(proxyConfiguration.getPort(),
                                    this,
                                    clientThreadGroup,
                                    false);
      if ((proxyConfiguration.getProxySSLFlag() == true)
         ||
         (proxyConfiguration.getProxySSLOnlyFlag() == true))
      {
        upst2 = new UniProxyServerT1(proxyConfiguration.getSSLPort(),
                                                    this, clientThreadGroup, true);
      }
      else
      {
        if (debugLevel > 0)
        {
          writeLog("Not starting ssl thread of proxy");
        }
        upst2 = null;
      }

      upst1.start();

      if (upst2 != null)
      {
        upst2.start();
      }
			// setup admin server, server socket
			adminServer = new UniProxyAdminServer(this);
			adminServer.start();

      this.waitMe();
    }
    catch (InterruptedException e)
    {
      writeLog("ProxyServer Interrupted Exception. Exiting " + e.getMessage());
    }

		try
		{
			shutdown();
			adminServer.stop();
			// we need to wait for the admin server thread to exit.
			adminServer.join(2000); // wait 2 minutes for admin server to shutdown
		}
		catch (InterruptedException e)
		{
			// let fall through
		}
		// we just let this fall through because we want the server to terminate
	} /* runServer() */

	/**
	 * Sets a new <code>UniProxyConfiguration</code> for this <code>UniProxyServer</code> instance.
	 *
	 * @param		aProxyConfiguration		a <code>UniProxyConfiguration</code> reference.
   * @exception  UniProxyException if any file IO errors occur while closing or
   *             opening the proxy server logging file.
	 * @since	UniProxy1.0
	 */
	public void setConfiguration(UniProxyConfiguration aProxyConfiguration) throws UniProxyException
	{
		// once this method completes, all new connections will use this new configuration.
		// However, all existing connections will still use the old configuration. All connections
		// will write their logging information to the new log file.
		synchronized(proxyConfiguration)
		{
			proxyConfiguration = aProxyConfiguration;
			debugLevel = proxyConfiguration.getDebugLevel();
			maxConnections = proxyConfiguration.getMaxConnections();
			try
			{
				// close current log file before we open a new one(or possibly the same one).
				if (logFile != null)
				{
					logFile.close();
				}
				logFile = new RandomAccessFile(proxyConfiguration.getPathLog() + proxyConfiguration.getNameLog(), "rw");
				// move file pointer to the end of log file
				long fileLength = logFile.length();
				logFile.seek(fileLength);
			}
			catch(IOException e)
			{
				throw new UniProxyException( "Error: Failed to open new logging file:" + e.getMessage(), UniProxyTokens.UNIPROXY_ERROR_GENERAL );
			}
		}
	} /* setConfiguration */

	/**
	 * Shutdown the proxy server. The proxy server is stoped and after all connection
	 * threads have completed on their own, the proxy server will exit.
	 *
	 * @since	UniProxy1.0
	 */
	public void shutdown()
	{
    
		if (debugLevel > 0)
		{
			writeLog("Shutting down proxy server.");
		}
		// stop accepting any new client connections
		suspendServer();
		// walk connection table waiting for each connection to be terminated
		UniProxyConnection item;
		// let server process shutdown
		isShutdownServer = true;
		isSuspendServer = false;
    if (this.upst1 != null)
    {
      this.upst1.shutdown();
    }
    if (this.upst2 != null)
    {
      this.upst2.shutdown();
    }
	} /* shutdown() */

	/**
	 * Shutdown the proxy server as fast as possible. The proxy server is suspended
	 * and after each connection has completed its current packet exchange they
	 * are terminated and then the proxy server will exit.
	 *
	 * @since	UniProxy1.0
	 */
	public void shutdownFast()
	{
		if (debugLevel > 0)
		{
			writeLog("Shutting down proxy server immediately.");
		}
		// stop accepting any new connections
		suspendServer();
		// walk connection table terminating each connection.
		// at the end of next packet exchange.
		if (debugLevel > 5)
		{
			writeLog("Signal all open client connection threads to terminate.");
		}

		// walk connection table waiting for each connection to finish
		if (debugLevel > 5)
		{
			writeLog("Wait on all open client connection threads to finish.");
		}
		// let server process shutdown
		isShutdownServer = true;
		isSuspendServer = false;
		synchronized(this)
		{
			notify();
		}
	} /* shutdownFast() */

  public boolean getisShutdown()
  {
    return(isShutdownServer);
  }

  public boolean getisSuspended()
  {
    return(isSuspendServer);
  }

	/**
	 * Write the current status of the proxy server to the log file. The status consistes of
	 * a detailed listing of active client connections as well as a dump of the current
	 * configuration in use by the proxy server.
	 *
	 * @since	UniProxy1.0
	 */
	public void status()
	{
		synchronized(proxyConfiguration)
		{
			if (debugLevel > -1)
			{
				writeLog("Dumping current status of proxy server to log file.");
				writeLog("   Updating the connection table.");
			}
			// dump a list of all connections and their states.
			if (debugLevel <= 8)
			{
				writeLog("Connection Table Details:");
				writeLog("   Maximum available connections=" + maxConnections);
//				writeLog("   Currently open client connections=" + clientConnectTable.size());
//				writeLog("   Current 'CLIENT' ThreadGroup active count=" + clientThreadGroup.activeCount());
			}
			// print out details of each connection
			writeLog("   Connection List:");
			// print server configuration
			getConfiguration().dump(this);
		}
	} /* status() */

	/**
	 * Suspend the proxy server. The proxy server is suspended and no new connections
	 * are accepted until it is restarted.
	 *
	 * @since	UniProxy1.0
	 */
	public void suspendServer()
	{
		// signal server to stop accepting requests
		if (debugLevel > 0)
		{
			writeLog("Suspending proxy server.");
		}
		isSuspendServer = true;
    if (this.upst1 != null)
    {
      this.upst1.SuspendT1Server();
    }
    if (this.upst2 != null)
    {
      this.upst2.SuspendT1Server();
    }
	}	/* suspendServer() */

	/**
	 * Write the specified ASCII text to the proxy server log file.
	 * This method is called by the <code>writeLog()</code> method of the other proxy
	 * server classes. It is internally synchronized so that all log messages are
	 * written in the correct order.
	 *
	 * @param		aLogEntry		ASCII log message
	 * @since	UniProxy1.0
	 */
	public void writeLogRaw(String aLogEntry)
	{
		// synchronize on the proxy configuration so that we can support changing the
		// proxy configuration while the proxy server is running.
		synchronized(proxyConfiguration)
		{
			if( logFile != null )
			{
				// write logging information to log file
				try
				{
					logFile.writeBytes(aLogEntry + "\n");
				}
				catch(IOException e)
				{
					System.out.println(aLogEntry);
					System.out.println("UniProxyServer.writeLogRaw() failed:" + e.toString());
				}
			}
			else
			{
				// write logging information to screen
				System.out.println(aLogEntry);
			}
		}
	} /* writeLogRaw() */

	/**
	 * Write the specified ASCII text to the proxy server log file.
	 * Prepend the text with the time, date and an "-S" to designate that this message
	 * was generated by <code>UniProxyServer</code>.
	 *
	 * @param		aLogEntry		ASCII log message
	 * @since	UniProxy1.0
	 */
	protected void writeLog(String aLogEntry)
	{
		writeLogRaw( logTime.format(new Date(System.currentTimeMillis()))
			+ "-S" + " " + aLogEntry);
	} /* writeLog() */
	
	/**
 	 * Prints the usage of UniProxyServer when instantiated from the command line.
 	 * This method is called when invalid options are specified on the command line.
	 *
	 * @since	UniProxy1.0
	 */
	private static void printUsage()
	{
 		// print the usage for this class
	 	System.out.println("Usage: UniProxyServer -config=configuration file");
	} /* printUsage() */


  public synchronized void waitMe() throws InterruptedException
  {
    if (!this.waitForThreads)
    {
      this.waitForThreads = true;
      this.wait();
    }
  }

  public synchronized void notifyMe() throws InterruptedException
  {
    if (this.waitForThreads)
    {
      this.waitForThreads = false;
      this.notify();
    }
  }

  public int getMaxConnections()
  {
    return(maxConnections);
  }

  public int getDebugLevel()
  {
    return(debugLevel);
  }

	// these variables are for each instance of the UniProxyServer class
	private boolean isSuspendServer = false;
	private boolean isShutdownServer = false;
  private boolean waitForThreads = false;
	private int debugLevel;
	private int maxConnections;

  private UniProxyServerT1 upst1;
  private UniProxyServerT1 upst2;

	private RandomAccessFile logFile;
	private SimpleDateFormat logTime;
	private UniProxyConfiguration proxyConfiguration;
	private UniProxyAdminServer adminServer;
//	private Hashtable clientConnectTable;
	private Hashtable dnsCache;
	private ThreadGroup clientThreadGroup;
}