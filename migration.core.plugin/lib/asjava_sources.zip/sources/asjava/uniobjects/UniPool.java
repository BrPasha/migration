/*************************************************************************
 *
 * UniPool.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 *       IBM Confidential
 *       OCO Source Materials
 *       Copyright (C) IBM Corp.  1993, 2005
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... ECASE  WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 10/26/06 E35580 JFM fix the open session timeout problem when cp is on
 * 08/04/05 E33964 JFM call closeServerConnection(us) when us isnot serverAlive()
 *                     to properly dispose of it and maintain the pool's min size
 * 07/26/05 E33964 RKK Use isServeAlive() of UniRPCConnection Class.
 * 07/12/05 E7815  RKK Socket alive for connection pooling
 * 06/22/05 E33849 RKK Handle case when when min pool size is greater than number of pooled licenses. 
 * 01/18/05 e33136 RKK Fix Null Exception in closeIdleSession()
 * 12/13/04 32565  JFM added hostPort for the constructor to allow change 
 *                    of default host port number, modified closeIdleConnections()
 *                    ,closeServerConnection(), etc.
 * 09/17/04 32565 RKK Initial Creation
 *************************************************************************/

package asjava.uniobjects;

import java.util.Date;
import java.util.Vector;

import asjava.uniclientlibs.*;

import asjava.unirpc.*;


/**
 * <code>UniPool</code> is a Class Connection Pooling. It is used for 
 * preallocating, recycling and managing U2 connections. Each UniPool is identified
 * as hashtable key "userid+password+servername+accountname".
 * @version	Version 2.0.3
 * @author	
 * @since	UNIOBJECTS 2.4
 */
public final class UniPool extends UniBase{
	
	
	
	/**
	 * Constructor for this Class. It preallocates U2 connections as per Min/Max Pool Size. 
	 * @param phostname String representing the name of the host to connect to
	 * @param puserid String representing the server-side username used for connection purposes.
	 * @param ppassword String representing the password to be used for the connection
	 * @param paccount String representing which account to connect to
	 * @param pservice String representing the datasource type.
	 * @param sslmode  Integer representing the ssl mode.
	 * @param pmin_poolsize Integer representing Min Pool Size.
	 * @param pmax_poolsize Integer representing Max Pool Size.
	 * @throws UniSessionException is thrown if an error occurs
	 */
	protected UniPool(String phostname, int phostport, String puserid, String ppassword,
			String paccount, String pservice, int psslmode, int pmin_poolsize,
			int pmax_poolsize) throws UniSessionException {
		synchronized (this) {
			userid = puserid;
			password = ppassword;
			server = phostname;
			account = paccount;
			service = pservice;
			sslmode = psslmode;
			hostport = phostport;
			minPoolSize = pmin_poolsize;
			maxPoolSize = pmax_poolsize;
			UniJava.uniLog("calling UniPool::UniPool() with " 
					+ " hostname : " + server 
					+ " hostport : " + hostport
					+ " userid : " + userid 
					+ " password : " + password 
					+ " account : " + account
					+ " service : " + service
					+ " sslmode : " + sslmode 
					+ " min_poolsize : " + minPoolSize
					+ " max_poolsize : " + maxPoolSize
					+ " IdleRemoveThreshold:" +UniJava.getIdleRemoveThreshold()
					+" IdleRemoveExecInterval:"+UniJava.getIdleRemoveExecInterval());
			if (availableConnections == null && busyConnections == null) {
				if (minPoolSize > maxPoolSize) {
					minPoolSize = maxPoolSize;
				}
				availableConnections = new Vector(minPoolSize);
				busyConnections = new Vector();
				int lIndex=0;
				try {
					for ( lIndex = 0; lIndex < minPoolSize; lIndex++) {
						availableConnections.add(makeNewConnection(sslmode));
					}
				} catch (UniSessionException e) {
					for (int i = 0; i < availableConnections.size(); i++) {
						UniSession us = (UniSession) availableConnections.elementAt(i);
						us.disconnectServer();
						UniJava.uniLog("In UniPool()::UniPool()us.disconnectServer is called due to exception");
					}
					if(lIndex > 0 && lIndex < minPoolSize)
					{
						// we already made "lIndex" number connections and trying more
						// looks like m_MinPoolSize > license limit
						UniJava.uniLog("In UniPool()::UniPool()may be m_MinPoolSize > license limit");
						throw new UniSessionException(UniTokens.UVE_MINPOOL_MORETHAN_LICENSE);
					}
					else
					{
						throw e;
					}
				}
			}
		}
	}
	
	/**
	 * This is a recursive function. Either it makes a new U2 connection or it gets from
	 * the available connection list. It calls itself as soon as it gets notification from 
	 * other thread.
	 * @param sessionTimeout 	Integer representing Session Timeout.
	 * @param sslmode 			Integer representing ssl mode.
	 * @return					UniSession Object
	 * @throws UniSessionException is thrown if an error occurs
	 */
	protected UniSession findSession(long sessionTimeout, int sslmode)
	throws UniSessionException {
		synchronized (this) {
			UniJava.uniLog("Enter UniPool::findSession()");
			int sizeAvailableConnections = availableConnections.size();
			int sizeBusyConnections = busyConnections.size();
			UniJava.uniLog("In UniPool::findSession()"
					+ " sizeAvailableConnections:" + sizeAvailableConnections
					+ " sizeBusyConnections:" + sizeBusyConnections);
			if (sizeAvailableConnections != 0) {
				int LastIndex = sizeAvailableConnections - 1;
				UniSession us = (UniSession) availableConnections.elementAt(LastIndex);
				availableConnections.removeElementAt(LastIndex);
			
				// New Server
				if(us.connection.isServerAlive())
				{
					busyConnections.add(us.connection);
					UniJava.uniLog("In UniPool::findSession() Found Session as sizeAvailableConnections != 0 and session is alive");
					return us;
				}
				else
				{
					UniJava.uniLog("In UniPool::findSession() Could not found Session. May be  Session is NOT alive");
					closeServerConnection(us);
					notifyAll(); // Freed up a spot for anybody waiting
					return findSession(sessionTimeout, sslmode);
				}
				
			} else {
				if (totalConnections() < maxPoolSize) {
					if (retryNewInTimes == 0) {
						try {
							UniSession us = makeNewConnection(sslmode);
							busyConnections.add(us.connection);
							nextRetryNewInTimes = defaultRetryNewInTimes;
							UniJava.uniLog("In UniPool::findSession() Created new Session as totalConnections() < maxPoolSize");
							return us;
						} catch (UniSessionException e) {
							// can't make new connection, should continue with
							// the wait logic
							retryNewInTimes = nextRetryNewInTimes;
							// increase the next retry wait time by 2 times
							nextRetryNewInTimes *= 2;
						}
					} else {
						//						 don't try to make a new connection since it most
						// likely
						// will fail, so wait for some iteration to do it
						retryNewInTimes--;
					}
				}
				// if already maxPoolSize or we can't make a new connection then
				// Wait for either a new connection to be established
				//  or for an existing connection to be freed up.
				long lDiffTime = 0;
				try {
					long lStartTime = new Date().getTime();
					UniJava.uniLog("In UniPool::findSession() - we are in wait");
                    // E35580 J.Mao
					wait(sessionTimeout);
					long lEndTime = new Date().getTime();
					lDiffTime = (lEndTime - lStartTime);
					UniJava.uniLog("In UniPool::findSession()"
							+ " sessionTimeout:" + sessionTimeout
							+ " lStartTime:" + lStartTime + " lEndTime:"
							+ lEndTime);
                    // E35580 J.Mao
                    if (lDiffTime >= sessionTimeout)
                        throw new UniSessionException(UniTokens.UVE_UNISESSION_TIMEOUT);
				} catch (InterruptedException ie) {
					throw new UniSessionException(UniTokens.UVE_UNISESSION_TIMEOUT);
				}
				//				 got notify
				UniJava.uniLog("In UniPool::findSession() - we got notify");
				return findSession(sessionTimeout - lDiffTime, sslmode);
			}
		}
	}
	
	/**
	 * Given UniSession Object is removed from the busy list and gets added to the
	 * available list. Then it wakes up the thread that are waiting for connection. 
	 * @param us UniSession Object 
	 * @throws UniSessionException is thrown if an error occurs
	 */
	protected void free(UniSession us) throws UniSessionException {
		synchronized (this) {
			UniJava.uniLog("Enter UniPool::free()");
			// this will solve the problem of adding new UniSession
			// when ~UniSession() is called at the end of an app
			if (availableConnections.contains(us))
				return;
			// already closed
			if (!us.isActive())
				return;
			// still active but has RPCException occured, so physically drop it
			// and adjust
			// the pool size according to minPoolSize
			if (us.isActive() && us.getRPCError()) {
				//UniObjects.CloseServerConnection(us);//rajan
				closeServerConnection(us);
				return;
			}
			// seems to be valid UniSession at this point
			//check there is no pending for UniCommand
			if (us.uniCommand != null) {
				int status = us.uniCommand.status();
				if ((status == UniObjectsTokens.UVS_REPLY)
						|| (status == UniObjectsTokens.UVS_MORE)) {
					throw new UniSessionException(UniTokens.UVE_EXECUTEISACTIVE);
				}
			}
			
			if (us.uniTransaction != null) {
				boolean  status = false;
				try {
					status = us.uniTransaction.isActive();
				} catch (UniTransactionException e) {
					throw new UniSessionException(UniTokens.UVE_EXECUTEISACTIVE);
				}
				if (status) {
					throw new UniSessionException(UniTokens.UVE_EXECUTEISACTIVE);
				}
			}
			
			// now we know the unisession object can be reused
			busyConnections.remove(us.connection);
			us.setFreedTime(new Date());
			//clone it. UniSession Object us will not be usable
			UniSession lNewus = (UniSession) us.clonePooled();
			// initialize the old UniSession so that it can't be used
			// anymore (see CheckEntryConditinos()), eventually it should
			// be garbage collected
			us.initDefaultValues();
			us.connection = null;
			// add cloned object to vector
			availableConnections.add(lNewus);
			notifyAll(); // Freed up a spot for anybody waiting
			UniJava.uniLog("Exit UniPool::free()");
		}
	}
	
	/**
	 * This function is called by timer object. If a connection is in available list
	 * exist more than specified time, it gets disconnected. 
	 * @throws UniSessionException is thrown if an error occurs
	 */
	protected void closeIdleConnections() throws UniSessionException {
		synchronized (this) {
			UniJava.uniLog("Enter UniPool::closeIdleConnections()");
			for (int i = 0; i < availableConnections.size(); i++) {
				UniSession us = (UniSession) availableConnections.elementAt(i);
				if(us == null){
					UniJava.uniLog("In UniPool::closeIdleConnections():Session (us) is null");
					return;
				}
				UniJava.uniLog("in UniPool::closeIdleConnections()"+ "size is:"+availableConnections.size()+ "this index is:"+ i);
				int p1 = UniJava.getIdleRemoveThreshold();
				UniJava.uniLog("in UniPool::closeIdleConnections()"+ "UniJava.getIdleRemoveThreshold() is:"+p1);
				long p2 = us.getFreedTime().getTime();
				UniJava.uniLog("in UniPool::closeIdleConnections()"+ "us.getFreedTime().getTime() is:"+p2);
				long freedtime = p2 +p1;
				long curtime = new Date().getTime();
				UniJava.uniLog("in UniPool::closeIdleConnections()"+ "curdtime is:"+curtime);
				long diff = curtime - freedtime;
				if (diff >= 0 && (availableConnections.size() > minPoolSize)) {
					UniJava.uniLog("in UniPool::closeIdleConnections() diff is:"+ diff);
					UniJava.uniLog("in UniPool::closeIdleConnections() availableConnections.size() is:"+ availableConnections.size() + " and minPoolSize is: " + minPoolSize);
					us.disconnectServer();
					availableConnections.remove(us);
					UniJava.uniLog("in UniPool::closeIdleConnections() closing session physically");
					i--;
				} else {
					UniJava.uniLog("in UniPool::closeIdleConnections() diff is:"+ diff);
					UniJava.uniLog("in UniPool::closeIdleConnections() availableConnections.size() is:"+ availableConnections.size());
					UniJava.uniLog("in UniPool::closeIdleConnections() minPoolSize is: " + minPoolSize);
					if(diff<0 ){
						UniJava.uniLog("in UniPool::closeIdleConnections() can not close session physically as diff < 0");
					}
					
					if(availableConnections.size() <=minPoolSize ){
						UniJava.uniLog("in UniPool::closeIdleConnections() can not close session physically as availableConnections.size() <=minPoolSize");
					}
				}
			}
			UniJava.uniLog("Exit UniPool::closeIdleConnections()");
		}
	}
	
	/**
	 * This function is called by UniJava Class. It physically removes U2 connection.
	 * @param us UniSession Object
	 * @throws UniSessionException is thrown if an error occurs
	 */
	protected void closeServerConnection(UniSession us)
	throws UniSessionException {
		synchronized (this) {
			int sslmode = us.getSSLMode();
			busyConnections.remove(us.connection);
			us.disconnectServer();
			UniJava.uniLog("In UniPool::closeServerConnection");
			adjustMinPoolSizeConnections(sslmode);
			//UniObjects.AdjustSession(us);//rajan
		}
	}
	
	/**
	 * This function is called by UniJava Class. It closes all U2 connections for this Pool.
	 * @throws UniSessionException is thrown if an error occurs
	 * @throws UniRPCConnectionException is thrown if an error occurs
	 */
	protected void closeAllConnections() throws UniSessionException,
	UniRPCConnectionException {
		synchronized (this) {
			UniJava.uniLog("Enter UniPool::closeAllConnections");
			closeConnections(availableConnections);
			availableConnections.clear();
			closeBusyConnections(busyConnections);
			busyConnections.clear();
			UniJava.uniLog("Exit UniPool::closeAllConnections");
		}
	}
	
	/**
	 * This function maintains Min Pool size.
	 * @param sslmode Integer representing ssl mode.
	 * @throws UniSessionException is thrown if an error occurs
	 */
	protected void adjustMinPoolSizeConnections(int sslmode)
	throws UniSessionException {
		synchronized (this) {
			UniJava.uniLog("Enter UniPool::adjustMinPoolSizeConnections");
			if (totalConnections() < minPoolSize) {
				UniSession us = null;
				us = makeNewConnection(sslmode);
				availableConnections.add(us);
			}
			UniJava.uniLog("Exit UniPool::adjustMinPoolSizeConnections");
		}
	}

	
	/**
	 * It enumerates through available vector list and close the connection.
	 * @param pUniSessions vector list of available connections
	 * @throws UniSessionException is thrown if an error occurs
	 */
	private void closeConnections(Vector pUniSessions)
	throws UniSessionException {
		UniJava.uniLog("Enter UniPool::closeConnections");
		if (pUniSessions == null) {
			UniJava.uniLog("Exit UniPool::closeConnections because pUniSessions is null");
			return;
		}
		for (int i = 0; i < pUniSessions.size(); i++) {
			UniSession us = (UniSession) pUniSessions.elementAt(i);
			if (us.isActive() == true) {
				us.disconnectServer();
				UniJava.uniLog("In UniPool::closeConnections() and us.disconnectServer");
			}
		}
		UniJava.uniLog("Exit UniPool::closeConnections");
	}
	
	/**
	 * It enumerates through busy vector list and close the connection.
	 * @param pUniSessions vector list of busy connections
	 * @throws UniSessionException is thrown if an error occurs
	 */
	private void closeBusyConnections(Vector pRPCConnections)
			throws UniRPCConnectionException {
		UniJava.uniLog("Enter UniPool::closeBusyConnections");
		if (pRPCConnections == null) {
			UniJava.uniLog("Exit UniPool::closeBusyConnections because pRPCConnections is null");
			return;
		}
		for (int i = 0; i < pRPCConnections.size(); i++) {
			UniRPCConnection uc = (UniRPCConnection) pRPCConnections.elementAt(i);
			uc.close();
			UniJava.uniLog("In UniPool::closeBusyConnections()");
		}
		UniJava.uniLog("Exit UniPool::closeBusyConnections");
	}


	
	/**
	 * This explicitly makes a new connection. Called by Constructor at the time of
	 * preallocation. Otherwise called by findSession in run time.
	 * @param sslmode Integer representing ssl mode.
	 * @return UniSession Object
	 * @throws UniSessionException is thrown if an error occurs
	 */
	private UniSession makeNewConnection(int sslmode)
			throws UniSessionException {
		synchronized (this) {
			try {
				UniSession us = null;
				if (sslmode == 0) {
					us = new UniSession();
				} else {
					us = new UniSession(sslmode);
				}
				us.setHostPort(hostport);
				us.setConnectionString(service);
				us.setHostName(server);
				us.setUserName(userid);
				us.setPassword(password);
				us.setAccountPath(account);
				us.connectInternal();
				us.setPooledSession(true);
				us.setCreationTime(new Date());
				UniJava.uniLog("In UniPool::makeNewConnection");
				return us;
			} catch (UniSessionException e) {
				throw new UniSessionException(e.getErrorCode(), e.getMessage());
			}
		}
	}	
	
	/**
	 * calculates total number of connections at any time
	 * @return
	 */
	private int totalConnections() {
		synchronized (this) {
			int val = availableConnections.size() + busyConnections.size();
			UniJava.uniLog("In UniPool::totalConnections and total connection is "
							+ val);
			return val;
		}
	}
	
	/**
	 * returns the account path being used for the connection
	 * @return String representing the account path being used for the current connection.
	 */
	protected String getAccount() {
		return account;
	}
	
	/**
	 * returns the Max Pool Size for the Pool
	 * @return Integer representing the Max Pool Size.
	 */
	protected int getMaxPoolSize() {
		return maxPoolSize;
	}
	
	/**
	 * returns the Min Pool Size for the Pool
	 * @return Integer representing the Min Pool Size.
	 */
	protected int getMinPoolSize() {
		return minPoolSize;
	}
	/**
	 * returns the password used to establish the connection to the host system
	 * @return String representing the password being used for the connection
	 */
	protected String getPassword() {
		return password;
	}
	/**
	 * returns the name of the host we are connecting to.
	 * @return String representing the host name we are connected to.
	 */
	protected String getServer() {
		return server;
	}
	/**
	 * returns the current user name used for this connection
	 * @return String representing the user name used for this connection.
	 */
	protected String getUserid() {
		return userid;
	}
	
	private String service = "";
	private String userid = "";
	private String password = "";
	private String server = "";
	private String account = "";
	private int sslmode = 0;
	private int hostport = UniRPCTokens.UNIRPC_DEFAULT_PORT;
	private int minPoolSize = 0;
	private int maxPoolSize = 0;
	private Vector availableConnections = null;
	private Vector busyConnections = null;
	private int retryNewInTimes = 0;
	private final int defaultRetryNewInTimes = 10;
	private int nextRetryNewInTimes = 0;
	
	
}
