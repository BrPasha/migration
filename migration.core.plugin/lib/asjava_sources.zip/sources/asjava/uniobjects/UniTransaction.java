/*************************************************************************
 *
 * UniTransaction.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition.......................................... 
 * 01/20/09 e38799 JFM fixed isActive() for UniVerse
 * 05/14/08 e37542 JFM fixed isActive() for Unidata
 * 11/18/04 e32565 RKK Connection Pooling
 * 05/05/99 24995 DTM Modified to be more thread safe
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniobjects;
 
import asjava.unirpc.UniRPCException;
import asjava.unirpc.UniRPCPacket;

/**
 * <code>UniTransaction</code> is used to control the transaction settings
 * It gives the developer the ability to provide transactional behavior for 
 * their applications.  
 * 
 * @author	David T. Meeks
 * @version	Version 1.0
 * @since		UNIOBJECTS 1.0
 */
public class UniTransaction extends UniBase
{
	/**
	 * Cannot instantiate as a standalone object, must be created from an active UniSession object
	 *
	 * @since UNIOBJECTS 1.0
	 */
	UniTransaction() throws UniTransactionException
	{
		throw new UniTransactionException( UniObjectsTokens.UVE_MUST_USE_SESSION );
	}
	
	/**
	 * Creates the UniTransaction object.  
	 *
	 * @since	UNIOBJECTS 1.0
	 */
	UniTransaction( UniSession aSession ) throws UniTransactionException
	{
		synchronized ( this ) {
			// We are passed in the session connection object for communication purposes
			if ( aSession == null )
				throw new UniTransactionException(UniObjectsTokens.UVE_SESSION_NOT_OPEN );
			uniParentSession	= aSession;
			uniConnection 		= aSession.connection;
			
			isTransActive 		= false;
		} // synch this
	};
	
	/**
	 * commits the currently active transaction
	 *
	 * @exception UniTransactionException is thrown if an error occurs
	 * @see #begin 
	 * @see #rollback
	 * @since UNIOBJECTS 1.0
	 */
	public void commit() throws UniTransactionException
	{
		uniReturnCode = serverTransaction( UVI_TRANS_COMMIT );
	};

	/**
	 * returns the current transaction level
	 *
	 * @exception UniTransactionException is thrown if an error occurs
	 * @return integer representing the current transaction level
	 * @since UNIOBJECTS 1.0
	 */

	public int getLevel() throws UniTransactionException
	{ 
		synchronized ( this ) {
			// Needs to return the integer value, but it will receive
			// a string from the server
			String uniReturnString;
			
			// Check to ensure that a UniCommand execution is not active
			if ( isCommandActive() )
			{
				throw new UniTransactionException( UniObjectsTokens.UVE_EXECUTEISACTIVE );
			}
			
			try
			{
				// Get the string back from the server and convert it into an integer
				uniReturnString = uniParentSession.getValue( UVI_AT_TRANSACTION_LEVEL );
				return Integer.parseInt( uniReturnString ); 
			}
			catch ( UniSessionException e )
			{
				throw new UniTransactionException( e.getErrorCode() );
			}
			catch ( java.lang.Exception e )
			{
				return 0;
			}
		} // synch this
	};
	
	/**
	 * determines whether a transaction is currently active.  A <code>true</code>
	 * return value will indicate that a transaction is active.
	 *
	 * @exception UniTransactionException is thrown if an error occurs
	 * @return boolean denoting whether the transaction is active.  
	 * @since UNIOBJECTS 1.0
	 */
	public boolean isActive() throws UniTransactionException
	{ 
		synchronized ( this ) {
			String uniReturnString;
			
			// Check to ensure that a UniCommand execution is not active
			if ( isCommandActive() )
			{
				throw new UniTransactionException( UniObjectsTokens.UVE_EXECUTEISACTIVE );
			}
	
			try{
				uniReturnString = uniParentSession.getValue( UVI_AT_TRANSACTION );
			}
			catch ( UniSessionException e )
			{
				throw new UniTransactionException( e.getErrorCode() );
			}
	
			
			// If we have a returned length for the string, then we have an active transaction
			if ( uniReturnString.equals("")|| uniReturnString.equals("0"))
				isTransActive = false;
			else
				isTransActive = true;
				
			return isTransActive;
		} // synch this
	}
	
	/**
	 * rollsback the current transaction
	 *
	 * @exception UniTransactionException is thrown if an error occurs
	 * @see #commit 
	 * @since UNIOBJECTS 1.0
	 */
	public void rollback() throws UniTransactionException
	{
		uniReturnCode = serverTransaction( UVI_TRANS_ROLLBACK );
	};
	
	/**
	 * begins a new transaction
	 *
	 * @exception UniTransactionException is thrown if an error occurs
	 * @see #commit
	 * @see #rollback 
	 * @since UNIOBJECTS 1.0
	 */
	public void begin() throws UniTransactionException
	{
		uniReturnCode = serverTransaction( UVI_TRANS_START );
	};
	
	
	// Private methods
	
	/**
	 * communicates to the server specific transaction requests, such as
	 * UVI_TRANS_ROLLBACK, UVI_TRANS_START, UVI_TRANS_COMMIT, etc...
	 * 
	 * @param aKey integer representing which transaction request to make
	 * @return integer representing the status of the transaction request
	 * @exception UniTransactionException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	private int serverTransaction( int aKey ) throws UniTransactionException
	{
		synchronized ( this ) {
			// Check to ensure that a UniCommand execution is not active
			if ( isCommandActive() )
			{
				throw new UniTransactionException( UniObjectsTokens.UVE_EXECUTEISACTIVE );
			}
	
			try
			{
				if (( inPacket == null ) || ( outPacket == null ))
				{
					inPacket 					= new UniRPCPacket( uniConnection );
					outPacket 				= new UniRPCPacket( uniConnection );
				}
	
				outPacket.write( 0, UniObjectsTokens.EIC_TRANSACTION );
				outPacket.write( 1, aKey );
			
				uniConnection.call( outPacket, inPacket );
				
				uniReturnCode 	= inPacket.readInteger( 0 );
				if ( uniReturnCode != 0)
					uniStatus 			= inPacket.readInteger( 1 );
				else
					uniStatus				= 0;
				
				return uniReturnCode;
			}
			catch ( UniRPCException e )
			{
				uniParentSession.setRPCError(true);
				throw new UniTransactionException( e.getErrorCode() );
			}
		} // synch this
	}

	/* Private properties */
	private final static int 	UVI_TRANS_START 					= 1;
	private final static int 	UVI_TRANS_COMMIT 					= 2;
	private final static int 	UVI_TRANS_ROLLBACK 				= 3;
	private final static int 	UVI_AT_TRANSACTION 				= 5;
	private final static int 	UVI_AT_TRANSACTION_LEVEL 	= 11;

	private boolean 					isTransActive 						= false;
	private int 							uniReturnCode 						= 0;
}
