
// Copyright (c) 2000 Informix Software
package asjava.uniobjects;

import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
/**
 * A Class class.
 * <P>
 * @author Pavel Smilanski
 */
public class UniSSLDescriptor extends Object {

  SSLSocketFactory sslSf;
  String cipherSuites[];
  SSLSession sslsession = null;

  /**
   * Constructor
   */

  public UniSSLDescriptor()
  {
      sslSf = null;
      sslsession = null;
      cipherSuites = null;
  }

  public UniSSLDescriptor(SSLSocketFactory sslsf, String[] ciphersuites)
  {
    this.sslSf = sslsf;
    this.cipherSuites = ciphersuites;
  }

  public void setSSLSocketFactory(SSLSocketFactory sslsf)
  {
    this.sslSf = sslsf;
  }

  public SSLSocketFactory getSSLSocketFactory()
  {
    return this.sslSf;
  }

  public void setEnabledCipherSuites(String [] cs)
  {
    this.cipherSuites = cs;
  }

  public String [] getEnabledCipherSuites()
  {
    return this.cipherSuites;
  }

  public SSLSession getSSLSession()
  {
    return(sslsession);
  }

  void setSSLSession(SSLSession isslsession)
  {
    sslsession = isslsession;
  }
}

