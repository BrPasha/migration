/*************************************************************************
 *
 * UniNLSlocale.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 11/18/04 e32565 RKK Connection Pooling
 * 05/05/99 24995 DTM Made code more thread safe
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniobjects;
 
import asjava.uniclientlibs.*;
import asjava.unirpc.*;

/**
 * <code>UniNLSlocale</code> is used to control the NLS locale settings.  The NLS
 * locale conventions it can control are Time, Numeric, Monetary, Character Type,
 * and Collate.  This object allows the application to modify those values to what
 * is appropriate for their given environment.  
 * 
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since		UNIOBJECTS 1.0
 */
public class UniNLSlocale extends UniBase
{
	UniNLSlocale() throws UniNLSException
	{
		throw new UniNLSException( UniObjectsTokens.UVE_MUST_USE_SESSION );
	}
	
	/** 
	 * Default contructor for this object.  Sets up clientArray and serverArray values
	 *
	 * @since UNIOBJECTS 1.0
	 */
 	UniNLSlocale( UniSession aSession ) 
 	{
 		synchronized ( this ){
	 		uniParentSession 	= aSession;
	 		uniConnection 		= uniParentSession.connection;
	 		inPacket					= null;
	 		outPacket					= null;
	 
	 		clientArray = new String[ UniObjectsTokens.NUM_OF_ELEMENTS + 1 ];
 		} // synch this
 	};
	
		
	/**
	 * returns a <code>UniDynArray</code> of the client representation of the locale 
	 * settings.  
	 *
	 * @return UniDynArray of locale settings, as seen by the client
	 * @see #getServerNames
	 * @since UNIOBJECTS 1.0
	 */
	public UniDynArray getClientNames()
	{ 
		synchronized ( this ) {
	
			UniDynArray returnVal = new UniDynArray(uniParentSession);
			
			for ( int i = UniObjectsTokens.LC_MIN; i <= UniObjectsTokens.LC_MAX; i++ )
			{
				returnVal.insert( i, (String)clientArray[ i ] );
			}
					
			return  returnVal;
		} // synch this
	};
	
	/**
	 * returns a <code>UniDynArray</code> of the server representation of the locale 
	 * settings.  
	 *
	 * @return UniDynArray of locale settings, as seen by the server
	 * @exception UniNLSException is thrown if an error occurs
	 * @see #getClientNames
	 * @since UNIOBJECTS 1.0
	 */
	public UniDynArray getServerNames() throws UniNLSException
	{ 
		synchronized ( this ) {
	
			UniDynArray returnVal = new UniDynArray(uniParentSession);
			
			for ( int i = UniObjectsTokens.LC_MIN; i <= UniObjectsTokens.LC_MAX; i++ )
			{
				returnVal.insert( i, (String)getLocaleName( i ) );
			}
			
			return returnVal; 
		} // synch this
	
	};
	
	/**
	 * sets the specified locale.  If <code>aName</code> is of type <code>UniDynArray</code>
	 * then each individual category is set to the corresponding <code>UniDynArray</code>
	 * value.  If it contains only one element, and <code>anIndex</code> is specified, 
	 * only that locale setting is changed.  If <code>anIndex</code> is not set, then 
	 * all locale categories are set to the value defined by <code>aName</code>
	 *
	 * @param aName String either a String or UniDynArray representing the new locale settings
	 * @param anIndex integer representing which category to be set
	 * @exception UniNLSException is thrown if an error occurs
	 * @see #getClientNames
	 * @see #getServerNames
	 * @since UNIOBJECTS 1.0
	 */
	public void setName( Object aName, int anIndex ) throws UniNLSException
	{
		synchronized ( this ) {
	
			if (( anIndex < UniObjectsTokens.LC_MIN ) || ( anIndex > UniObjectsTokens.LC_MAX ))
				throw new UniNLSException( UniObjectsTokens.UVE_EINVAL );
				
			String localeName = aName.toString();
			clientArray[ anIndex ] = localeName;
			
			// Ensure we have no errors to report
			checkEntryConditions();
			
			try 
			{
				outPacket.write( 0, UniObjectsTokens.EIC_SETLOCALE );
				outPacket.write( 1, anIndex );
				outPacket.write( 2, encode(localeName ));
				
				uniConnection.call( outPacket, inPacket );
				
				int uniReturnCode = inPacket.readInteger( 0 );
				if ( uniReturnCode != 0 )
				{
					throw new UniNLSException( uniReturnCode );
				}
				else
				{
					uniStatus = inPacket.readInteger( 1 );
				}
			}
			catch ( UniRPCException e )
			{
				uniStatus = 0;
				uniParentSession.setRPCError(true);
				throw new UniNLSException( e.getErrorCode() );
			}
		} // synchthis
	};
	
	/**
	 * sets the specified locale.  If <code>aName</code> is of type <code>UniDynArray</code>
	 * then each individual category is set to the corresponding <code>UniDynArray</code>
	 * value.  If it contains only one element, and <code>anIndex</code> is specified, 
	 * only that locale setting is changed.  If <code>anIndex</code> is not set, then 
	 * all locale categories are set to the value defined by <code>aName</code>
	 *
	 * @param aName String either a String or UniDynArray representing the new locale settings
	 * @exception UniNLSException is thrown if an error occurs
	 * @see #getClientNames
	 * @see #getServerNames
	 * @since UNIOBJECTS 1.0
	 */
	public void setName( Object aName ) throws UniNLSException
	{
		synchronized ( this ) {
	
			UniDynArray localeName = new UniDynArray(uniParentSession, aName.toString() );
			if ( localeName.dcount() == 5 ) // We have an array of values
			{	
				for ( int i = UniObjectsTokens.LC_MIN; i <= UniObjectsTokens.LC_MAX; i++ )
				{
					setName( localeName.extract( i ), i );
				}
			}
			else	// We have one value to set for each index 
			{
				for ( int i = UniObjectsTokens.LC_MIN; i <= UniObjectsTokens.LC_MAX; i++ )
				{
					setName( aName, i );
				}
			}
		} // synch this
	}
	
	/* Private Methods */
	private String getLocaleName( int localeKey ) throws UniNLSException
	{
		// Contact the server to get this locale name.
		checkEntryConditions();
		
		try 
		{
			outPacket.write( 0, UniObjectsTokens.EIC_GETLOCALE );
			outPacket.write( 1, localeKey );
			
			uniConnection.call( outPacket, inPacket );
			
			int uniReturnCode = inPacket.readInteger( 0 );
			if ( uniReturnCode != 0 )
			{
				throw new UniNLSException( uniReturnCode );
			}
			else
			{
				return decode(inPacket.readBytes(1));
			}
		}
		catch ( UniRPCException e )
		{
			uniParentSession.setRPCError(true);
			throw new UniNLSException( e.getErrorCode() );
		}
	}
	
	private void checkEntryConditions() throws UniNLSException
	{
		// Check to ensure that a UniCommand execution is not active
		if ( isCommandActive() )
		{
			throw new UniNLSException( UniObjectsTokens.UVE_EXECUTEISACTIVE );
		}

		// Make sure we have inPacket and outPacket set up
		if ( inPacket == null )
		{
			try
			{
				outPacket 		= new UniRPCPacket( uniConnection );
				inPacket 			=	new UniRPCPacket( uniConnection );
				uniStatus 		= 0;
			}
			catch ( UniRPCPacketException e )
			{
				throw new UniNLSException( e.getErrorCode() );
			}
		}
	}
	
	/* Private class variables */	
	private String[] 							clientArray;
}