/*************************************************************************
 *
 * UniObjectsTokens.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 05/04/99 24995 DTM Moved OLD_SERVER/NEW_SERVER to UniTokens.
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniobjects;
 
/**
 * <code>UniObjectsTokens</code> is the primary class used for holding UniObjects 
 * defines.
 * 
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since	  UNIOBJECTS 1.0
 */
public class UniObjectsTokens extends asjava.uniclientlibs.UniTokens
{
	public UniObjectsTokens(){};
	
	// UniVerse define values

  	// Session SSL modes

  	public final static int NON_SECURE_SESSION = 0;
  	public final static int SECURE_SESSION = 1;
  	public final static int EXTERNALLY_SECURE_PROXY_SESSION=2;
    public final static int SECURE_PROXY_SESSION = 3;
	
	// For UniSession
	public final static int MAX_OPEN_FILES 						= 32;
	public final static int NUM_AT_VARIABLES 					= 11; // number of at variables + 1 
	public final static int RETURN_ON_LOCKED					= 2;
	public final static int NO_LOCKS									= 0;
	public final static int WRITE_RELEASE							= 1;
	public final static int LOCK_NO_LOCK							= 0;
	public final static int LOCK_MY_READL							= 1;
	public final static int LOCK_MY_READU							= 2;
	public final static int LOCK_MY_FILELOCK					= 3;
	public final static int LOCK_OTHER_READL					= -1;
	public final static int LOCK_OTHER_READU					= -2;
	public final static int LOCK_OTHER_FILELOCK				= -3;
	
	// At variable definitions
	public final static int	AT_LOGNAME								= 1;
	public final static int AT_PATH										= 2;
	public final static int	AT_USER_NO								= 3;
	public final static int AT_WHO										= 4;
	public final static int	AT_TRANSACTION						= 5;
	public final static int AT_DATA_PENDING						= 6;
	public final static int	AT_USER_RETURN_CODE				= 7;
	public final static int AT_SYSTEM_RETURN_CODE			= 8;
	public final static int	AT_NULL_STR								= 9;
	public final static int AT_SCHEMA									= 10;
	public final static int AT_POOLING_USER         = 	12;


	// For UniSelectList
	public final static int UVT_SELECTLISTEMPTY_STATE = 1;
	
	// For UniNLS
	public static final int	NUMICMARKS 								= 6;
	public static final int	IK_MARK_MIN								= 0;
	public static final int IK_MARK_MAX								= 6;
	public static final int	NUM_OF_ELEMENTS 					= 5;
	public static final int	LC_MIN 										= 1;
	public static final int	LC_MAX 										= 5;
	public static final int UVT_NLS_TIME							= 1;
	public static final int UVT_NLS_NUMERIC						= 2;
	public static final int UVT_NLS_MONETARY					= 3;
	public static final int UVT_NLS_CTYPE							= 4;
	public static final int UVT_NLS_COLLATE						= 5;
	
	
	// For UniCommand
	public static final int UVS_COMPLETE							= 0;	// Command was successful
	public static final int UVS_REPLY    							= 1;  // Command waiting for reply
	public static final int UVS_MORE     							= 2;  // Command has more output.
	public static final int RESULT_BUFFER_SIZE 				= 8192;
	
	// For UniFile
	public static final int UVT_EXCLUSIVE_READ				=	1;
	public static final int UVT_SHARED_READ 					= 2;
	public static final int UVT_NO_LOCKS							=	0;
	public static final int UVT_WRITE_RELEASE 				=	1;
	public static final int UVT_READ_RELEASE 					= 2;
	public static final int UVT_EXPLICIT_RELEASE 			= 4;
	public static final int UVT_CHANGE_RELEASE 				=	8;
	public static final int UVT_WAIT_LOCKED 					= 1;
	public static final int UVT_RETURN_LOCKED 				= 2;
	public static final int UVT_NORELEASEALL 					= 0;
	public static final int UVT_DATA									= 0;
	public static final int UVT_DICT									= 1;
	public static final int UVORNFSUBARGCNT						= 7;
	
	public static final int IK_READ  									= 0;
	public static final int IK_READL 									=	4;
	public static final int IK_READU 									= 2;
	public static final int IK_DELETE 								= 0;
	public static final int IK_DELETEU 								= 3;
	public static final int IK_WAIT 									= 1;
	public static final int IK_WRITE 									= 0;
	public static final int IK_WRITEW 								= 1;
	public static final int IK_WRITEU 								= 5;
	
	public static final int IK_DATA 									= 0;
	public static final int IK_DICT 									= 0;
	
	public static final int RESULT_ARG_NO							= 0;
	public static final int FILENAME_ARG_NO						= 1;
	public static final int LOCKTYPE_ARG_NO						= 2;
	public static final int RECORDID_ARG_NO						= 3;
	public static final int FIELDNAME_ARG_NO					= 4;
	public static final int STATUSCODE_ARG_NO					= 5;
	public static final int ERRORCODE_ARG_NO					= 6;
	public static final String UVORNFSUB							= "-UVORNF";
	public static final String UVT_DICT_DICT_FILE   	= "DICT.DICT";
	
	// For UniDictionary
	public static final int UVT_TYPE_INDEX						=	1;
	public static final int UVT_LOC_INDEX  						= 2;
	public static final int UVT_CONV_INDEX 						= 3;
	public static final int UVT_NAME_INDEX 						= 4;
	public static final int UVT_FORMAT_INDEX					=	5;
	public static final int UVT_SM_INDEX							= 6;
	public static final int UVT_ASSOC_INDEX						=	7;
	public static final int UVT_SQLTYPE_INDEX					= 8;	

	// For UniSequentialFile
	public static final	int	UVT_START									= 0;
	public static final int UVT_CURR									= 1;
	public static final int UVT_END										= 2;

}