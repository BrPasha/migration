/*************************************************************************
 *
 * UniCommand.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 11/18/04 e32565 RKK Connection Pooling
 * 05/05/99 24995 DTM Synchronized code for thread safety
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniobjects;

import asjava.unirpc.UniRPCException;
import asjava.unirpc.UniRPCPacket;
import asjava.unirpc.UniRPCPacketException;

/**
 * <code>UniCommand</code> is used to control remote command execution.  With it users
 * can run UniVerse commands or stored procedures on the server.  
 * 
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since		UNIOBJECTS 1.0
 */
public class UniCommand extends UniBase
{
	/**
	 * constructor for the class.  Sets up comms layer
	 *
	 * @since UNIOBJECTS 1.0
	 */
	UniCommand() throws UniCommandException
	{
		throw new UniCommandException( UniObjectsTokens.UVE_MUST_USE_SESSION );
	}
	
	UniCommand( UniSession aSession ) throws UniCommandException
	{
		synchronized ( this ) {
			if ( aSession == null )
				throw new UniCommandException( UniObjectsTokens.UVE_SESSION_NOT_OPEN );
				
			uniParentSession 	= aSession;
			uniConnection    	= uniParentSession.connection;
			uniStatus 				= UniObjectsTokens.UVS_COMPLETE;
			uniBlockSize			= 0;
			uniEncryptionType = uniParentSession.getDefaultEncryptionType();
		} // synch this
	}
	
	
	/**
	 * cancels all outstanding output from the executing command.  It can only be called when
	 * the command status, as returned by <code>status</code> is either 
	 * <code>UVS_REPLY</code> or <code>UVS_MORE</code>.  Upon completion, the command 
	 * status will be set to <code>UVS_COMPLETE</code>, allowing another command to be
	 * executed
	 *
	 * @exception UniCommandException is thrown upon failure conditions
	 * @see #status
	 * @see #exec
	 * @since UNIOBJECTS 1.0
	 */
	public void cancel() throws UniCommandException
	{
		// If we are in a state that the server is awaiting a response, 
		// we can cancel the current command.  If not awaiting a response, just continue
		synchronized ( this ){
	  	// Check for error state
			checkEntryConditions( CHECK_STATE, NO_THROW );
		
			if (( uniStatus == UniObjectsTokens.UVS_MORE ) ||
		    ( uniStatus == UniObjectsTokens.UVS_REPLY ))
			{
				try
				{
					outPacket.write( 0, UniObjectsTokens.EIC_CANCEL );
					uniConnection.call( outPacket, inPacket, (byte) uniEncryptionType );
				
					uniReturnCode 	= inPacket.readInteger( 0 );
					if ( uniReturnCode == 0 ) 	// Successful
						uniStatus = UniObjectsTokens.UVS_COMPLETE;
					else
						uniStatus = uniReturnCode;
				}
				catch (UniRPCException e)
				{
						throw new UniCommandException(  e.getMessage(), e.getErrorCode()  );
				}
			}
		} // synchronized block
	};
	
	/**
	 * executes the command that was set up using the <code>setCommand</code> method. The
	 * results of the execution can be obtained using the <code>response</code> method. The
	 * <code>status</code> method can be used to get the current state of the 
	 * command.
	 *
	 * @exception UniCommandException is thrown with error conditions
	 * @see #setCommand
	 * @see #status
	 * @see #response
	 * @since UNIOBJECTS 1.0
	 */
	public void exec() throws UniCommandException
	{
		synchronized ( this ){
			// This means we called this in the middle of some other execute occuring...
			checkEntryConditions( CHECK_STATE, SHOULD_THROW );
			
			// Reset values back to the base state.
			uniAtSystemReturnCode = 0;
			uniAtSelected					= 0;
			commandOutput					= null;
	
			// Reset the internal read size to either be what was requested, or the maximum buffer
			// size for any given action
			int internalReadSize = getBlockSize();
			if ( internalReadSize == 0 )
				internalReadSize = UniObjectsTokens.RESULT_BUFFER_SIZE;
			
			// Execute command
			int code = doExecute( UniObjectsTokens.EIC_EXECUTE, internalReadSize, "" );
				
			// Handle case where readSize = 0, reading entire data segment
			if ( getBlockSize() == 0 )
			{
				uniStatus = code;
				while ( code == UniObjectsTokens.UVS_MORE )
				{
					code = doExecuteContinue( internalReadSize );
					if (( code == UniObjectsTokens.UVS_MORE) || ( code == UniObjectsTokens.UVS_COMPLETE ) )
						commandOutput += nextBuffer;
					uniStatus = code;
				}
			}
			else	// Switch state depending on return value
			{
				if ( code == UniObjectsTokens.UVS_MORE )		/* Block too small */
				{
					uniStatus = UniObjectsTokens.UVS_MORE;
					code = UniObjectsTokens.UVS_COMPLETE;
				}
				else
				{
					uniStatus = code;
				}
			}	
		} // synchronized block
	}
		
	/**
	 * returns the value of the @SELECTED variable from the server when the command
	 * has successfully completed
	 *
	 * @return integer representing the value of the @SELECTED variable
	 * @see #exec
	 * @since UNIOBJECTS 1.0
	 */	
	public int getAtSelected()
	{
		return uniAtSelected;
	};

	/** 
	 * returns the current block size, in bytes, that is in use for server communications.
	 * By default, a value of 0 is set, which denotes that all data should be returned.
	 *
	 * @return integer representing the current block size, in bytes.
	 * @see #setBlockSize
	 * @since UNIOBJECTS 1.0
	 */
	public int getBlockSize()
	{
		/* If uniBlockSize = 0, it means get everything */
		return uniBlockSize;
	}
	
	/**
	 * returns the current execution string that was set with the <code>setCommand</code> method.
	 *
	 * @return String representing the command to be executed
	 * @see #setCommand
	 * @since UNIOBJECTS 1.0
	 */
	public String getCommand()
	{
		return command;
	}
	
	/**
	 * returns the current execution status 
	 *
	 * @return integer representing the current Command Status.  Valid values are:
	 * <ul>
	 * <li> UVS_COMPLETE (0) - command has finished execution and is awaiting next command
	 * <li> UVS_REPLY (1) - server is waiting for input data.  The reply can be sent 
	 *                       using the <code>reply</code> method.
	 * <li> UVS_MORE (2) - denotes that there is more data waiting to be retrieved.  Will
	 *                      only occur if the BlockSize is set to a non-zero value from
	 *                      <code>setBlockSize</code>.  The <code>response</code> method
	 *                      will return a response block of BlockSize bytes each time it
	 *                      is called until no more data remains, at which point, the 
	 *                      status will be changed to <code>UniS_COMPLETE</code.
	 * @see #reply
	 * @see #setBlockSize
	 * @see #getBlockSize
	 * @see #nextBlock
	 * @since UNIOBJECTS 1.0
	 */
	public int status()
	{
		return uniStatus;
	};
	
	/**
	 * returns the current value of @SYSTEM.RETURN.CODE from the server
	 *
	 * @return integer representing the current state of the @SYSTEM.RETURN.CODE
	 * @since UNIOBJECTS 1.0
	 */
	public int getSystemReturnCode()
	{
		return uniAtSystemReturnCode;
	};

	/**
	 * returns the next block of data from the command response, if the command response
	 * size was greater than the block size established with <code>setBlockSize</code>
	 * After each call to <code>nextBlock</code>, the <code>response</code> method can be
	 * called to retrieve the new block of data, and the <code>status</code>
	 * method can be called to determine the state of execution
	 *
	 * @exception UniCommandException is thrown if an error occurs
	 * @see #setBlockSize
	 * @see #nextBlock
	 * @see #response
	 * @see #status
	 * @since UNIOBJECTS 1.0
	 */
	public void nextBlock() throws UniCommandException
	{
		synchronized( this ){
			// Basically, it's going to do a doExecuteNext, but store the result in command
			int code = 0;
			
			// this only checks to ensure we have RPC Packets defined
			checkEntryConditions( NO_CHECK, NO_THROW );
			
			if ( uniStatus != UniObjectsTokens.UVS_MORE )
			{
				// This means we called this in the middle of some other execute occuring...
				throw new UniCommandException( UniObjectsTokens.UVE_NOMORE );
			}
			
			uniAtSystemReturnCode 	= 0;
			uniAtSelected						= 0;
			commandOutput						= null;
	
			int internalReadSize = getBlockSize();
			if ( internalReadSize == 0 )
				internalReadSize = UniObjectsTokens.RESULT_BUFFER_SIZE;
			
		
		 	code = doExecuteContinue( internalReadSize );
			commandOutput = nextBuffer;
		
			// Handle case where readSize = 0, reading entire data segment
			if ( getBlockSize() == 0 )
			{
				uniStatus = code;
				while ( code == UniObjectsTokens.UVS_MORE )
				{
					code = doExecuteContinue( internalReadSize );
					if (( code == UniObjectsTokens.UVS_MORE) || ( code == UniObjectsTokens.UVS_COMPLETE ) )
						commandOutput += nextBuffer;
					uniStatus = code;
				}
			}
			else	// Switch state depending on return value
			{
				if ( code == UniObjectsTokens.UVS_MORE )		/* Block too small */
				{
					uniStatus = UniObjectsTokens.UVS_MORE;
					code = UniObjectsTokens.UVS_COMPLETE;
				}
				else
				{
					uniStatus = code;
				}
			}
		} // synchronized block
	}
	
	
	/**
	 * replies to a command execution that it currently in the <code>UniS_REPLY</code>
	 * state.  Often, a server side command may require user input.  Use this method
	 * to send the input requested.
	 *
	 * @param aReplyString reply string to be sent to the server 
	 * @exception UniCommandException is thrown if an error occurs
	 * @see #status
	 * @since UNIOBJECTS 1.0
	 */
	public void reply( String aReplyString ) throws UniCommandException
	{
		synchronized( this ){
			// only checks to see that we have RPC Packets
			checkEntryConditions( NO_CHECK, NO_THROW );
			
			if ( uniStatus != UniObjectsTokens.UVS_REPLY )
				throw new UniCommandException( UniObjectsTokens.UVE_NOTATINPUT );
				
			uniStatus = UniObjectsTokens.UVS_COMPLETE;
			
			int internalReadSize = getBlockSize();
			int code = 0;
			
			if ( internalReadSize == 0 )
				 internalReadSize = UniObjectsTokens.RESULT_BUFFER_SIZE;
			
			code = doInputReply( internalReadSize, aReplyString );
		
			// Handle case where readSize = 0, reading entire data segment
			if ( getBlockSize() == 0 )
			{
				uniStatus = code;
				while ( code == UniObjectsTokens.UVS_MORE )
				{
					code = doExecuteContinue( internalReadSize );
					if (( code == UniObjectsTokens.UVS_MORE) || ( code == UniObjectsTokens.UVS_COMPLETE ) )
						commandOutput += nextBuffer;
				}
				uniStatus = UniObjectsTokens.UVS_COMPLETE;
			}
			else
			{
				if ( code == UniObjectsTokens.UVS_MORE )
				{
					uniStatus = UniObjectsTokens.UVS_MORE;
					code = UniObjectsTokens.UVS_COMPLETE;
				}
			}
					
			if ( code == UniObjectsTokens.UVS_REPLY )	// Need to get another reply
			{
				uniStatus = UniObjectsTokens.UVS_REPLY;
				code = UniObjectsTokens.UVS_COMPLETE;
			}
		} // synchronized block
	}
	
	/**
	 * returns the output from the command <code>exec</code> and <code>reply</code> methods
	 *
	 * @return String output from the <code>exec</code> or <code>reply</code> methods
	 * @see #exec
	 * @see #reply
	 */
	public String response()
	{
		return  commandOutput;
	}
	
	/**
	 * Sets the current block size to the value passed in
	 *
	 * @param aBlockSize integer representing the new block size, in bytes.  This is the 
	 *         amount of data retrieved with each <code>response</code> method.
	 * @see #getBlockSize
	 * @see #response
	 * @since UNIOBJECTS 1.0
	 */
	public void setBlockSize( int aBlockSize )
	{
		synchronized ( this ){
			if ( aBlockSize < 0 )
				aBlockSize = 0;
				
			uniBlockSize = aBlockSize;
		} // synch this
	};

	/**
	 * establishes the command string or stored procedure to be run on the server
	 *
	 * @param aCommand command string to be executed on the server
	 * @see #getCommand
	 * @see #exec
	 * @since UNIOBJECTS 1.0
	 */
	public void setCommand( String aCommand )
	{
		command = aCommand;
	}
	
	/* Private Methods */
	/**
	 * performs the actual execution of the command requested.  Talks to server and gets return information
	 *
	 * @param internalReadSize integer representing how much data should be read in each reply block
	 * @return integer representing the return status of the server operation
	 * @exception UniCommandException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	private int	doExecute( int serverCommand, int internalReadSize, String inputReply ) 
			throws UniCommandException
	{
		int retCode = 0;
		
		try
		{				
			outPacket.write(0, serverCommand);
			switch( serverCommand )
			{
				case UniObjectsTokens.EIC_EXECUTE:			
					outPacket.write(1, internalReadSize );					
					outPacket.write(2, encode(command));				
					commandOutput = null;			
					break;
				case UniObjectsTokens.EIC_EXECUTECONTINUE:
					outPacket.write(1, internalReadSize );
					nextBuffer = null;			
					break;
				case UniObjectsTokens.EIC_INPUTREPLY:
					commandOutput = null;
					String replyString = inputReply + "\n"; //must add newline
					outPacket.write(1,encode(replyString));
					outPacket.write(2, internalReadSize );
					break;
				default:
					throw new UniCommandException( "Illegal doExecute() serverCommand", UniObjectsTokens.UVE_EINVAL );
			}

			uniConnection.call( outPacket, inPacket, (byte) uniEncryptionType );					
	
			int response = inPacket.readInteger( 0 );
			String tmpOutput = null;
			switch ( response )
			{
				case	1:					
					tmpOutput	= uniParentSession.decode(inPacket.readBytes( 1 ));
					uniConnection.readPacketSpoofProxy( inPacket );
					uniAtSystemReturnCode 	= inPacket.readInteger( 1 );
					uniAtSelected						= inPacket.readInteger( 2 );
					break;
				case	UniObjectsTokens.UVE_BTS:
					tmpOutput = uniParentSession.decode(inPacket.readBytes(1));
					retCode = UniObjectsTokens.UVS_MORE;
					break;
				case	UniObjectsTokens.UVE_AT_INPUT:
					tmpOutput = uniParentSession.decode(inPacket.readBytes(1));
					retCode = UniObjectsTokens.UVS_REPLY;	
					break;
				default:
					retCode = response;						
					break;
			}
			if ( serverCommand == UniObjectsTokens.EIC_EXECUTECONTINUE )				
				nextBuffer = tmpOutput;
			else
				commandOutput = tmpOutput;
				
			return retCode;
		}
		catch (UniRPCException e)
		{
			uniParentSession.setRPCError(true);
			/* Error Condition */
			throw new UniCommandException( e.getMessage(), e.getErrorCode() );
		}				
	}
	
	/**
	 * performs the actual execution of the command requested.  Talks to server and gets return information
	 * Differs from <code>doExecute</code> in that this handles the secondary communication to the server
	 *
	 * @param internalReadSize integer representing how much data should be read in each reply block
	 * @return integer representing the return status of the server operation
	 * @exception UniCommandException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	private int doExecuteContinue( int internalReadSize ) throws UniCommandException
	{
		return doExecute( UniObjectsTokens.EIC_EXECUTECONTINUE, internalReadSize, "" );
	}
	
	/**
	 * Sends a reply to the server when one is required.  
	 *
	 * @param internalReadSize integer representing how much data should be read in each reply block
	 * @param aInputReply input reply to be sent to the server
	 * @return integer representing the return status of the server operation
	 * @exception UniCommandException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	private int	doInputReply( int internalReadSize, String aInputReply ) throws UniCommandException
	{
		return doExecute( UniObjectsTokens.EIC_INPUTREPLY, internalReadSize, aInputReply );
	}
	
	/**
	 * this routine will check whether or not we are in a state that we can perform any object operation,
	 * especially server communications.  It checks to see if a command is currently in the active state
	 * and it checks to ensure that the internal RPC packets are initialized.   If an error occurs,
	 * it passes it back up
	 *
	 * @param checkState boolean denoting whether or not we should check the command status
	 * @param shouldThrow boolean denoting whether or not we should throw an exception if one is found
	 * @exception UniCommandException is thrown if an exception if encountered
	 * @since UNIOBJECTS 1.0
	 */
	private void checkEntryConditions( boolean checkState, boolean shouldThrow ) throws UniCommandException
	{
		// Check to ensure that a UniCommand execution is not active
		if ( checkState )
		{
			if ( isCommandActive() )
			{
				if ( shouldThrow )
					throw new UniCommandException( UniObjectsTokens.UVE_EXECUTEISACTIVE );
			}
		}

		// Make sure we have inPacket and outPacket set up
		if ( inPacket == null )
		{
			try
			{
				outPacket 		= new UniRPCPacket( uniConnection );
				inPacket 			=	new UniRPCPacket( uniConnection );
				uniStatus 		= 0;
			}
			catch ( UniRPCPacketException e )
			{
				throw new UniCommandException( e.getErrorCode() );
			}
		}
	}

	/* Private properties */
	private	static final boolean	SHOULD_THROW	=	true;
	private static final boolean  NO_THROW			= false;
	private static final boolean	CHECK_STATE		= true;
	private static final boolean	NO_CHECK			= false;
	
	private String command											= null;
	private String commandOutput								= null;
	private String nextBuffer										= null;
	
	private int uniReturnCode 									= 0;
	private int uniBlockSize 										= 0;
	private int uniAtSystemReturnCode 					= 0;
	private int uniAtSelected										= 0;
}