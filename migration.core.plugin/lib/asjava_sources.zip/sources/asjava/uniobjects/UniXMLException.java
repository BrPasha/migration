/*************************************************************************
 *
 * UniXMLException.java
 *
 *       IBM Confidential
 *       OCO Source Materials
 *       Copyright (C) IBM Corp.  2004, 2004
 * Module	%M%	Version	%I%	Date	%H%
 *
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 08/26/04 WMY 32722 Initial Creation
 *************************************************************************/


package asjava.uniobjects;
 
import asjava.uniclientlibs.*;

/**
 * <code>UniXMLException</code> is the primary class used for handling UniObjects 
 * exceptions and errors.
 * This internal error handling method is based on Java's method of handling
 * errors. This exception class is derived from the base UniObjects exception 
 * class, <code>UniException</code>. We have also carried over the idea of having an integer identifier 
 * for the message which can make the handling of said message a lot easier.
 * 
 * @version	Version 2.0.4
 * @author	Weiming Yeh
 * @since		UNIOBJECTS 2.0.4
 */
public class UniXMLException extends UniException
{
	/**
	 * Creates the UniXMLException object.  
	 *
	 * @since	UNIOBJECTS 2.0.4
	 */
	UniXMLException()
	{
		super();
		errorType = UNIXML_EXCEPTION;
	}
	
	/**
	 * Creates the UniXMLException object.  
	 *
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNIOBJECTS 2.0.4
	 */
	UniXMLException( int aErrorCode )
	{
		super( aErrorCode );
		errorType = UNIXML_EXCEPTION;
	}

	/**
	 * Creates the UniXMLException object.  
	 *
	 * @param aError string representing the message to be displayed
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNIOBJECTS 2.0.4
	 */
	UniXMLException(String aError, int aErrorCode)
	{
		super(aError, aErrorCode);
		errorType = UNIXML_EXCEPTION;
	}
	
	/**
	 * Creates the UniXMLException object.  
	 *
	 * @param aExtraInfo string representing the message to be displayed
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNIOBJECTS 2.0.4
	 */
	UniXMLException( int aErrorCode, String aExtraInfo )
	{
		super( aErrorCode, aExtraInfo );
		errorType = UNIXML_EXCEPTION;
	}

	/**
	 * Creates the UniXMLException object.  
	 *
	 * @param aClassName string representing the name of the class failure occured
	 * @param aError string representing the message to be displayed
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNIOBJECTS 2.0.4
	 */
	UniXMLException(String aClassName, String aError, int aErrorCode)
	{
		super(aClassName, aError, aErrorCode);
		errorType = UNIXML_EXCEPTION;
	}
}
