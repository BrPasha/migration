/*************************************************************************
 *
 * UniSequentialFile.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 11/18/04 e32565 RKK Connection Pooling
 * 09/10/04 WMY 32722 change @param
 * 05/05/99 24995 DTM Made change for thread safety
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniobjects;

import asjava.uniclientlibs.UniString;
import asjava.unirpc.UniRPCException;
import asjava.unirpc.UniRPCPacket;

/**
 * <code>UniSequentialFile</code> is created via the <code>UniSession.openSequential</code>
 * method.  It is used to define and manage UniVerse Sequential Files, which are operating system
 * files.
 *
 * @author	David T. Meeks
 * @version	Version 1.0
 * @since		UNIOBJECTS 1.0
 */
public class UniSequentialFile extends UniBase
{
	UniSequentialFile() throws UniSequentialFileException
	{
		throw new UniSequentialFileException( UniObjectsTokens.UVE_MUST_USE_SESSION );
	}
	
	/**
	 * Constructs a <code>UniSequentialFile</code> object.  It automatically opens the file and will create
	 * the file is the <code>aCreateFlag</code> parameter is set to <code>true</code>.
	 *
	 * @since UNIOBJECTS 1.0
	 */
	UniSequentialFile( UniSession aSession, Object aFileName, Object aRecordID, boolean aCreateFlag )
		throws UniSequentialFileException
	{
		synchronized ( this ) {
	
			//  Set up our network layer
			if ( aSession == null )
				throw new UniSequentialFileException( UniObjectsTokens.UVE_SESSION_NOT_OPEN );
				
			uniParentSession		= aSession;
			uniConnection 			= aSession.connection;
			
			// Establish the internal properties as passed in
			uniSeqFileName 		= aFileName.toString();
			uniRecordName 		= aRecordID.toString();
			uniEncryptionType	= uniParentSession.getDefaultEncryptionType();
			isFileOpen				= false;
			uniTimeout				= 0;
			uniBlockSize			= 0;
			uniFileHandle			= 0;
			
			if ( aCreateFlag ) 
				uniCreateFlag 	= 1;
			else
				uniCreateFlag 	= 0;
				
			// Open the file
			open();
		}// synch this
	};
	
	/**
	 * Closes an open sequential file
	 *
	 * @exception UniSequentialFileException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void close() throws UniSequentialFileException
	{
		synchronized ( this ) {
	
			// Check entry conditions
			checkEntryConditions( true );
			
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_CLOSESEQ );
				outPacket.write( 1, uniFileHandle );
			
				uniConnection.call( outPacket, inPacket );
					
				uniReturnCode 	= inPacket.readInteger( 0 );
				if ( uniReturnCode == 0 )
				{
					// Fully close out the object, releasing references to other objects
					isFileOpen 				= false;
					uniParentSession 	= null;
					uniConnection			= null;
					inPacket					= null;
					outPacket					= null;
					uniFileHandle			= 0;
				}
				else
				{
					throw new UniSequentialFileException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSequentialFileException( e.getErrorCode() );
			}
		}// synch this
	}
	
	/**
	 * Moves the file pointer within the Sequential File by an offset position specified in bytes,
	 * relative to the current position, beginning of the file, or the end of the file, as determined
	 * by the <code>aRelPos</code> parameter.
	 *
	 * @param aRelPos integer denoting the relative position within a file to seek from.  A 0 (UniT_START)
	 *         implies to start from the beginning of the file.  1 (UniT_CURR) means to start from the
	 *         current position.  2 (UniT_END) means to start from the end of the file.
	 * @param aOffset integer denoting the number of bytes before or after aRelPos.  A negative value
	 *         moves the pointer to a position before aRelPos
	 * @exception UniSequentialFileException if any errors occur
	 * @since UNIOBJECTS 1.0
	 */
	public void fileSeek( int aRelPos, int aOffset ) throws UniSequentialFileException
	{
		synchronized ( this ) {
	
			if (( aRelPos < UniObjectsTokens.UVT_START ) || ( aRelPos > UniObjectsTokens.UVT_END ))
			{
				throw new UniSequentialFileException( UniObjectsTokens.UVE_EINVAL );
			}
			
			// Check entry conditions
			checkEntryConditions( false );
	
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_SEEK );
				outPacket.write( 1, uniFileHandle );
				outPacket.write( 2, aOffset );
				outPacket.write( 3, aRelPos );
			
				uniConnection.call( outPacket, inPacket );
					
				uniReturnCode 	= inPacket.readInteger( 0 );
				uniStatus				= 0;
				if ( uniReturnCode != 0 )
				{
					throw new UniSequentialFileException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSequentialFileException( e.getErrorCode() );
			}
		}//synch this
	};

	/**
	 * returns the current readblock size for this object
	 *
	 * @return integer value representing the current block size to be used when reading blocks of data
	 * @see #setReadSize
	 * @since UNIOBJECTS 1.0
	 */
	public int getReadSize()
	{
		return uniBlockSize;
	};
	
	/**
	 * returns the current timeout value for this object
	 *
	 * @return integer value representing the current timeout value
	 * @see #setTimeout
	 * @since UNIOBJECTS 1.0
	 */
	public int getTimeout()
	{
		return uniTimeout;
	};

	/**
	 * returns whether or not this sequential file is open
	 *
	 * @return boolean value denoting whether the file is open.  <code>true</code> represents the file being open
	 * @since UNIOBJECTS 1.0
	 */
	public boolean isOpen()
	{
		return isFileOpen;
	}
	
	/**
	 * physically opens the server-side file, creating it if the CreateFlag value was set and the file
	 * doesn't exist
	 *
	 * @exception UniSequentialFileException is thrown whenever an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void open() throws UniSequentialFileException
	{
		synchronized ( this ) {
	
			// Check entry conditions
			checkEntryConditions( false );
	
			try
			{
				inPacket 					= new UniRPCPacket( uniConnection );
				outPacket 				= new UniRPCPacket( uniConnection );
	
				outPacket.write( 0, UniObjectsTokens.EIC_OPENSEQ );
				outPacket.write( 1, encode(uniSeqFileName) );
				outPacket.write( 2, encode(uniRecordName ));
				outPacket.write( 3, uniCreateFlag );
			
				uniConnection.call( outPacket, inPacket, (byte) uniEncryptionType );
					
				uniReturnCode 	= inPacket.readInteger( 0 );
				
				// If the open was successful, load up the uniStatus and uniFileHandle value.  
				if ( uniReturnCode == 0 )
				{
					uniStatus 			= inPacket.readInteger( 1 );
					uniFileHandle 	= inPacket.readInteger( 2 );
					isFileOpen 			= true;
				}
				else
				{
					throw new UniSequentialFileException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSequentialFileException( e.getErrorCode() );
			}
		} // synch this
	};
	
	/**
	 * reads a block of data from the sequential file.  The size of the data block is defined by what
	 * is set using the <code>setReadSize</code> method.  Upon completion, the <code>getReadSize</code>
	 * method can be used to determine the number of bytes read.  Additionally, the <code>status</code>
	 * method will return one of the following value:
	 * <p>
	 * <ul>
	 * <li> -1 The file is not open for reading
	 * <li> 0  The read was successful
	 * <li> 1  The end of file was reached
	 * </ul>
	 *
	 * @return a String value representing the data that was read
	 * @exception UniSequentialFileException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public UniString readBlk() throws UniSequentialFileException
	{
		synchronized ( this ) {

			// Check entry conditions
			checkEntryConditions( true );
			
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_READBLK );
				outPacket.write( 1, uniFileHandle );
				outPacket.write( 2, (( uniBlockSize != 0 ) ? uniBlockSize : UniObjectsTokens.RESULT_BUFFER_SIZE ) );
			
				UniString tmpString = new UniString(uniParentSession);
				uniReturnString = null;
	
				while ( uniStatus == 0 )
				{
					uniConnection.call( outPacket, inPacket, (byte) uniEncryptionType );
					
					uniReturnCode 	= inPacket.readInteger( 0 );
					// If read was successful, get the data read, set the status, and set the read size
					if ( uniReturnCode == 0 )
					{	
					
						/* Status can have three known values:
								-1 : File not open for read
								 0 : read was successful
							 	 1 : end of file reached
						*/
						uniStatus 			= inPacket.readInteger( 1 );
						
						// If blockSize was set, we just get block and return
						if ( uniBlockSize != 0 )
						{
							uniReturnString = new UniString(uniParentSession,inPacket.readBytes( 2 ));
							setReadSize( uniReturnString.length() );
							return uniReturnString;
						}
						else
						{
							// Otherwise, build temporary string
							tmpString.append(inPacket.readBytes( 2 ));
						}
					}
					else
					{
						setReadSize( 0 );
						throw new UniSequentialFileException( uniReturnCode );
					}
				}
				uniReturnString = tmpString;
				setReadSize( uniReturnString.length() );
				return uniReturnString;
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSequentialFileException( e.getErrorCode() );
			}
		} // synch this
	}
	
	/**
	 * reads a line of data from the sequential file.  The lines must be delimited with a newline character.
	 * Additionally, the <code>status</code> method will return one of the following values:
	 * <p>
	 * <ul>
	 * <li> -1 The file is not open for reading
	 * <li> 0  The read was successful
	 * <li> 1  The end of file was reached of the <code>getReadSize</code> method is 0 or less
	 * </ul>
	 *
	 * @return a String value representing the data that was read
	 * @exception UniSequentialFileException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public UniString readLine() throws UniSequentialFileException
	{
		synchronized ( this ) {
	
			// Check entry conditions
			checkEntryConditions( true );
	
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_READSEQ );
				outPacket.write( 1, uniFileHandle );
			
				uniConnection.call( outPacket, inPacket, (byte) uniEncryptionType );
					
				uniReturnCode 	= inPacket.readInteger( 0 );
				
				// Read was successful
				if ( uniReturnCode == 0 )
				{
					uniStatus = inPacket.readInteger( 1 );
					uniReturnString = new UniString(uniParentSession,inPacket.readBytes( 2 ));
					return uniReturnString;
				}
				else
				{
					uniStatus = 0;
					throw new UniSequentialFileException( uniReturnCode );
				}
	
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSequentialFileException( e.getErrorCode() );
			}
		} // synch this
	};
	
	/**
	 * sets the current ReadSize for this object
	 *
	 * @param aBlockSize the block size to be set for subsequent read requests
	 * @see #getReadSize
	 * @since UNIOBJECTS 1.0
	 */
	public void setReadSize( int aBlockSize )
	{
		synchronized ( this ){
			// Handle boundary conditions
			if ( aBlockSize < 0 )
				aBlockSize = 0;
				
			uniBlockSize = aBlockSize;
		} // synch this
	};

	/**
	 * sets the current Timeout for this object
	 *
	 * @param aTimeOut the timeout value to be used for read requests
	 * @exception UniSequentialFileException is thrown if there is an error
	 * @see #setTimeout
	 * @since UNIOBJECTS 1.0
	 */
	public void setTimeout( int aTimeOut ) throws UniSequentialFileException
	{
		synchronized ( this ) {
	
			// Check entry conditions
			checkEntryConditions( true );
	
			// Handle boundary conditions
			if ( aTimeOut < 0 )
				aTimeOut = 0;
				
			uniTimeout = aTimeOut;
		
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_TIMEOUT );
				outPacket.write( 1, uniFileHandle );
				outPacket.write( 2, uniTimeout );
			
				uniConnection.call( outPacket, inPacket );
					
				uniReturnCode 	= inPacket.readInteger( 0 );
				if ( uniReturnCode != 0 )
				{
					throw new UniSequentialFileException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSequentialFileException(  e.getErrorCode() );
			}
		} // synch this
	};

	/**
	 * writes the given block to the sequential file, at the location currently set
	 *
	 * @param aString a String representing the data block to be written
	 * @exception UniSequentialFileException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void writeBlk( Object aString ) throws UniSequentialFileException
	{
		synchronized ( this ) {
	
			// Check entry conditions
			checkEntryConditions( true );
	
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_WRITEBLK );
				outPacket.write( 1, uniFileHandle );
                if (UniString.class.isInstance(aString))
                    outPacket.write(2,((UniString)aString).getBytes());
                else
                    outPacket.write( 2, encode(aString.toString()));
			
				uniConnection.call( outPacket, inPacket, (byte) uniEncryptionType );
					
				uniReturnCode 	= inPacket.readInteger( 0 );
				if ( uniReturnCode == 0 )
				{
					uniStatus = inPacket.readInteger( 1 );
				}
				else
				{
					uniStatus = 0;
					throw new UniSequentialFileException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSequentialFileException( e.getErrorCode() );
			}
		} // synch this
	};
		
	/**
	 * writes an EOF marker	 
	 *
	 * @exception UniSequentialFileException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void writeEOF() throws UniSequentialFileException
	{
		synchronized ( this ) {
	
			// Check entry conditions
			checkEntryConditions( true );
	
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_WEOFSEQ );
				outPacket.write( 1, uniFileHandle );
			
				uniConnection.call( outPacket, inPacket, (byte) uniEncryptionType );
					
				uniReturnCode 	= inPacket.readInteger( 0 );
				if ( uniReturnCode != 0 )
				{
					throw new UniSequentialFileException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSequentialFileException( e.getErrorCode() );
			}
		} // synch this
	};
	
	/**
	 * writes the given line to the sequential file, at the location currently set
	 *
	 * @param aString a String representing the line to be written
	 * @exception UniSequentialFileException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void writeLine( Object aString ) throws UniSequentialFileException
	{
		synchronized ( this ) {
	
			// Check entry conditions
			checkEntryConditions( true );
			
			try
			{
			    outPacket.write( 0, UniObjectsTokens.EIC_WRITESEQ );
			    outPacket.write( 1, uniFileHandle );
			    if (UniString.class.isInstance(aString))
			        outPacket.write(2,((UniString)aString).getBytes());
			    else
			        outPacket.write( 2, encode(aString.toString()));
			    
				uniConnection.call( outPacket, inPacket, (byte) uniEncryptionType );
					
				uniReturnCode 	= inPacket.readInteger( 0 );
				if ( uniReturnCode == 0 )
				{
					uniStatus = inPacket.readInteger( 1 );
				}
				else
				{
					uniStatus = 0;
					throw new UniSequentialFileException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSequentialFileException( e.getErrorCode() );
			}
		} // synch this
	};


	/**
	 * checks entry conditions to make sure we can perform this operation
	 * checks to make sure that the file is open, that we are not within
	 * an active UnICommand.exec() state, etc...
	 *
	 * @exception UniSequentialFileException is thrown if entry conditions not met
	 * @since UNIOBJECT 1.0
	 */
	private void checkEntryConditions( boolean shouldThrow ) throws UniSequentialFileException
	{
		if ( !isOpen() )
		{
			// Only denote an error if not from open()
			if ( shouldThrow )
			{
				String tmpFileName = uniSeqFileName + ":" + uniRecordName;
				uniStatus = -1;
				throw new UniSequentialFileException( UniObjectsTokens.UVE_FILE_NOT_OPEN, tmpFileName );
			}
		}

		// Check to ensure that a UniCommand execution is not active
		if ( isCommandActive() )
		{
			throw new UniSequentialFileException( UniObjectsTokens.UVE_EXECUTEISACTIVE );
		}

		// Reset status to 0 before command is issued.
		uniStatus = 0;
	}	
	
	/* Protected properties */
	protected  int  				uniFileHandle;
	
	/* Private properties */
	private String  				uniSeqFileName;
	private String					uniRecordName;
	private UniString				uniReturnString;
	private int 	  				uniReturnCode;
	private int		  				uniCreateFlag;
	private int		  				uniBlockSize;
	private int		  				uniTimeout;
	private boolean 				isFileOpen;
}
