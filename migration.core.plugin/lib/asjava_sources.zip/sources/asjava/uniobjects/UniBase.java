/*************************************************************************
 *
 * UniBase.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniobjects;
 
import asjava.unirpc.UniRPCConnection;
import asjava.unirpc.UniRPCPacket;

/**
 * <code>UniBase</code> is a base class that will be inherited by other classes
 * 
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since		UNIOBJECTS 1.0
 */
public abstract class UniBase 
{
	/**
	 * Creates the UniBase object.  
	 *
	 * @since	UNIOBJECTS 1.0
	 */
	 UniBase()
	 {
	 	// currently, we do nothing but initialization here as this is just an abstract class
	 	uniStatus 				= UniObjectsTokens.UVE_NOERROR;
	 	uniEncryptionType = UniObjectsTokens.NO_ENCRYPTION;
	 	uniParentSession 	= null;
	 	inPacket 					= null;
	 	outPacket 				= null;
	 	uniConnection 		= null;
	 }
	 
	/**
	 * returns the status of the last method performed on this object.  See individual classes for 
	 * potential return values
	 * 
	 * @return integer representing the status of any given command.  See the individual
	 *                 methods for more details
	 * @since UNIOBJECTS 1.0
	 */
	 public int status() 
	 {
	 	return uniStatus;
	 }
	 
  /** 
	 * retrieves the current EncryptionType value for this object.  It can be set with the 
	 * <code>setEncryptionType</code> method to override the <code>UniSession</code> default
	 * EncryptionType.  
	 *
	 * @return integer value representing the current EncryptionType for this object.
	 * @see #setEncryptionType
	 * @since UNIOBJECTS 1.0
	 */
	 public int getEncryptionType()
	 {
	 	return uniEncryptionType;
	 }
	 
	/** 
	 * sets up the EncryptionType to be used for client-server communications in this object
	 *
	 * @param aEncryptType integer representing which type of encryption is to be used.  0 disables encryption
	 * @see #getEncryptionType
	 * @since UNIOBJECTS 1.0
	 */
	 public void setEncryptionType( int aEncryptType )
	 {
	 	uniEncryptionType = aEncryptType;
	 }
	 
	 /**
	  * checks to see if a command is in an active state
	  *
	  * @return boolean stating whether we are in the middle of a command execution or not
	  * @since UNIOBJECTS 1.0
	  */
	 protected boolean isCommandActive()
	 {
	 	if ( uniParentSession != null )
	 	{
	 		return uniParentSession.isCommandActive();
	 	}
	 	// If we reach here, no active command is present;
	 	return false;
	 }
	 
     protected byte[] encode(String aString)
     {
         return uniParentSession.encode(aString);
     }
     
     protected String decode(byte[] bytes)
     {
         return uniParentSession.decode(bytes);
     }
     
	 // Define the instance variables common to all other classes
	 public UniRPCConnection 	uniConnection;		// RPC Connection handle
	 public UniRPCPacket			inPacket;					// input RPC packet
	 public UniRPCPacket			outPacket;				// output RPC packet
	 
	 public UniSession 				uniParentSession;	// Parent session that object was instantiated from
	 public int 							uniEncryptionType;// Defines the current encryption type being used
	 public int								uniStatus;				// object status
}