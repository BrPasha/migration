/*************************************************************************
 *
 * UniSelectList.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 11/18/04 e32565 RKK Connection Pooling
 * 09/10/04 WMY change @param
 * 05/05/99 24995 DTM Made code more thread safe
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniobjects;

import asjava.uniclientlibs.UniDataSet;
import asjava.uniclientlibs.UniDynArray;
import asjava.uniclientlibs.UniString;
import asjava.unirpc.UniRPCException;
import asjava.unirpc.UniRPCPacket;
import asjava.unirpc.UniRPCPacketException;

/**
 * <code>UniSelectList</code> is used to control, access, and manipulate server
 * side select lists.
 * 
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since	UNIOBJECTS 1.0
 */
public class UniSelectList extends UniBase
{
	/* Constructor */
	
	public UniSelectList() throws UniSelectListException
	{
		throw new UniSelectListException( UniObjectsTokens.UVE_MUST_USE_SESSION );
	}
	
	/**
	 * Returns the runtime class of the object 
	 *
	 * @since UNIOBJECTS 1.0
	 */
	public UniSelectList( UniSession aSession, int aSelectListNumber ) throws UniSelectListException
	{
		synchronized ( this ) {
	
			// Try establishing the uniConnection information
			if ( aSession == null )
				throw new UniSelectListException( UniObjectsTokens.UVE_SESSION_NOT_OPEN );
			
			if (( aSelectListNumber < 0 ) || ( aSelectListNumber > 10 ))
				throw new UniSelectListException( "Select List Number must be between 0 and 10",
																										UniObjectsTokens.UVE_EINVAL );
			uniParentSession					= aSession;
			uniConnection 						= uniParentSession.connection;
			
			// Set up default values
			uniSelectListNumber 	= aSelectListNumber;
			uniEncryptionType 		= aSession.getDefaultEncryptionType();
			bLastRecordRead 			= false;
			bIsSelectListActive		= false;
		}// synch this
	}
	
	/**
	 * Clears the selected list, emptying the contents and preparing for a new select
	 * list to be generated.
	 *
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void clearList() throws UniSelectListException
	{	
		synchronized ( this ) {
	
			// perform error checking
			checkEntryConditions();
			
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_CLEARSELECT );
				outPacket.write( 1, uniSelectListNumber );
			
				uniConnection.call( outPacket, inPacket, (byte)uniEncryptionType );
		
				// Set state back to default
				uniReturnCode 						= inPacket.readInteger( 0 );
				
				// A return code of 0 means it was successful
				if ( uniReturnCode == 0 )
				{
					bLastRecordRead 					= true;
					numberOfSelectListItems 	= 0;
				}
				else
				{
					throw new UniSelectListException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSelectListException(  e.getErrorCode() );
			}
		} // synch this
	}
	
	/**
	 * creates a new select list from the supplied list of record IDs
	 *
	 * @param aString a delimited String or UniDynArray containing the records IDs to use
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void formList( Object aString ) throws UniSelectListException
	{
		synchronized ( this ) {
	
			// check for errors
			checkEntryConditions();
			
			if ( aString.equals("") )
				return;
				
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_FORMLIST );
				outPacket.write( 1, uniSelectListNumber );
				if (UniString.class.isInstance(aString))
				    outPacket.write(2,((UniString)aString).getBytes());
				else
				    outPacket.write( 2, encode(aString.toString()));
				
				uniConnection.call( outPacket, inPacket, (byte)uniEncryptionType );
		
				uniReturnCode 		= inPacket.readInteger( 0 );
				if ( uniReturnCode == 0 )
				{
					bLastRecordRead = false;
				}
				else
				{
					throw new UniSelectListException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSelectListException( e.getErrorCode() );
			}
		} // synch this
	}

	/**
	 * creates a new select list from the supplied list of record IDs contained in the
	 * UniDataSet object
	 *
	 * @param aDataSet an existing UniDataSet object
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void formList( UniDataSet aDataSet ) throws UniSelectListException
	{
		synchronized ( this ) {
	
			if ( aDataSet == null )
				throw new UniSelectListException( UniObjectsTokens.UVE_EINVAL );
			
			UniString fList = aDataSet.getIDSetUniDynArray();
            byte[] imbyte = {fList.getMarkByte(UniObjectsTokens.IM)};
            byte[] fmbyte = {fList.getMarkByte(UniObjectsTokens.FM)};
			fList.change(imbyte , fmbyte);
			this.formList( fList );
		} // synch this
	}
	
	/**
	 * activates the named select list from the &SAVEDLISTS& file on the server
	 *
	 * @param aListName String denoting the name of which select list to activate
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void getList( Object aListName ) throws UniSelectListException 
	{
		synchronized ( this ) {
	
			// check for errors
			checkEntryConditions();
	
			if ( aListName.equals("") )
				return;
				
			try
			{
				uniListName = aListName.toString();
				
				outPacket.write( 0, UniObjectsTokens.EIC_GETLIST );
				outPacket.write( 1, uniSelectListNumber );
				outPacket.write( 2, encode(uniListName ));
				uniConnection.call( outPacket, inPacket, (byte)uniEncryptionType );
	
				uniReturnCode = inPacket.readInteger( 0 );
				if ( uniReturnCode == 0 )
				{
					bLastRecordRead = false;
				}
				else
				{
					throw new UniSelectListException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSelectListException( e.getErrorCode() );
			}
		} // synch this
	}

	/** 
	 * boolean entry denoting whether or not the last record has been read.  <code>true</code>
	 * denotes that no more records are left in the select list.
	 *
	 * @return the boolean value representing whether the last record was read.
	 * <ul>
	 * <li>     <code>true</code> means the select list has no more records
	 * <li>     <code>false</code> means the select list still has records IDs
	 * </ul>
	 * @since UNIOBJECTS 1.0
	 */
	public boolean isLastRecordRead()
	{
		return bLastRecordRead;
	}
	
	/**
	 * returns the next record ID in the select list.  If exhausted, it will return a
	 * <code>null</code> value and the <code>isLastRecordRead</code> method will return
	 * <code>true</code>
	 *
	 * @return the next record ID from the select list, or a <code>null</code> if exhausted
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @see #isLastRecordRead
	 * @since UNIOBJECTS 1.0
	 */
	public UniString next() throws UniSelectListException
	{
		synchronized ( this ) {
	
			// check for errors
			checkEntryConditions();
	
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_READNEXT );
				outPacket.write( 1, uniSelectListNumber );
			
				uniConnection.call( outPacket, inPacket, (byte)uniEncryptionType );
				
				uniReturnCode = inPacket.readInteger( 0 );
				// A return code of 0 means it was successful
				if ( uniReturnCode == 0 )
				{
					bLastRecordRead = false;
					return new UniString(uniParentSession, inPacket.readBytes( 1 ));
				}
				else
				{
					if ( uniReturnCode == UniObjectsTokens.UVE_LRR )
					{
						bLastRecordRead = true;
						uniReturnCode 		= 0;
						return new UniString(uniParentSession);
					}
					else
					{
						throw new UniSelectListException( uniReturnCode );
					}
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSelectListException( e.getErrorCode() );
			}
		} // synch this
	}
	
	/**
	 * reads the entire contents of the select list and returns it all at once
	 *
	 * @return UniDynArray representing the entire select list
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public UniDynArray readList() throws UniSelectListException
	{
		synchronized ( this ) {
	
			// check for errors
			checkEntryConditions();
	
			UniDynArray uniSelectList = null;
			numberOfSelectListItems = 0;
			
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_READLIST );
				outPacket.write( 1, uniSelectListNumber );
			
				uniConnection.call( outPacket, inPacket, (byte)uniEncryptionType );
				uniReturnCode = inPacket.readInteger( 0 );
				
				/* If uniReturnCode == 0, it means we have a valid select list */
				if ( uniReturnCode == 0 )
				{
					numberOfSelectListItems = inPacket.readInteger( 1 );
					if ( numberOfSelectListItems > 0 )
					{
						uniSelectList = new UniDynArray( uniParentSession, inPacket.readBytes( 2 ) );
						bLastRecordRead = false;
					}
					else
					{
						uniSelectList = new UniDynArray(uniParentSession);
						bLastRecordRead = true;
					}
					return uniSelectList;
				}
				else
				{
					if ( uniReturnCode == UniObjectsTokens.UVE_LRR )
					{
						bLastRecordRead = true;
						uniReturnCode = 0;	
						uniSelectList = new UniDynArray(uniParentSession);
						return uniSelectList;
					}
					else
					{
						throw new UniSelectListException( uniReturnCode );
					}
				}		
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSelectListException( e.getErrorCode() );
			}
		} // synch this
	}
	
	/**
	 * Saves the current select list in &SAVEDLISTS& file on the server with the name
	 * supplied
	 *
	 * @param aListNameObj String denoting the name the select list should be saved to
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void saveList( Object aListNameObj ) throws UniSelectListException
	{	// Interestingly enough, because there isn't an equivalent call in intercall,
		// we will need to issue a UniCommand for this...

		synchronized ( this ) {
	
			// check for errors
			checkEntryConditions();
	
			if ( aListNameObj.equals("") )
				return;
				
			try 
			{
				UniCommand unic 	= new UniCommand( uniParentSession );
				String uniCommand = "SAVE.LIST " + aListNameObj + " FROM " + uniSelectListNumber;
				unic.setCommand ( uniCommand );
				unic.exec();
				
				// Can't think of any reasons why this should ever occur, but just in case
				if ( unic.status() != UniObjectsTokens.UVS_COMPLETE )
					unic.reply("");
				
			}
			catch ( UniCommandException e )
			{
				throw new UniSelectListException( e.getErrorCode() );
			}
		} // synch this
	}
	
	/**
	 * creates a new select list by selecting the <code>UniFile</code> object and 
	 * generating a select list of all the record IDs from that file.  It will overwrite
	 * any previous select list and the select list pointer will be reset to the first
	 * record in the list.
	 *
	 * @param uniFile <code>UniFile</code> object to be selected
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void select( UniFile uniFile ) throws UniSelectListException
	{
		synchronized ( this ) {
	
			// check for errors
			checkEntryConditions();
			
			if ( uniFile == null )
				throw new UniSelectListException( UniObjectsTokens.UVE_ENFILE );
			if (!uniFile.isOpen() )
				throw new UniSelectListException( UniObjectsTokens.UVE_FILE_NOT_OPEN, uniFile.getFileName() );
	
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_SELECT );
				outPacket.write( 1, uniFile.uniFileHandle );
				outPacket.write( 2, uniSelectListNumber );
			
				uniConnection.call( outPacket, inPacket, (byte)uniEncryptionType );
		
				uniReturnCode = inPacket.readInteger( 0 );
				if ( uniReturnCode == 0 )
				{
					bLastRecordRead = false;
				}
				else
				{
					throw new UniSelectListException( uniReturnCode );
				}
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSelectListException( e.getErrorCode() );
			}
		}//synch this
	}
	
	/**
	 * creates a new select list by selecting the <code>UniDictionary</code> object and 
	 * generating a select list of all the record IDs from that file.  It will overwrite
	 * any previous select list and the select list pointer will be reset to the first
	 * record in the list.
	 *
	 * @param uniFile <code>UniDictionary</code> object to be selected
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void select( UniDictionary uniFile ) throws UniSelectListException
	{
		select( (UniFile) uniFile );
	}
	
	/**
	 * generate a select list from the given <code>UniFile</code> from values in the 
	 * secondary key index that is specified.
	 *
	 * @param uniFile <code>UniFile</code> to be selected
	 * @param aIndexName index name to select on
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void selectAlternateKey( UniFile uniFile,  Object aIndexName )
			throws UniSelectListException
	{
		this.doAKSelect( uniFile, aIndexName, -1, emptyString );
	}
	
	/**
	 * generate a select list from the given <code>UniDictionary</code> from values in the 
	 * secondary key index that is specified.
	 *
	 * @param unid <code>UniDictionary</code> to be selected
	 * @param aIndexName index name to select on
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void selectAlternateKey( UniDictionary unid,  Object aIndexName )
		  throws UniSelectListException
	{
		this.doAKSelect( unid, aIndexName, -1, emptyString );
	}
	
	/**
	 * generate a select list from the given <code>UniFile</code> from values in the 
	 * secondary key index that is specified whose value matches that in the named 
	 * value.
	 *
	 * @param uniFile <code>UniFile</code> to be selected
	 * @param aIndexName index name to select on
	 * @param aIndexValue	value within the index to select to
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void selectMatchingAK( UniFile uniFile,  Object aIndexName, Object aIndexValue )
		throws UniSelectListException
	{
		this.doAKSelect( uniFile, aIndexName, aIndexValue.toString().length(), aIndexValue );
	}
	
	/**
	 * generate a select list from the given <code>UniDictionary</code> from values in the 
	 * secondary key index that is specified whose value matches that in the named
	 * value.
	 *
	 * @param unid <code>UniDictionary</code> to be selected
	 * @param aIndexName index name to select on
	 * @param aIndexValue	value from the secondary key index.  Records are selected when the 
	 *                  indexed field matches this value.
	 * @exception UniSelectListException is thrown if an error condition occurs
	 * @since UNIOBJECTS 1.0
	 */
	public void selectMatchingAK( UniDictionary unid,  Object aIndexName, Object aIndexValue )
		throws UniSelectListException
	{
		this.doAKSelect( unid,  aIndexName, aIndexValue.toString().length(), aIndexValue );
	}

	/* Private Methods */
	private void doAKSelect( UniFile uniFile,  Object aIndexNameObj, int aIndexLen, Object aIndexValueObj )
		throws UniSelectListException
	{
		synchronized ( this ) {
	
			// check for errors
			checkEntryConditions();
			if ( uniFile == null )
				throw new UniSelectListException( UniObjectsTokens.UVE_ENFILE );
			if (!uniFile.isOpen() )
				throw new UniSelectListException( UniObjectsTokens.UVE_FILE_NOT_OPEN, uniFile.getFileName() );
	
			try
			{
				int uniStatus = 0;
				
				outPacket.write( 0, UniObjectsTokens.EIC_SELECTINDEX );
				outPacket.write( 1, uniFile.uniFileHandle );
				outPacket.write( 2, uniSelectListNumber );
				outPacket.write( 3, encode(aIndexNameObj.toString()));
				outPacket.write( 4, aIndexLen );
				outPacket.write( 5, encode(aIndexValueObj.toString()));
				
				uniConnection.call( outPacket, inPacket, (byte)uniEncryptionType );
	
				uniReturnCode = inPacket.readInteger( 0 );
				uniStatus = inPacket.readInteger( 1 );
				if ( uniStatus == UniObjectsTokens.UVT_SELECTLISTEMPTY_STATE )
					bLastRecordRead = true;
				else
					bLastRecordRead = false;
			}
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSelectListException( e.getErrorCode() );
			}
		} // synch this
	}
	
	private void checkEntryConditions() throws UniSelectListException
	{
		// Check to ensure that a UniCommand execution is not active
		if ( isCommandActive() )
		{
			throw new UniSelectListException( UniObjectsTokens.UVE_EXECUTEISACTIVE );
		}

		// Make sure we have inPacket and outPacket set up
		if ( inPacket == null )
		{
			try
			{
				outPacket 		= new UniRPCPacket( uniConnection );
				inPacket 			=	new UniRPCPacket( uniConnection );
				uniStatus 		= 0;
			}
			catch ( UniRPCPacketException e )
			{
				throw new UniSelectListException( e.getErrorCode() );
			}
		}
	}

		
	/* Private class variables */
	private	final	String			emptyString								= new String("");
	private String 						uniListName 							= new String("");
	private	int								uniSelectListNumber 			= -1;
	private int 							uniReturnCode 						= 0;
	private int 							numberOfSelectListItems 	= 0;
	private boolean 					bLastRecordRead 					= false;
	private boolean						bIsSelectListActive				= false;
}
