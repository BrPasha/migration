/*************************************************************************
 *
 * UniFile.java
 *
 *
 * IBM Confidential
 * OCO Source Materials
 * Copyright (C) IBM Corp.  1998, 2009
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 07/10/09 40310 JFM more NLS enhancement dealing with Object type parameter
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 07/25/05 7898  JFM reverse a change made to setRecordID() so that we don't re
 alease lock on record when setRecordID() is called. The original design for rele
 asing record locks when record id changes was not well thoughtout, so it was dis
 abled. We enabled it when we were fixing some locking/releasing related bugs. No
 w customers reported regression and so we need to disable it again. This makes t
 he UniObjectsTokens.UVT_CHANGE_RELEASE release strategy not effective at all,alt
 hough it is the default release strategy. As it will involve doc change, we deci
 de not to touch this part for now.
 * 11/18/04 e32565 RKK Connection Pooling
 * 09/10/04 W.YEH 32722 change @see to avoid javadoc warning.
 * 11/04/03 5747  RKK readNamedField - change uniReocrd to uniRecordID
 * 10/14/02 2607,2609,2984 RKK NLS Stuff
 * 10/10/02 Ecase2162 RKK ReadNamedFields() and WriteNamedFields()
 * 06/26/02 2417  RK  changed setRelaseStargy() to return correct value
 * 05/05/99 24995 DTM Made code blocks synchronized for thread safety
 * 02/19/99 24571 DTM Fixed readnamedfield to use dataset instead of subroutine
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniobjects;

import asjava.uniclientlibs.UniByteArrayTokenizer;
import asjava.uniclientlibs.UniDataSet;
import asjava.uniclientlibs.UniDynArray;
import asjava.uniclientlibs.UniException;
import asjava.uniclientlibs.UniRecord;
import asjava.uniclientlibs.UniString;
import asjava.uniclientlibs.UniStringException;
import asjava.uniclientlibs.UniTokens;
import asjava.unirpc.UniRPCException;
import asjava.unirpc.UniRPCPacket;

/**
 * <code>UniFile</code> is used to access to all file operations
 * 
 * @version Version 1.0
 * @author David T. Meeks
 * @since UNIOBJECTS 1.0
 */
public class UniFile extends UniBase {
    /**
     * Default constructor for this class.
     * 
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniFile() throws UniFileException {
        throw new UniFileException(UniObjectsTokens.UVE_MUST_USE_SESSION);
    }

    public UniFile(UniSession aSession, Object aFileName, int aDictFlag)
            throws UniFileException {
        synchronized (this) {
            if (aSession == null)
                throw new UniFileException(
                        UniObjectsTokens.UVE_SESSION_NOT_OPEN);

            // must be a valid filename. If the file name is empty, throw
            // exception
            if ((aFileName == null) || (aFileName.toString().equals(""))) {
                throw new UniFileException(UniObjectsTokens.UVE_INVALIDFILENAME);
            }

            // set up initial values
            uniParentSession = aSession;
            uniConnection = uniParentSession.connection;
            inPacket = null;
            outPacket = null;

            uniFileName = new UniString(uniParentSession,aFileName.toString());
            uniDictFlag = aDictFlag; /*
                                         * Dict flag is set to 0 for normal
                                         * files.
                                         */
            uniLockCount = 0;
            isFileOpen = false;

            // inherit various lock strategies from the Session object by
            // default.
            setBlockingStrategy(uniParentSession.getDefaultBlockingStrategy());
            setLockStrategy(uniParentSession.getDefaultLockStrategy());
            setReleaseStrategy(uniParentSession.getDefaultReleaseStrategy());
            setEncryptionType(uniParentSession.getDefaultEncryptionType());

            // try opening the file. If successful, it will set
            // <code>isFileOpen</code>
            // to <code>true</code>.
            open();
        } // synchronized block
    };

    /**
     * clears a file, deleting all records contained within it. If a file is
     * locked by another user, the <code>BlockingStrategy</code>, which can
     * be set with the <code>setBlockingStrategy</code> method, determines the
     * behavior
     * 
     * @exception UniFileException
     *                is thrown is an error occurs
     * @since UNIOBJECTS 1.0
     */
    public void clearFile() throws UniFileException {
        synchronized (this) {
            // check to ensure that the file is open.
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_CLEARFILE);
                outPacket.write(1, uniFileHandle);

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);
                uniReturnCode = inPacket.readInteger(0);

                // Should never get here, but just in case...
                if (uniReturnCode != 0) {
                    throw new UniFileException(uniReturnCode);
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synchronized this
    };

    /**
     * closes the file. All file and record locks are released
     * 
     * @exception UniFileException
     *                is thrown is an error occurs
     * @since UNIOBJECTS 1.0
     */
    public void close() throws UniFileException {
        synchronized (this) {
            // if the file is not open, just return and don't worry about
            // things...
            checkEntryConditions(NO_EXCEPTION, NO_RECORD);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_CLOSE);
                outPacket.write(1, uniFileHandle);

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);

                uniReturnCode = inPacket.readInteger(0);
                uniLockCount = 0;
                isFileOpen = false;

                // Should never get here, but just in case...
                if (uniReturnCode != 0) {
                    throw new UniFileException(uniReturnCode);
                }
            } catch (UniRPCException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch. this
    };

    /**
     * deletes the record identified by <code>setRecordID</code>.
     * 
     * @exception UniFileException
     *                is thrown is an error occurs
     * @since UNIOBJECTS 1.0
     */
    public void deleteRecord() throws UniFileException {
        synchronized (this) {
            // If the file is not open, we obviously cannot delete a record from
            // it
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_DELETE);
                outPacket.write(1, uniFileHandle);
                outPacket.write(2, getDeleteLock());
                outPacket.write(3, uniRecordID.getBytes());

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);
                uniReturnCode = inPacket.readInteger(0);

                if (uniReturnCode != 0) {
                    // set the status value upon failure
                    uniStatus = inPacket.readInteger(1);
                    throw new UniFileException(uniReturnCode);
                } else {
                    uniStatus = 0;
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch. this
    };

    /**
     * deletes the records identified by <code>aDataSet</code> UniDataSet
     * object
     * 
     * @param aDataSet
     *            <code>UniDataSet</code> object which identifies which record
     *            IDs to be deleted.
     * @exception UniFileException
     *                is thrown is an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDataSet deleteRecord(UniDataSet aDataSet) throws UniFileException {
        synchronized (this) {

            // If the file is not open, we obviously cannot delete a record from
            // it
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            return fileAction(UniTokens.EIC_DELETESET, aDataSet, null,
                    getReadLock());
        } // synch this
    }

    /**
     * deletes the record identified by <code>aRecordIDObj</code>.
     * 
     * @param aRecordIDObj
     *            identifies which record ID is to be deleted.
     * @exception UniFileException
     *                is thrown is an error occurs
     * @since UNIOBJECTS 1.0
     */
    public void deleteRecord(Object aRecordIDObj) throws UniFileException {
        synchronized (this) {
            this.setRecordID(aRecordIDObj);
            this.deleteRecord();
        } // synch this
    }

    /**
     * obtains information concerning the secondary key indexes available for
     * this object. The return value will vary depending on the type of index,
     * as follows:
     * <ul>
     * <li> For D-Type indexes: Field 1 contains D as first character and Field
     * 2 contains the location number of the indexed field
     * <li> For I-type indexes: Field 1 contains I as first character, Field 2
     * contains the I-type expression, and the compiled I-type resides in field
     * 19 and onward.
     * <li> For both types: 2nd value of Field 1 indicates if the index needs to
     * be rebuilt. It is an empty string otherwise. 3rd value of Field 1 is set
     * if the index is null-suppressed. It is an empty string otherwise. 4th
     * value of Field 1 is set if automatic updates are disabled. It is an empty
     * string otherwise. 6th value of Field 1 contains an S for single valued
     * indices or M for a multivalued index.
     * </ul>
     * If <code>akNameObj</code> is passed in as an empty string, then the
     * list of available indices is returned
     * 
     * @param akNameObj
     *            name of the index to query about
     * @return the information concerning the given index, or a list of all the
     *         indexes available
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDynArray getAkInfo(Object akNameObj) throws UniFileException {
        synchronized (this) {
            // Check for errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            String akName = akNameObj.toString();

            try {
                outPacket.write(0, UniObjectsTokens.EIC_INDICES);
                outPacket.write(1, uniFileHandle);
                outPacket.write(2, akName.length());
                outPacket.write(3, encode(akName.toString()));

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);
                uniReturnCode = inPacket.readInteger(0);
                if (uniReturnCode != 0) {
                    throw new UniFileException(uniReturnCode);
                } else {
                    uniStatus = 0;
                    uniRecord = new UniString(uniParentSession, inPacket
                            .readBytes(1));
                    return new UniDynArray(uniRecord);
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    };

    /**
     * returns the current blocking strategy. The initial value is inherited
     * from the <code>UniSession.setDefaultBlockingStrategy</code> method.
     * Valid values are:
     * <ul>
     * <li> WAIT_ON_LOCKED (1) - If the record is locked, wait until it is
     * released
     * <li> RETURN_ON_LOCKED (2) - Return a value to <code>status</code> to
     * indicate the state of the lock.
     * </ul>
     * 
     * @return integer representing the current blocking strategy for this
     *         object
     * @see #setBlockingStrategy
     * @since UNIOBJECTS 1.0
     */
    public int getBlockingStrategy() {
        return uniBlockingStrategy;
    };

    /**
     * returns the name of the file this object represents
     * 
     * @return String representing the UniVerse file that was opened
     * @see #setFileName
     * @since UNIOBJECTS 1.0
     */
    public String getFileName() {
        return uniFileName.toString();
    };

    /**
     * returns the type of file this is. The file is either a static hashed
     * (2-18), directory (1 or 19), b-tree (25), or dynamic (30).
     * 
     * @return integer representing the type of UniVerse file that was opened.
     * @since UNIOBJECTS 1.0
     */
    public int getFileType() {
        return uniFileType;
    };

    /**
     * returns the current locking strategy. The initial value is inherited from
     * the <code>UniSession.setDefaultLockStrategy</code> method. Valid values
     * are:
     * <ul>
     * <li> NO_LOCKS (0) - No locking is to be done by default
     * <li> EXCLUSIVE_UPDATE - Sets an exclusive update lock (READU) for all
     * file access
     * <li> SHARED_READ - Sets a shared lock (READL) for all file access
     * </ul>
     * 
     * @return integer representing the current locking strategy for this object
     * @see #setLockStrategy
     * @since UNIOBJECTS 1.0
     */
    public int getLockStrategy() {
        return uniLockStrategy;
    };

    /**
     * returns the contents of the record that was last read. It is updated
     * every time a <code>read</code>, <code>readField</code>, or
     * <code>readNamedField</code> is performed.
     * 
     * @return UniString representing the data that was last read
     * @see #setRecord
     * @see #read
     * @see #readField
     * @see #readNamedField
     * @since UNIOBJECTS 1.0
     */
    public UniString getRecord() {
        return uniRecord;
    };

    /**
     * returns the ID of the record that was last read. It is updated every time
     * a <code>read</code>, <code>readField</code>, or
     * <code>readNamedField</code> is performed.
     * 
     * @return String representing the ID of the data that was last read
     * @see #setRecordID
     * @see #read
     * @see #readField
     * @see #readNamedField
     * @since UNIOBJECTS 1.0
     */
    public String getRecordID() {
        return uniRecordID.toString();
    };

    /**
     * returns the current release strategy. The initial value is inherited from
     * the <code>UniSession.setDefaultReleaseStrategy</code> method. Valid
     * values are:
     * <ul>
     * <li> WRITE_RELEASE (1) - Release the lock when the record is written
     * <li> READ_RELEASE (2) - Release the lock when the record is read
     * <li> EXPLICIT_RELEASE (4) - maintains locks as specified by the
     * <code>setLockStrategy</code> method. Locks can only be released with
     * the <code>unlockRecord</code>method
     * <li> CHANGE_RELEASE (8) - releases the lock whenever a new value is set
     * using the <code>setRecordID</code> method
     * 
     * @return integer representing the current release strategy for this object
     * @see #setReleaseStrategy
     * @see #setLockStrategy
     * @see #unlockRecord
     * @since UNIOBJECTS 1.0
     */
    public int getReleaseStrategy() {
        return uniReleaseStrategy;
    };

    /**
     * Denotes whether the file is open. A <code>true</code> value indicates
     * the file is still open for use, a <code>false</code> indicates the file
     * is closed and unavailable until reopened.
     * 
     * @return boolean representing whether the file is opened or closed
     * @since UNIOBJECTS 1.0
     */
    public boolean isOpen() {
        return isFileOpen;
    };

    /**
     * determines whether or not a user or session currently holds a lock on a
     * given record ID.
     * 
     * @return boolean representing whether the record is locked.
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public boolean isRecordLocked() throws UniFileException {
        synchronized (this) {

            int lockStatus = 0;

            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_RECORDLOCKED);
                outPacket.write(1, uniFileHandle);
                outPacket.write(2, uniRecordID.getBytes());

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);

                uniReturnCode = inPacket.readInteger(0);

                // can't think of why we'd ever get here, but just in case.
                if (uniReturnCode != 0) {
                    throw new UniFileException(uniReturnCode);
                } else {
                    lockStatus = inPacket.readInteger(1);
                    uniStatus = inPacket.readInteger(2);
                }

                if (lockStatus == 0)
                    return false;
                else
                    return true;
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    }

    /**
     * determines whether or not a user or session currently holds a lock on a
     * given record ID.
     * 
     * @param aRecordIDObj
     *            represents the record ID to be checked.
     * @return boolean representing whether the record is locked.
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public boolean isRecordLocked(Object aRecordIDObj) throws UniFileException {
        synchronized (this) {
            this.setRecordID(aRecordIDObj);
            return this.isRecordLocked();
        } // synch this
    }

    /**
     * Evalutes the specified I-descriptor and returns the evaluated string. It
     * applies no conversion to the data.
     * 
     * @param aRecordIDObj
     *            record ID of the record supplied as data to the Itype facility
     * @param aITypeIDObj
     *            record ID of the Idescriptor record to be evaluated
     * @return UniString representing the evaluated string
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniString iType(Object aRecordIDObj, Object aITypeIDObj)
            throws UniFileException {
        synchronized (this) {

            String aRecordID = aRecordIDObj.toString();
            UniString aITypeID = new UniString(uniParentSession,aITypeIDObj.toString());

            // Check for Errors
            this.setRecordID(aRecordIDObj);
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_ITYPE);
                outPacket.write(1, uniFileName.getBytes());
                outPacket.write(2, uniRecordID.getBytes());
                outPacket.write(3, aITypeID.getBytes());

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);
                uniReturnCode = inPacket.readInteger(0);

                if (uniReturnCode != 0) {
                    throw new UniFileException(uniReturnCode);
                } else {
                    return new UniString(uniParentSession, inPacket
                            .readBytes(1));

                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    };

    /**
     * locks this UniVerse file. If another user currently owns a lock, it will
     * throw a UniFileException
     * 
     * @exception UniFileException
     *                is thrown if an error is detected
     * @since UNIOBJECTS 1.0
     */
    public void lockFile() throws UniFileException {
        synchronized (this) {

            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_FILELOCK);
                outPacket.write(1, uniFileHandle);

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);
                uniReturnCode = inPacket.readInteger(0);

                if (uniReturnCode != 0) {
                    uniStatus = inPacket.readInteger(1);
                    throw new UniFileException(uniReturnCode);
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    };

    /**
     * locks the recordID established with the <code>setRecordID</code>method.
     * This method is used to override the current locking strategy
     * 
     * @param aLockFlag
     *            Type of lock to set. Valid values are:
     *            <ul>
     *            <li> EXCLUSIVE_UPDATE (1) - Sets a READU lock
     *            <li> SHARED_READ (2) - Sets a READL lock
     *            </ul>
     * @exception UniFileException
     *                is thrown if an error is detected
     * @since UNIOBJECTS 1.0
     */
    public void lockRecord(int aLockFlag) throws UniFileException {
        synchronized (this) {

            // if we are requesting no locks, just return.
            if (aLockFlag == UniObjectsTokens.UVT_NO_LOCKS)
                return;

            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);

            uniLockFlag = UniObjectsTokens.IK_READU;

            if (aLockFlag == UniObjectsTokens.UVT_SHARED_READ)
                uniLockFlag = UniObjectsTokens.IK_READL;

            if (uniBlockingStrategy == UniObjectsTokens.UVT_WAIT_LOCKED)
                uniLockFlag += UniObjectsTokens.IK_WAIT;

            try {
                outPacket.write(0, UniObjectsTokens.EIC_RECORDLOCK);
                outPacket.write(1, uniFileHandle);
                outPacket.write(2, uniLockFlag);
                outPacket.write(3, uniRecordID.getBytes());

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);

                uniReturnCode = inPacket.readInteger(0);
                if (uniReturnCode != 0) {
                    uniStatus = inPacket.readInteger(1);
                    throw new UniFileException(uniReturnCode);
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    };

    /**
     * locks the recordID established with the <code>aRecordIDObj</code>
     * argument.. This method is used to override the current locking strategy
     * 
     * @param aRecordIDObj
     *            String denoting which record ID to lock
     * @param aLockFlag
     *            Type of lock to set. Valid values are:
     *            <ul>
     *            <li> EXCLUSIVE_UPDATE (1) - Sets a READU lock
     *            <li> SHARED_READ (2) - Sets a READL lock
     *            </ul>
     * @exception UniFileException
     *                is thrown if an error is detected
     * @since UNIOBJECTS 1.0
     */
    public void lockRecord(Object aRecordIDObj, int aLockFlag)
            throws UniFileException {
        synchronized (this) {
            this.setRecordID(aRecordIDObj);
            this.lockRecord(aLockFlag);
        } // synch this
    }

    /**
     * locks the recordIDs established with the <code>UniDataSet</code> object
     * argument.. This method is used to override the current locking strategy
     * 
     * @param aDataSet
     *            UniDataSet denoting which record IDs to lock
     * @param aLockFlag
     *            Type of lock to set. Valid values are:
     *            <ul>
     *            <li> EXCLUSIVE_UPDATE (1) - Sets a READU lock
     *            <li> SHARED_READ (2) - Sets a READL lock
     *            </ul>
     * @return UniDataSet object denoting which records were successfully locked
     * @exception UniFileException
     *                is thrown if an error is detected
     * @since UNIOBJECTS 1.0
     */

    public UniDataSet lockRecord(UniDataSet aDataSet, int aLockFlag)
            throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            uniLockFlag = UniObjectsTokens.IK_READU;

            if (aLockFlag == UniObjectsTokens.UVT_SHARED_READ)
                uniLockFlag = UniObjectsTokens.IK_READL;

            if (uniBlockingStrategy == UniObjectsTokens.UVT_WAIT_LOCKED)
                uniLockFlag += UniObjectsTokens.IK_WAIT;

            return fileAction(UniTokens.EIC_LOCKSET, aDataSet, null,
                    uniLockFlag);
        } // synch this
    }

    /**
     * Opens the named file. If it cannot be opened, a UniFileException will be
     * thrown
     * 
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public void open() throws UniFileException {
        synchronized (this) {

            // Check for Errors
            checkEntryConditions(NO_EXCEPTION, NO_RECORD);

            try {
                if (outPacket == null) {
                    outPacket = new UniRPCPacket(uniConnection);
                    inPacket = new UniRPCPacket(uniConnection);
                }

                outPacket.write(0, UniObjectsTokens.EIC_OPEN);
                outPacket.write(1, uniDictFlag);
                outPacket.write(2, uniFileName.getBytes());
                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);

                uniStatus = 0;
                uniReturnCode = inPacket.readInteger(0);
                if (uniReturnCode == 0) {
                    uniStatus = inPacket.readInteger(1);
                    uniFileHandle = inPacket.readInteger(2);
                    uniFileType = uniStatus;
                    isFileOpen = true;
                } else { // We got some error back
                    throw new UniFileException(uniReturnCode);
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode(), uniFileName.toString());
            }
        } // synch this
    };

    /**
     * reads the UniVerse record from this file. It uses the record ID
     * established via the <code>setRecordID</code> method.
     * 
     * @return UniString representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @see #setRecordID
     * @since UNIOBJECTS 1.0
     */
    public UniString read() throws UniFileException {
        synchronized (this) {

            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);

            uniRecord = null;

            try {
                outPacket.write(0, UniObjectsTokens.EIC_READ);
                outPacket.write(1, uniFileHandle);
                outPacket.write(2, getReadLock());
                outPacket.write(3, uniRecordID.getBytes());

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);

                uniReturnCode = inPacket.readInteger(0);
                uniStatus = inPacket.readInteger(1);

                // If no error occured
                if (uniReturnCode == 0) {
                    uniRecord = new UniString(uniParentSession, inPacket
                            .readBytes(2));
                    Lock();
                    doReadRelease();
                } else {
                    switch (uniReturnCode) {
                    case UniTokens.UVE_EIO: {
                        String msg;
                        switch (uniStatus) {
                        case 1:
                            msg = new String(
                                    "A bad partitioning algorithm exists for this file");
                            break;
                        case 2:
                            msg = new String("No such part file");
                            break;
                        case 3:
                            msg = new String(
                                    "Record ID contains unmappable NLS characters");
                            break;
                        case 4:
                            msg = new String(
                                    "Record data contains unmappable NLS characters");
                            break;
                        default:
                            msg = new String("An IO Error has occured");
                            break;
                        }
                        throw new UniFileException(msg, UniTokens.UVE_EIO);
                    }
                    default:
                        throw new UniFileException(uniReturnCode);
                    }
                }
                return uniRecord;
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    }

    /**
     * reads the set of UniVerse records passed in via the UniDataSet object.
     * This UniDataSet object should contain the list of record IDs to be read
     * from this file.
     * 
     * @param aRowSet
     *            list of record IDs to be read from this file
     * @return UniDataSet representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDataSet read(UniDataSet aRowSet) throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            return fileAction(UniTokens.EIC_READSET, aRowSet, null,
                    getReadLock());
        } // synch this
    }

    /**
     * reads the UniVerse record from this file. It uses the record ID
     * established via the <code>aRecordIDObj</code> argument that is passed
     * in.
     * 
     * @param aRecordIDObj
     *            record ID to be read from the file
     * @return UniString representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniString read(Object aRecordIDObj) throws UniFileException {
        synchronized (this) {
            this.setRecordID(aRecordIDObj);
            return this.read();
        } // synch this
    }

    /**
     * reads the UniVerse record from this file. It uses the record ID
     * established via the <code>aRecordIDObj</code> argument that is passed
     * in. It will also lock the record according to the <code>aLockFlag</code>
     * argument that is passed in.
     * 
     * @param aRecordIDObj
     *            record ID to be read from the file
     * @param aLockFlag
     *            is the type of lock that is to be set. See
     *            <code>setLockStrategy</code> for details on valid values
     * @return UniString representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @see #setLockStrategy
     * @since UNIOBJECTS 1.0
     */
    public UniString read(Object aRecordIDObj, int aLockFlag)
            throws UniFileException {
        synchronized (this) {
            uniLockFlag = aLockFlag;
            return this.read(aRecordIDObj);
        } // synch this
    }

    /**
     * reads the specified field from the UniVerse record identified. It uses
     * the record ID established via the <code>aRecordIDObj</code> argument
     * that is passed in. It will return only the field number specified in
     * <code>aFieldNumber</code>
     * 
     * @param aRecordIDObj
     *            record ID to be read from the file
     * @param aFieldNumber
     *            integer representing which field is to be read
     * @return UniString representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniString readField(Object aRecordIDObj, int aFieldNumber)
            throws UniFileException {
        synchronized (this) {

            this.setRecordID(aRecordIDObj);

            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            uniRecord = null;

            try {
                outPacket.write(0, UniObjectsTokens.EIC_READV);
                outPacket.write(1, uniFileHandle);
                outPacket.write(2, getReadLock());
                outPacket.write(3, aFieldNumber);
                outPacket.write(4, uniRecordID.getBytes());

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);

                uniReturnCode = inPacket.readInteger(0);
                uniStatus = inPacket.readInteger(1);
                if (uniReturnCode == 0) {
                    Lock();
                    doReadRelease();
                    uniRecord = new UniString(uniParentSession, inPacket
                            .readBytes(2));

                } else {
                    switch (uniReturnCode) {
                    case UniTokens.UVE_EIO: {
                        String msg;
                        switch (uniStatus) {
                        case 1:
                            msg = new String(
                                    "A bad partitioning algorithm exists for this file");
                            break;
                        case 2:
                            msg = new String("No such part file");
                            break;
                        case 3:
                            msg = new String(
                                    "Record ID contains unmappable NLS characters");
                            break;
                        case 4:
                            msg = new String(
                                    "Record data contains unmappable NLS characters");
                            break;
                        default:
                            msg = new String("An IO Error has occured");
                            break;
                        }
                        throw new UniFileException(msg, UniTokens.UVE_EIO);
                    }
                    default:
                        throw new UniFileException(uniReturnCode);
                    }
                }
                return uniRecord;
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    }

    /**
     * reads the specified field from the UniVerse record identified. It uses
     * the record ID established via the <code>aRecordIDObj</code> argument
     * that is passed in. It will return only the field number specified in
     * <code>aFieldNumber</code>. It will set a lock on the record based on
     * the value of <code>aLockFlag</code>
     * 
     * @param aRecordIDObj
     *            record ID to be read from the file
     * @param aFieldNumber
     *            integer representing which field is to be read
     * @param aLockFlag
     *            type of lock to be set on the record
     * @return UniString representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniString readField(Object aRecordIDObj, int aFieldNumber,
            int aLockFlag) throws UniFileException {
        synchronized (this) {
            uniLockFlag = aLockFlag;
            return this.readField(aRecordIDObj, aFieldNumber);
        } // synch this
    }

    /**
     * reads the set of UniVerse records passed in via the UniDataSet object.
     * This UniDataSet object should contain the list of record IDs to be read
     * from this file.
     * 
     * @param aRowSet
     *            list of record IDs to be read from this file
     * @return UniDataSet representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDataSet readField(UniDataSet aRowSet, int aFieldNumber)
            throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            Integer x = new Integer(aFieldNumber);
            String fieldStr = x.toString();

            return fileAction(UniTokens.EIC_READFIELDSET, aRowSet, fieldStr,
                    getReadLock());
        }// synch this
    }

    /**
     * reads the set of UniVerse records passed in via the UniDataSet object.
     * This UniDataSet object should contain the list of record IDs to be read
     * from this file.
     * 
     * @param aRowSet
     *            list of record IDs to be read from this file
     * @return UniDataSet representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDataSet readField(UniDataSet aRowSet, Object aFieldNumber)
            throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            String fieldStr = aFieldNumber.toString();

            return fileAction(UniTokens.EIC_READFIELDSET, aRowSet, fieldStr,
                    getReadLock());
        } // synch this
    }

    /**
     * reads the field identifed by the named field in
     * <code>aFieldNameObj</code>. It does this by extracting the physical
     * field number from the dictionary associated with this file, and then
     * performs a <code>readField</code> on that field. It will use the record
     * ID established via the <code>setRecordID</code> as the record to be
     * read
     * 
     * @param aFieldNameObj
     *            name of the field in the dictionary to use as the field number
     * @return UniString representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniString readNamedField(Object aFieldNameObj)
            throws UniFileException {
        return readNamedField(uniRecordID, aFieldNameObj);
    };

    /**
     * reads the field identifed by the named field in
     * <code>aFieldNameObj</code>. It does this by extracting the physical
     * field number from the dictionary associated with this file, and then
     * performs a <code>readField</code> on that field.
     * 
     * @param aRecordIDObj
     *            record ID to be read
     * @param aFieldNameObj
     *            name of the field in the dictionary to use as the field number
     * @return UniString representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniString readNamedField(Object aRecordIDObj, Object aFieldNameObj)
            throws UniFileException {
        synchronized (this) {
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);
            UniDataSet x = new UniDataSet(uniParentSession);
            x.insert(aRecordIDObj);

            UniDataSet y = readNamedField(x, aFieldNameObj);
            return y.getUniRecord(0).getRecord();
        } // synch this
    }

    /**
     * reads the set of UniVerse records passed in via the UniDataSet object.
     * This UniDataSet object should contain the list of record IDs to be read
     * from this file.
     * 
     * @param aRowSet
     *            list of record IDs to be read from this file
     * @param aFieldNameObj
     *            name of the field in the dictionary to use as the field number
     * @return UniDataSet representing the data read
     * @exception UniFileException
     *                will be thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDataSet readNamedField(UniDataSet aRowSet, Object aFieldNameObj)
            throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            return fileAction(UniTokens.EIC_READNAMEDFIELDSET, aRowSet,
                    aFieldNameObj, getReadLock());
        } // synch this
    }

    /**
     * set the blocking strategy to the value indicated by the
     * <code>aBlock</code> parameter.
     * 
     * @param aBlock
     *            integer representing the blocking strategy to be used
     * @exception UniFileException
     *                is thrown if an invalid blocking strategy is set
     * @see #getBlockingStrategy
     * @since UNIOBJECTS 1.0
     */
    public void setBlockingStrategy(int aBlock) throws UniFileException {
        if ((aBlock < UniObjectsTokens.UVT_WAIT_LOCKED)
                || (aBlock > UniObjectsTokens.UVT_RETURN_LOCKED)) {
            throw new UniFileException(
                    "Blocking strategy must be either UniObjectsTokens.UVT_WAIT_LOCKED(1) or UniObjectsTokens.UVT_RETURN_LOCKED(2)",
                    UniObjectsTokens.UVE_EINVAL);
        }
        uniBlockingStrategy = aBlock;
    };

    /**
     * set the filename to be opened
     * 
     * @param aFileNameObj
     *            name of the UniVerse file to be opened
     * @see #getFileName
     * @since UNIOBJECTS 1.0
     */
    public void setFileName(Object aFileNameObj) {
        uniFileName = new UniString(uniParentSession,aFileNameObj.toString());
    };

    /**
     * set the locking strategy to the value indicated by the <code>aLock</code>
     * parameter.
     * 
     * @param aLock
     *            integer representing the locking strategy to be used
     * @exception UniFileException
     *                is thrown if an invalid blocking strategy is set
     * @see #getLockStrategy
     * @since UNIOBJECTS 1.0
     */
    public void setLockStrategy(int aLock) throws UniFileException {
        if ((aLock < UniObjectsTokens.UVT_NO_LOCKS)
                || (aLock > UniObjectsTokens.UVT_SHARED_READ)) {
            throw new UniFileException(
                    "Locking strategy must be either UniObjectsTokens.UVT_NO_LOCKS(0), UniObjectsTokens.UVT_EXCLUSIVE_UPDATE(1) or UniObjectsTokens.UVT_SHARED_READ(2)",
                    UniObjectsTokens.UVE_EINVAL);
        }

        uniLockStrategy = aLock;
    };

    /**
     * set the data portion of the record, primarily to be used for subsequent
     * <code>write</code> methods.
     * 
     * @param aStringObj
     *            data portion of the record
     * @see #getRecord
     * @see #write
     * @since UNIOBJECTS 1.0
     */
    public void setRecord(Object aStringObj) {
        if (UniString.class.isInstance(aStringObj))
            uniRecord = new UniString((UniString) aStringObj);
        else
            uniRecord = new UniString(uniParentSession, aStringObj);
    };

    /**
     * set the record ID of the record to be read
     * 
     * @param aStringObj
     *            String representing the record ID to be read from the file
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see #getRecordID
     * @since UNIOBJECTS 1.0
     */
    public void setRecordID(Object aStringObj) throws UniFileException {
        // doOnChangeRelease();
        uniRecordID = new UniString(uniParentSession,aStringObj.toString());
    };

    /**
     * set the release strategy to the value indicated by the
     * <code>aRelease</code> parameter.
     * 
     * @param aRelease
     *            integer representing the release strategy to be used
     * @see #getReleaseStrategy
     * @since UNIOBJECTS 1.0
     */
    public void setReleaseStrategy(int aRelease) throws UniFileException {
        if ((aRelease < 0) || (aRelease > 15)) {
            throw new UniFileException(
                    "UniFile.setReleaseStrategy() failed:  Strategy either"
                            + "WRITE_RELEASE (1), READ_RELEASE (2), EXPLICIT_RELEASE (4) or CHANGE_RELEASE (8)",
                    UniObjectsTokens.UVE_EINVAL);
        }
        uniReleaseStrategy = aRelease;
    };

    /**
     * unlocks the file
     * 
     * @exception UniFileException
     *                is thrown if an error is detected
     * @see #lockFile
     * @since UNIOBJECTS 1.0
     */
    public void unlockFile() throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_FILEUNLOCK);
                outPacket.write(1, uniFileHandle);

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);
                uniReturnCode = inPacket.readInteger(0);
                if (uniReturnCode != 0) {
                    uniStatus = inPacket.readInteger(1);
                    throw new UniFileException(uniReturnCode);
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    };

    /**
     * unlocks the recordID established with the <code>setRecordID</code>method.
     * 
     * @exception UniFileException
     *                is thrown if an error is detected
     * @see #setRecordID
     * @since UNIOBJECTS 1.0
     */
    public void unlockRecord() throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);

            this.releaseLock(uniRecordID, UniObjectsTokens.UVT_NORELEASEALL);
        } // synch this
    };

    /**
     * unlocks the recordIDs established with the <code>UniDataSet</code>
     * object argument..
     * 
     * @param aDataSet
     *            UniDataSet denoting which record IDs to lock
     * @exception UniFileException
     *                is thrown if an error is detected
     * @since UNIOBJECTS 1.0
     */
    public void unlockRecord(UniDataSet aDataSet) throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            fileAction(UniTokens.EIC_UNLOCKSET, aDataSet, null, 0);
        } // synch this
    }

    /**
     * unlocks the recordID established with the <code>aRecordIDObj</code>
     * parameter.
     * 
     * @param aRecordIDObj
     *            record id to be unlocked
     * @exception UniFileException
     *                is thrown if an error is detected
     * @see #setRecordID
     * @since UNIOBJECTS 1.0
     */
    public void unlockRecord(Object aRecordIDObj) throws UniFileException {
        synchronized (this) {
            this.setRecordID(aRecordIDObj);
            this.unlockRecord();
        } // synch this
    }

    /**
     * used to write the data specified with the <code>setRecord</code> and
     * <code>setRecordID</code> methods into the file. After completion, the
     * <code>status</code> method can be used to determine the results of the
     * operation. A 0 indicates the record was locked, a -2 indicates it was not
     * locked
     * 
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see #setRecord
     * @see #setRecordID
     * @see asjava.uniobjects.UniBase#status
     * @since UNIOBJECTS 1.0
     */
    public void write() throws UniFileException {
        synchronized (this) {

            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_WRITE);
                outPacket.write(1, uniFileHandle);
                outPacket.write(2, getWriteLock());
                outPacket.write(3, uniRecordID.getBytes());
                outPacket.write(4, uniRecord.getBytes());

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);

                uniReturnCode = inPacket.readInteger(0);
                if (uniReturnCode != 0) {
                    uniStatus = inPacket.readInteger(1);
                    throw new UniFileException(uniReturnCode);
                } else {
                    unLock();
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    }

    /**
     * used to write the data specified with the <code>aRecordIDObj</code> and
     * <code>aRecordDataObj</code> parameters into the file. After completion,
     * the <code>status</code> method can be used to determine the results of
     * the operation. A 0 indicates the record was locked, a -2 indicates it was
     * not locked
     * 
     * @param aRecordIDObj
     *            record ID that is to be written
     * @param aRecordDataObj
     *            record data that is to be written
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see #setRecord
     * @see #setRecordID
     * @see asjava.uniobjects.UniBase#status
     * @since UNIOBJECTS 1.0
     */
    public void write(Object aRecordIDObj, Object aRecordDataObj)
            throws UniFileException {
        synchronized (this) {
            // this.setRecordID( aRecordIDObj );
            uniRecordID = new UniString(uniParentSession,aRecordIDObj.toString());
            if (UniString.class.isInstance(aRecordDataObj))
                uniRecord = new UniString((UniString) aRecordDataObj);
            else
                uniRecord = new UniString(uniParentSession, aRecordDataObj
                        .toString());
            this.write();
        } // synch this
    }

    /**
     * used to write the data specified with the <code>aRecordIDObj</code> and
     * <code>aRecordDataObj</code> parameters into the file. After completion,
     * the <code>status</code> method can be used to determine the results of
     * the operation. A 0 indicates the record was locked, a -2 indicates it was
     * not locked. You can use this version to also specify the kind of locking
     * to be used during the write operation
     * 
     * @param aRecordIDObj
     *            record ID that is to be written
     * @param aRecordDataObj
     *            record data that is to be written
     * @param aLockFlag
     *            type of lock to be set
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see #setRecord
     * @see #setRecordID
     * @see asjava.uniobjects.UniBase#status
     * @since UNIOBJECTS 1.0
     */
    public void write(Object aRecordIDObj, Object aRecordDataObj, int aLockFlag)
            throws UniFileException {
        synchronized (this) {
            uniLockFlag = aLockFlag;
            this.write(aRecordIDObj, aRecordDataObj);
        } // synch this
    }

    /**
     * used to write the data specified with the <code>aDataSet</code>
     * parameters into the file. After completion, the returned UniDataSet
     * object can be used to determine the results of the operation. A 0
     * indicates the record was locked, a -2 indicates it was not locked
     * 
     * @param aDataSet
     *            UniDataSet object representing the data that is to be written
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDataSet write(UniDataSet aDataSet) throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            return fileAction(UniTokens.EIC_WRITESET, aDataSet, null,
                    getWriteLock());
        } // synch this
    }

    /**
     * used to write the data specified with the <code>setRecord</code> and
     * <code>setRecordID</code> methods into the file, but only the field
     * specified. After completion, the <code>status</code> method can be used
     * to determine the results of the operation. A 0 indicates the record was
     * locked, a -2 indicates it was not locked
     * 
     * @param uniFieldNumber
     *            field to be written
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see #setRecord
     * @see #setRecordID
     * @see asjava.uniobjects.UniBase#status
     * @since UNIOBJECTS 1.0
     */
    public void writeField(int uniFieldNumber) throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_WRITEV);
                outPacket.write(1, uniFileHandle);
                outPacket.write(2, getWriteLock());
                outPacket.write(3, uniFieldNumber);
                outPacket.write(4, uniRecordID.getBytes());
                outPacket.write(5, uniRecord.getBytes());

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);

                uniReturnCode = inPacket.readInteger(0);
                if (uniReturnCode != 0) {
                    uniStatus = inPacket.readInteger(1);
                    throw new UniFileException(uniReturnCode);
                } else {
                    unLock();
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    }

    /**
     * used to write the data specified with the <code>aDataSet</code>
     * parameters into the file. After completion, the returned UniDataSet
     * object can be used to determine the results of the operation. A 0
     * indicates the record was locked, a -2 indicates it was not locked
     * 
     * @param aDataSet
     *            UniDataSet object representing the data that is to be written
     * @param uniFieldNumber
     *            field to be written
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDataSet writeField(UniDataSet aDataSet, int uniFieldNumber)
            throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            Integer x = new Integer(uniFieldNumber);
            String fieldStr = x.toString();

            return fileAction(UniTokens.EIC_WRITEFIELDSET, aDataSet, fieldStr,
                    getWriteLock());
        } // synch this
    }

    /**
     * used to write the data specified with the <code>aDataSet</code>
     * parameters into the file. After completion, the returned UniDataSet
     * object can be used to determine the results of the operation. A 0
     * indicates the record was locked, a -2 indicates it was not locked
     * 
     * @param aDataSet
     *            UniDataSet object representing the data that is to be written
     * @param uniFieldName
     *            field to be written
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDataSet writeField(UniDataSet aDataSet, Object uniFieldName)
            throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);
            String fieldNum = uniFieldName.toString();
            return fileAction(UniTokens.EIC_WRITEFIELDSET, aDataSet, fieldNum,
                    getWriteLock());
        } // synch this
    }

    /**
     * used to write the data specified with the <code>aRecordIDObj</code> and
     * <code>aRecordDataObj</code> parameters into the file, but only the
     * field specified. After completion, the <code>status</code> method can
     * be used to determine the results of the operation. A 0 indicates the
     * record was locked, a -2 indicates it was not locked
     * 
     * @param aRecordIDObj
     *            record ID to be written
     * @param aRecordDataObj
     *            data to be written
     * @param aFieldNumber
     *            field within the record to be written
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see asjava.uniobjects.UniBase#status
     * @since UNIOBJECTS 1.0
     */
    public void writeField(Object aRecordIDObj, Object aRecordDataObj,
            int aFieldNumber) throws UniFileException {
        synchronized (this) {
            this.setRecordID(aRecordIDObj);
            if (UniString.class.isInstance(aRecordDataObj))
                uniRecord = new UniString((UniString) aRecordDataObj);
            else
                uniRecord = new UniString(uniParentSession, aRecordDataObj
                        .toString());
            this.writeField(aFieldNumber);
        } // synch this
    }

    /**
     * used to write the data specified with the <code>aRecordIDObj</code> and
     * <code>aRecordDataObj</code> parameters into the file, but only the
     * field specified. After completion, the <code>status</code> method can
     * be used to determine the results of the operation. A 0 indicates the
     * record was locked, a -2 indicates it was not locked. You can also specify
     * the specific locking to be used via the aLockFlag parameter
     * 
     * @param aRecordIDObj
     *            record ID to be written
     * @param aRecordDataObj
     *            data to be written
     * @param aFieldNumber
     *            field within the record to be written
     * @param aLockFlag
     *            integer representing the type of lock to be set.
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see asjava.uniobjects.UniBase#status
     * @since UNIOBJECTS 1.0
     */
    public void writeField(Object aRecordIDObj, Object aRecordDataObj,
            int aFieldNumber, int aLockFlag) throws UniFileException {
        synchronized (this) {
            uniLockFlag = aLockFlag;
            this.writeField(aRecordIDObj, aRecordDataObj, aFieldNumber);
        } // synch this
    }

    /**
     * used to write the data specified with the <code>aRecordIDObj</code> and
     * <code>aRecordDataObj</code> parameters into the file, but only the name
     * field specified. The Named Field is extracted from the files Dictionary.
     * After completion, the <code>status</code> method can be used to
     * determine the results of the operation. A 0 indicates the record was
     * locked, a -2 indicates it was not locked
     * 
     * @param aFieldName
     *            name of the field that is to be written
     * @param aString
     *            data to be written to that field
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see asjava.uniobjects.UniBase#status
     * @since UNIOBJECTS 1.0
     */
    public void writeNamedField(Object aFieldName, Object aString)
            throws UniFileException {
        synchronized (this) {
            writeNamedField(uniRecord, aFieldName, aString);
        }
    };

    /**
     * used to write the data specified with the <code>aRecordID</code> and
     * <code>aRecordDataObj</code> parameters into the file, but only the name
     * field specified. The Named Field is extracted from the files Dictionary.
     * After completion, the <code>status</code> method can be used to
     * determine the results of the operation. A 0 indicates the record was
     * locked, a -2 indicates it was not locked
     * 
     * @param aRecordID
     *            record ID that is to be written
     * @param aFieldName
     *            name of the field that is to be written
     * @param aString
     *            data to be written to that field
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see asjava.uniobjects.UniBase#status
     * @since UNIOBJECTS 1.0
     */
    public void writeNamedField(Object aRecordID, Object aFieldName,
            Object aString) throws UniFileException {
        synchronized (this) {
            checkEntryConditions(THROW_EXCEPTION, CHECK_RECORD);
            UniDataSet x = new UniDataSet(uniParentSession);
            x.insert(aRecordID, aString);
            UniDataSet y = writeNamedField(x, aFieldName);

        } // synch this
    }

    /**
     * used to write the data specified with the <code>aDataSet</code>
     * parameters into the file. After completion, the returned UniDataSet
     * object can be used to determine the results of the operation. A 0
     * indicates the record was locked, a -2 indicates it was not locked
     * 
     * @param aDataSet
     *            UniDataSet object representing the data that is to be written
     * @param aFieldName
     *            field to be written
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    public UniDataSet writeNamedField(UniDataSet aDataSet, Object aFieldName)
            throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(THROW_EXCEPTION, NO_RECORD);

            return fileAction(UniTokens.EIC_WRITENAMEDFIELDSET, aDataSet,
                    aFieldName, getWriteLock());
        } // synch this
    }

    /* Private methods */
    private int convertField(Object aFieldNameObj, Object aFieldDataObj)
            throws UniFileException {
        UniString convRecord = null;
        UniDictionary unid = null;
        String dictName = null;
        int fieldNumber = 0;

        if (uniDictFlag == UniObjectsTokens.UVT_DICT) // This file is, in
                                                        // fact, a dictionary
        {
            dictName = UniObjectsTokens.UVT_DICT_DICT_FILE;
            unid = new UniDictionary(uniParentSession,
                    UniObjectsTokens.UVT_DICT_DICT_FILE,
                    UniObjectsTokens.UVT_DATA);
        } else {
            dictName = uniFileName.toString();
            unid = new UniDictionary(uniParentSession, uniFileName,
                    UniObjectsTokens.UVT_DICT);
        }

        // Read the dictionary record
        UniString uniDictRecord = unid.read(aFieldNameObj,
                UniObjectsTokens.IK_READ);
        unid.close();

        // Put record into dynamic array form
        UniDynArray uniDictEntry = new UniDynArray(uniDictRecord);
        UniDynArray uniDictType = uniDictEntry
                .extract(UniObjectsTokens.UVT_TYPE_INDEX);
        switch (uniDictType.toString().charAt(0)) {
        case 'D':
        case 'd':
            break;
        default:
            throw new UniFileException(UniObjectsTokens.UVE_INVALID_DATAFIELD);
        }

        // Ok, we have a valid type of dictionary entry (D type). Let's get the
        // conversion to be applied
        UniDynArray uniDictConv = uniDictEntry
                .extract(UniObjectsTokens.UVT_CONV_INDEX);

        // Apply the conversion to the string
        try {
            convRecord = uniParentSession.iconv(aFieldDataObj, uniDictConv);
        } catch (UniStringException e) {
            throw new UniFileException(UniObjectsTokens.UVE_BAD_CONVERSION_DATA);
        }

        // Ok, we now have valid data, let's figure out where to put it.
        UniDynArray uniDictLoc = uniDictEntry
                .extract(UniObjectsTokens.UVT_LOC_INDEX);
        // Let's check whether or not we have a numeric value

        try {
            // if this succeeds, we have a valid entry
            Integer tmpField = new Integer(uniDictLoc.toString());
            fieldNumber = tmpField.intValue();
        } catch (NumberFormatException e) {
            throw new UniFileException(
                    UniObjectsTokens.UVE_BAD_DICTIONARY_ENTRY);
        }

        // Ok, now we have a proper field number and a properly converted data
        // string...
        uniRecord = convRecord;

        return fieldNumber;
    }

    /**
     * checks to see whether the given record should be released after being
     * changed
     * 
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see #setRecord
     * @since UNIOBJECTS 1.0
     */
    private void doOnChangeRelease() throws UniFileException {
        if ((uniReleaseStrategy & UniObjectsTokens.UVT_CHANGE_RELEASE) != 0)
            singleRelease();
    }

    /**
     * checks to see whether the given record should be released after being
     * read
     * 
     * @exception UniFileException
     *                is thrown if an error occurs
     * @see #read
     * @since UNIOBJECTS 1.0
     */
    private void doReadRelease() throws UniFileException {
        if ((uniReleaseStrategy & UniObjectsTokens.UVT_READ_RELEASE) != 0)
            singleRelease();
    };

    /**
     * returns the appropriate lock type, given the current locking parameters
     * 
     * @return lock type to be used for this operation
     * @see #deleteRecord
     * @since UNIOBJECTS 1.0
     */
    private int getDeleteLock() {
        int lockType = UniObjectsTokens.IK_DELETE;

        if ((uniReleaseStrategy & UniObjectsTokens.UVT_WRITE_RELEASE) == 0) {
            lockType = UniObjectsTokens.IK_DELETEU;
        }

        if (uniBlockingStrategy == UniObjectsTokens.UVT_WAIT_LOCKED)
            lockType += UniObjectsTokens.IK_WAIT;

        return lockType;
    }

    /**
     * returns the appropriate lock type, given the current locking parameters
     * 
     * @return lock type to be used for this operation
     * @see #read
     * @since UNIOBJECTS 1.0
     */
    private int getReadLock() {
        int lockType = UniObjectsTokens.IK_READ;

        switch (uniLockStrategy) {
        case UniObjectsTokens.UVT_SHARED_READ:
            lockType = UniObjectsTokens.IK_READL;
            break;
        case UniObjectsTokens.UVT_EXCLUSIVE_READ:
            lockType = UniObjectsTokens.IK_READU;
            break;
        default:
            // no locks
            break;
        }

        if (uniBlockingStrategy == UniObjectsTokens.UVT_WAIT_LOCKED)
            lockType += UniObjectsTokens.IK_WAIT;

        return lockType;
    }

    /**
     * returns the appropriate lock type, given the current locking parameters
     * 
     * @return lock type to be used for this operation
     * @see #write
     * @since UNIOBJECTS 1.0
     */
    private int getWriteLock() {
        int lockType = UniObjectsTokens.IK_WRITE;

        if ((uniReleaseStrategy & UniObjectsTokens.UVT_WRITE_RELEASE) != 0) {
            lockType = UniObjectsTokens.IK_WRITE;
        } else {
            lockType = UniObjectsTokens.IK_WRITEU;
        }

        if (uniBlockingStrategy == UniObjectsTokens.UVT_WAIT_LOCKED)
            lockType += UniObjectsTokens.IK_WAIT;

        return lockType;
    }

    /**
     * increments the current lock count by one, if locking is set on
     * 
     * @return lock type to be used for this operation
     * @see #deleteRecord
     * @since UNIOBJECTS 1.0
     */
    private void Lock() {
        if (uniLockStrategy != UniObjectsTokens.UVT_NO_LOCKS) {
            uniLockCount += 1;
        }
    }

    /**
     * unlocks the recordID established with the <code>setRecordID</code>method.
     * 
     * @param aRecordIDObj
     *            record ID to be unlocked
     * @param aClearFlag
     *            integer representing whether or not to clear all the records
     * @exception UniFileException
     *                is thrown if an error is detected
     * @see #setRecordID
     * @since UNIOBJECTS 1.0
     */
    private void releaseLock(Object aRecordIDObj, int aClearFlag)
            throws UniFileException {
        synchronized (this) {
            // Check for Errors
            checkEntryConditions(true, false);

            try {
                outPacket.write(0, UniObjectsTokens.EIC_RELEASE);
                outPacket.write(1, uniFileHandle);
                outPacket.write(2, aClearFlag);
                outPacket.write(3, encode(aRecordIDObj.toString()));

                uniConnection.call(outPacket, inPacket,
                        (byte) uniEncryptionType);
                uniReturnCode = inPacket.readInteger(0);
                if (uniReturnCode != 0) {
                    throw new UniFileException(uniReturnCode);
                }
            } catch (UniException e) {
                uniParentSession.setRPCError(true);
                throw new UniFileException(e.getErrorCode());
            }
        } // synch this
    }

    /**
     * releases a single record
     * 
     * @exception UniFileException
     *                is thrown if an error occurs
     * @since UNIOBJECTS 1.0
     */
    private void singleRelease() throws UniFileException {
        releaseLock(uniRecordID, UniObjectsTokens.UVT_NORELEASEALL);
    }

    /**
     * reduces the current number of locks held counter
     * 
     * @since UNIOBJECTS 1.0
     */
    private void unLock() {
        if (uniLockStrategy != UniObjectsTokens.UVT_NO_LOCKS) {
            uniLockCount--;
            if (uniLockCount < 0)
                uniLockCount = 0;
        }
    }

    protected UniDataSet fileAction(int actionRequested, UniDataSet dataSet,
            Object fieldList, int lockType) throws UniFileException {
        // Used to determine whether we are talking to an old server or new
        // server
        int serverVersion = uniParentSession.getServerVersion();
        // int serverVersion = UniObjectsTokens.OLD_SERVER;
        try {
            switch (serverVersion) {
            // With an old server, we need to emulate the functionality by
            // manually
            // extracting data from the dataset, issuing single commands, and
            // filling
            // in the new dataset.
            case UniObjectsTokens.OLD_SERVER: // old server
                int numItems = dataSet.getRowCount();

                byte delimiter = uniParentSession.getMarkByte(UniTokens.IM);
                UniByteArrayTokenizer idSet = new UniByteArrayTokenizer(dataSet
                        .getIDSetUniDynArray().getBytes(), delimiter);
                UniByteArrayTokenizer recSet = new UniByteArrayTokenizer(
                        dataSet.getDataSetUniDynArray().getBytes(), delimiter);
                UniDataSet returnSet = new UniDataSet(uniParentSession);

                for (int i = 0; i < numItems; i++) {
                    UniString recID = new UniString(uniParentSession, idSet
                            .nextToken());
                    UniString recVal = new UniString(uniParentSession, recSet
                            .nextToken());

                    switch (actionRequested) {
                    case UniTokens.EIC_READSET:
                        try {
                            UniString dataVal = this.read(recID);
                            UniRecord resultRec = new UniRecord(recID, dataVal,
                                    uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        } catch (UniException e) {
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        }
                        break;
                    case UniTokens.EIC_READFIELDSET:
                        try {
                            UniDynArray fieldArray = new UniDynArray(
                                    uniParentSession, fieldList);
                            UniDynArray fieldOne = fieldArray.extract(1);
                            int fieldNum = Integer
                                    .parseInt(fieldOne.toString());

                            UniString dataVal = this.readField(recID, fieldNum);
                            UniRecord resultRec = new UniRecord(recID, dataVal,
                                    uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        } catch (UniException e) {
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        }
                        break;
                    case UniTokens.EIC_READNAMEDFIELDSET:
                        try {
                            UniString dataVal = this.readNamedField(recID,
                                    fieldList);
                            UniRecord resultRec = new UniRecord(recID, dataVal,
                                    uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        } catch (UniException e) {
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        }
                        break;
                    case UniTokens.EIC_WRITESET:
                        try {
                            this.write(recID, recVal);
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        } catch (UniException e) {
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        }
                        break;
                    case UniTokens.EIC_WRITEFIELDSET:
                        try {
                            UniDynArray fieldArray = new UniDynArray(
                                    uniParentSession, fieldList);
                            UniDynArray fieldOne = fieldArray.extract(1);
                            int fieldNum = Integer
                                    .parseInt(fieldOne.toString());

                            this.writeField(recID, recVal, fieldNum);
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        } catch (UniException e) {
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        }
                        break;
                    case UniTokens.EIC_WRITENAMEDFIELDSET:
                        try {
                            this.writeNamedField(recID, recVal, fieldList);
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        } catch (UniException e) {
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        }
                        break;
                    case UniTokens.EIC_LOCKSET:
                        try {
                            this.lockRecord(recID, lockType);
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        } catch (UniException e) {
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        }
                        break;
                    case UniTokens.EIC_UNLOCKSET:
                        try {
                            this.unlockRecord(recID);
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        } catch (UniException e) {
                            UniRecord resultRec = new UniRecord(recID,
                                    new UniString(uniParentSession), uniStatus);
                            resultRec.setReturnCode(uniReturnCode);
                            returnSet.append(resultRec);
                        }
                        break;
                    default:
                        throw new UniFileException(UniObjectsTokens.UVE_USC);
                    }
                }
                return returnSet;
            case UniObjectsTokens.NEW_SERVER:
            default:// new server
                return serverRequest(actionRequested, dataSet, fieldList,
                        lockType);
            }
        } catch (UniException e) {
            uniParentSession.setRPCError(true);
            throw new UniFileException(e.getErrorCode());
        }
    }

    /**
     * This private method is to actually contact the server to perform the request.  The format
     * of the packet is, essentially:
     * <ul>
     * <li> serverRequest
     * <li> fileHandle
     * <li> lockType
     * <li> data ids to be operated on
     * <li> data to be operated on
     * <li> if required, the list of field designations.
     * </ul>
     * 
     * Additionally, the return packet will look like:
     * <ul>
     * <li> returnCode
     * <li> statusCode
     * <li> for read operations, the data returned
     * </ul>
     * 
     */
     private UniDataSet serverRequest(int serverRequestVal, UniDataSet dataSet,
            Object fieldStr, int lockType) throws UniException {
        // write out the common header information
        outPacket.write(0, serverRequestVal);
        outPacket.write(1, uniFileHandle);
        outPacket.write(2, lockType);
        outPacket.write(3, dataSet.getIDSetUniDynArray().getBytes());
        outPacket.write(4, dataSet.getDataSetUniDynArray().getBytes());

        if (fieldStr != null)
            outPacket.write(5, getByteValue(fieldStr));

        // contact the server
        uniConnection.call(outPacket, inPacket, (byte) getEncryptionType());

        // first value is the overall status of the operation.
        int uniReturnCode = inPacket.readInteger(0);

        // get the common return data
        UniDynArray uniReturnSet = new UniDynArray(uniParentSession, inPacket
                .readBytes(1));
        UniDynArray uniStatus = new UniDynArray(uniParentSession, inPacket
                .readBytes(2));

        UniDynArray returnDataSet;

        // if necessary, get the return data set
        if ((serverRequestVal == UniTokens.EIC_READSET)
                || (serverRequestVal == UniTokens.EIC_READFIELDSET)
                || (serverRequestVal == UniTokens.EIC_READNAMEDFIELDSET)) {
            returnDataSet = new UniDynArray(uniParentSession, inPacket
                    .readBytes(3));

        } else {
            returnDataSet = new UniDynArray(uniParentSession);
        }

        return new UniDataSet(dataSet, returnDataSet, uniReturnSet, uniStatus,
                uniReturnCode);
    }
     
 	private byte[] getByteValue(Object aString) {
 		if (aString instanceof byte[])
             return (byte[])aString;
         else if (aString instanceof UniString)
         	return ((UniString)aString).getBytes();
         else {
             String insertString = aString.toString();
             // Deal with boundary conditions
             if (insertString.equals(""))
                 return null;
             return encode(insertString);
         }
 	}
 	
    /**
     * checks entry conditions to make sure we can perform this operation
     * checks to make sure that the file is open, that we are not within
     * an active UniCommand.exec() state, etc...
     *
     * @exception UniFileException is thrown if entry conditions not met
     * @since UNIOBJECT 1.0
     */
    private void checkEntryConditions(boolean shouldThrow,
            boolean checkForRecord) throws UniFileException {
        if (!isOpen()) {
            // Only denote an error if not from open()
            if (shouldThrow) {
                uniStatus = -1;
                throw new UniFileException(UniObjectsTokens.UVE_FILE_NOT_OPEN,
                        uniFileName.toString());
            }
        }

        // Check to ensure that a UniCommand execution is not active
        if (isCommandActive()) {
            throw new UniFileException(UniObjectsTokens.UVE_EXECUTEISACTIVE);
        }

        if (checkForRecord) {
            // Must specify a record to be had.
            if ((uniRecordID == null) || uniRecordID.equals(""))
                throw new UniFileException(
                        UniObjectsTokens.UVE_NONNULL_RECORDID);
        }

        // Reset status to 0 before command is issued.
        uniStatus = 0;
    }

    /* Private class variables */
    protected int uniFileHandle = 0;

    private static final boolean THROW_EXCEPTION = true;

    private static final boolean NO_EXCEPTION = false;

    private static final boolean CHECK_RECORD = true;

    private static final boolean NO_RECORD = false;

    private UniString uniFileName;

    private UniString uniRecordID;

    private UniString uniRecord;

    private int uniFieldNumber = 0;

    private int uniLockFlag = 0;

    private int uniDictFlag = 0;

    private int uniFileType = 0;

    private int uniReturnCode = 0;

    private int uniLockCount = 0;

    private int uniReleaseStrategy = 0;

    private int uniLockStrategy = 0;

    private int uniBlockingStrategy = 0;

    private boolean isFileOpen = false;
}
