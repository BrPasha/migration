/*************************************************************************
 *
 * UniNLSmap.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 02/16/07 35954 JFM add workaround to set the correct marks when UV server NLS map is set to "NONE"
 * 01/12/07 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 11/18/04 e32565 RKK Connection Pooling
 * 10/14/02 2607,2609,2984 RKK NLS Stuff
 * 05/05/99 24995 DTM Made code more thread safe	
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniobjects;

import asjava.unirpc.UniRPCException;
import asjava.unirpc.UniRPCPacket;
import asjava.unirpc.UniRPCPacketException;

/**
 * <code>UniNLSmap</code> is used to control the NLS map settings.  It is only available
 * if NLS is enabled on the server uniConnection.  
 * 
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since	UNIOBJECTS 1.0
 */
public class UniNLSmap extends UniBase {
    UniNLSmap() throws UniNLSException {
        throw new UniNLSException(UniObjectsTokens.UVE_MUST_USE_SESSION);
    }

    /**
     * default constructor for this class. If NLS is not enabled on the server 
     * system, a <code>null</code> will be returned.
     *
     * @since UNIOBJECTS 1.0
     */
    UniNLSmap(UniSession aSession) {
        synchronized (this) {
            uniParentSession = aSession;
            uniConnection = uniParentSession.connection;
            nlsMarkChars = new String[UniObjectsTokens.NUMICMARKS];
            nlsMarkBytes = new byte[UniObjectsTokens.NUMICMARKS];
            inPacket = null;
            outPacket = null;
            clientName = null;
        } // synch this
    };

    /**
     * sets the specified map. If <code>aName</code>
     * 
     * @param aName
     *            New NLS map name to be set for this client/server relationship
     * @exception UniNLSException
     *                is thrown if an error occurs
     * @see #getClientNames
     * @see #getServerNames
     * @since UNIOBJECTS 1.0
     */
    public void setName(Object aName) throws UniNLSException {
        synchronized (this) {

            String nameVal = aName.toString();
            clientName = nameVal;

            // Check for errors
            checkEntryConditions();

            try {
                outPacket.write(0, UniObjectsTokens.EIC_SETMAP);
                outPacket.write(1, encode(nameVal));

                uniConnection.call(outPacket, inPacket);
                int uniReturnCode = inPacket.readInteger(0);
                if (uniReturnCode != 0) {
                    throw new UniNLSException(uniReturnCode);
                } else {
                    // Not sure what to do with the status return code at this point...
                    uniStatus = inPacket.readInteger(1);

                    // Get mark characters
                    for (int i = 0; i < UniObjectsTokens.NUMICMARKS; i++) {
                        nlsMarkChars[UniObjectsTokens.NUMICMARKS - i - 1]
                                     =uniParentSession.decode(inPacket.readBytes(2+i));
                    }

                    for (int i = 0; i < UniObjectsTokens.NUMICMARKS; i++) {
                        nlsMarkBytes[UniObjectsTokens.NUMICMARKS - i - 1] = inPacket
                                .readBytes(2 + i)[0];
                    }

                    /* hack, to workaround a server problem */
                    if (nlsMarkBytes[0] == (byte)255 && nlsMarkBytes[1] == (byte)255) {
                        int i;
                        for (i = 0; i < UniObjectsTokens.NUMICMARKS-1;i++)
                            nlsMarkBytes[i] = (byte)(255 - i);
                        nlsMarkBytes[i]=(byte)128;
                        
                    }
                    // set back to session object
                    uniParentSession.setMarks(nlsMarkChars);
                    uniParentSession.setByteMarks(nlsMarkBytes);

                }
            } catch (UniRPCException e) {
                uniParentSession.setRPCError(true);
                throw new UniNLSException(e.getErrorCode());
            }
        } // synch this
    };

    /**
     * returns the client representation of the map name.  This is the same name that
     * was used to establish the NLS Map from the application perspective, via the
     * <code>setName</code> method.
     * 
     * @return String representing client side map name
     * @see #getServerNames
     * @see #setName
     * @since UNIOBJECTS 1.0
     */
    public String getClientNames() {
        return clientName;
    };

    /**
     * returns the server representation of the map name.  This value may differ from 
     * the name that was requested via the <code>setName</code> method.  This is due to
     * a client-server NLS Map name mapping that is done.
     * 
     * @return String representing server side map name
     * @exception UniNLSException is thrown if an error occurs
     * @see #getClientNames
     * @see #setName
     * @since UNIOBJECTS 1.0
     */
    public String getServerNames() throws UniNLSException {
        synchronized (this) {

            // Check for errors
            checkEntryConditions();

            try {
                outPacket.write(0, UniObjectsTokens.EIC_GETMAP);

                uniConnection.call(outPacket, inPacket);
                int uniReturnCode = inPacket.readInteger(0);
                if (uniReturnCode != 0) {
                    throw new UniNLSException(uniReturnCode);
                } else { // Get server name
                    return uniParentSession.decode(inPacket.readBytes(1));
                }
            } catch (UniRPCException e) {
                uniParentSession.setRPCError(true);
                throw new UniNLSException(e.getErrorCode());
            }
        } // synch this
    };

    /**
     * returns the requested mark character.  This may change from the default values
     * depending on the map that was established.
     *
     * @return String representing the requested mark character
     * @exception UniNLSException is thrown if an error occurs
     * @since #UNIOBJECTS 1.0
     */
    public String getMarkCharacter(int aTokenVal) throws UniNLSException {
        synchronized (this) {

            // Check to ensure token value within proper range
            if ((aTokenVal < UniObjectsTokens.IK_MARK_MIN)
                    || (aTokenVal > UniObjectsTokens.IK_MARK_MAX)) {
                throw new UniNLSException(UniObjectsTokens.UVE_EINVAL);
            }

            // Return the requested mark character
            return nlsMarkChars[aTokenVal];
        } // synch this
    }

    private void checkEntryConditions() throws UniNLSException {
        // Check to ensure that a UniCommand execution is not active
        if (isCommandActive()) {
            throw new UniNLSException(UniObjectsTokens.UVE_EXECUTEISACTIVE);
        }

        // Make sure we have inPacket and outPacket set up
        if (inPacket == null) {
            try {
                outPacket = new UniRPCPacket(uniConnection);
                inPacket = new UniRPCPacket(uniConnection);
                uniStatus = 0;
            } catch (UniRPCPacketException e) {
                throw new UniNLSException(e.getErrorCode());
            }
        }
    }

    /* Private class variables */
    private String[] nlsMarkChars;

    private byte[] nlsMarkBytes;

    private String clientName;
}
