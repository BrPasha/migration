/*************************************************************************
 * UniJava.java
 *
 * IBM Confidential
 * OCO Source Materials
 * Copyright (C) IBM Corp.  1998, 2008
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 08/16/10 UNV-697 JFM allow minpoolsize to be 0
 * 06/03/08       JFM bump the version to 4.1.3
 * 02/01/08 36962 JFM initialize uniSessionsVector to prevent nullptr exception
 * 12/11/07 10149 JFM  use the right name for IdleRemoveExecInterval property
 * 08/08/07       JFM bump the version to 4.1.1
 * 08/08/07 36441 JFM fix the CP tracing issue
 * 01/12/07 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support) bump the version number
 * 07/07/06       JFM bump the verison number
 * 08/24/05 e7815,33964 JFM bump the verison number
 * 08/03/05 e33985 JFM make Timer a daemon thread so that it won't prolong
 *                     the application life after the app exits
 *                     also set the default maxPoolSize = 10
 * 06/22/05 E33849 RKK Implement get/set method for poolingOpenSessionTimeout.  
 * 01/18/05 e33134 RKK MinSize and MaxSize for per Application.
 * 12/16/04 e32565 JFM changed openSession()s to not append unisessionVector
 *                     when uoPooling is true
 * 12/14/04 e32565 JFM change some synchronized usage
 * 12/13/04 e32565 JFM replaced added opensession()s with openPooledSession,
 *                 UniSession.connect(). modified closeServerConnection(), 
 *                 setUOPooling(), setPoolingDebug(), etc.
 * 11/18/04 e32565 RKK Connection Pooling
 * 09/10/04 WMY bump version to 2.0.4 for UniXML class.
 * 12/05/03 E3912 JFM bump version to 2.0.3 for GB18030 fix  
 * 11/13/02 E2984, E2732 NLS/readNamedField.. fixes/ bump version to 2.0.1  
 * 02/12/01 PTS146450 JFM fix closeSession()  
 * 05/05/99 24995 DTM Bumped up version number to 1.1, made code synch.
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniobjects;


import asjava.uniclientlibs.*;
import java.io.*;
import java.util.*;
import asjava.unirpc.*;




/**
 * <code>UniJava</code> is the base class for the UniObjects for Java product.  Its primary
 * purpose is object marshalling and enumeration, as well as instantiation of all
 * <code>UniSession</code> objects.  One <code>UniJava</code> object MUST be created by every 
 * application that uses this API.  
 * 
 * @author	David T. Meeks
 * @version	Version 1.0
 * @since		UNIOBJECTS 1.0
 */
public class UniJava 
{
	/**
	 * Constructs a <code>UniJava</code> object.
	 *
	 * @since UNIOBJECTS 1.0
	 */
	
	public UniJava()
	{
		synchronized ( UniJava.class ) {
			
			//	Only need to initialize once
			if (uniJavaIsActive > 0) {
				uniJavaIsActive++;
				return;
			}
			// Otherwise, set things up
			uniJavaIsActive = 1;
			uniSessionsVector = new Vector();
			uniNumSessions = 0;
			uojProperties = new UniProperties();
			readUOJProperties();
		}
	};
	
	/**
	 * sets Debug Level for trace.
	 * @param debug boolean representing debug level.ON=true,OFF=false
	 */
	public static synchronized void setPoolingDebug(boolean debug) {
		if (!UniJava.getUOPooling())
			return;
		
		UniJava.uniPoolingDebug = debug;
		if (debug == false) {
			if (uniPW != null) uniPW.close();
			uniPW = null;
			return;
		}
		if (debug == true && uniPW == null) {
			try {
				uniPW = new java.io.PrintWriter(new java.io.FileWriter("uoj_trace.log"));
			}
			catch (IOException e) 
			{
			}
		}			
	}
	
	/**
	 * This fucntion is used to write trace log related with info
	 * @param message String representing message contents
	 */
	protected static  void uniLog(String message) {
		
		if (uniPoolingDebug && uniPW != null) 
		{ 
			uniPW.println(Thread.currentThread().toString() + " " + message);
			uniPW.flush();
		}
		
	}
	
	
	/**
	 * This method will close all open sessions by going through the uniSessionsVector list
	 * and calling the <code>UniSession.disconnect()</code> method for each individual session.  It will
	 * then eliminate all entries from the uniSessionsVector.
	 *
	 * @exception UniSessionException is thrown if an error occurs
	 * @see   #closeSession
	 * @since UNIOBJECTS 1.0
	 */	
	public void  closeAllSessions() throws UniRPCConnectionException,UniSessionException
	{
		synchronized ( UniJava.class ) {
			
			if(uoPooling == true)
			{
				// get enumerator
				Enumeration lEnumerator = poolList.elements();
				while ( lEnumerator.hasMoreElements() )
				{
					UniPool lPool = (UniPool)lEnumerator.nextElement();
					lPool.closeAllConnections();
				}
				poolList.clear();
				poolListMinSize.clear();
				poolListMaxSize.clear();
				poolListThreshold.clear();
				poolListInterval.clear();
				uniLog("In UniJava::closeAllSessions()");
				if(timer != null){
					timer.cancel();	
				}
				uniPW = null;
			}
		
			/* Go through list of open sessions and call the disconnect method for each*/
			for ( Enumeration e = uniSessionsVector.elements(); e.hasMoreElements(); )
			{
				UniSession unis = (UniSession)e.nextElement();
				unis.disconnectServer();
				uniLog("calling UniJava::closeAllSessions() and us.disconnectServer and pooling is off");
			}
			/* Let's just make sure the number of open sessions is reset to 0 */
			uniSessionsVector.removeAllElements();
			uniNumSessions = 0;
			
		}
	}
	
	public static synchronized void closeAllCPSessions() throws UniRPCConnectionException,UniSessionException
	{
		if(uoPooling == true)
		{
			// get enumerator
			Enumeration lEnumerator = poolList.elements();
			while ( lEnumerator.hasMoreElements() )
			{
				UniPool lPool = (UniPool)lEnumerator.nextElement();
				lPool.closeAllConnections();
				
			}
			poolList.clear();
			poolListMinSize.clear();
			poolListMaxSize.clear();
			poolListThreshold.clear();
			poolListInterval.clear();
			uniLog("In UniJava::closeAllCPSessions()");
			if(timer != null){
				timer.cancel();	
			}
			uniPW = null;
			
		}
	}
	
	/**
	 * This method will close the session passed into it.  It will do this by calling the 
	 * <code>UniSession.disconnect()</code> method, allowing the session to properly close.  
	 * It will also remove the entry from the uniSessionsVector.
	 *
	 * @param aSession	the UniSession object that should be closed
	 * @exception UniSessionException is thrown if an error occurs
	 * @see #closeAllSessions
	 * @since UNIOBJECTS 1.0
	 **/
	public void closeSession( UniSession aSession ) throws UniSessionException
	{
		closeSessionInternal(aSession);
	}
	
	protected static void closeSessionInternal(UniSession aSession) throws UniSessionException
	{
		UniPool lPool = null;
		if (aSession == null) return;
		if (!aSession.isActive()) return;
		
		
		if (aSession.getPooledSession() == false) {
			aSession.disconnectServer();
			uniLog("In  UniJava::closeSessionInternal UniJava::closeSession() and us.disconnectServer and getpooledSession is false");
			synchronized ( UniJava.class ) {
				
				uniSessionsVector.removeElement(aSession);
				uniNumSessions--;
				
				if (uniNumSessions < 0)
					uniNumSessions = 0;
			}
			return;
			
		}
		
		synchronized ( UniJava.class ) {
			uniLog("In  UniJava::closeSessionInternal UniJava::closeSession() and UniPool.free()");
			String lKey = aSession.getHostName() + aSession.getUserName()
			+ aSession.getPassword() + aSession.getAccountPath();
			lPool = (UniPool) poolList.get(lKey);
			if (lPool == null) {
				return;
			}
		} 
		
		lPool.free(aSession);
	}
	
	
	/**
	 * The maximum number of open sessions that can be open. If a 0 is returned,
	 * there is no set limit.
	 * 
	 * @return the maximum number of open sessions, or a 0 for unlimited session
	 *         support
	 * @since UNIOBJECTS 1.0
	 */	 	
	public int getMaxSessions()				{ return uniMaxSessions; }
	
	/**
	 * The current number of open sessions that are open.  
	 *
	 * @return the current number of open sessions
	 * @since UNIOBJECTS 1.0
	 **/
	public int getNumSessions()				{ return uniNumSessions; }
	
	/**
	 * The current version number 
	 *
	 * @return the current version number
	 * @since UNIOBJECTS 1.0
	 **/
	public String getVersionNumber()	{ return uniJavaVersionNumber; }
	
	/**
	 * Instantiates a new <code>UniSession</code> object.  It also stores the reference into
	 * the uniSessionsVector. If an error occurs, it throws a <code>UniSessionException</code>
	 *
	 * @return a UniSession object
	 * @exception UniSessionException if it encounters an error during creation.
	 * @since UNIOBJECTS 1.0
	 **/
	public UniSession openSession() throws UniSessionException
	{
		synchronized ( UniJava.class ) {
			
			if (( uniNumSessions == uniMaxSessions ) && ( uniMaxSessions != 0 ))
			{
				throw new UniSessionException( UniObjectsTokens.UVE_OPENSESSION_ERR );
			}
			uniNumSessions++;
			UniSession unis = new UniSession();
			if (!uoPooling)
				uniSessionsVector.addElement( unis );
			return unis;
		}
	}
	
	
	/**
	 * Instantiates a new <code>UniSession</code> object.  It also stores the reference into
	 * the uniSessionsVector. If an error occurs, it throws a <code>UniSessionException</code>
	 *
	 * @return a UniSession object
	 * @exception UniSessionException if it encounters an error during creation.
	 * @since UNIOBJECTS 1.0
	 **/
	public UniSession openSession(int sslmode) throws UniSessionException
	{
		synchronized ( UniJava.class ) {
			
			if (( uniNumSessions == uniMaxSessions ) && ( uniMaxSessions != 0 ))
			{
				throw new UniSessionException( UniObjectsTokens.UVE_OPENSESSION_ERR );
			}
			uniNumSessions++;
			UniSession unis = new UniSession(sslmode);
			if (!uoPooling)
				uniSessionsVector.addElement( unis );
			return unis;
		}
	}
	
	/**
	 * This function physically closes given connection.
	 * @param us UniSession Object
	 * @throws UniSessionException is thrown if an error occurs
	 */
	public static void closeServerConnection(UniSession us)
	throws UniSessionException {
		uniLog("Enter UniJava::closeServerConnection()");
		
		if (!us.isActive()) return;
		
		if (us.getPooledSession() == false) {
			us.disconnectServer();
			uniLog("calling closeServerConnection() and us.disconnectServer and pooling is false");
			return;
		}
		
		synchronized ( UniJava.class ) {
			String lKey = us.getHostName() + us.getUserName() + us.getPassword()
			+ us.getAccountPath();
			UniPool lPool = (UniPool) poolList.get(lKey);
			if (lPool == null) {
				return;
			}
			lPool.closeServerConnection(us);
		}
		uniLog("Exir UniJava::closeServerConnection()");
	}
	
	/**
	 * This function is called by 4 above overloaded openSession() functions.
	 * @param hostname String representing the name of the host to connect to
	 * @param userid String representing the server-side username used for connection purposes.
	 * @param password String representing the password to be used for the connection
	 * @param account String representing which account to connect to
	 * @param service String representing the datasource type.
	 * @param sslmode Integer representing the ssl mode.
	 * @param min_poolsize Integer representing Min Pool Size.
	 * @param max_poolsize Integer representing Max Pool Size.
	 * @return
	 * @throws UniSessionException is thrown if an error occurs
	 */
	protected static UniSession openPooledSession(String hostname, int hostport, String userid,
			String password, String account, String service, int sslmode)
	throws UniSessionException {
		
		UniSession us = null;
		UniPool lPool = null;
		uniLog("Enter UniJava::openPooledSession()");
		
		synchronized (UniJava.class) {
			if (uoPooling == false) {
				throw new UniSessionException(UniObjectsTokens.EIC_POOLOFF);
			}
			String lKey = hostname + userid + password + account;
			lPool = (UniPool) poolList.get(lKey);
			if (lPool == null) {
				Integer p = (Integer)poolListMinSize.get(Thread.currentThread());
				Integer q = (Integer)poolListMaxSize.get(Thread.currentThread());
				if(p!= null){
					minPoolSize=p.intValue();	
				}
				if(q!=null){
					maxPoolSize=q.intValue();	
				}
					
				
				lPool = new UniPool(hostname, hostport, userid, password, account,
						service, sslmode, minPoolSize,maxPoolSize);
				poolList.put(lKey, lPool);
			}
		}
		us = lPool.findSession(poolingOpenSessionTimeout, sslmode);
		uniLog("Exit UniJava::openPooledSession()");
		return us;
	}
	
	
	/**
	 * This function will be called by timer object.
	 * @param o for now it is not in use.
	 * @throws UniSessionException is thrown if an error occurs
	 */
	private static void closeIdleSessions(Object o) throws UniSessionException {
		uniLog("Enter UniJava::closeIdleSessions()");
		// get enumerator
		if (poolList != null) {
			//synchronized (UniJava.class) {
				Enumeration lEnumerator = poolList.elements();
				while (lEnumerator.hasMoreElements()) {
					UniPool lPool = (UniPool) lEnumerator.nextElement();
					String s = lPool.getServer()+""+ lPool.getUserid() +""+ lPool.getPassword()+""+lPool.getAccount();
					uniLog("Int UniJava::closeIdleSessions() Application details is:" +s );
					lPool.closeIdleConnections();
				}
			//}
		}
		uniLog("Exit UniJava::closeIdleSessions()");
	}
	
	
	private static void readUOJProperties() 
	{
		int lminPoolSize;
		int lmaxPoolSize;
		int lpoolingOpenSessionTimeout;
		int lidleRemoveThreshold;
		int lidleRemoveExecInterval;
		String luniDebugLevel = "";
		String luoPooling = "";
		try 
		{
			lminPoolSize = -1;
			lmaxPoolSize = -1;
			lpoolingOpenSessionTimeout = -1;
			lidleRemoveThreshold = -1;
			lidleRemoveExecInterval = -1;
			luoPooling = uojProperties.getPropertyString("ConnectionPoolingOn");
			lminPoolSize = uojProperties.getPropertyInt("MinimumPoolSize");
			lmaxPoolSize = uojProperties.getPropertyInt("MaximumPoolSize");
			lpoolingOpenSessionTimeout = uojProperties.getPropertyInt("OpenSessionTimeOut");
			lidleRemoveThreshold = uojProperties.getPropertyInt("IdleRemoveThreshold");
			lidleRemoveExecInterval = uojProperties.getPropertyInt("IdleRemoveExecInterval");
			luniDebugLevel = uojProperties.getPropertyString("PoolingDebug");
			luoPooling = uojProperties.getPropertyString("ConnectionPoolingOn");
			if (luoPooling.equals("1")){
				if (lminPoolSize > -1)
					minPoolSize = lminPoolSize;
				if (lmaxPoolSize > 0)
					maxPoolSize = lmaxPoolSize;
				if (lpoolingOpenSessionTimeout != -1)
					poolingOpenSessionTimeout = lpoolingOpenSessionTimeout;
				if (lidleRemoveThreshold != -1)
					idleRemoveThreshold = lidleRemoveThreshold;
				if (lidleRemoveExecInterval != -1)
					idleRemoveExecInterval = lidleRemoveExecInterval;
				if (luniDebugLevel.equals("1"))
					uniPoolingDebug = true;

				setUOPooling(true);
			}
			uniLog("In UniJava::readUOJProperties()");
				
		} 
		catch (UniSessionException e1) 
		{
			uniLog("In UniJava::readUOJProperties() got exception");
		}
	}
	
	/**
	 * retuns Idle Remove Execution Interval.
	 * @return idleRemoveExecInterval Integer representing Idle Remove Execution Interval.
	 */
	public static synchronized int getIdleRemoveExecInterval() {
		return idleRemoveExecInterval;
	}
	/**
	 * sets Idle Remove Execution Interval.
	 * 
	 * @param idleRemoveExecInterval Integer representing Idle Remove Execution Interval.
	 */
	public static synchronized  void setIdleRemoveExecInterval(
			int pidleRemoveExecInterval) {
		idleRemoveExecInterval = pidleRemoveExecInterval;
		if(poolListInterval != null){
			poolListInterval.put(Thread.currentThread(), new Integer(idleRemoveExecInterval));
		}
		uniLog("in UniJava::setidleRemoveExecInterval " + idleRemoveExecInterval + "Thread:"+Thread.currentThread());
	}
	
	/**
	 * returns Idle Remove Threshold
	 * @return idleRemoveThreshold. Integer representing Idle Remove Threshold
	 */
	public static synchronized int getIdleRemoveThreshold() {
		return idleRemoveThreshold;
	}
	/**
	 * set Idle Remove Threshold
	 * @param idleRemoveThreshold. Integer representing Idle Remove Threshold.
	 */
	public static synchronized void setIdleRemoveThreshold(
			int pidleRemoveThreshold) {
		idleRemoveThreshold = pidleRemoveThreshold;
		if(poolListThreshold != null){
			poolListThreshold.put(Thread.currentThread(), new Integer(idleRemoveThreshold));
		}
		uniLog("in UniJava::setidleRemoveThreshold " + idleRemoveThreshold + "Thread:"+Thread.currentThread());
	}
	
	/**
	 * returns Socket Time Out
	 * @return socketTimeout Integer representing Socket Time Out
	 */
	public static synchronized int getSocketTimeout() {
		return socketTimeout;
	}
	
	/**
	 * sets Socket Time Out
	 * @param socketTimeout Integer representing Socket Time Out
	 */
	public static synchronized  void setSocketTimeout(int ptimeout) {
		socketTimeout = ptimeout;
	}

	/**
	 * returns Open  Session TimeOut
	 * @return poolingOpenSessionTimeout Integer representing Open  Session TimeOut
	 */
	public static synchronized int getOpenSessionTimeOut() 
	{
		return poolingOpenSessionTimeout ;
	}
	
	/**
	 * sets Open Session TimeOut
	 * @param poolingOpenSessionTimeout Integer representing Open  Session TimeOut
	 */
	public static synchronized  void setOpenSessionTimeOut(int ptimeout) 
	{
		poolingOpenSessionTimeout  = ptimeout;
	}
	
	/**
	 * returns UOJ Connection Pooling flag
	 * @return uoPooling Integer representing UOJ Connection Pooling flag
	 */
	public static  synchronized  boolean getUOPooling() {
		//synchronized(UniJava.class){
			return uoPooling;	
		//}
		//return uoPooling;
		
	}
	
	/**
	 * sets UOJ Connection Pooling flag
	 * @param uoPooling Integer representing UOJ Connection Pooling flag
	 */
	public static synchronized void setUOPooling(boolean puoPooling) {
		if (uoPooling == puoPooling)
			return;
		
		if (uoPooling == true && puoPooling == false)
		{
			try {
				closeAllCPSessions();
			} catch (UniRPCConnectionException e) {
			} catch (UniSessionException e) {
			}
			if(timer != null){
				timer.cancel();	
			}
			uniPW = null;
		}
		
		//System.out.println(Thread.currentThread().toString() + " " + "Enter calling UniJava::setuoPooling()");
		uoPooling = puoPooling;
		if (uoPooling == true && poolList == null && timer == null) 
		{
			// init pool hash table
			poolList = new Hashtable();
			poolListMinSize = new Hashtable();
			poolListMaxSize = new Hashtable();
			poolListThreshold  = new Hashtable();
			poolListInterval = new Hashtable();
			timer = new Timer(true);
			//start timer object so that it can close idle connections
			timer.schedule(new UniTimerTask(), 0, idleRemoveExecInterval);
			if (uniPoolingDebug) {
				try 
				{
					// a real FileTrace would need to obtain the filename somewhere
					// for the example I'll hardcode it
					if (uniPW == null) 
					{
						uniPW = new java.io.PrintWriter(new java.io.FileWriter("uoj_trace.log"));
						uniLog("in UniJava::setUOPooling() Program Started at:" +new Date());
						uniLog("===========================================================");
						
					}
				} 
				catch (IOException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
	}
	
	/**
	 * returns Maximum Pool Size Number.
	 * @return  maxPoolSize Integer representing Min Pool Size.
	 */
	public static synchronized int getMaxPoolSize() {
		return maxPoolSize;
	}
	/**
	 * sets Maximum Pool Size Number.
	 * @param maxPoolSize  Integer representing Maximum Pool Size Number.
	 */
	public static synchronized void setMaxPoolSize(int pmaxPoolSize) {
		if (pmaxPoolSize >= minPoolSize)
			maxPoolSize = pmaxPoolSize;
		else
			maxPoolSize = minPoolSize;
		if(poolListMaxSize != null){
			poolListMaxSize.put(Thread.currentThread(), new Integer(maxPoolSize));
		}
		uniLog("in UniJava::setMaxPoolSize " + maxPoolSize + "Thread:"+Thread.currentThread());
	}
	
	/**
	 * returns Minimum Pool Size Number.
	 * @return minPoolSize Integer representing Min Pool Size.
	 */
	public static synchronized int getMinPoolSize() {
		return minPoolSize;
	}
	
	
	
	/**
	 * sets Maximum Pool Size Number.
	 * @param minPoolSize Integer representing Minimum Pool Size Number.
	 */
	public static synchronized void setMinPoolSize(int pminPoolSize) {
		if (pminPoolSize <= maxPoolSize)
			minPoolSize = pminPoolSize;
		if (pminPoolSize < 0)
			minPoolSize = 0;
		if(poolListMinSize != null){
			poolListMinSize.put(Thread.currentThread(), new Integer(minPoolSize));
		}
		uniLog("in UniJava::setMinPoolSize " + minPoolSize + "Thread:"+Thread.currentThread());
	}
	
	static class UniTimerTask extends TimerTask {
		//. . . some Class definitions later
		public void run() {
			try {
				uniLog("in UniTimerTask::run() Timer Started at:" +new Date());
				closeIdleSessions(null);
			} catch (UniSessionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	// Private instance variables
	private final static int 		MAX_OPEN_SESSIONS 		= 0;	// If > 0, will limit the number of active connections
	private final static String	UVJAVA_VERSION_NUM		= "4.1.3";
	
	// Note:  Need to update the Java Version Number with each release.
	private final int 		uniMaxSessions 				= MAX_OPEN_SESSIONS;
	private final String 	uniJavaVersionNumber 	= UVJAVA_VERSION_NUM;
	private static int				uniJavaIsActive 			= 0;
	private static int 					uniNumSessions				= 0;
	private static  Vector 				uniSessionsVector			= new Vector();
	private static boolean uoPooling = false;
	private static int socketTimeout = UniTokens.DEFAULT_TIMEOUT;
	private static Hashtable poolList = null;
	private static Hashtable poolListMinSize = null;
	private static Hashtable poolListMaxSize = null;
	private static Hashtable poolListThreshold  = null;
	private static Hashtable poolListInterval = null;
	private static int minPoolSize = 0;
	private static int maxPoolSize = 10;
	private static Thread pollingThread = null;
	private static int poolingOpenSessionTimeout = 30000;
	private static int idleRemoveThreshold = 300000;
	private static int idleRemoveExecInterval = 300000;
	private static Timer timer = null;
	private static PrintWriter uniPW;
	private static boolean uniPoolingDebug=false;
	private static UniProperties uojProperties = null;
}
