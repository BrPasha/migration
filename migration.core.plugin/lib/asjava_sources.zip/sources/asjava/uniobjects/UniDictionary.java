/*************************************************************************
 *
 * UniDictionary.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniobjects;

import asjava.uniclientlibs.*;

/**
 * <code>UniDictionary</code> is used to control access to UniVerse dictionary
 *	files.  It is an extension of the standard <code>UniFile</code> class
 *
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since		UNIOBJECTS 1.0
 */
public class UniDictionary extends UniFile
{
	/**
	 * Constructs a <code>UniDictionary</code> object
	 *
	 * @exception UniFileException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public UniDictionary() throws UniFileException
	{
		throw new UniFileException( UniObjectsTokens.UVE_MUST_USE_SESSION );
	}
	
	public UniDictionary( UniSession aSession, Object aDictName, int dictFlag ) 
		throws UniFileException
	{
		super( aSession, aDictName, dictFlag );
	}
	
	/**
	 * Returns the current ASSOC field from the dictionary
	 *
	 * @return a UniString representing the ASSOC field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setAssoc
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getAssoc() throws UniFileException
	{
		return getIndexedField( getRecordID(), UniObjectsTokens.UVT_ASSOC_INDEX );
	};
	
	/**
	 * Returns the current ASSOC field from the dictionary for the record ID specified
	 *
	 * @param aRecordID String representing which recordID from the dictionary to examine
	 * @return a UniString representing the ASSOC field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setAssoc
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getAssoc( Object aRecordID ) throws UniFileException
	{
		return getIndexedField( aRecordID, UniObjectsTokens.UVT_ASSOC_INDEX );
	};

	/**
	 * Sets the ASSOC field from the dictionary to the String passed in
	 *
	 * @param aString a String representing the new value of the ASSOC field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getAssoc
	 * @since UNIOBJECTS 1.0
	 */
	public void setAssoc( Object aString ) throws UniFileException
	{
		setIndexedField( getRecordID(), aString, UniObjectsTokens.UVT_ASSOC_INDEX );
	};
	
	/**
	 * Sets the ASSOC field of the recordID specified from the dictionary to the String passed in
	 *
	 * @param aRecordID a String representing the recordID to be modified
	 * @param aString a String representing the new value of the ASSOC field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getAssoc
	 * @since UNIOBJECTS 1.0
	 */
	public void setAssoc( Object aRecordID, Object aString ) throws UniFileException
	{
		setIndexedField( aRecordID, aString, UniObjectsTokens.UVT_ASSOC_INDEX );
	};

	/**
	 * Returns the current CONV field from the dictionary
	 *
	 * @return a UniString representing the CONV field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setConv
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getConv() throws UniFileException
	{
		return getIndexedField( getRecordID(), UniObjectsTokens.UVT_CONV_INDEX );
	};
	
	/**
	 * Returns the current CONV field from the dictionary for the recordID specified
	 *
	 * @param aRecordID a String representing the recordID to be examined
	 * @return a UniString representing the CONV field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setConv
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getConv( Object aRecordID ) throws UniFileException
	{
		return getIndexedField( aRecordID, UniObjectsTokens.UVT_CONV_INDEX );
	};

	/**
	 * Sets the CONV field from the dictionary to the String passed in
	 *
	 * @param aString a String representing the new value of the CONV field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getConv
	 * @since UNIOBJECTS 1.0
	 */
	public void setConv(Object aString) throws UniFileException
	{
		setIndexedField( getRecordID(), aString, UniObjectsTokens.UVT_CONV_INDEX );
	};
	
	/**
	 * Sets the CONV field for the specified recordID from the dictionary to the String passed in
	 *
	 * @param aRecordID a String representing the recordID from the dictionary to modify
	 * @param aString a String representing the new value of the CONV field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getConv
	 * @since UNIOBJECTS 1.0
	 */
	public void setConv( Object aRecordID, Object aString ) throws UniFileException
	{
		setIndexedField( aRecordID, aString, UniObjectsTokens.UVT_CONV_INDEX );
	};

	/**
	 * Returns the current FORMAT field from the dictionary
	 *
	 * @return a UniString representing the FORMAT field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setFormat
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getFormat() throws UniFileException
	{
		return getIndexedField( getRecordID(), UniObjectsTokens.UVT_FORMAT_INDEX );
	};
	
	/**
	 * Returns the current FORMAT field from the dictionary for the recordID specified
	 *
	 * @param aRecordID a String representing which recordID to examine
	 * @return a UniString representing the FORMAT field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setFormat
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getFormat( Object aRecordID ) throws UniFileException
	{
		return getIndexedField( aRecordID, UniObjectsTokens.UVT_FORMAT_INDEX );
	};

	/**
	 * Sets the FORMAT field from the dictionary to the String passed in
	 *
	 * @param aString a String representing the new value of the FORMAT field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getFormat
	 * @since UNIOBJECTS 1.0
	 */
	public void setFormat(Object aString) throws UniFileException
	{
		setIndexedField( getRecordID(), aString, UniObjectsTokens.UVT_FORMAT_INDEX );
	};
	
	/**
	 * Sets the FORMAT field for the recordID specified from the dictionary to the String passed in
	 *
	 * @param aRecordID a String representing the recordID from the dictionary to modify
	 * @param aString a String representing the new value of the FORMAT field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getFormat
	 * @since UNIOBJECTS 1.0
	 */
	public void setFormat( Object aRecordID, Object aString ) throws UniFileException
	{
		setIndexedField( aRecordID, aString, UniObjectsTokens.UVT_FORMAT_INDEX );
	};

	/**
	 * Returns the current LOC field from the dictionary
	 *
	 * @return a UniString representing the LOC field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setLoc
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getLoc() throws UniFileException
	{
		return getIndexedField( getRecordID(), UniObjectsTokens.UVT_LOC_INDEX );
	};
	
	/**
	 * Returns the current LOC field from the dictionary for the recordID specified
	 *
	 * @param aRecordID a String representing which recordID to examine
	 * @return a UniString representing the LOC field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setLoc
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getLoc( Object aRecordID ) throws UniFileException
	{
		return getIndexedField( aRecordID, UniObjectsTokens.UVT_LOC_INDEX );
	};

	/**
	 * Sets the LOC field from the dictionary to the String passed in
	 *
	 * @param aString a String representing the new value of the LOC field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getLoc
	 * @since UNIOBJECTS 1.0
	 */
	public void setLoc(Object aString) throws UniFileException
	{
		setIndexedField( getRecordID(), aString, UniObjectsTokens.UVT_LOC_INDEX );
	};
	
	/**
	 * Sets the LOC field for the recordID specified from the dictionary to the String passed in
	 *
	 * @param aRecordID a String representing the recordID from the dictionary to modify
	 * @param aString a String representing the new value of the LOC field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getLoc
	 * @since UNIOBJECTS 1.0
	 */
	public void setLoc( Object aRecordID, Object aString ) throws UniFileException
	{
		setIndexedField( aRecordID, aString, UniObjectsTokens.UVT_LOC_INDEX );
	};

	/**
	 * Returns the current NAME field from the dictionary
	 *
	 * @return a UniString representing the NAME field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setName
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getName() throws UniFileException
	{
		return getIndexedField( getRecordID(), UniObjectsTokens.UVT_NAME_INDEX );
	};
	
	/**
	 * Returns the current NAME field from the dictionary for the recordID specified
	 *
	 * @param aRecordID a String representing which recordID from the dictionary to examine
	 * @return a UniString representing the NAME field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setName
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getName( Object aRecordID ) throws UniFileException
	{
		return getIndexedField( aRecordID, UniObjectsTokens.UVT_NAME_INDEX );
	};

	/**
	 * Sets the NAME field from the dictionary to the String passed in
	 *
	 * @param aString a String representing the new value of the NAME field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getName
	 * @since UNIOBJECTS 1.0
	 */
	public void setName(Object aString) throws UniFileException
	{
		setIndexedField( getRecordID(), aString,UniObjectsTokens.UVT_NAME_INDEX );
	};
	
	/**
	 * Sets the NAME field for the recordID specified from the dictionary to the String passed in
	 *
	 * @param aRecordID a String representing which recordID from the dictionary to modify
	 * @param aString a String representing the new value of the NAME field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getName
	 * @since UNIOBJECTS 1.0
	 */
	public void setName( Object aRecordID, Object aString ) throws UniFileException
	{
		setIndexedField( aRecordID, aString,UniObjectsTokens.UVT_NAME_INDEX );
	};

	/**
	 * Returns the current SM field (single/multivalued) from the dictionary
	 *
	 * @return a UniString representing the SM field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setSM
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getSM() throws UniFileException
	{
		return getIndexedField( getRecordID(), UniObjectsTokens.UVT_SM_INDEX );
	};
	
	/**
	 * Returns the current SM field (single/multivalued) from the dictionary for the field specified
	 *
	 * @param aRecordID a String representing which recordID to examine
	 * @return a UniString representing the SM field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setSM
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getSM( Object aRecordID ) throws UniFileException
	{
		return getIndexedField( aRecordID, UniObjectsTokens.UVT_SM_INDEX );
	};

	/**
	 * Sets the SM (single/multivalued) field from the dictionary to the String passed in
	 *
	 * @param aString a String representing the new value of the SM field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getSM
	 * @since UNIOBJECTS 1.0
	 */
	public void setSM(Object aString) throws UniFileException
	{
		setIndexedField( getRecordID(), aString, UniObjectsTokens.UVT_SM_INDEX );
	};
	
	/**
	 * Sets the SM (single/multivalued) field for the recordID specified from the dictionary to the String passed in
	 *
	 * @param aRecordID a String representing which dictionary recordID to modify
	 * @param aString a String representing the new value of the SM field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getSM
	 * @since UNIOBJECTS 1.0
	 */
	public void setSM( Object aRecordID, Object aString ) throws UniFileException
	{
		setIndexedField( aRecordID, aString, UniObjectsTokens.UVT_SM_INDEX );
	};

	
	/**
	 * Returns the current SQLTYPE field from the dictionary
	 *
	 * @return a UniString representing the SQLTYPE field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setSQLType
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getSQLType() throws UniFileException
	{
		return getIndexedField( getRecordID(), UniObjectsTokens.UVT_SQLTYPE_INDEX );
	};
	
	/**
	 * Returns the current SQLTYPE field from the dictionary for the field specified
	 *
	 * @param aRecordID a String representing which recordID to examine
	 * @return a UniString representing the SQLTYPE field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setSQLType
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getSQLType( Object aRecordID ) throws UniFileException
	{
		return getIndexedField( aRecordID, UniObjectsTokens.UVT_SQLTYPE_INDEX );
	};

	/**
	 * Sets the SQLTYPE field from the dictionary to the String passed in
	 *
	 * @param aString a String representing the new value of the SQLTYPE field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getSQLType
	 * @since UNIOBJECTS 1.0
	 */
	public void setSQLType(Object aString) throws UniFileException
	{
		setIndexedField( getRecordID(), aString, UniObjectsTokens.UVT_SQLTYPE_INDEX );
	};
	
	/**
	 * Sets the SQLTYPE field for the recordID specified from the dictionary to the String passed in
	 *
	 * @param aRecordID a String representing which dictionary recordID to modify
	 * @param aString a String representing the new value of the SQLTYPE field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getSQLType
	 * @since UNIOBJECTS 1.0
	 */
	public void setSQLType( Object aRecordID, Object aString) throws UniFileException
	{
		setIndexedField( aRecordID, aString, UniObjectsTokens.UVT_SQLTYPE_INDEX );
	};

	/**
	 * Returns the current TYPE field from the dictionary
	 *
	 * @return a UniString representing the TYPE field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setType
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getType() throws UniFileException
	{
		return getIndexedField( getRecordID(), UniObjectsTokens.UVT_TYPE_INDEX );
	};
	
	/**
	 * Returns the current TYPE field from the dictionary for the recordID specified
	 *
	 * @param aRecordID a String representing which recordID to examine
	 * @return a UniString representing the TYPE field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #setType
	 * @since UNIOBJECTS 1.0
	 */
	public UniString getType( Object aRecordID ) throws UniFileException
	{
		return getIndexedField( aRecordID, UniObjectsTokens.UVT_TYPE_INDEX );
	};

	/**
	 * Sets the TYPE field from the dictionary to the String passed in
	 *
	 * @param aString a String representing the new value of the TYPE field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getType
	 * @since UNIOBJECTS 1.0
	 */
	public void setType(Object aString) throws UniFileException
	{
		setIndexedField( getRecordID(), aString, UniObjectsTokens.UVT_TYPE_INDEX );
	};
	
	/**
	 * Sets the TYPE field for the recordID specified from the dictionary to the String passed in
	 *
	 * @param aRecordID a String representing which dictionary recordID to modify
	 * @param aString a String representing the new value of the TYPE field
	 * @exception UniFileException is thrown if an error occurs
	 * @see #getType
	 * @since UNIOBJECTS 1.0
	 */
	public void setType( Object aRecordID, Object aString ) throws UniFileException
	{
		setIndexedField( aRecordID, aString, UniObjectsTokens.UVT_TYPE_INDEX );
	};

	/* Private methods */
	private UniString getIndexedField( Object aRecordID, int aType ) throws UniFileException
	{
		return readField( aRecordID, aType );
	}
	
	private void setIndexedField( Object aRecordID, Object aString, int aType ) throws UniFileException
	{
		writeField( aRecordID, aString, aType );
	}
}