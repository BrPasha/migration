/*************************************************************************
 *
 * UniSubroutine.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 11/18/04 e32565 RKK Connection Pooling
 * 05/05/99 24995 DTM Changed for thread safety
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniobjects;

import asjava.uniclientlibs.*;
import asjava.unirpc.*;

/**
 * <code>UniSubroutine</code> is the object type used to allow the user to run a cataloged
 * BASIC subroutine on the server.
 *
 * @author	David T. Meeks
 * @version	Version 1.0
 * @since		UNIOBJECTS 1.0
 */
public class UniSubroutine extends UniBase
{
	/**
	 * Cannot instantiate as a standalone object, must be created from UniSession.subroutine()
	 *
	 * @since UNIOBJECTS 1.0
	 */
	UniSubroutine() throws UniSubroutineException
	{
		throw new UniSubroutineException( UniObjectsTokens.UVE_MUST_USE_SESSION );
	}
	
	/**
	 * Default contructor creates the <code>UniSubroutine</code> object.  It will create the 
	 * default input and output argument arrays.  
	 *
	 * @param asession unisession representing the parent session object we are created by 
	 * @param asubname string representing the name of the subroutine to be called
	 * @param anumargs integer representing the number of arguments expected
	 * @since UNIOBJECTS 1.0
	 */
	UniSubroutine( UniSession aSession, Object aSubName, int aNumArgs ) throws UniSubroutineException
	{
		synchronized ( this ) {
			// Handle boundary condition
			if ( aNumArgs < 0 ) aNumArgs = 1;
			if ( aNumArgs > UVSUB_MAX_ARGS ) aNumArgs = UVSUB_MAX_ARGS;
			if ( aSession == null )
				throw new UniSubroutineException( UniObjectsTokens.UVE_SESSION_NOT_OPEN );
			
			// Set up uniConnection.  For performance reasons, we won't actually initialize 
			// the Packet information until we need to, in the call() method.
			uniParentSession	=	aSession;
			uniConnection 		= aSession.connection;
				
			// Set up the routine name and number of arguments from the values passed in
			setRoutineName( aSubName );
			uniNumArgs = aNumArgs;
			
			// Set up the input and output argument arrays
			uniInputArgArray 	= new UniString[ uniNumArgs ];
            uniOutputArgArray = new UniString[ uniNumArgs ];
			
			// Initialize the input array to all empty values
			for ( int i = 0; i < uniNumArgs; i++ )
			{
				uniInputArgArray[ i ] = new UniString(aSession);
                uniOutputArgArray[ i ] = new UniString(aSession);
			}
			
			// Initialize the output array
			//this.resetArgs();
			
			// Initialize other values
			uniReturnCode = 0;
			
			// Get default encryption type from UniSession object
			uniEncryptionType = uniParentSession.getDefaultEncryptionType();
		} // synch this
	}; 
	
	/**
	 * Executes the catalogued UniVerse subroutine identified during the <code>UniSubroutine</code>
	 * creation.  Uses the arguments established with the <code>setArg</code> method.
	 * 
	 * @exception UniSubroutineException if a server error occurs
	 * @see #setArg
	 * @since UNIOBJECTS 1.0
	 */
	public void call() throws UniSubroutineException
	{
		synchronized ( this ) {
			// Check to ensure that a UniCommand execution is not active
			if ( isCommandActive() )
			{
				throw new UniSubroutineException( UniObjectsTokens.UVE_EXECUTEISACTIVE );
			}
	
			// Handle boundary conditions
			if ( ( uniRoutineName == null ) || ( uniRoutineName.equals("") ) )
				throw new UniSubroutineException( UniTokens.UVE_UNABLETOLOADSUB );
				
			try
			{
				int rpc_argnum = UVSUB_INIT_SEND_ARGS;	// Because we will be sticking the first 3 arguments on 
				
				if (( inPacket == null ) || ( outPacket == null ))
				{
					inPacket 		= new UniRPCPacket( uniConnection );
					outPacket 	= new UniRPCPacket( uniConnection );
				}
				
				// Set up the packet information
				outPacket.write( 0, UniObjectsTokens.EIC_SUBCALL );
				outPacket.write( 1, uniNumArgs );
				outPacket.write( 2, encode(uniRoutineName) );
				
				// Fill in the input arguments
				for ( int i = 0; i < uniNumArgs; i++ )
				{
					outPacket.write( rpc_argnum, uniInputArgArray[ i ].getBytes() );
					rpc_argnum++;
				}
				// Make server call
				uniConnection.call( outPacket, inPacket, (byte) uniEncryptionType );
			
				// Ok, let's get data back from server.  First read of the return code
				uniReturnCode 	= inPacket.readInteger( 0 );
				
				// If uniReturnCode != 0, we have an error to address
				if ( uniReturnCode != 0 )
				{
					throw new UniSubroutineException( uniReturnCode );
				}
				else
				{	// Successful return, let's get the result args out.
					rpc_argnum = UVSUB_INIT_RETURN_ARGS;	/* Because we already grabbed off the first result */
					for ( int i = 0; i < uniNumArgs; i++ )
					{
						uniOutputArgArray[ i ].setValue(inPacket.readBytes( rpc_argnum ));
                       	rpc_argnum++;
					}
				}
			}
			// UniRpc Error.  Just send it back up the chain, but as a UniSubroutineException
			catch (UniRPCException e)
			{
				uniParentSession.setRPCError(true);
				throw new UniSubroutineException( e.getErrorCode() );
			}
		} // synch this
	};
	
	/**
	 * retrieves the the contents of the subroutine arguments after a successful <code>call</code> has
	 * been executed
	 *
	 * @param aArgNum integer value of the argument to be retrieved.  0 based, first argument is 0.
	 * @return String value representing the subroutine argument requested
	 * @exception UniSubroutineException if an invalid argument value is passed in
	 * @see #setArg
	 * @since UNIOBJECTS 1.0
	 */
	public String getArg( int aArgNum ) throws UniSubroutineException
	{
		// Check that the argument number expected is correct
		if (( aArgNum < 0 ) || ( aArgNum >= uniNumArgs ))
		{
			throw new UniSubroutineException( UniObjectsTokens.UVE_BADPARAM );
		}
		return uniOutputArgArray[ aArgNum ].toString();
	};

    /**
     * retrieves the the contents of the subroutine arguments as dynamic arrays
     * after a successful <code>call</code> has been executed
     *
     * @param aArgNum integer value of the argument to be retrieved.  0 based, first argument is 0.
     * @return String value representing the subroutine argument requested
     * @exception UniSubroutineException if an invalid argument value is passed in
     * @see #setArg
     * @since UNIOBJECTS 2.0
     */
    public UniDynArray getArgDynArray( int aArgNum ) throws UniSubroutineException
    {
        // Check that the argument number expected is correct
        if (( aArgNum < 0 ) || ( aArgNum >= uniNumArgs ))
        {
            throw new UniSubroutineException( UniObjectsTokens.UVE_BADPARAM );
        }
        return new UniDynArray(uniOutputArgArray[ aArgNum ]);
    };
    
	/** 
	 * Returns the number of arguments set for this subroutine  
	 *
	 * @return integer value representing the number of argument set up for this subrouting
	 * @see #setNumArgs
	 * @since UNIOBJECTS 1.0
	 */
	public int getNumArgs()
	{
		return uniNumArgs;
	};

	/** 
	 * Retrieves the routine name established during the object creation 
	 *
	 * @return String value representing the name of the server-side BASIC routine to execute
	 * @see #setRoutineName
	 * @since UNIOBJECTS 1.0
	 */
	public String getRoutineName()
	{
		return uniRoutineName;
	};
	
	/** 
	 * resets the output argument array back to all empty values.
	 *
	 * @since UNIOBJECTS 1.0
	 */
	public void resetArgs()
	{
		synchronized ( this ){
			for ( int i = 0; i < uniNumArgs; i++ )
			{
				uniOutputArgArray[ i ].setValue(uniInputArgArray[ i ]);
			}
		} // synch this
	};

	/** 
	 * sets up the input argument array to be used for the catalogued subroutine call
	 *
	 * @param aArgNum integer representing which argument value is to be set.  0 represents the first argument
	 * @param aArgVal String representing the value to set this argument to
	 * @exception UniSubroutineException is thrown if the argument number is invalid
	 * @see #getArg
	 * @since UNIOBJECTS 1.0
	 */
	public void setArg( int aArgNum, Object aArgVal ) throws UniSubroutineException
	{
		synchronized ( this ){
			if (( aArgNum < 0 ) || ( aArgNum >= uniNumArgs ))
			{
				throw new UniSubroutineException( UniObjectsTokens.UVE_BADPARAM );
			}
            
            if (aArgVal instanceof UniString)
            {
                uniInputArgArray[ aArgNum ].setValue((UniString)aArgVal);
                uniOutputArgArray[ aArgNum ].setValue((UniString)aArgVal);
            } else {
                uniInputArgArray[ aArgNum ].setValue(aArgVal.toString());
                uniOutputArgArray[ aArgNum ].setValue(aArgVal.toString());
            }
		} // synch this
	};
	
	/** 
	 * sets up the number of input arguments to be used for this catalogued subroutine call
	 *
	 * @param aNumArgs integer representing the number of arguments this subroutine uses
	 * @exception UniSubroutineException is thrown if the argument number if invalid
	 * @see #getNumArgs
	 * @since UNIOBJECTS 1.0
	 */
	public void setNumArgs( int aNumArgs ) throws UniSubroutineException
	{
		if (( aNumArgs < 0 ) || ( aNumArgs > UVSUB_MAX_ARGS ))
		{
			throw new UniSubroutineException( UniObjectsTokens.UVE_BADPARAM );
		}

		uniNumArgs = aNumArgs;
	};
	
	/** 
	 * sets up the name of the subroutine to be called on the server.
	 *
	 * @param aRoutineName String representing the name of the catalogued BASIC subroutine to be called on the server
	 * @see #getRoutineName
	 * @since UNIOBJECTS 1.0
	 */
	public void setRoutineName( Object aRoutineName )
	{
		uniRoutineName = aRoutineName.toString();
	};
	
	
	/* Private instance variables */
	private static final int		UVSUB_INIT_SEND_ARGS		=	3;	// Initial static arguments we put on stack
	private static final int	  UVSUB_INIT_RETURN_ARGS	= 1;  // Initial number of arguments on return stack
	private static final int		UVSUB_MAX_ARGS					= 1024;
	
	private UniString[] 						uniInputArgArray;			 		// array of input args to subroutine
	private UniString[] 						uniOutputArgArray;			 	// array of output args to subroutine
	private String 							uniRoutineName;						// Name of the subroutine
	private int 								uniReturnCode;
	private int 								uniNumArgs; 							// Number of subroutine arguments
    
}