/*************************************************************************
*
* UniProperties.java
*
* Module	%M%	Version	%I%	Date	%H%
*
*       IBM Confidential
*       OCO Source Materials
*       Copyright (C) IBM Corp.  1993, 2004
*
*************************************************************************
*
* Maintenance Log - Insert most recent change descriptions at top
*
* Date.... ECASE WHO Descrition..........................................
* 12/13/04 32565 JFM removed unnecessary code using uniLog() because logging 
*                    won't be available till CP is turned on, we limit logging
*                    only to CP
* 12/07/04 32565 RKK Initial Creation
*************************************************************************/


package asjava.uniobjects;
import java.util.Properties;
import java.util.Enumeration;
import java.io.InputStream;
import java.io.IOException;
import java.io.FileInputStream;
/**
 *  <code>UniProperties</code> is used to control "uoj.properties" file. It loads connection
 * pooling parameters from "uoj.properties" file.  
 *
 * @author rajank
 * 
 */
public final class UniProperties {
	String fileName = "uoj.properties";
	Properties uojProp = new Properties();
	int intRetValue = -1;
	
	
	
	/**
	 * This is no argument constructor. In the constructor, it loads "uoj.properties" parameters.
	 */
	public UniProperties() {
		InputStream propsFile;
		try {
			propsFile = new FileInputStream(fileName);
			uojProp.load(propsFile);
			propsFile.close();
		} catch (IOException ioe) {
			//System.out.println(fileName + ": I/O Exception.");
			//ioe.printStackTrace();
		}
	}
	/**
	 * Searches for the property with the specified key in this property list.
	 * @param uojKey
	 * @return the integer value in this property list with the specified key value.
	 * @throws         UniSessionException
	 */
	public int getPropertyInt(String uojKey) throws UniSessionException {
		if (uojProp == null)
			return -1;
		Enumeration enProps = uojProp.propertyNames();
		String key = "";
		int value = -1;
		String sValue = "";
		while (enProps.hasMoreElements()) {
			key = (String) enProps.nextElement();
			if (key.equals(uojKey)) {
				sValue = uojProp.getProperty(key);
				intRetValue = Integer.parseInt(sValue);
				break;
			} else {
				intRetValue = -1;
			}
		}
		return intRetValue;
	}
	/**
	 * Searches for the property with the specified key in this property list.
	 * @param uojKey
	 * @return the integer value in this property list with the specified key value.
	 * @throws         UniSessionException
	 */
	public String getPropertyString(String uojKey) throws UniSessionException {
		if (uojProp == null)
			return "";
		Enumeration enProps = uojProp.propertyNames();
		String key = "";
		String value = "";
		while (enProps.hasMoreElements()) {
			key = (String) enProps.nextElement();
			if (key.equals(uojKey)) {
				value = uojProp.getProperty(key);
				break;
			} else {
				value = "";
			}
		}
		return value;
	}
}