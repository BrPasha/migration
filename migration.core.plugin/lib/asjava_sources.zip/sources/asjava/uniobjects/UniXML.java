/*************************************************************************
 *
 * UniXML.java
 *
 *       IBM Confidential
 *       OCO Source Materials
 *       Copyright (C) IBM Corp.  2004, 2004
 * Module	%M%	Version	%I%	Date	%H%
 *
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 04/22/05 E33623 RKK Generate correct message if connecting to older version of U2
 * 11/03/04 WMY add getErrmsg() and getErrcode()
 * 10/15/04 WMY add two arguments generateXML().
 * 09/14/04 WMY 32728 change catalog name to XMLTODBXMAP/DBTOXMLXMAP
 * 08/26/04 WMY 32722 Initial Creation
 *************************************************************************/

package asjava.uniobjects;
import asjava.uniclientlibs.*;


/**
 * <code>UniXML</code> is used to access to U2 server XML features
 * 
 * @version	Version 2.0.4
 * @author	Weiming Yeh
 * @since		UNIOBJECTS 2.0.4
 */
public class UniXML extends UniBase 
{
	/** 
	 * Default constructor for this class.
	 *
	 * @exception UniXMLException is thrown if an error occurs
	 * @since UNIOBJECTS 2.0.4
	 */
	public UniXML() throws UniXMLException
	{
		throw new UniXMLException( UniObjectsTokens.UVE_MUST_USE_SESSION );
	}
	
	/**
	 * Default constructor for this class.
	 * @param aSession unisession representing the parent sesion object we are created by
	 * @exception UniXMLException is thrown if an error occurs
	 * @since UNIOBJECTS 2.0.4
	 */
	public UniXML( UniSession aSession )
			throws UniXMLException
	{
		if ( aSession == null )
			throw new UniXMLException( UniObjectsTokens.UVE_SESSION_NOT_OPEN );
		uniParentSession 	= aSession;
		uniConnection 		= uniParentSession.connection;
	};
	
	/**
	 * retrieve the contents of retuened strXml after successful <code>generateXML</code> has 
	 * been executed
	 * <code>getXML</code> method, return existing strXml
	 *
	 * @since UNIOBJECTS 2.0.4
	 */
	public String getXML()
	{
		return strXml;
	}
	/**
	 * set strXml to String axml, it is assumed hold xml doc
	 * <code>setXML</code>
	 * @param axml String value of the xml document holder
	 * @since UNIOBJECTS 2.0.4
	 */
	public void setXML(String axml)
	{
		strXml = axml;
	}

	/**
	 * retrieve the contents of retuened strXsd after successful <code>generateXML</code> has 
	 * been executed
	 * it should hold xml schema corresponding to strXml.
	 * <code>getXsd</code> method, return existing strXml
	 *
	 * @since UNIOBJECTS 2.0.4
	 */
	public String getXsd()
	{
			return strXsd;
	}
	/**
	 * set strXsd to String axsd, it is assumed hold xml schema
	 * <code>setXsd</code>
	 * @param axsd String value of the xml schema 
	 * @since UNIOBJECTS 2.0.4
	 */
	public void setXsd(String axsd)
	{
		strXsd = axsd;
	}

	/**
	 *	retrieve contents of errmsg
	 *	@since UNIOBJECTS 2.0.4
	 */
	public String getErrmsg()
	{
		return errString;
	}

	/**
	 *	retrieve contents of errmsg
	 *	@since UNIOBJECTS 2.0.4
	 */
	public int getErrcode()
	{
		return errorCode;
	}

	/**
	 * Executes the cataloged program GETXMLSUB to use the user given
	 * query/sql command to call XMLEXECUTE().
	 * @exception UniXMLException if a server or query error occurs
	 * @param cmd a String represent Uniquery/UniSql command valid for U2 server
	 *	
	 * @since UNIOBJECTS 2.0.4
	 */

 	public void generateXML(String cmd) throws UniXMLException,UniSessionException
	{
		String options = "";

		generateXML(cmd,options);
	}
	/**
	 * Executes the cataloged program GETXMLSUB to use the user given query
	 * or sql command to call XMLEXECUTE().
	 * @exception UniXMLException if a server or query error occurs
	 * @param cmd a String represent Uniquery/UniSql command valid for U2 server
	 * @param options can be @FM or ' ' separated xmlout options.
	 *
	 * @since UNIOBJECTS 2.0.4
	 */
	
	public void generateXML(String cmd,String options) throws UniXMLException,UniSessionException
	{
		UniSubroutine uniSub;

		synchronized ( this ) {
				
			try 
			{
				uniSub = uniParentSession.subroutine("*GETXMLSUB",6);

				uniSub.setArg(0,cmd);
				uniSub.setArg(1,options);
				uniSub.call();
				errString = uniSub.getArg(4);
				errorCode = Integer.parseInt(errString.toString());
				if (errorCode == 0)
				{
					strXml = uniSub.getArg(2);
					strXsd = uniSub.getArg(3);
				}
				else
				{
					// error case from U2 server, however, we don't have a way to display
					// the server error message, so we just use errorCode here

					errString = uniSub.getArg(5);
					
					throw new UniXMLException(errString,errorCode);
				}

			}
			catch ( UniSubroutineException e )
			{
				String s = e.getMessage() + UniErrorMessage.getErrorMessage( UniTokens.UVE_XML_VERIFY_U2VERSION);
				throw new UniXMLException( s,e.getErrorCode());

			}
		} // synchronized this
		
	}
	/**
	 * Execute cataloged basic program DBTOXMLXMAP to generate
	 * xml document using xmap, returns strXml as result 
	 *
	 * @exception UniXMLException if a server error occurs
	 * @param Xmapname a String represent U2 server side xmap file name.
	 *	
	 * @since UNIOBJECTS 2.0.4
	 */

	public void generateXMLUsingXmap(String Xmapname) 
		throws UniXMLException,UniSessionException
	{
		String condition = "";
		UniSubroutine uniSub;

		synchronized ( this ) {
				
			try 
			{
				uniSub = uniParentSession.subroutine("*DBTOXMLXMAP",5);

				uniSub.setArg(0,Xmapname);
				uniSub.setArg(1,condition);
				uniSub.call();
				errString = uniSub.getArg(3);
				errorCode = Integer.parseInt(errString.toString());
				if (errorCode == 0) {
					strXml = uniSub.getArg(2);
					strXsd = "";
					
				}
				else
				{
					// error from U2 server 
					errString = uniSub.getArg(4);
					
					throw new UniXMLException(errString,errorCode);
				}

			}
			catch ( UniSubroutineException e )
			{
				String s = e.getMessage() + UniErrorMessage.getErrorMessage( UniTokens.UVE_XML_VERIFY_U2VERSION);
				throw new UniXMLException( s,e.getErrorCode());

			}
		} // synchronized this
		
		
	}
			
	/**
	 * Execute cataloged basic program XMLTODBXMAP to update the
	 * U2 server datafile using Xmap as defined relationship between the xml
	 * document and file's dictionary defines.
	 * using xml doc stored in strXml in this class to be base of the update
	 *
	 * @exception UniXMLException if a server error occurs
	 *
	 * @param xmapName a String represent U2 server side xmap file name.
	 *	
	 * @since UNIOBJECTS 2.0.4
	 */
	public void updateDataUsingXmap(String xmapName) 
		throws UniXMLException,UniSessionException
	{
		UniSubroutine uniSub;
		
		try
		{
			uniSub = uniParentSession.subroutine("*XMLTODBXMAP",4);

			uniSub.setArg(0,xmapName);
			uniSub.setArg(1,strXml);
			uniSub.setArg(2,"1");
			uniSub.call();
			errString = uniSub.getArg(2);
			errorCode = Integer.parseInt(errString.toString());
			if (errorCode == 0) {
				/* this command does not return anything. but, attempt
				 * to update U2 server side database files.
				 */
				
				return;
			}
			else
			{
				// error from U2 server 
// System.out.print("XMLTODB errString="+errString);
				errString = uniSub.getArg(3);
// System.out.println("arg(3)="+errString);
				throw new UniXMLException(errString,errorCode);
			}
		}
		catch (UniSubroutineException e)
		{
			String s = e.getMessage() + UniErrorMessage.getErrorMessage( UniTokens.UVE_XML_VERIFY_U2VERSION);
			throw new UniXMLException( s,e.getErrorCode());

		}
 	
		

	}

	/**
	 * Execute cataloged basic program XMLTODBXMAP to update the
	 * U2 server datafile using Xmap as defined relationship between the xml
	 * document and file's dictionary defines.
	 * using xml doc stored in U2 server _XML_ / &XML& as xmlName
	 *
	 * @exception UniXMLException if a server error occurs
	 *
	 * @param xmapName a String represent U2 server side xmap file name.
	 * @param xmlName a String represents U2 server side xml doc name.
	 *	
	 * @since UNIOBJECTS 2.0.4
	 */
	public void updateDataUsingXmap(String xmapName,String xmlName)
		throws UniXMLException,UniSessionException
	{
		UniSubroutine uniSub;
		
		try
		{
			uniSub = uniParentSession.subroutine("*XMLTODBXMAP",4);

			uniSub.setArg(0,xmapName);
			uniSub.setArg(1,xmlName);
			uniSub.setArg(2,"0");
			uniSub.call();
			errString = uniSub.getArg(2);
			errorCode = Integer.parseInt(errString.toString());
			if (errorCode == 0) {
				/* this command does not return anything. but, attempt
				 * to update U2 server side database files.
				 */
				return;
			}
			else
			{
				// error from U2 server 
				// errString = uniSub.getArg(3);
				throw new UniXMLException(errorCode);
			}
		}
		catch (UniSubroutineException e)
		{
			String s = e.getMessage() + UniErrorMessage.getErrorMessage( UniTokens.UVE_XML_VERIFY_U2VERSION);
			throw new UniXMLException( s,e.getErrorCode());

		}
 	

	}

	/* Private class variables */
	private static String className ="UniXML";
	private static String strXml = "";
	private static String strXsd = "";
	private static String errString = "";
	private int errorCode = 0;
}
