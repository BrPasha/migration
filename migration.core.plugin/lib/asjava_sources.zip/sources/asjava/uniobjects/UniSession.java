/*************************************************************************
 *
 * UniSession.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 *       IBM Confidential
 *       OCO Source Materials
 *       Copyright (C) IBM Corp.  1993, 2009
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR#  WHO Descrition..........................................
 * 07/15/09 40334 JFM for CP,copyp NLS reltaed properties to the new session obj
 * in connect().
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 03/30/06 E8327  JFM need to update UniTokens.defaultMarkArray[] in setMarks()
 * 10/19/05 E8268  JFM call connection.close() after connection failed
 * 08/11/05 E33998 RKK Proxy not supported when Connection Pooling is ON.
 * 08/02/05 E8041  JFM change setMarks() to also update the default mark chars
 *      in UniTokens because AT_FM, AT_IM ... are used in UniDataSet and some 
 *      other places. This is only a temporary solution that will make the 
 *      -Dclientencoding=xxx work on UniDataSet too. Eventually we'll need 
 *      to upgrade UOJ to have the same level of NLS support in UO.NET.
 * 07/26/05 E33964 RKK  Do not make isServerAlive a public function.
 * 07/12/05 E7815  RKK  Socket alive for connection pooling
 * 01/18/05 e33136 RKK Fix Null Exception by initialising  freedTime.
 * 12/13/04 e32565 JFM synchronized disconnectServer()
 * 12/13/04 e32565 JFM modified connect(), disconnect(), added disconnectServer()
 *                     and connectInternal(). Removed setHostName(),setPassword(),
 *                     setAccountPath(), setUserName()
 * 11/18/04 e32565 RKK Connection Pooling
 * 08/30/04 32722 WMY add UniXML return xml(). for new UniXML class.
 *	changed several @see.
 * 10/03/03 4091  JFM fix getDataSourceType() problem
 * 04/03/03 3495.3496 JFM fixed two NLS related bugs
 * 10/14/02 2607,2609,2984 RKK NLS Stuff
 * 06/04/01 34014 JFM added return code checking in setTaskLock()
 * 05/16/00 27344 JFM fix applet security in proxy connection
 * 05/12/99 24995 DTM Made it connect to 'defcs' or 'uvcs' by default
 * 05/05/99 24995 DTM Made more thread safe
 * 03/01/99 24607 DTM Fixed iconv()/oconv()
 * 11/05/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniobjects;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.util.Date;
import java.util.Locale;

import asjava.uniclientlibs.UniConnection;
import asjava.uniclientlibs.UniConnectionException;
import asjava.uniclientlibs.UniDataSet;
import asjava.uniclientlibs.UniDynArray;
import asjava.uniclientlibs.UniException;
import asjava.uniclientlibs.UniString;
import asjava.uniclientlibs.UniStringException;
import asjava.uniclientlibs.UniTokens;
import asjava.unirpc.UniRPCConnection;
import asjava.unirpc.UniRPCException;
import asjava.unirpc.UniRPCPacket;


/**
 * <code>UniSession</code> acts as the central object for any database connection,
 * controlling access to any and all child objects.  It controls information regarding
 * the connection.  It is from this object that the various sub-objects are created,
 * such as the <code>UniSelectList</code>, <code>UniFile</code>, <code>UniSubroutine</code>
 * and other objects.  Multiple sessions can be created, up to <code>UniJava.getMaxSessions</code>
 *
 *
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since	UNIOBJECTS 1.0
 */
public class UniSession extends UniConnection implements Cloneable
{
	/* Constructor methods */
	
	/**
	 * Constructor for this class.  It establishes the <code>UniRPCConnection</code> object.
	 *
	 * @since UNIOBJECTS 1.0
	 */
	public UniSession()
	{
		/* Create the new UniRPCConnection object for each session */
		connection 			= new UniRPCConnection();
		
		isActive 				= false;
		
		// Set up default mark character array
		initDefaultValues();
	}
	
	public Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}
	
	/**
	 * Constructor for this class.  It establishes the <code>UniRPCConnection</code> object.
	 * This version multiplexes the connection through an existing connection
	 *
	 * @param aSession UniSession representing an existing active session
	 * @exception UniSessionException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public UniSession( UniSession aSession ) throws UniSessionException
	{
		/* Create the new UniRPCConnection object for each session */
		if ( aSession == null )
			throw new UniSessionException( UniObjectsTokens.UVE_SESSION_NOT_OPEN );
		if (( aSession.getSSLMode() == UniObjectsTokens.SECURE_SESSION)
				||
				(aSession.getSSLMode() == UniObjectsTokens.SECURE_PROXY_SESSION)
		)
		{
			throw new UniSessionException( UniObjectsTokens.UVE_MLTPLEX_SECURE_SESSION );
		}
		try
		{
			connection 			= new UniRPCConnection( aSession.connection );
		}
		catch ( UniRPCException e )
		{
			throw new UniSessionException( e.getErrorCode() );
		}
		
		isActive 				= false;
		
		// Set up default mark character arrayT
		initDefaultValues();
	}
	
	/**
	 * Constructor for this class.  It establishes the <code>UniRPCConnection</code> object.
	 *
	 * Allows to create secure SSL session by setting sslflag to true
	 * @since UNIOBJECTS ???
	 */
	public UniSession(int sslmode) throws UniSessionException
	{
		/* Create the new UniRPCConnection object for each session */
		if ( (sslmode != UniObjectsTokens.NON_SECURE_SESSION ) &&
				(sslmode != UniObjectsTokens.SECURE_PROXY_SESSION) &&
				(sslmode != UniObjectsTokens.SECURE_SESSION) &&
				(sslmode != UniObjectsTokens.EXTERNALLY_SECURE_PROXY_SESSION))
		{
			// bad ssl mode throw an exception
			throw new UniSessionException( UniObjectsTokens.UVE_BAD_SSL_MODE);
		}
		connection 			= new UniRPCConnection(sslmode);
		
		// Set up default mark character array
		initDefaultValues();
		
		this.sslMode = sslmode;
	}
	
	protected synchronized void finalize() {
		// GC will call
		// although garbage collector is reclaim this object, we still
		// follow the CloseSession() logic, so that good pooled UniSession can
		// still be resued.
		try {
			UniJava.uniLog("UniSession.finalize called");
			UniJava.closeSessionInternal(this);
		} catch (UniSessionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/* Public Methods */
	
	/**
	 * Creates the command object for this session
	 *
	 * @exception UniSessionException is thrown if there is no active connection or if their is an error
	 *            establishing the <code>UniCommand</code> object
	 * @since UNIOBJECTS 1.0
	 */
	public UniCommand command() throws UniSessionException
	{
		// If connection is active, meaning we have established a connection
		checkEntryConditions();
		
		if ( uniCommand == null )
		{
			try {	uniCommand = new UniCommand( this ); }
			catch ( UniCommandException e )
			{
				throw new UniSessionException( e.getErrorCode() );
			}
		}
		return uniCommand;
	}
	
	
	/**
	 * Gets  a value that indicates whether a connection is alive.
	 * @return true if the connection is alive ; otherwise, false.
	 */
	private boolean isSessionAlive()
	{
		return this.connection.isServerAlive();
	}
	
	/**
	 * Creates the command object for this session, uses the passed in argument as the default command to run
	 *
	 * @param aCommandString String representing the server-side command/stored procedure to be run.  Performs
	 *				an automatic <code>UniCommand.setCommand()</code> as a convenience.
	 * @exception UniSessionException is thrown if there is no active connection or if their is an error
	 *            establishing the <code>UniCommand</code> object
	 * @since UNIOBJECTS 1.0
	 */
	public UniCommand command( Object aCommandString ) throws UniSessionException
	{
		uniCommand = this.command();
		uniCommand.setCommand( aCommandString.toString() );
		return uniCommand;
	}
	
	protected void connectInternal() throws UniSessionException 
	{
		synchronized (this) {
			try {
				// Establish the default RPC connection settings
				if (proxyHost != null) {
					connection.setProxyHost(proxyHost);
					connection.setProxyPort(proxyPort);
					connection.setProxyToken(proxySecurityToken);
				}
				connection.setHost(hostName);
				connection.setPort(hostPort);
				connection.setService(uniConnectionString);
				connection.setTimeoutSeconds(timeout);
				connection.setTransportType(transport);
				//  Try to actually connect to the server
				if (sslMode == UniObjectsTokens.NON_SECURE_SESSION) {
					try {
						connection.connect();
					} catch (UniException e) {
						this.setRPCError(true);
						// Need to retry the connection, in case
						// it's an old pre common middleware connection,
						// still using the 'uvcs' tag, instead of 'defcs'
						connection.setService(UniObjectsTokens.UVCS_SERVICE);
						connection.connect();
					}
				} else if ((sslMode == UniObjectsTokens.SECURE_SESSION)
						|| (sslMode == UniObjectsTokens.SECURE_PROXY_SESSION)) {
					//completely secure connection
					connection.sconnect(uSSLD);
				} else if (sslMode == UniObjectsTokens.EXTERNALLY_SECURE_PROXY_SESSION) {
					//externally secure connection with proxy
					//check that it is a proxy connection
					if (proxyHost != null) {
						if (sslMode == UniObjectsTokens.EXTERNALLY_SECURE_PROXY_SESSION) {
							connection.espconnect(uSSLD, false);
						} else {
							connection.espconnect(uSSLD, true);
						}
					} else {
						// not a proxy session; throw an exception
						throw new UniSessionException(
								UniObjectsTokens.UVE_NOT_A_PROXY_SESSION);
					}
				} else {
					// incorrect ssl mode; throw an exception
					throw new UniSessionException(
							UniObjectsTokens.UVE_BAD_SSL_MODE);
				}
				// Establish inPacket and outPacket objects with this session
				outPacket = new UniRPCPacket(connection);
				inPacket = new UniRPCPacket(connection);
				// validate that we have a user name and account specified
				if ((userName == null) || (userName.equals("")))
					throw new UniSessionException(
							UniObjectsTokens.UVE_BAD_LOGINNAME);
				if ((accountPath == null) || (accountPath.equals("")))
					throw new UniSessionException(UniObjectsTokens.UVE_BADDIR);
				switch (getServerVersion()) {
				// With an old server (pre-9.5), pretend we are an old
				// client
				case UniObjectsTokens.OLD_SERVER :
					//  Try to actually login
					outPacket.write(0, UniObjectsTokens.OLD_COMMS_VERSION);
				outPacket.write(1, UniObjectsTokens.OLD_CS_VERSION);
				outPacket.write(2, encode(userName));
				outPacket.write(3, encode(encrypt(password))); // encrypt the
				// password
				outPacket.write(4, encode(accountPath));
				outPacket.write(5, encode(licenseToken));
				outPacket.write(6, UniObjectsTokens.INTERNAL_FLAG);
				break;
				// With a new server, we send the new COMMS_VERSION and
				// CS_VERSION as
				// required, as well as the client-side licensing
				// information
				case UniObjectsTokens.NEW_SERVER :
				default :
					//  Try to actually login
					outPacket.write(0, UniObjectsTokens.COMMS_VERSION);
				outPacket.write(1, UniObjectsTokens.CS_VERSION);
				outPacket.write(2, encode(userName));
				outPacket.write(3, encode(encrypt(password))); // encrypt the
				// password
				outPacket.write(4, encode(accountPath));
				outPacket.write(5, encode(licenseToken));
				outPacket.write(6, UniObjectsTokens.INTERNAL_FLAG);
				outPacket.write(7, getIPaddress());
				outPacket.write(8, encode(getMacAddress()));
				outPacket.write(9, encode(getDeviceName()));
				outPacket.write(10, encode(getDeviceSubkey()));
				//					 J.Mao for CP licensing
				if (UniJava.getUOPooling()) {
					if (IsCPSupported(connection.getServerId()))
						outPacket.write(11, 1);
					else {
						throw new UniSessionException(
								UniTokens.UVE_CP_NOTSUPPORTED);
					}
				} else
					// may not need to send it
					outPacket.write(11, 0);
				// Need to add the new client server logic here...
				break;
				}
				connection.call(outPacket, inPacket);
				uniReturnCode = inPacket.readInteger(0);
				if (uniReturnCode == 0) {
					// Ok, now let's get the session information
					getHostInfo();
					// Ok, now let's see if NLS is initialized.
					nlsInit();
					// If we made it this far, we are all set...
					isActive = true;
				} else {
					connection.close();
					throw new UniSessionException(uniReturnCode);
				}
			} catch (UniRPCException e) {
				throw new UniSessionException(e.getErrorCode());
			}
		} // synch this
		
	}
	/**
	 * Opens up the session on the host identified with the <code>setHost</code> method.
	 * It uses the values established with the <code> setUserName, setPassword, setAccountPath,
	 * setProxyHost, and setProxySecurityToken</code> methods.  If an error occurs during
	 * the connection request, a UniSessionException is thrown.
	 *
	 * @exception UniSessionException is thrown if the connection cannot be established
	 * @see asjava.uniclientlibs.UniConnection#setUserName
	 * @see asjava.uniclientlibs.UniConnection#setHostName
	 * @see asjava.uniclientlibs.UniConnection#setHostPort
	 * @see asjava.uniclientlibs.UniConnection#setPassword
	 * @see asjava.uniclientlibs.UniConnection#setAccountPath
	 * @see asjava.uniclientlibs.UniConnection#setProxyHost
	 * @see asjava.uniclientlibs.UniConnection#setProxyPort
	 * @see asjava.uniclientlibs.UniConnection#setProxyToken
	 * @since UNIOBJECTS 1.0
	 */
	public void connect() throws UniSessionException {
		// when Pooling is off or proxy is on
		if (UniJava.getUOPooling() == false || proxyHost != null)
			connectInternal();
		else if(UniJava.getUOPooling() ==  true && proxyHost != null){
			throw new UniSessionException(UniObjectsTokens.UVE_PROXY_NOTSUPPORTED_WHEN_CP_ON);
			
		}
		else {
			synchronized (this) {
				UniSession us = UniJava.openPooledSession(hostName,hostPort,userName,
						password,accountPath,uniConnectionString,sslMode);
				
				connection 	= us.connection;
				inPacket = us.inPacket;
				outPacket = us.outPacket;
				uniMarkCharacters = us.uniMarkCharacters;

				uniMarkBytes = us.uniMarkBytes;
				encoding = us.encoding;
				charset = us.charset;
				
				uniConnectionString		= us.uniConnectionString;
				uniDataSourceType		= us.uniDataSourceType;
				proxyHost 				= us.proxyHost;
				proxySecurityToken		= us.proxySecurityToken;
				licenseToken 	= us.licenseToken;
				uniSubKey		= us.uniSubKey;
				hostPort 		= us.hostPort;
				proxyPort 		= us.proxyPort;
				transport 		= us.transport; 
				compressionThreshold 	= us.compressionThreshold; 
				timeout 		= us.timeout; 
				encryptionType	= us.encryptionType;	
				hostType 		= us.hostType;
				isNLSEnabled 	= us.isNLSEnabled;
				isNLSLocalesEnabled	= us.isNLSLocalesEnabled;	
				isActive 			= us.isActive;
				isRPCError 			= us.isRPCError;
				isNLSUnidataSession = us.isNLSUnidataSession;
				
				uniNLSMap  = us.uniNLSMap;
				uniNLSLocale  = us.uniNLSLocale;
				sslMode = us.sslMode;
				uniTransaction	= us.uniTransaction;
				uniCommand	 = us.uniCommand;
				atVariableArray = us.atVariableArray;
				blockingStrategy = us.blockingStrategy;
				lockStrategy 	= us.lockStrategy;
				releaseStrategy = us.releaseStrategy;
				uniReturnCode = us.uniReturnCode;
				numOpenFiles = us.numOpenFiles;
				uniStatus	  = us.uniStatus;
				uSSLD         = us.uSSLD;
				pooledSession = us.pooledSession;
				creationTime =us.creationTime;
				freedTime = us.freedTime;
				
				us.connection = null;
				us.initDefaultValues();
				us = null;
			}
			
		}
		
	}
	
	/**
	 * Establishes connection to the Host passed in, using the Username,
	 * Password, and initial account path passed in.
	 * 
	 * @param aHost
	 *            String representing the host to connect to. Either the name of
	 *            the host or the IP address (ex. 192.102.111.1)
	 * @param aUser
	 *            String representing the user name on the server machine.
	 * @param aPass
	 *            String representing the password on the server machine
	 * @param aPath
	 *            String representing the account path to log into on the server
	 *            machine
	 * @exception UniSessionException
	 *                is thrown if the connection cannot be made
	 * @since UNIOBJECTS 1.0
	 */
	public void connect( Object aHost, Object aUser, Object aPass, Object aPath ) throws UniSessionException
	{
		synchronized ( this ) {
			super.setHostName( aHost );
			super.setUserName( aUser );
			super.setPassword( aPass );
			super.setAccountPath( aPath );
			connect();
		} // synch this
	}
	
	/**
	 * Establishes connection to the Host/Port passed in, using the Username, Password, and
	 * initial account path passed in.
	 *
	 * @param aHost String representing the host to connect to.  Either the name of the host
	 *              or the IP address (ex. 192.102.111.1)
	 * @param aPortNumber integer representing the port to connect to
	 * @param aUser String representing the user name on the server machine.
	 * @param aPass String representing the password on the server machine
	 * @param aPath String representing the account path to log into on the server machine
	 * @exception UniSessionException is thrown if the connection cannot be made
	 * @since UNIOBJECTS 1.0
	 */
	public void connect( Object aHost, int aPortNumber, Object aUser, Object aPass, Object aPath ) throws UniSessionException
	{
		synchronized ( this ) {
			setHostPort( aPortNumber );
			connect( aHost, aUser, aPass, aPath );
		} // synch this
	}
	
	
	/**
	 * Establishes connection to the Host passed in, using the Username, Password, and
	 * initial account path passed in.
	 *
	 * @param aHost String representing the host to connect to.  Either the name of the host
	 *              or the IP address (ex. 192.102.111.1)
	 * @param aUser String representing the user name on the server machine.
	 * @param aPass String representing the password on the server machine
	 * @param aPath String representing the account path to log into on the server machine
	 * @param aProxyHost String representing the proxy host to connect to.  Either the name
	 *              of the host or the IP address.
	 * @param aProxyToken string representing the Proxy password
	 * @exception UniSessionException is thrown if the connection cannot be made
	 * @since UNIOBJECTS 1.0
	 */
	public void connect( Object aHost, Object aUser, Object aPass, Object aPath,
			Object aProxyHost, Object aProxyToken ) throws UniSessionException
			{
		synchronized ( this ) {
			setProxyHost( aProxyHost );
			setProxyToken( aProxyToken );
			connect( aHost, aUser, aPass, aPath );
		}//synch this
			}
	
	
	/**
	 * Establishes connection to the Host passed in, using the Username, Password, and
	 * initial account path passed in.
	 *
	 * @param aHost String representing the host to connect to.  Either the name of the host
	 *              or the IP address (ex. 192.102.111.1)
	 * @param aUser String representing the user name on the server machine.
	 * @param aPass String representing the password on the server machine
	 * @param aPath String representing the account path to log into on the server machine
	 * @param aProxyHost String representing the proxy host to connect to.  Either the name
	 *              of the host or the IP address.
	 * @param aProxyToken string representing the Proxy password
	 * @exception UniSessionException is thrown if the connection cannot be made
	 * @since UNIOBJECTS 1.0
	 */
	public void connect( Object aHost, Object aUser, Object aPass, Object aPath,
			Object aProxyHost, int aProxyPort, Object aProxyToken ) throws UniSessionException
			{
		synchronized ( this ) {
			setProxyPort( aProxyPort );
			connect( aHost, aUser, aPass, aPath, aProxyHost, aProxyToken );
		} // synch this
			}
	
	/**
	 * Establishes connection to the Host passed in, using the Username, Password, and
	 * initial account path passed in.
	 *
	 * @param aHost String representing the host to connect to.  Either the name of the host
	 *              or the IP address (ex. 192.102.111.1)
	 * @param aUser String representing the user name on the server machine.
	 * @param aPass String representing the password on the server machine
	 * @param aPath String representing the account path to log into on the server machine
	 * @param aProxyHost String representing the proxy host to connect to.  Either the name
	 *              of the host or the IP address.
	 * @param aProxyToken string representing the Proxy password
	 * @exception UniSessionException is thrown if the connection cannot be made
	 * @since UNIOBJECTS 1.0
	 */
	public void connect( Object aHost, int aHostPort, Object aUser, Object aPass, Object aPath, Object aProxyHost, Object aProxyToken ) throws UniSessionException
	{
		synchronized ( this ) {
			setHostPort( aHostPort );
			connect( aHost, aUser, aPass, aPath, aProxyHost, aProxyToken );
		}// synch this
	}
	
	/**
	 * Terminates an active connection.  If the connection has not been established, will just return
	 *
	 * @exception UniSessionException occurs is an error occurs during the termination
	 * @see #connect
	 * @since UNIOBJECTS 1.0
	 */
	public void disconnect() throws UniSessionException
	{
		synchronized ( this ){
			UniJava.closeSessionInternal(this);
		}// synch this
	}
	
	// to close the server connection
	protected void disconnectServer() throws UniSessionException
	{
		synchronized (this) {
			if (!isActive) return;
			
			//  Try to close the connection
			try
			{
				connection.close();
				
				// Reset all the old values back to their default values
				initDefaultValues();
				connection = null;
			}
			catch (UniRPCException e)
			{
				this.setRPCError(true);
				throw new UniSessionException( e.getErrorCode() );
			}
		}
	}
    
    /**
     * Creates an empty UniDataSet
     *
     * @since UNIOBJECTS 2.0
     */
    public UniDataSet dataSet()
    {
        return new UniDataSet(this);
    }
    
	
	/**
	 * Creates an empty dynamic array
	 *
	 * @since UNIOBJECTS 1.0
	 */
	public UniDynArray dynArray()
	{
		return new UniDynArray(this);
	}
	
	/**
	 * Creates a dynamic array from the given object
	 *
	 * @param aString object by which the dynamic array will be initialized with
	 * @since UNIOBJECTS 1.0
	 */
	public UniDynArray dynArray( Object aString )
	{
		return new UniDynArray(this, aString );
	}
	
	/**
	 * returns the current value of the @variable specified by the input parameter.  Valid
	 * values for the input value are:
	 * <ul>
	 * <li> Token (Value)							UniVerse @Variable
	 * <li> AT_LOGNAME(1)							@LOGNAME
	 * <li> AT_PATH(2)								@PATH
	 * <li> AT_USERNO(3)							@USERNO
	 * <li> AT_WHO(4)									@WHO
	 * <li> AT_TRANSACTION(5)					@TRANSACTION
	 * <li> AT_DATA_PENDING(6)				@DATA.PENDING
	 * <li> AT_USER_RETURN_CODE(7)		@USER.RETURN.CODE
	 * <li>	AT_SYSTEM_RETURN_CODE(8)	@SYSTEM.RETURN.CODE
	 * <li> AT_NULL_STR(9)						@NULL.STR
	 * <li> AT_SCHEMA(10)							@SCHEMA
	 * </ul>
	 *
	 * @param aTokenVal integer representing which @variable to return.
	 * @return String representing the @variable requested
	 * @exception UniSessionException is thrown if an illegal argument is passed in
	 * @see #setAtVariable
	 * @since UNIOBJECTS 1.0
	 */
	public String getAtVariable( int aTokenVal ) throws UniSessionException
	{
//		if (( aTokenVal < UniObjectsTokens.AT_LOGNAME ) || ( aTokenVal > UniObjectsTokens.AT_SCHEMA ))
//			throw new UniSessionException( "@Variable key must be between 1-10", UniObjectsTokens.UVE_EINVAL );
		
		return getValue( aTokenVal );
	}
	
	/**
	 * returns the default blocking strategy for this session.  This controls the default behavior of what
	 * requests that block on another lock do.  It can be overriden by individual objects or requests.
	 * Valid values are:
	 * <ul>
	 * <li> WAIT_ON_LOCKED (1) - If record is locked, wait until it is released.
	 * <li> RETURN_ON_LOCKED (2) - Return a value to the <code>status</code> method to indicate the state of the
	 *														 lock. This is the default value.
	 * </ul>
	 *
	 * @return integer representing the current default blocking strategy
	 * @see #setDefaultBlockingStrategy
	 * @since UNIOBJECTS 1.0
	 */
	public int getDefaultBlockingStrategy()
	{
		return blockingStrategy;
	}
	
	/**
	 * returns the default locking strategy for this session.  This controls the default behavior of what
	 * type of lock is to be set when data is manipulated.  It can be overriden by individual objects or requests.
	 * Valid values are:
	 * <ul>
	 * <li> NO_LOCKS (0) - no locking is to be performed.  This is the default.
	 * <li> EXCLUSIVE_UPDATE (1) - Set an exclusive update lock (READU)
	 * <li> SHARED_READ (2) - Sets a shared read lock (READL)
	 * </ul>
	 *
	 * @return integer representing the current default locking strategy
	 * @see #setDefaultLockStrategy
	 * @since UNIOBJECTS 1.0
	 */
	public int getDefaultLockStrategy()
	{
		return lockStrategy;
	}
	
	/**
	 * returns the default release strategy for this session.  This controls the default behavior of what
	 * requests that manipulate data does to existing locks.  It can be overriden by individual objects or requests.
	 * Valid values are:
	 * <ul>
	 * <li> WRITE_RELEASE (1) - Releases the lock when the record is written.  This is the default.
	 * <li> READ_RELEASE (2) - Releases the lock when the record is read.
	 * <li> EXPLICIT_RELEASE (4) - maintains locks as specified by the <code>LockStrategy</code>.
	 *                             requires an <code>unlockRecord</code> method to unlock the record.
	 * <li> CHANGE_RELEASE (8) - releases the lock whenever a new value is assigned to the recordID property via
	 *                             the <code>setRecordID</code> method.
	 * <ul>
	 *
	 * @return integer representing the current default release strategy
	 * @see #setDefaultReleaseStrategy
	 * @since UNIOBJECTS 1.0
	 */
	public int getDefaultReleaseStrategy()
	{
		return releaseStrategy;
	}
	
	/**
	 * returns the maximum number of <code>UniFile</code> objects we can open at any one time.
	 * A return value of 0 means there is no limit.
	 *
	 * @return integer representing the maximum number of files that can be opened.
	 * @since UNIOBJECTS 1.0
	 */
	public int getMaxOpenFiles()
	{
		return UniObjectsTokens.MAX_OPEN_FILES;
	}
	
	/**
	 * returns the current number of open <code>UniFile</code> objects.
	 *
	 * @return integer representing the number of currently active <code>UniFile</code> objects
	 * @since UNIOBJECTS 1.0
	 */
	public int getNumOpenFiles()
	{
		return numOpenFiles;
	}
	
	public UniSSLDescriptor getSSLDescriptor()
	{
		return uSSLD;
	}
	
	/**
	 * converts an input string into a UniVerse internal storage format using the
	 * conversion format specified.  The <code>status</code> function can be used
	 * after this method to determine the status of the <code>iconv</code> method.
	 *
	 * @param aString input string that is to be converted
	 * @param aConvCode conversion code used to convert the string
	 * @return UniString representing the newly converted string
	 * @exception UniStringException is thrown if an error occurs
	 * @see #oconv
	 * @see #status
	 * @since UNIOBJECTS 1.0
	 */
	public UniString iconv( Object aString, Object aConvCode ) throws UniStringException
	{
		synchronized ( this ) {
			UniString tmpString = new UniString(this, aString );
			UniString retVal =  tmpString.iconv( this, aConvCode );
			this.uniStatus = tmpString.status();
			return retVal;
		} // snch this
	}
	/**
	 * returns false if the session is SSL secure session; true otherwise
	 * @since UNIOBJECTS ???
	 */
	public boolean isnSecure()
	{
		if (this.sslMode == UniObjectsTokens.NON_SECURE_SESSION)
			return true;
		else
			return false;
	}
	
	public int getSSLMode()
	{
		return this.sslMode;
	}
	
	/**
	 * If NLS is enabled on the server machine, this method will return an active <code>UniNLSlocale</code>
	 * object, which can then be used to manipulate server-side NLS Locale settings.
	 *
	 * @return UniNLSlocale object representing the state of the server-side NLS Locale.
	 * @exception UniSessionException is thrown if an error occurs
	 * @see #nlsMap
	 * @since UNIOBJECTS 1.0
	 */
	
	
	public UniNLSlocale nlsLocale() throws UniSessionException
	{
		checkEntryConditions();
		
		// do not create UniNLSlocale Object if unidata session is on
		if ( isNLSEnabled  && isNLSUnidataSession == false)
		{	// Only create one uniNLSLocale object per session
			if ( uniNLSLocale == null )
			{
				uniNLSLocale = new UniNLSlocale( this );
			}
		}
		return uniNLSLocale;
	}
	
	/**
	 * If NLS is enabled on the server machine, this method will return an active <code>UniNLSmap</code>
	 * object, which can then be used to manipulate server-side NLS Map settings.
	 *
	 * @return UniNLSmap object representing the state of the server-side NLS map.
	 * @exception UniSessionException is thrown if an error occurs
	 * @see #nlsLocale
	 * @since UNIOBJECTS 1.0
	 */
	public UniNLSmap nlsMap() throws UniSessionException
	{
		checkEntryConditions();
		
		// do not create UniNLSmap Class if unidata session is on
		if ( isNLSEnabled  && isNLSUnidataSession == false )
		{	// Only create one uniNLSMap object per session
			if ( uniNLSMap == null )
			{
				uniNLSMap = new UniNLSmap( this );
			}
		}
		return uniNLSMap;
	}
	
	/**
	 * converts an output string into a UniVerse output storage format using the
	 * conversion format specified.  The <code>status</code> function can be used
	 * after this method to determine the status of the <code>oconv</code> method.
	 *
	 * @param aString input string that is to be converted
	 * @param aConvCode conversion code used to convert the string
	 * @return UniString representing the newly converted string
	 * @exception UniStringException is thrown if an error occurs
	 * @see #iconv
	 * @see #status
	 * @since UNIOBJECTS 1.0
	 */
	public UniString oconv( Object aString, Object aConvCode ) throws UniStringException
	{
		synchronized ( this ) {
			UniString tmpString = new UniString(this,aString );
			UniString retVal =  tmpString.oconv( this, aConvCode );
			this.uniStatus = tmpString.status();
			return retVal;
		} // synch this
	}
	
	/**
	 * returns a new <code>UniFile</code> object.
	 *
	 * @param aFileName name of the universe file to be opened.
	 * @return UniFile object representing the newly opened file
	 * @exception UniSessionException is thrown if there is an error
	 * @since UNIOBJECTS 1.0
	 */
	public UniFile openFile( Object aFileName ) throws UniSessionException
	{
		checkEntryConditions();
		
		try {
			return new UniFile( this, aFileName, 0 );
		}
		catch ( UniFileException e )
		{
			throw new UniSessionException( e.getErrorCode() );
		}
	}
	
	/**
	 * returns a new <code>UniFile</code> object.
	 *
	 * @param aFileName name of the universe file to be opened.
	 * @return UniFile object representing the newly opened file
	 * @exception UniSessionException is thrown if there is an error
	 * @since UNIOBJECTS 1.0
	 */
	public UniFile open( Object aFileName ) throws UniSessionException
	{
		return openFile( aFileName );
	}
	
	/**
	 * returns a new <code>UniDictionary</code> object.
	 *
	 * @param aFileName name of the universe dictionary file to be opened.
	 * @return UniDictionary object representing the newly opened dictionary file
	 * @exception UniSessionException is thrown if there is an error
	 * @since UNIOBJECTS 1.0
	 */
	public UniDictionary openDict( Object aFileName ) throws UniSessionException
	{
		checkEntryConditions();
		
		try{
			return new UniDictionary( this, aFileName, 1 );
		}
		catch ( UniFileException e )
		{
			throw new UniSessionException( e.getErrorCode() );
		}
	}
	
	/**
	 * returns a new <code>UniSequentialFile</code> object.
	 *
	 * @param aFileName name of the sequential file to be opened.  A UniVerse Type 1 or 19 file
	 * @param aRecordID refers to a record within the file, optionally created if it does not exist
	 * @param aCreateFlag boolean denoting whether or not the file should be created if it does not exist.
	 * @exception UniSessionException is thrown if there is an error
	 * @return UniSequentialFile object representing the newly opened sequential file
	 * @since UNIOBJECTS 1.0
	 */
	public UniSequentialFile openSeq( Object aFileName, Object aRecordID, boolean aCreateFlag )
	throws UniSessionException
	{
		checkEntryConditions();
		
		try
		{
			return new UniSequentialFile( this, aFileName, aRecordID, aCreateFlag );
		}
		catch ( UniSequentialFileException e )
		{
			throw new UniSessionException( e.getErrorCode() );
		}
	}
	
	/**
	 * used to release a <code>TaskLock</code> that was set previously using the <code>setTaskLock</code>
	 * method.
	 *
	 * @param aLockNum integer representing which of the 64 UniVerse task locks is to be set.
	 * @exception UniSessionException is thrown if an error occurs.
	 * @see #setTaskLock
	 * @since UNIOBJECTS 1.0
	 */
	public void releaseTaskLock( int aLockNum ) throws UniSessionException
	{
		synchronized ( this ) {
			checkEntryConditions();
			
			if (( aLockNum < 0 ) || ( aLockNum > 64 ))
			{
				throw new UniSessionException( UniObjectsTokens.UVE_LOCKINVALID );
			}
			
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_UNLOCK );
				outPacket.write( 1, aLockNum );
				
				connection.call( outPacket, inPacket );
				uniReturnCode = inPacket.readInteger( 0 );
			}
			catch ( UniRPCException e )
			{
				this.setRPCError(true);
				throw new UniSessionException( e.getErrorCode() );
			}
		} // synch this
	}
	
	/**
	 * returns a newly created <code>UniSelectList</code> object
	 *
	 * @param aSelectListNumber which UniVerse select list to create
	 * @exception UniSessionException is thrown if an error occurs
	 * @return UniSelectList object
	 * @since UNIOBJECTS 1.0
	 */
	public UniSelectList selectList( int aSelectListNumber ) throws UniSessionException
	{
		checkEntryConditions();
		
		try {		return new UniSelectList( this, aSelectListNumber ); }
		catch ( UniSelectListException e )
		{
			throw new UniSessionException( e.getErrorCode() );
		}
	}
	
	/**
	 * sets the given @variable to the value passed in. Only affects UniObjectsTokens.AT_USER_RETURN_CODE
	 * (value = 7 )
	 *
	 * @param aTokenVal integer representing which @variable to set
	 * @param aAtVariable String representing the @variables new value
	 * @exception UniSessionException is thrown if an invalid aTokenVal is passed in
	 * @see #getAtVariable
	 * @since UNIOBJECTS 1.0
	 */
	public void setAtVariable( int aTokenVal, Object aAtVariable ) throws UniSessionException
	{
		if ( aTokenVal == UniObjectsTokens.AT_USER_RETURN_CODE 
				|| aTokenVal == UniObjectsTokens.AT_POOLING_USER)
			setValue( aTokenVal, aAtVariable.toString() );
	}
	
	/**
	 * sets the current <code>CompressionThreshold</code> value.
	 *
	 * @param aCompressionThresholdVal integer representing the amount, in bytes, to set the compression
	 *                                 threshold to
	 * @exception UniSessionException is thrown if an invalid aCompressionThresholdVal is passed in
	 * @since UNIOBJECTS 1.0
	 */
	public void setCompressionThreshold( int aCompressionThresholdVal ) throws UniSessionException
	{
		try{
			this.setCompressionThresholdInt( aCompressionThresholdVal );
		}
		catch ( UniConnectionException e )
		{
			throw new UniSessionException( e.getErrorCode() );
		}
	}
	
	/**
	 * sets the default blocking strategy
	 *
	 * @param aBlockingStrategy integer representing the default blocking strategy
	 * @exception UniSessionException is thrown if an invalid aBlockingStrategy is passed in
	 * @see #getDefaultBlockingStrategy
	 * @since UNIOBJECTS 1.0
	 */
	public void setDefaultBlockingStrategy( int aBlockingStrategy ) throws UniSessionException
	{
		if (( aBlockingStrategy < 1 ) || ( aBlockingStrategy > 2 ))
		{
			throw new UniSessionException("UniSession.setDefaultBlockingStrategy() failed:  Strategy either" +
					"WAIT_ON_LOCKED (1) or RETURN_ON_LOCKED(2)",	UniObjectsTokens.UVE_EINVAL );
		}
		
		blockingStrategy = aBlockingStrategy;
	}
	
	/**
	 * sets the current default encryption type to be used for this session.  All subobjects will inherit this
	 * value unless specifically overriden.  It controls the type of encryption that is to be used for data transfer.
	 * Valid values are:
	 * <ul>
	 * <li> NO_ENCRYPTION (0) - no encryption is to be done.  This is the default value.
	 * <li> INTERNAL_ENCRYPTION (1) - use UniVerse internal encryption.
	 * /ul>
	 *
	 * @param aEncryptionType integer representing the type of encryption that is to be used.
	 * @exception UniSessionException is thrown if an invalid aType is passed in
	 * @since UNIOBJECTS 1.0
	 */
	public void setDefaultEncryptionType( int aEncryptionType ) throws UniSessionException
	{
		try{
			this.setDefaultEncryptionTypeInt( aEncryptionType );
		}
		catch ( UniConnectionException e )
		{
			throw new UniSessionException( e.getErrorCode() );
		}
	}
	
	/**
	 * sets the default locking strategy
	 *
	 * @param aLockingStrategy integer representing the default locking strategy
	 * @exception UniSessionException is thrown if an invalid aLockingStrategy is passed in
	 * @see #getDefaultLockStrategy
	 * @since UNIOBJECTS 1.0
	 */
	public void setDefaultLockStrategy( int aLockingStrategy ) throws UniSessionException
	{
		if (( aLockingStrategy < 0 ) || ( aLockingStrategy > 2 ))
		{
			throw new UniSessionException("UniSession.setDefaultLockStrategy() failed:  Strategy either" +
					"NO_LOCKS (0), EXCLUSIVE_UPDATE (1) or SHARED_READ(2)",	UniObjectsTokens.UVE_EINVAL );
		}
		
		lockStrategy = aLockingStrategy;
	}
	
	/**
	 * sets the default release strategy
	 *
	 * @param aReleaseStrategy integer representing the default release strategy
	 * @exception UniSessionException is thrown if an invalid aReleaseStrategy is passed in
	 * @see #getDefaultReleaseStrategy
	 * @since UNIOBJECTS 1.0
	 */
	public void setDefaultReleaseStrategy( int aReleaseStrategy ) throws UniSessionException
	{
		if (( aReleaseStrategy < 0 ) || ( aReleaseStrategy > 8 ))
		{
			throw new UniSessionException("UniSession.setDefaultReleaseStrategy() failed:  Strategy either" +
					"WRITE_RELEASE (1), READ_RELEASE (2), EXPLICIT_RELEASE (4) or CHANGE_RELEASE (8)", UniObjectsTokens.UVE_EINVAL );
		}
		
		releaseStrategy = aReleaseStrategy;
	}
	
	public void setSSLDescriptor(UniSSLDescriptor ussld)
	{
		this.uSSLD = ussld;
	}
	
	/**
	 * used to set on of the 64 UniVerse synchronization locks.
	 *
	 * @param aLockNum integer representing which one of the 64 UniVerse synchronization locks is to be set
	 * @exception UniSessionException is thrown is an error occurs in obtaining the task lock
	 * @see #releaseTaskLock
	 * @since UNIOBJECTS 1.0
	 */
	public void setTaskLock( int aLockNum ) throws UniSessionException
	{
		synchronized ( this ) {
			checkEntryConditions();
			
			if (( aLockNum < 0 ) || ( aLockNum > 64 ))
			{
				throw new UniSessionException( UniObjectsTokens.UVE_LOCKINVALID );
			}
			
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_LOCK );
				outPacket.write( 1, aLockNum );
				
				connection.call( outPacket, inPacket );
				uniReturnCode = inPacket.readInteger( 0 );
				if (uniReturnCode != 0)
					throw new UniSessionException(UniTokens.UVE_LCK);
				
			}
			catch ( UniRPCException e )
			{
				this.setRPCError(true);
				throw new UniSessionException( e.getErrorCode() );
			}
		} // synch this
	}
	
	/**
	 * Sets the UniRPC timeout value.  Initially, it is set to 0, indicating no timeout is to occur.  If it is set
	 * to a value > 0, the UniRPC will timeout after that many seconds.
	 *
	 * @param aTimeoutVal integer representing the number of seconds the UniRPC should wait until it times out.
	 * @exception UniSessionException is thrown if the timeout cannot be set
	 * @since UNIOBJECTS 1.0
	 */
	public void setTimeout( int aTimeoutVal ) throws UniSessionException
	{
		try{
			this.setTimeoutInt( aTimeoutVal );
		}
		catch ( UniConnectionException e )
		{
			this.setRPCError(true);
			throw new UniSessionException( e.getErrorCode() );
		}
	}
	

    /**
     * Sets the MArks from NLSMap Object
     *
     * @param MarksArray integer representing the number of seconds the UniRPC should wait until it times out.
     * @exception UniSessionException is thrown if the timeout cannot be set
     * @since UNIOBJECTS 1.0
     */
    protected void setMarks(String[] MarksArray) {
        uniMarkCharacters = MarksArray;
        UniTokens.AT_IM = uniMarkCharacters[0];
        UniTokens.AT_FM = uniMarkCharacters[1];
        UniTokens.AT_VM = uniMarkCharacters[2];
        UniTokens.AT_SVM = uniMarkCharacters[3];
        UniTokens.AT_TM = uniMarkCharacters[4];
        UniTokens.AT_SQLNULL = uniMarkCharacters[5];
        UniTokens.defaultMarkArray[0] = UniTokens.AT_IM;
        UniTokens.defaultMarkArray[1] = UniTokens.AT_FM;
        UniTokens.defaultMarkArray[2] = UniTokens.AT_VM;
        UniTokens.defaultMarkArray[3] = UniTokens.AT_SVM;
        UniTokens.defaultMarkArray[4] = UniTokens.AT_TM;
        UniTokens.defaultMarkArray[5] = UniTokens.AT_SQLNULL;
    }
		
	/**
	 * returns information concerning the state of certain operations.  See those methods for more details
	 *
	 * @return integer representing the status of the last operation performed.
	 * @see #connect
	 * @since UNIOBJECTS 1.0
	 */
	public int status()
	{
		return uniStatus;
	}
	
	/**
	 * returns a new <code>UniSubroutine</code> representing the new subroutine object created.
	 *
	 * @param aSubName String representing the name of the subroutine to be executed on the server.
	 * @param aNumArgs integer representing the number of arguments this subroutine has
	 * @return UniSubroutine object representing the new subroutine
	 * @exception UniSessionException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public UniSubroutine subroutine( Object aSubName, int aNumArgs ) throws UniSessionException
	{
		checkEntryConditions();
		try
		{
			return new UniSubroutine( this, aSubName, aNumArgs );
		}
		catch ( UniSubroutineException e )
		{
			throw new UniSessionException( e.getErrorCode() );
		}
	}
	
	/**
	 * returns a new <code>UniXML</code> representing the new xml object created.
	 *
	 * @return UniXML object representing the new xml
	 * @exception UniSessionException is thrown if an error occurs
	 * @since UNIOBJECTS 2.4
	 */
	public UniXML xml( ) throws UniSessionException
	{
		checkEntryConditions();
		try
		{
			return new UniXML( this );
		}
		catch ( UniXMLException e )
		{
			throw new UniSessionException( e.getErrorCode() );
		}
	}
	
	/**
	 * returns a new <code>UniTransaction</code> object to allow transactional control
	 * of the session.
	 *
	 * @return UniTransaction object allow modification of the sessions transactional behavior
	 * @exception UniSessionException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	public UniTransaction transaction() throws UniSessionException
	{
		checkEntryConditions();
		if (this.uniTransaction == null) {
			try {
				uniTransaction = new UniTransaction(this);
			} catch (UniTransactionException e) {
				throw new UniSessionException(e.getErrorCode());
			}
		}
		return uniTransaction;
	}
	
	
	/* Private Methods */
	/**
	 * used to get a AT value from the server
	 *
	 * @param key integer representing the key value requested
	 * @return String representing the UniVerse session @variable
	 * @exception UniSessionException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	protected String getValue( int key ) throws UniSessionException
	{
		synchronized ( this ) {
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_GETVALUE );
				outPacket.write( 1, key );
				
				connection.call( outPacket, inPacket );
				
				int uniReturnCode = inPacket.readInteger( 0 );
				
				if ( uniReturnCode == 0 )
					return decode(inPacket.readBytes( 1 ));
				else
					throw new UniSessionException( uniReturnCode );
			}
			catch ( UniRPCException e )
			{
				this.setRPCError(true);
				throw new UniSessionException( e.getErrorCode() );
			}
		} // synch this
	}
	
	/**
	 * checks to see if a command is in an active state
	 *
	 * @return boolean stating whether we are in the middle of a command execution or not
	 * @since UNIOBJECTS 1.0
	 */
	protected boolean isCommandActive()
	{
		if ( uniCommand != null )
		{
			int status = uniCommand.status();
			
			if (( status == UniObjectsTokens.UVS_REPLY ) ||
					( status == UniObjectsTokens.UVS_MORE ))
				return true;
		}
		return false;
	}
	
	
	/**
	 * this method ensures that all entry conditions are met before we process any method that
	 * communicates to the server.  Currently, the only two conditions for this object are:
	 * <ul>
	 * <li> The session must be active
	 * <li> The command object, if present, cannot be in a wait state (UVS_REPLY or UVS_MORE)
	 * </ul>
	 * @exception UniSessionException is thrown if one of the pre-conditions fails
	 * @since UNIOBJECTS 1.0
	 */
	private void checkEntryConditions() throws UniSessionException
	{
		// First make sure that the session is open
		if ( !isActive() )
			throw new UniSessionException( UniObjectsTokens.UVE_SESSION_NOT_OPEN );
		
		// Ok, now lets' make sure we aren't in the middle of processing a UniCommand
		if ( isCommandActive() )
		{
			throw new UniSessionException( UniObjectsTokens.UVE_EXECUTEISACTIVE );
		}
	}
	
	/**
	 * used to get host information from the server
	 *
	 * @exception UniRPCException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	private void getHostInfo() throws UniRPCException
	{
		synchronized ( this ) {
			outPacket.write( 0, UniObjectsTokens.EIC_SESSIONINFO );
			connection.call( outPacket, inPacket );
			
			int response = inPacket.readInteger( 0 );
			if ( response == 0 )
			{
				userName = decode(inPacket.readBytes( 1 ));
				hostType = inPacket.readInteger( 2 );
			}
		} // synch this
	}
	
	/**
	 * used to get the client IP address being used
	 *
	 * @return integer representing the client IP address
	 * @since UNIOBJECTS 1.0
	 */
	private int getIPaddress()
	{
		try{
			return InetAddress.getLocalHost().hashCode();
		}
		catch ( java.net.UnknownHostException e )
		{
			return 0;
		}
	}
	
	/**
	 * used to get client MAC address
	 *
	 * @return String representing the MAC address
	 * @since UNIOBJECTS 1.0
	 */
	private String getMacAddress()
	{
		return MAC_ADDRESS;
	}
	
	/**
	 * used to get client device name
	 *
	 * @return String representing the client device name
	 * @since UNIOBJECTS 1.0
	 */
	private String getDeviceName()
	{
		try{
			return InetAddress.getLocalHost().getHostName();
		}
		catch ( java.net.UnknownHostException e )
		{
			return DEVICE_NAME;
		}
	}
	
	/**
	 * this method is used to determine whether or not NLS is available on the server, and if so, establish
	 * the default maps/locales necessary
	 *
	 */
	private void nlsInit()
	{
		isNLSEnabled = false;
		isNLSLocalesEnabled = false;
		isNLSUnidataSession = false;
		
		if ( getServerVersion() == UniObjectsTokens.OLD_SERVER )
			return;
		
		try
		{
			int nlsMode, nlsLCmode;
			String nlsmapname;
			
			outPacket.write( 0, UniObjectsTokens.EIC_GETSERVERINFO );
			
			connection.call( outPacket, inPacket );
			uniReturnCode = inPacket.readInteger( 0 );
			nlsMode = inPacket.readInteger( 1 );
			nlsLCmode = inPacket.readInteger( 2 );
			if ( nlsMode == 1 )
			{
				isNLSEnabled = true;
				if ( nlsLCmode == 1 )
					isNLSLocalesEnabled = true;
				uniDataSourceType = "UNIVERSE";
			}
			
			
			if(nlsMode == 2) //unidata session
			{
				isNLSUnidataSession = true;
				uniDataSourceType = "UNIDATA";
			}
			
			if(isNLSEnabled || isNLSUnidataSession)
			{
				byte[]  byteArray= new byte[1];
				InputStream inputStream = new ByteArrayInputStream(byteArray);
				InputStreamReader reader = new InputStreamReader(inputStream);
				nlsmapname = reader.getEncoding();
				try {
					reader.close();
					inputStream.close();
				} catch (Exception e) {};
				if(nlsmapname.equals("") == false)
				{
					// set client nls map
					uniNLSMap = new UniNLSmap(this);
					try {
						
						uniNLSMap.setName(nlsmapname);
					}
					catch ( UniNLSException e ){
						
						// this should not throw exception
						uniNLSMap.setName("DEFAULT");
					}
					
					if(isNLSLocalesEnabled)
					{
						// set client locale
						uniNLSLocale = new UniNLSlocale(this);
						try {
							
							Locale lc = Locale.getDefault();
							uniNLSLocale.setName(lc);
						}
						catch ( UniNLSException e ){
							
							// this should not throw exception
							uniNLSLocale.setName("DEFAULT");
						}
					}
				}
				
			}
			
			
			
		}
		catch ( UniRPCException e )
		{
			isNLSEnabled 				= false;
			isNLSLocalesEnabled = false;
			isNLSUnidataSession = false;
			this.setRPCError(true);
		}
		catch ( UniNLSException e)
		{
			isNLSEnabled 				= false;
			isNLSLocalesEnabled = false;
			isNLSUnidataSession = false;
		}
		catch ( Exception e)
		{
		}
	}
	
	/**
	 * used to set a AT value on the server
	 *
	 * @param key integer representing the key value requested
	 * @param aNewVal String representing the UniVerse session @variable to be changed
	 * @exception UniSessionException is thrown if an error occurs
	 * @since UNIOBJECTS 1.0
	 */
	private void setValue( int key, String aNewVal ) throws UniSessionException
	{
		synchronized ( this ) {
			try
			{
				outPacket.write( 0, UniObjectsTokens.EIC_SETVALUE );
				outPacket.write( 1, key );
				outPacket.write( 2, encode(aNewVal ));
				
				connection.call( outPacket, inPacket );
				
				int uniReturnCode = inPacket.readInteger( 0 );
			}
			catch ( UniRPCException e )
			{
				this.setRPCError(true);
				throw new UniSessionException( e.getErrorCode() );
			}
		} // sync this
	}
	
	
	protected  Object clonePooled() throws UniSessionException
	{
		UniSession us =null;
		us = (UniSession)this.clone();
		us.uniCommand = null;
		us.uniTransaction = null;
		us.uniStatus = 0;
		return us;
		
	}
	
	protected boolean  IsCPSupported(String ServerId)
	{
		if (ServerId.startsWith("udapi") || ServerId.startsWith("uvapi"))
			return true;
		else
			return false;
	}
	
	/**
	 * @return Returns the creationTime.
	 */
	protected synchronized Date getCreationTime() {
		return creationTime;
	}
	/**
	 * @param creationTime The creationTime to set.
	 */
	protected synchronized void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
		//UniJava.uniLog("In UniSession::setCreationTime() and time is " + creationTime.getTime());
	}
	/**
	 * @return Returns the pooledSession.
	 */
	protected synchronized boolean getPooledSession() {
		return pooledSession;
	}
	/**
	 * @param pooledSession The pooledSession to set.
	 */
	protected synchronized void setPooledSession(boolean pooledSession) {
		this.pooledSession = pooledSession;
	}
	/**
	 * @return Returns the freedTime.
	 */
	protected synchronized Date getFreedTime() {
		return freedTime;
	}
	/**
	 * @param freedTime The freedTime to set.
	 */
	protected synchronized void setFreedTime(Date freedTime) {
		this.freedTime = freedTime;
		//UniJava.uniLog("In UniSession::setFreedTime() and time is " + freedTime.getTime());
	}
	
	
	/**
	 * sets up the default values
	 *
	 */
	protected  void initDefaultValues()
	{
		this.setRPCError(false);
		isNLSUnidataSession				= false;
		
		uniMarkCharacters = UniTokens.defaultMarkArray;
		
		isActive 						= false;
		isRPCError						= false;
		isNLSEnabled 					= false;
		uniCommand 						= null;
		uniTransaction 					= null;
		uniNLSLocale 					= null;
		uniNLSMap 						= null;
		uSSLD                 			= null;
		blockingStrategy 			= UniObjectsTokens.RETURN_ON_LOCKED;
		// Initial value
		lockStrategy 					= UniObjectsTokens.NO_LOCKS;
		releaseStrategy 			= ( UniObjectsTokens.UVT_EXPLICIT_RELEASE | UniObjectsTokens.UVT_CHANGE_RELEASE );
		uniReturnCode 				= 0;
		numOpenFiles 					= 0;
		uniStatus							= 0;
		sslMode               = UniObjectsTokens.NON_SECURE_SESSION;
		pooledSession = false;
	}
	
    
    /**
     * 
     * @return encoding used by this session
     * @since UNIOBJECTS 2.0
     */
    public String getSessionEncoding() {
        return super.getEncoding();
    }

    /**
     * set the encoding to be used by this session
     * @param encoding
     * @throws UniConnectionException
     * @since UNIOBJECTS 2.0
     */
    public void setSessionEncoding(String encoding) throws UniSessionException {

            try {
                    super.setEncoding(encoding);
            } catch (UniConnectionException e) {
                throw new UniSessionException(
                        UniTokens.UVE_ENCODING_NOTSUPPORTED);
            }
  
    }
    
	protected UniTransaction	uniTransaction					= null;	// UniTransaction objects
	protected UniCommand		uniCommand					= null;	// UniCommand objects
	protected UniNLSlocale		uniNLSLocale				= null;
	protected UniNLSmap			uniNLSMap						= null;
	protected String[] 			atVariableArray; // Holds array of various at values
	private int 				blockingStrategy 			= UniObjectsTokens.RETURN_ON_LOCKED;		// Initial value
	private int 				lockStrategy 					= UniObjectsTokens.NO_LOCKS;
	private int 				releaseStrategy 			= ( UniObjectsTokens.UVT_EXPLICIT_RELEASE | UniObjectsTokens.UVT_CHANGE_RELEASE );
	private int 				uniReturnCode 				= 0;
	private int 				numOpenFiles 					= 0;
	private int					uniStatus							= 0;
	private UniSSLDescriptor uSSLD             = null;
	private int             sslMode               = UniObjectsTokens.NON_SECURE_SESSION;
	private final String		MAC_ADDRESS						= "JAVA";
	private final String		DEVICE_NAME						= "unknown host";
	private boolean pooledSession = false;
	private Date creationTime=new Date();
	private Date freedTime=new Date();

	
	
	
}
