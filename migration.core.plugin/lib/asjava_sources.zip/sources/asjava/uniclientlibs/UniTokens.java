/*************************************************************************
 *
 * UniTokens.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * IBM Confidential
 * OCO Source Materials
 * Copyright (C) IBM Corp.  1998, 2002
 *
 * \uFFFDCopyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 
 * 06/27/08 E37957 Initialize char_marks in fixed ISO-8859-1 encoding.
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 01/20/06 E8316  JFM added UNIRPC_SOCKETREAD_MAX_SIZE
 * 08/11/05 E33998 RKK Proxy not supported when Connection Pooling is ON.
 * 06/22/05 E33849 RKK New message when min pool size is greater than number of pooled licenses. 
 * 04/22/05 E33623 RKK Generate correct message if connecting to older version of U2
 * 11/18/04 e32565 RKK Connection Pooling
 * 10/14/04 W.YEH add UVE_QUERY_SYNTAX for UniXML.
 * 04/03/03 3495 JFM fix default nls marks problem
 * 10/14/02 2607,2609,2984 RKK NLS Stuff
 * 07/11/00 29361 WMY change DEFAULT_TIMEOUT from 60 to 300.
 * 05/04/99 24995 DTM Moved OLD_SERVER/NEW_SERVER into here, added UNI_SERVICE
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniclientlibs;

/**
 * <code>UniTokens</code> is the primary class used for holding UniObjects
 * defines.  It contains definitions for the following:
 * <ul>
 * <li> Mark characters:  Representing as both <code>Character</code> and <code>String</code>
 *											values
 * <li> Error Codes:  All the known error codes that UniObjects can report on
 * <li> Client Request Codes:  All the known client request codes UniObjects may support
 * </ul>
 *
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since	  UNICLIENTLIBS 1.0
 */
public class UniTokens
{
	public UniTokens(){};

	// Values for UniConnection
	public static final String UVCS_SERVICE 					= "uvcs";
	public static final String UDCS_SERVICE						= "udcs";
	public static final String UNI_SERVICE						= "defcs";
	public static final String UNIVERSE								= "UNIVERSE";
	public static final String UNIDATA								= "UNIDATA";
	public static final int COMMS_VERSION 						= 4;
  public static final int CS_VERSION 								= 6; 	// this is out of UV/Objects
  public static final int OLD_COMMS_VERSION					= 3;
  public static final int OLD_CS_VERSION						= 4;
  public static final int INTERNAL_FLAG 						= 0; 	// this is out of UV/Objects
	public static final int NO_COMPRESSION						= 0;
	public static final int INTERNAL_COMPRESSION			= 1;
	public static final int DEFAULT_TIMEOUT						= 300;
	public static final int NO_ENCRYPTION							= 0;
	public static final int UVT_NONE									= 0;
	public static final int UVT_UNIX									= 1;
	public static final int UVT_NT										= 2;
	public final static int OLD_SERVER								= 1;
	public final static int NEW_SERVER								= 2;


	// Array positions for the defaultMarkCharacters array
	public static final int IM												= 0;
	public static final int FM												= 1;
	public static final int VM												= 2;
	public static final int SVM												= 3;
	public static final int TM												= 4;
	public static final int SQLNULL										= 5;
	public static final int NUM_MARK_CHARACTERS				= 6;	// number of mark characters

	// The mark characters represented as Character values
	public static byte[] b_im ={(byte)255};
	public static byte[] b_fm ={(byte)254};
	public static byte[] b_vm ={(byte)253};
	public static byte[] b_svm ={(byte)252};
	public static byte[] b_tm ={(byte)251};
	public static byte[] b_sqlnull ={(byte)128};
    public static byte[] b_marks= {(byte)255,(byte)254,(byte)253,(byte)252,(byte)251,(byte)128};

	public static Character IM_CHAR	= new Character((char)255);
	public static Character FM_CHAR	= new Character((char)254);
	public static Character VM_CHAR	= new Character((char)253);
	public static Character SVM_CHAR	= new Character((char)252);
	public static Character TM_CHAR	= new Character((char)251);
	public static Character SQLNULL_CHAR= new Character((char)128);
	private static char[] char_marks;
	
	static {
	    try {
	    	char_marks = new String(b_marks,"ISO-8859-1").toCharArray();
	    	IM_CHAR = new Character(char_marks[0]);
			FM_CHAR = new Character(char_marks[1]);
			VM_CHAR = new Character(char_marks[2]);
			SVM_CHAR    = new Character(char_marks[3]);
			TM_CHAR = new Character(char_marks[4]);
			SQLNULL_CHAR= new Character(char_marks[5]);
	
	    } catch (Exception e) {
	
	    }
	}
	public static final Character NULL_CHAR									= new Character( (char)0   );
	//  The mark characters represented as String values
	public static String AT_IM												= IM_CHAR.toString();
	public static String AT_FM												= FM_CHAR.toString();
	public static String AT_VM												= VM_CHAR.toString();
	public static String AT_SVM												= SVM_CHAR.toString();
	public static String AT_TM												= TM_CHAR.toString();
	public static String AT_SQLNULL										= SQLNULL_CHAR.toString();

	public static final String AT_NULL											= NULL_CHAR.toString();

	// The default mark character array
	public static String[]	defaultMarkArray		= { UniTokens.AT_IM,
														UniTokens.AT_FM,
	        											UniTokens.AT_VM,
														UniTokens.AT_SVM,
														UniTokens.AT_TM,
														UniTokens.AT_SQLNULL
													};

	// UniObjects error codes
	public static final int UVE_NOERROR								= 0;
	public static final int UVE_ENOENT								= 14002;
	public static final int UVE_EIO										= 14005;
	public static final int UVE_EACCESS								= 14013;
	public static final int UVE_EINVAL								= 14022;
	public static final int UVE_ENFILE								= 14023;
	public static final int UVE_EMFILE								= 14024;
	public static final int UVE_ENOSPC								=	14028;
	public static final int UVE_NETUNREACH						= 14551;
	public static final int UVE_BFN										= 22001;
	public static final int UVE_BTS 									= 22002;
	public static final int UVE_IID										= 22003;
	public static final int UVE_LRR										= 22004;
	public static final int UVE_NFI										= 22005;
	public static final int UVE_RNF										= 30001;
	public static final int UVE_LCK										= 30002;
	public static final int UVE_USC										= 30096;
	public static final int UVE_SELFAIL								= 30097;
	public static final int UVE_LOCKINVALID						= 30098;
	public static final int UVE_SEEKFAILED						= 30101;
	public static final int UVE_INVALIDATKEY					= 30103;
	public static final int UVE_UNABLETOLOADSUB				= 30105;
	public static final int UVE_BADNUMARGS						= 30106;
	public static final int	UVE_SUBERROR							= 30107;
	public static final int UVE_ITYPEFTC							= 30108;
	public static final int UVE_ITYPEFAILEDTOLOAD			= 30109;
	public static final int UVE_ITYPENOTCOMPILED			= 30110;
	public static final int UVE_BADITYPE							= 30111;
	public static final int UVE_INVALIDFILENAME				= 30112;
	public static final int UVE_WEOFFAILED						= 30113;
	public static final int UVE_EXECUTEISACTIVE				= 30114;
	public static final int UVE_EXECUTENOTACTIVE			= 30115;
	public static final int UVE_TX_ACTIVE							= 30124;
	public static final int UVE_CANT_ACCESS_PF				= 30125;
	public static final int UVE_FAIL_TO_CANCEL				= 30126;
	public static final int UVE_INVALID_INFO_KEY			= 30127;
	public static final int UVE_CREATE_FAILED					= 30128;
	public static final int UVE_DUPHANDLE_FAILED			= 30129;
	public static final int UVE_NVR										= 31000;
	public static final int UVE_NPN										= 31001;
	public static final int UVE_NODATA								= 39101;
	public static final int UVE_AT_INPUT							= 39119;
	public static final int UVE_SESSION_NOT_OPEN			= 39120;
	public static final int UVE_UVEXPIRED							= 39121;
	public static final int UVE_CSVERSION							= 39122;
	public static final int UVE_COMMSVERSION					= 39123;
	public static final int UVE_BADDIR								= 39125;
	public static final int UVE_BAD_UVHOME						= 39127;
	public static final int UVE_INVALIDPATH						= 39128;
	public static final int UVE_INVALIDACCOUNT				= 39129;
	public static final int UVE_BAD_UVACCOUNT_FILE		= 39130;
	public static final int UVE_FTA_NEW_ACCOUNT				= 39131;
	public static final int UVE_ULR										= 39134;
	public static final int UVE_NO_NLS								= 39135;
	public static final int UVE_MAP_NOT_FOUND					= 39136;
	public static final int UVE_NO_LOCALE							= 39137;
	public static final int UVE_LOCALE_NOT_FOUND			= 39138;
	public static final int UVE_CATEGORY_NOT_FOUND		= 39139;
	public static final int UVE_SR_SLAVE_READ_FAIL		= 39207;
	public static final int UVE_INVALIDFIELD					= 40001;
	public static final int UVE_SESSIONEXISTS					= 40002;
	public static final int	UVE_BADPARAM							= 40003;
	public static final int UVE_NOMORE								= 40005;
	public static final int UVE_NOTATINPUT						= 40006;
	public static final int UVE_INVALID_DATAFIELD			= 40007;
	public static final int UVE_BAD_DICTIONARY_ENTRY	= 40008;
	public static final int UVE_BAD_CONVERSION_DATA		= 40009;
	public static final int UVE_FILE_NOT_OPEN					= 45000;
	public static	final int	UVE_OPENSESSION_ERR 			= 45001;
	public static final	int	UVE_NONNULL_RECORDID			= 45002;
	public static final int UVE_BAD_LOGINNAME					= 80011;
	public static final int UVE_BAD_PASSWORD					= 80019;
	public static final int UVE_ACCOUNT_EXPIRED				= 80144;
	public static final int UVE_RUN_REMOTE_FAILED			= 80147;
	public static final int UVE_UPDATE_USER_FAILED		= 80148;
	public static final int UVE_RPC_BAD_CONNECTION		= 81001;
	public static final int UVE_RPC_NO_CONNECTION			= 81002;
	public static final int UVE_RPC_WRONG_VERSION			= 81005;
	public static final int UVE_RPC_FAILED						= 81009;
	public static final int UVE_RPC_UNKNOWN_HOST			= 81011;
	public static final int UNIRPC_NO_MORE_CONNECTIONS= 81007;
	public static final int UNIRPC_CANT_FIND_SERVICE	= 81014;
	public static final int UNIRPC_TIMEOUT						= 81015;
	public static final int UNIRPC_REFUSED						= 81016;

  	public static final int UVE_MLTPLEX_SECURE_SESSION= 84444;
	public static final int UVE_NOT_A_PROXY_SESSION=84445;
	public static final int UVE_BAD_SSL_MODE=84446;
	public static final int UVE_QUERY_SYNTAX=80120;
    
    public static final int UVE_UNISESSION_TIMEOUT = 82001;
    public static final int UVE_CP_NOTSUPPORTED = 82002;
    public static final int UVE_XML_VERIFY_U2VERSION= 82003;
    public static final int UVE_MINPOOL_MORETHAN_LICENSE = 82004;
    public static final int UVE_PROXY_NOTSUPPORTED_WHEN_CP_ON = 82005;
    public static final int UVE_ENCODING_NOTSUPPORTED = 82006;
    
	public static final int UVE_SUCCESS_WITH_INFO			= 88888;
	public static final int UVE_MUST_USE_SESSION			= 88889;

	// Intercall define numbers - client side - from "uvclient.h"
	public static final int EIC_ALPHA									= 1;
	public static final int	EIC_CLEARDATA							= 2;
	public static final int	EIC_CLEARFILE							= 3;
	public static final int	EIC_CLEARSELECT						=	4;
	public static final int	EIC_CLOSE									=	5;
	public static final int EIC_CLOSESEQ							=	6;
	public static final int	EIC_COL1									=	7;
	public static final int	EIC_COL2									=	8;
	public static final int	EIC_CONVERT								=	9;
	public static final int	EIC_COUNT									=	10;
	public static final int	EIC_DATA									=	11;
	public static final int	EIC_DATE									=	12;
	public static final int	EIC_DCOUND								=	13;
	public static final int	EIC_DELETE								=	14;
	public static final int	EIC_EXECUTE								=	15;
	public static final int	EIC_EXTRACT								=	16;
	public static final int	EIC_FIELD 								=	17;
	public static final int	EIC_FIELDSTORE						=	18;
	public static final int	EIC_FILEINFO							=	19;
	public static final int	EIC_FILELOCK							=	20;
	public static final int	EIC_FILEUNLOCK						=	21;
	public static final int	EIC_FMT										=	22;
	public static final int	EIC_FORMLIST							=	23;
	public static final int	EIC_GETLIST								=	24;
	public static final int EIC_GETVALUE							=	25;
	public static final int	EIC_ICONV									=	26;
	public static final int	EIC_INDICES								=	27;
	public static final int	EIC_INSERT								=	28;
	public static final int	EIC_ITYPE									=	29;
	public static final int EIC_LOCATE								=	30;
	public static final int	EIC_LOCK									=	31;
	public static final int EIC_LOWER									=	32;
	public static final int	EIC_OCONV									=	33;
	public static final int	EIC_OPEN									=	34;
	public static final int	EIC_OPENSEQ								=	35;
	public static final int	EIC_RAISE									=	36;
	public static final int	EIC_READ									=	37;
	public static final int	EIC_READBLK								=	38;
	public static final int	EIC_READLIST							=	39;
	public static final int	EIC_READNEXT							=	40;
	public static final int	EIC_READSEQ								=	41;
	public static final int	EIC_READV 								=	42;
	public static final int	EIC_RECORDLOCK						=	43;
	public static final int	EIC_RECORDLOCKED					=	44;
	public static final int	EIC_RELEASE								=	45;
	public static final int	EIC_REPLACE								=	46;
	public static final int	EIC_SEEK									=	47;
	public static final int	EIC_SELECT								=	48;
	public static final int	EIC_SELECTINDEX						=	49;
	public static final int	EIC_SETVALUE							=	50;
	public static final int	EIC_STRDEL								=	51;
	public static final int	EIC_SUBCALL								=	52;
	public static final int	EIC_TIME									=	53;
	public static final int	EIC_TIMEDATE							=	54;
	public static final int	EIC_TIMEOUT								=	55;
	public static final int	EIC_TRANS									=	56;
	public static final int	EIC_TRANSACTION						=	57;
	public static final int	EIC_TRIM									=	58;
	public static final int	EIC_UNLOCK								=	59;
	public static final int EIC_WEOFSEQ								=	60;
	public static final int	EIC_WRITE									=	61;
	public static final int	EIC_WRITEBLK							=	62;
	public static final int	EIC_WRITECONTINUE 				=	63;
	public static final int	EIC_WRITESEQ							=	64;
	public static final int	EIC_WRITEV								=	65;
	public static final int EIC_EXECUTECONTINUE 			=	66;
	public static final int EIC_INPUTREPLY						=	67;
	public static final int EIC_CANCEL								=	68;
	public static final int EIC_SESSIONINFO						=	69;
	public static final int EIC_SETMAP								=	70;
	public static final int EIC_GETMAP								=	71;
	public static final int EIC_SETLOCALE							=	72;
	public static final int EIC_GETLOCALE							=	73;
	public static final int EIC_GETVERSION						=	74;
	public static final int EIC_GETSERVERINFO					= 75;
	public static final int EIC_READSET								= 76;
	public static final int EIC_READFIELDSET					= 77;
	public static final int EIC_READNAMEDFIELDSET			= 78;
	public static final int EIC_DELETESET							= 79;
	public static final int EIC_WRITESET							= 80;
	public static final int EIC_WRITEFIELDSET					= 81;
	public static final int EIC_WRITENAMEDFIELDSET		= 82;
	public static final int	EIC_LOCKSET								= 83;
	public static final int EIC_UNLOCKSET							= 84;
	// Set to the largest number
	public static final int	EIC_LASTMESSAGE						=	85;
	public static final int EIC_POOLOFF = 86;
    
    

    
    public static int UNIRPC_SOCKETREAD_MAX_SIZE=10*1024*1024;

}
