/*************************************************************************
 *
 * UniDataSetException.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/


package asjava.uniclientlibs;
 

/**
 * <code>UniDataSetException</code> is the primary class used for handling UniObjects  
 * exceptions and errors.
 * This internal error handling method is based on Java's method of handling
 * errors. This exception class is derived from the base UniObjects exception 
 * class, <code>UniException</code>. We have also carried over the idea of having an integer identifier 
 * for the message which can make the handling of said message a lot easier.
 * 
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since	  UNICLIENTLIBS 1.0
 */
public class UniDataSetException extends UniException
{
	/**
	 * Creates the UniDataSetException object.  
	 *
	 * @since	UNICLIENTLIBS 1.0
	 */
	UniDataSetException()
	{
		super();
		errorType = UNIDATASET_EXCEPTION;
	}
	
	/**
	 * Creates the UniDataSetException object.  
	 *
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNICLIENTLIBS 1.0
	 */
	UniDataSetException( int aErrorCode )
	{
		super( aErrorCode );
		errorType = UNIDATASET_EXCEPTION;
	}

	/**
	 * Creates the UniDataSetException object.  
	 *
	 * @param aError string representing the message to be displayed
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNICLIENTLIBS 1.0
	 */
	UniDataSetException(String aError, int aErrorCode)
	{
		super(aError, aErrorCode);
		errorType = UNIDATASET_EXCEPTION;
	}
	
	/**
	 * Creates the UniDataSetException object.  
	 *
	 * @param aExtraInfo string representing the message to be displayed
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNICLIENTLIBS 1.0
	 */
	UniDataSetException( int aErrorCode, String aExtraInfo )
	{
		super( aErrorCode, aExtraInfo );
		errorType = UNIDATASET_EXCEPTION;
	}

	/**
	 * Creates the UniDataSetException object.  
	 *
	 * @param aClassName string representing the name of the class failure occured
	 * @param aError string representing the message to be displayed
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNICLIENTLIBS 1.0
	 */
	UniDataSetException(String aClassName, String aError, int aErrorCode)
	{
		super(aClassName, aError, aErrorCode);
		errorType = UNIDATASET_EXCEPTION;
	}
}