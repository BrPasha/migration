/*************************************************************************
 *
 * UniException.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 08/26/04 WMY add UNIXML_EXCEPTION
 * 05/04/99 24995 DTM Made exception types public, now extends Exception 
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniclientlibs;
 

/**
 * <code>UniException</code> is the primary class used for handling UniObjects 
 * Java class exceptions and errors. This internal error handling method is
 * based on Java's method of handling errors. We have also carried over the
 * idea of having an integer identifier for the message which can make the
 * handling of said message a lot easier.

 * @version	Version 1.0
 * @author	David T. Meeks
 * @since	UNICLIENTLIBS 1.0
 */
public class UniException extends Exception
{
	/**
	 * Creates the UniException object.  
	 *
	 * @since	UNICLIENTLIBS 1.0
	 */
	public UniException()
	{
		super();
	}
	
	/**
	 * Creates the UniException object.  This version only takes the error code
	 * of the failure, which it will use to lookup the error text from the 
	 * <code>UniErrorMessage</code> object.
	 *
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNICLIENTLIBS 1.0
	 */
	public UniException( int aErrorCode )
	{
		super( UniErrorMessage.getErrorMessage( aErrorCode ) );
		errorCode = aErrorCode;
	}

	/**
	 * Creates the UniException object. Takes the error text from the exception
	 * and does not extract the message from <code>UniErrorMessage</code> 
	 *
	 * @param aError string representing the message to be displayed
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNICLIENTLIBS 1.0
	 */
	public UniException(String aError, int aErrorCode)
	{
		super( aError );
		errorCode = aErrorCode;
	}
	
	/**
	 * Creates the UniException object. Takes the error text from the from 
	 * <code>UniErrorMessage</code>, also uses the extra info passed in to properly
	 * set the error message
	 *
	 * @param aExtraInfo string representing the extra information to be displayed
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNICLIENTLIBS 1.0
	 */
	public UniException( int aErrorCode, String aExtraInfo )
	{
		super( UniErrorMessage.getErrorMessage( aErrorCode, aExtraInfo ) );
		errorCode = aErrorCode;
	}

	/**
	 * Creates the UniException object.  
	 *
	 * @param aClassName string representing the name of the class failure occured
	 * @param aError string representing the message to be displayed
	 * @param aErrorCode integer representing the error number that occured
	 * @since	UNICLIENTLIBS 1.0
	 */
	public UniException( String aClassName, String aError, int aErrorCode )
	{
		this( aError, aErrorCode );
		uniClassName = aClassName;
	}
		
	/**
	 * Returns the error number associated with this exception.  
	 *
	 * @return integer representing the error number
	 * @since	UNICLIENTLIBS 1.0
	 */
	public int getErrorCode()
	{
		return errorCode;
	}
	
	
	/**
	 * Returns the extended error text associated with this exception
	 * 
	 * @return integer representing the error number
	 * @since	UNICLIENTLIBS 1.0
	 */
	public String getExtendedMessage()
	{
		String returnString = IBMU2_BANNER + UNIOBJECT_BANNER + 
													"[" + getErrorTypeText() + "]" +
													"[ErrorCode: " + getErrorCode() + "]" +
													getMessage(); 
		return returnString;
	}
	
	/**
	 * Returns the type of exception.  
	 *
	 * @return int representing this exception
	 * @since	UNICLIENTLIBS 1.0
	 */
	public int getErrorType()
	{
		return this.errorType;
	}

	/**
	 * Returns the type of exception in String form 
	 *
	 * @return String representing this exception
	 * @since	UNICLIENTLIBS 1.0
	 */
	public String getErrorTypeText()
	{
		switch( this.getErrorType() )
		{
			case UNICLIENTLIBS_EXCEPTION:
				return new String( "UniClientLibs Generic Exception" );
			case UNISTRING_EXCEPTION:
				return new String( "UniString Exception" );
			case UNIDYNARRAY_EXCEPTION:
				return new String( "UniDynArray Exception" );
			case UNICOMMAND_EXCEPTION:
				return new String( "UniCommand Exception" );
			case UNIFILE_EXCEPTION:
				return new String( "UniFile Exception" );
			case UNINLS_EXCEPTION:
				return new String( "UniNLS Exception" );
			case UNISELECTLIST_EXCEPTION:
				return new String( "UniSelectList Exception" );
			case UNISEQUENTIALFILE_EXCEPTION:
				return new String( "UniSequentialFile Exception" );
			case UNISESSION_EXCEPTION:
				return new String( "UniSession Exception" );
			case UNISUBROUTINE_EXCEPTION:
				return new String( "UniSubroutine Exception" );
			case UNITRANSACTION_EXCEPTION:
				return new String( "UniTransaction Exception" );
			case UNICONNECTION_EXCEPTION:
				return new String( "UniConnection Exception" );
			case UNIDATASET_EXCEPTION:
				return new String( "UniDataSet Exception" );
			case UNIXML_EXCEPTION:
				return new String( "UniXML Exception" );
			default:
				return new String( "Unknown Error Type" );
		}
	}
	
	// Private instance variables
	public static final int	UNICLIENTLIBS_EXCEPTION			= 0;
	public static final int	UNISTRING_EXCEPTION 				= 1;
	public static final int UNIDYNARRAY_EXCEPTION				= 2;
	public static final int	UNICOMMAND_EXCEPTION				= 3;
	public static final int	UNIFILE_EXCEPTION						= 4;
	public static final int	UNINLS_EXCEPTION						= 5;
	public static final int	UNISELECTLIST_EXCEPTION			= 6;
	public static final int	UNISEQUENTIALFILE_EXCEPTION	= 7;
	public static final int	UNISESSION_EXCEPTION				= 8;
	public static final int	UNISUBROUTINE_EXCEPTION			= 9;
	public static final int	UNITRANSACTION_EXCEPTION		= 10;
	public static final int UNICONNECTION_EXCEPTION			= 11;
	public static final int	UNIDATASET_EXCEPTION				= 12;
	public static final int UNIXML_EXCEPTION		= 13;
	
	private static final String IBMU2_BANNER 							= "[IBM U2]";
	private static final String UNIOBJECT_BANNER 						= "[UniObjects for Java]";
	private int 								errorCode 									= 0;
	private String 							uniClassName 								= null;
	protected	int								errorType 									= UNICLIENTLIBS_EXCEPTION;
}
