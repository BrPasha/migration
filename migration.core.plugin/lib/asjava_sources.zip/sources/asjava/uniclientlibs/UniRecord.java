/*************************************************************************
 *
 * UniRecord.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 *       IBM Confidential
 *       OCO Source Materials
 *       Copyright (C) IBM Corp.  1993, 2009
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 07/10/09 40310 JFM more NLS enhancement dealing with Object type parameter
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniclientlibs;

import java.io.*;
/**
 * <code>UniRecord</code> is used to control UniVerse Record interaction.  It is an extension
 * of the <code>UniDynArray</code> object, and thus behaves in a similar fashion.  All 
 * <code>UniDynArray</code> operations can be performed, and will be performed on the data
 * portion of this object.  
 * 
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since		UNICLIENTLIBS 1.0
 */
public class UniRecord extends UniDynArray implements Serializable
{
  /**
    * Constructs a UniRecord with no data in it. 
    *
    * @since   UNICLIENTLIBS 1.0
    */
	public UniRecord()
	{
		this( "" );
	}
	
  /**
    * Constructs a UniRecord with just the record ID
    *
    * @param aRecID the record ID this record represents
    * @since   UNICLIENTLIBS 1.0
    */
	public UniRecord( Object aRecID )
	{
		this( aRecID, "" );
	}

  /**
    * Constructs a UniRecord with the record ID and record data
    *
    * @param aRecID the record ID this record represents
    * @param aRecVal the record Data this record represents...
    * @since   UNICLIENTLIBS 1.0
    */
	public UniRecord( Object aRecID, Object aRecVal )
	{
		this( aRecID, aRecVal, UniTokens.UVE_NOERROR );
	}
	
    
  /**
    * Constructs a UniRecord with the record ID and record data, setting the initial 
    * status as well
    *
    * @param aRecID the record ID this record represents
    * @param aRecVal the record Data this record represents...
    * @param aStatus the initial status value of this record
    * @since   UNICLIENTLIBS 1.0
    */
	public UniRecord( Object aRecID, Object aRecVal, int aStatus )
	{
		super(aRecVal );
		setRecordID( aRecID );
		setRecord( aRecVal );
		setStatus( aStatus );
		uniReturnCode = 0;
	}

    
    /* new UniRecord constructors for NLS enhancement project
     */
    protected UniRecord(UniString aRecID)
    {
        this(aRecID,null,UniTokens.UVE_NOERROR);
        uniConnection = aRecID.uniConnection;
        if (uniConnection != null) {
            setMarks(uniConnection.getByteMarks());
            setEncoding(uniConnection.getEncoding());
        }
           
    }
    
    protected UniRecord(UniString aRecID,UniString aRecVal)
    {
        this(aRecID,aRecVal,UniTokens.UVE_NOERROR);
    }
    
    public UniRecord(UniString aRecID, UniString aRecVal, int aStatus)
    {
        super(aRecVal);
        setRecordID(aRecID);
        setRecord( aRecVal );
        setStatus( aStatus );
        uniReturnCode = 0;
    }
    
  /**
    * return the objects RecordID
    *
		* @return UniDynArray representing the objects record ID
    * @since   UNICLIENTLIBS 1.0
    */
	public UniDynArray getRecordID()
	{
		return recID;
	}

  /**
    * return the objects data value
    *
		* @return UniDynArray representing the objects record data
    * @since   UNICLIENTLIBS 1.0
    */
	public UniDynArray getRecord()
	{
		return recData;
	}
	
  /**
    * return the objects return code
    *
		* @return integer representing the objects record return code
    * @since   UNICLIENTLIBS 1.0
    */
	public int returnCode()
	{
		return uniReturnCode;
	}
	
  /**
    * return the objects stats
    *
		* @return integer representing the objects status
		* @since   UNICLIENTLIBS 1.0
    */
	public int status()
	{
		return uniStatus;
	}

   /**
    * sets the objects RecordID value
    *
		* param aRecID UniDynArray representing the objects record ID
    * @since   UNICLIENTLIBS 1.0
    */
	public void setRecordID( Object aRecID )
	{
	    if ( aRecID != null )
	    {
	        if (aRecID instanceof UniString)
	            this.setRecordID(new UniDynArray((UniString)aRecID));         
	        else 
	            recID		= new UniDynArray( aRecID.toString() );
	    }
	}

   /**
    * sets the objects RecordID value
    *
		* param aRecID UniDynArray representing the objects record ID
    * @since   UNICLIENTLIBS 1.0
    */
	public void setRecordID( UniDynArray aRecID )
	{
		if ( aRecID != null )
			recID = new UniDynArray(aRecID);
	}
	
	 /**
    * sets the objects data value
    *
		* param aRecVal UniDynArray representing the objects record data value
    * @since   UNICLIENTLIBS 1.0
    */	
	public void setRecord( Object aRecVal )
	{
		if ( aRecVal != null )
		{
            if (aRecVal instanceof UniString)
                this.setRecord(new UniDynArray((UniString)aRecVal));
            else { 
                String tmpStr = aRecVal.toString();
			
                this.setValue( tmpStr );
                recData = new UniDynArray( tmpStr );
            }
		}
	}

  /**
    * sets the objects data value
    *
		* param aRecVal UniDynArray representing the objects record data value
    * @since   UNICLIENTLIBS 1.0
    */	
	public void setRecord( UniDynArray aRecVal )
	{
		if ( aRecVal != null )
		{
			this.setValue( aRecVal);
			recData = new UniDynArray(aRecVal);
		}
	}
	
  /**
    * sets the objects data value
    *
		* param aRecVal UniDynArray representing the objects record data value
    * @since   UNICLIENTLIBS 1.0
    */	
	public void setRecord( String aRecVal )
	{
		if ( aRecVal != null )
		{
			this.setValue( aRecVal );
			recData = new UniDynArray( aRecVal );
		}
	}

  /**
    * sets the objects return value
    *
		* param aReturnCode integer representing the objects return code
		* @since   UNICLIENTLIBS 1.0
    */
	public void setReturnCode( int aReturnCode )
	{
		uniReturnCode = aReturnCode;
	}
	
  /**
    * sets the objects status value
    *
		* param aStatusVal integer representing the objects status
		* @since   UNICLIENTLIBS 1.0
    */
	public void setStatus( int aStatusVal )
	{
		uniStatus = aStatusVal;
	}
	
  /**
    * returns the String representation of the object.  The recordID and record data are
    * combined, being separated by a uniVerse @IM character.
    *
		* return String representing the objects string representation
		* @since   UNICLIENTLIBS 1.0
    */
	public String toString()
	{
	    return toUniString().toString();
	}
	
  /**
    * returns the UniDynArray representation of the object.  
    *
		* return UniDynArray representing the objects as a UniDynArray 
		* @since   UNICLIENTLIBS 1.0
    */
	public UniDynArray toUniDynArray()
	{
        return new UniDynArray(toUniString());
	}
	
  /**
    * returns the UniString representation of the object.  
    *
		* return UniString representing the objects as a UniString 
		* @since   UNICLIENTLIBS 1.0
    */
	public UniString toUniString()
	{
        UniString uniString = new UniString(recID);
        uniString.append(uniString.getMarkByte(UniTokens.IM));
        uniString.append(recData);
		return uniString;
	}
	
	UniDynArray			recID;			// Record ID being dealt with
	UniDynArray			recData;
}