/*************************************************************************
 *
 * UniDynArray.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *       IBM Confidential
 *       OCO Source Materials
 *       Copyright (C) IBM Corp.  1993, 2009
 *
 * ? Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 07/10/09 40310 JFM more NLS enhancement dealing with Object type parameter
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 12/05/03 E3912 JFM fixed an NLS related problem in extract() method
 * 11/15/00 31602 DTM Fixed dcount() to handle null value/subvalues.  It will
 *                    now return a 0 as expected, instead of a 1.
 * 05/22/00 28926 DTM Changed toString() method to properly convert
 * 05/22/00 26465 JFM Fixed extra VM after insertion
 * 03/22/99 24738 DTM Fixed count()/dcount()
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniclientlibs;

import java.io.*;
import java.util.*;


/**
 * <code>UniDynArray</code> is used to control dynamic array interaction. It
 * is important to note that <code>UniDynArray</code> referencing is done in
 * '1'-based notation, meaning the first field is field 1.
 * 
 * @version Version 1.0
 * @author David T. Meeks
 * @since UNICLIENTLIBS 1.0
 */
public class UniDynArray extends UniString implements Serializable {
    
    /**
     * Constructs a dynamic array with no characters in it
     * 
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray() {
        this("");
    }

    /**
     * Constructs a dynamic array with the passed in Object value
     * 
     * @param aString
     *            Object representing the data to be converted into a dynamic
     *            array
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray(Object aString) {
        super(aString);
    }
    
    public UniDynArray(UniString aString) {
        super(aString);
    }

    /**
     * Constructs a dynamic array with the passed in object value
     * 
     * @param aString
     *            Object representing the data to be converted into a dynamic
     *            array
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray(String aString) {
        super(aString);
    }

    /**
     * Constructs a UniDynArray with data set to the passed in Object, and binds it to 
     * the given UniConnection object
     * 
     * @param uniConnection
     * @param obj
     *            an Object to supply the initial data to the dynamic array 
     * @since UNICLIENTLIBS 2.0
     */
    public UniDynArray(UniConnection uniConnection,Object obj) {
        super(uniConnection, obj);
    }
    
    public UniDynArray(UniConnection uniConnection,byte[] obj) {
        super(uniConnection, obj);
    }
    /**
     * Constructs a UniDynArray with no data in it, and binds it to 
     * the given UniConnection object
     * 
     * @param uniConnection
     *            UniConnection object to bind the dynamic array to
     * @since UNICLIENTLIBS 2.0
     */
    public UniDynArray(UniConnection uniConnection) {
        super(uniConnection);
    }

    /**
     * Constructs a UniDynArray (copy constructor)
     * 
     * @param uniDynArray
     * @since UNICLIENTLIBS 2.0
     */
    public UniDynArray(UniDynArray uniDynArray)
    {
        super(uniDynArray);
    }
    
    /**
     * Counts the number of text marks that exist in the array
     * 
     * @param aField
     *            integer representing which field mark to count
     * @param aValue
     *            integer representing the value position to count
     * @param aSubValue
     *            integer representing which subvalue position to count
     * @return integer representing the number of text mark characters in the
     *         array
     * @since UNICLIENTLIBS 1.0
     */
    public int count(int aField, int aValue, int aSubValue) {
        return count_marks(aField, aValue, aSubValue, 0);
    }

    /**
     * Counts the number of subvalue marks that exist in the array
     * 
     * @param aField
     *            integer representing which field mark to count
     * @param aValue
     *            integer representing the value position to count
     * @return integer representing the number of subvalue mark characters in
     *         the array
     * @since UNICLIENTLIBS 1.0
     */
    public int count(int aField, int aValue) {
        return count(aField, aValue, 0);
    }

    /**
     * Counts the number of value marks that exist in the array
     * 
     * @param aField
     *            integer representing which field mark to count
     * @return integer representing the number of value mark characters in the
     *         array
     * @since UNICLIENTLIBS 1.0
     */
    public int count(int aField) {
        return count(aField, 0, 0);
    }

    /**
     * Counts the number of field marks that exist in the array
     * 
     * @return integer representing the number of field mark characters in the
     *         array
     * @since UNICLIENTLIBS 1.0
     */
    public int count() {
        return count(0, 0, 0);
    }

    /**
     * Counts the number of text values that exist in the array at the given
     * field,value,subvalue position, equivalent to <code>count()</code> + 1
     * 
     * @param aField
     *            integer representing which field to count values for
     * @param aValue
     *            integer representing which value to use
     * @param aSubValue
     *            integer representing which subvalue to use
     * @return integer representing the number of text values in the array
     * @since UNICLIENTLIBS 1.0
     */
    public int dcount(int aField, int aValue, int aSubValue) {
        String tmpVal = this.toString();

        // Check case with empty dynarray
        if (tmpVal.equals(""))
            return 0;

        int ret_val = count_marks(aField, aValue, aSubValue, -1) + 1;

        return ret_val;
    }

    /**
     * Counts the number of subvalues that exist in the array at the given
     * field,value position, equivalent to
     * <code>count( aFieldValue, aValue)</code> + 1
     * 
     * @param aField
     *            integer representing which field to count values for
     * @param aValue
     *            integer representing which value to count subvalues for
     * @return integer representing the number of subvalue in the field/value of
     *         the array
     * @since UNICLIENTLIBS 1.0
     */
    public int dcount(int aField, int aValue) {
        return dcount(aField, aValue, 0);
    }

    /**
     * Counts the number of values that exist in the array at the given field
     * position, equivalent to <code>count( aField )</code> + 1
     * 
     * @param aField
     *            integer representing which field to count values for
     * @return integer representing the number of value in the field of the
     *         array
     * @since UNICLIENTLIBS 1.0
     */
    public int dcount(int aField) {
        return dcount(aField, 0, 0);
    }

    /**
     * Counts the number of fields that exist in the array, equivalent to
     * <code>count()</code> + 1
     * 
     * @return integer representing the number of fields in the array
     * @since UNICLIENTLIBS 1.0
     */
    public int dcount() {
        return dcount(0, 0, 0);
    }

    /**
     * Deletes the given field/value/subvalue value from the array
     * 
     * @param aField
     *            integer representing which field to delete
     * @param aValue
     *            integer representing which value within the field to delete
     * @param aSubValue
     *            integer representing which subvalue within the value to delete
     * @since UNICLIENTLIBS 1.0
     */
    public void delete(int aField, int aValue, int aSubValue) {
        Vector fieldVector, valueVector;

        // check to see if we need to construct the array
        checkBytesChanged();

        // Deal with boundary conditions
        // If we try to delete a field that is 0
        if ((aField <= 0) || (aField > dynArray.size()))
            return;

        // If a value of 0 is specified, it means we want to remove the field
        if (aValue == 0) {
            dynArray.removeElementAt(aField - 1);
            dynArrayChanged = true;
            return;
        }

        // Get field we want to play with
        fieldVector = (Vector) dynArray.elementAt(aField - 1);

        // Deal with boundary conditions
        if ((aValue < 0) || (aValue > fieldVector.size()))
            return;

        // If a subvalue of 0 is specified, it means we want to remove the value
        if (aSubValue == 0) {
            fieldVector.removeElementAt(aValue - 1);
            dynArrayChanged = true;
            return;
        }

        // Get value we want to play with
        valueVector = (Vector) fieldVector.elementAt(aValue - 1);

        // Deal with boundary conditions
        if ((aSubValue < 0) || (aSubValue > valueVector.size()))
            return;

        // Array has changed, mark string as inactive
        dynArrayChanged = true;
        valueVector.removeElementAt(aSubValue - 1);
    }

    /**
     * Deletes the given field/value value from the array
     * 
     * @param aField
     *            integer representing which field to delete
     * @param aValue
     *            integer representing which value within the field to delete
     * @since UNICLIENTLIBS 1.0
     */
    public void delete(int aField, int aValue) {
        delete(aField, aValue, 0);
    }

    /**
     * Deletes the given field value from the array
     * 
     * @param aField
     *            integer representing which field to delete
     * @since UNICLIENTLIBS 1.0
     */
    public void delete(int aField) {
        delete(aField, 0, 0);
    }

    /**
     * Extracts a copy of the requested subvalue
     * 
     * @param aField
     *            integer representing which field to extract
     * @param aValue
     *            integer representing which value to extract
     * @param aSubValue
     *            integer representing which subvalue to extract
     * @return UniDynArray representing the requested subvalue
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray extract(int aField, int aValue, int aSubValue) {
        Vector fieldVector, valueVector;
        UniDynArray tmpDyn = new UniDynArray(uniConnection);

        // Deal with boundary conditions
        if (aField == -1)
            return this;

        // check to see if we need to construct the array
        checkBytesChanged();

        // Deal with boundary conditions
        if ((aField > dynArray.size()) || (aField < -1)) {
            /* E3912 */
            return tmpDyn;
        }

        // Deal with boundary conditions
        if (aField == 0) {
            if ((aValue == 0) && (aSubValue == 0)) {
                return tmpDyn;
            } else
                aField = 1;
        }

        // Get field we want to play with. Must subtract one as the array is 0
        // based
        fieldVector = (Vector) dynArray.elementAt(aField - 1);

        // We just want to get this field in it's entire fashion
        if ((aValue == 0) && (aSubValue == 0)) {
            tmpDyn = new UniDynArray(uniConnection);
            int numValues = fieldVector.size();

            for (int i = 0; i < numValues; i++) {
                valueVector = (Vector) fieldVector.elementAt(i);
                int numSubValues = valueVector.size();
                for (int j = 0; j < numSubValues; j++) {
                    tmpDyn.append((byte[]) valueVector.elementAt(j));
                    // If we aren't at the end, we must tack on a SubValue mark
                    if (j != (numSubValues - 1)) {
                        tmpDyn.append(getMarkByte(UniTokens.SVM));
                    }
                }
                // If we aren't at the end, we must tack on a Value mark
                if (i != (numValues - 1)) {
                    tmpDyn.append(getMarkByte(UniTokens.VM));
                }
            }
            return tmpDyn;
        } else {
            // otherwise, if we are truly looking for a subvalue, a value of 0
            // becomes a 1
            if (aValue == 0)
                aValue = 1;
        }

        // Deal with boundary conditions
        if ((aValue > fieldVector.size()) || (aValue < 0)) {
            return tmpDyn;
        }

        // Get value we want to play with. Must subtract one as the array is 0
        // based
        valueVector = (Vector) fieldVector.elementAt(aValue - 1);

        // We want to get the entire value in it's entire fashion
        if (aSubValue == 0) {
            tmpDyn = new UniDynArray(uniConnection);
            int n = valueVector.size();

            for (int i = 0; i < n; i++) {
                tmpDyn.append((byte[]) valueVector.elementAt(i));
                if (i != n - 1) { // If we aren't at the end, we must tack on
                    // a SubValue mark
                    tmpDyn.append(getMarkByte(UniTokens.SVM));
                }
            }
            // E3912 -return new UniDynArray( tmpString );
            return tmpDyn;
        }

        // Deal with boundary conditions
        if ((aSubValue > valueVector.size()) || (aSubValue < 0)) {
            return tmpDyn;
        }

        // Finally, if all we want is the subvalue, let's send it back
        // E3912- return new UniDynArray( (String)valueVector.elementAt(
        // aSubValue - 1 ) );
        tmpDyn.append((byte[]) valueVector.elementAt(aSubValue - 1));
        return tmpDyn;
    }

    /**
     * Extracts a copy of the requested field
     * 
     * @param aField
     *            integer representing which field to extract
     * @param aValue
     *            integer representing which value to extract
     * @return UniDynArray representing the requested field
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray extract(int aField, int aValue) {
        return extract(aField, aValue, 0);
    }

    /**
     * Extracts a copy of the entire array
     * 
     * @param aField
     *            integer representing which field to extract
     * @return UniDynArray representing the requested extraction
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray extract(int aField) {
        return extract(aField, 0, 0);
    }

    /**
     * Inserts an Object into the dynamic array at the given
     * field,value,subvalue position
     * 
     * @param aField
     *            integer representing which field to insert data into
     * @param aValue
     *            integer representing which value to insert data into
     * @param aSubValue
     *            integer representing which subvalue to insert data into
     * @param aString
     *            String representing the data to be inserted
     * @since UNICLIENTLIBS 1.0
     */
    public void insert(int aField, int aValue, int aSubValue, Object aString) {
        Vector fieldVector, valueVector;
        byte[] insertBytes;
        
        insertBytes = getByteValue(aString);
        if (insertBytes == null) return;

        // check to see if we need to construct the array
        checkBytesChanged();

        // If field is < 0, it means to append to the array
        if (aField < 0) {
            fieldVector = new Vector();
            valueVector = new Vector();
            dynArray.addElement(fieldVector);
            fieldVector.addElement(valueVector);
            valueVector.addElement(insertBytes);

            dynArrayChanged = true;

            // This is required to assure that if we add a string with mark
            // characters in it,
            // it will be properly generated
            if (hasMarkBytes(insertBytes))
                regenerateDynArray();

            return;
        }

        // If field is 0, is means to prepend to the array
        if (aField == 0) {
            fieldVector = new Vector();
            valueVector = new Vector();
            dynArray.insertElementAt(fieldVector, 0);
            fieldVector.insertElementAt(valueVector, 0);
            valueVector.addElement(insertBytes);

            dynArrayChanged = true;

            // This is required to assure that if we add a string with mark
            // characters in it,
            // it will be properly generated
            if (hasMarkBytes(insertBytes))
                regenerateDynArray();

            return;
        }

        // If field is greater than the end, we need to pad it out with empty
        // fields
        if (aField > dynArray.size()) {
            int currFields = dynArray.size();

            // Pad out current array with new entries till the
            // to be inserted one
            for (int i = currFields; i < aField - 1; i++) {
                fieldVector = new Vector();
                valueVector = new Vector();
                dynArray.addElement(fieldVector);
                fieldVector.addElement(valueVector);
                valueVector.addElement(new byte[0]);
            }

            // insert an empty field with no element at all when
            // there is a value or subvalue to be inserted
            // otherwise it will be a complete new field and it is going
            // be taken care of below
            if (!(aValue == 0 && aSubValue == 0)) {
                fieldVector = new Vector();
                dynArray.addElement(fieldVector);
            }
        }

        // If value is 0, it means to add a completely new field within the
        // array
        if ((aValue == 0) && (aSubValue == 0)) {
            fieldVector = new Vector();
            valueVector = new Vector();
            dynArray.insertElementAt(fieldVector, aField - 1);
            fieldVector.insertElementAt(valueVector, 0);
            valueVector.addElement(insertBytes);

            dynArrayChanged = true;

            // This is required to assure that if we add a string with mark
            // characters in it,
            // it will be properly generated
            if (hasMarkBytes(insertBytes))
                regenerateDynArray();

            return;
        }

        // Otherwise, we are dealing with adding a value

        // Deal with boundary condition
        if (aValue == 0)
            aValue = 1;

        // get the field array, remembering to subtract one
        fieldVector = (Vector) dynArray.elementAt(aField - 1);

        // value of < 0 means to append to the current values
        if (aValue < 0) {
            aValue = fieldVector.size() + 1;
        }

        // value greater than current size means we need to pad out some
        if (aValue > fieldVector.size()) {
            int currValues = fieldVector.size();

            // Pad out current array with new values till the to be
            // inserted one
            for (int i = currValues; i < aValue - 1; i++) {
                valueVector = new Vector();
                fieldVector.addElement(valueVector);
                valueVector.addElement(new byte[0]);
            }

            // if there is a subvalue to be inserted, add a empty
            // value vector
            // otherwise it will be a complete new value and will be
            // taken care of in the code below
            if (!(aSubValue == 0)) {
                valueVector = new Vector();
                fieldVector.addElement(valueVector);
            }
        }

        // a subvalue of 0 means add a complete new value to the array and
        // be done with it
        if (aSubValue == 0) {
            valueVector = new Vector();
            fieldVector.insertElementAt(valueVector, aValue - 1);
            valueVector.addElement(insertBytes);

            dynArrayChanged = true;

            // This is required to assure that if we add a string with mark
            // characters in it,
            // it will be properly generated
            if (hasMarkBytes(insertBytes))
                regenerateDynArray();

            return;
        }

        // Otherwise, we are dealing with adding a subvalue

        // Get the value array, remembering to subtract 1
        valueVector = (Vector) fieldVector.elementAt(aValue - 1);

        // value of < 0 means to append to the current subvalues
        if (aSubValue < 0) {
            // If we are appending to just one element, and that element has
            // already
            // been creacter, we don't want to just add in a new element, we
            // want to
            // replace this element.
            if ((valueVector.size() == 1)
                    && ((byte[]) valueVector.elementAt(0)).length == 0) {
                valueVector.setElementAt(insertBytes, 0);
            } else {
                // otherwise, we want to append
                valueVector.addElement(insertBytes);
            }
        } else {
            // Pad out current array with new values till the
            // to be inserted one
            if (aSubValue > valueVector.size()) {
                int currSubValues = valueVector.size();
                for (int i = currSubValues; i < aSubValue - 1; i++) {
                    valueVector.addElement(new byte[0]);
                }
            }

            // Finally! Add the new subvalue
            // J.Mao this should be bug, it may cause a empty subvalue be lost
//            if ((valueVector.size() == 1)
//                    && ((byte[]) valueVector.elementAt(0)).length == 0) {
//                valueVector.setElementAt(insertBytes, 0);
//            } else {
//                valueVector.insertElementAt(insertBytes, aSubValue - 1);
//            }
            valueVector.insertElementAt(insertBytes, aSubValue - 1);
        }

        dynArrayChanged = true;

        // This is required to assure that if we add a string with mark
        // characters in it,
        // it will be properly generated
        if (hasMarkBytes(insertBytes))
            regenerateDynArray();
    }

    /**
     * Inserts an Object into the dynamic array at the given field,value
     * position
     * 
     * @param aField
     *            integer representing which field to insert data into
     * @param aValue
     *            integer representing which value to insert data into
     * @param aString
     *            String representing the data to be inserted
     * @since UNICLIENTLIBS 1.0
     */
    public void insert(int aField, int aValue, Object aString) {
        insert(aField, aValue, 0, aString);
    }

    /**
     * Inserts an Object into the dynamic array at the given field position
     * 
     * @param aField
     *            integer representing which field to insert data into
     * @param aString
     *            String representing the data to be inserted
     * @since UNICLIENTLIBS 1.0
     */
    public void insert(int aField, Object aString) {
        insert(aField, 0, 0, aString);
    }

    /**
     * Returns the length of the given field,value,subvalue of the dynamic array
     * 
     * @param aField
     *            integer representing the field to obtain the length of
     * @param aValue
     *            integer representing the value to get the length from
     * @param aSubValue
     *            integer representing the subvalue to get the length from
     * @return integer representing the length of the field,value,subvalue of
     *         the dynamic array
     * @since UNICLIENTLIBS 1.0
     */
    public int length(int aField, int aValue, int aSubValue) {
        // if we are requesting a field less than 0, just return 0
        if (aField < 0)
            return 0;

        // check to see if we need to construct the array
        checkBytesChanged();

        // extract temporary copy of the dynamic array
        UniDynArray tmpVal = this.extract(aField, aValue, aSubValue);

        // figure out how long it really is
        return tmpVal.toString().length();
    }

    /**
     * Returns the length of the given field,value of the dynamic array
     * 
     * @param aField
     *            integer representing the field to obtain the length of
     * @param aValue
     *            integer representing the value to get the length from
     * @return integer representing the length of the field,value of the dynamic
     *         array
     * @since UNICLIENTLIBS 1.0
     */
    public int length(int aField, int aValue) {
        return length(aField, aValue, 0);
    }

    /**
     * Returns the length of the entire dynamic array
     * 
     * @param aField
     *            integer representing which field to insert data into
     * @return integer representing the length of the dynamic array
     * @since UNICLIENTLIBS 1.0
     */
    public int length(int aField) {
        return length(aField, 0, 0);
    }

    /**
     * Performs a delete on the given field/value/subvalue, but also returns the
     * deleted subvalue
     * 
     * @param aField
     *            integer representing the field to remove
     * @param aValue
     *            integer representing the value to remove
     * @param aSubValue
     *            integer representing the subvalue to remove
     * @return UniDynArray representing the deleted subvalue from the array
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray remove(int aField, int aValue, int aSubValue) {
        // check to see if we need to construct the array
        checkBytesChanged();

        UniDynArray retArray = this.extract(aField, aValue, aSubValue);
        this.delete(aField, aValue, aSubValue);
        return retArray;
    }

    /**
     * Performs a delete on the given field/value, but also returns the deleted
     * value
     * 
     * @param aField
     *            integer representing the field to remove
     * @param aValue
     *            integer representing the value to remove
     * @return UniDynArray representing the deleted value from the array
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray remove(int aField, int aValue) {
        return remove(aField, aValue, 0);
    }

    /**
     * Performs a delete on the given field, but also returns the deleted field
     * 
     * @param aField
     *            integer representing the field to remove
     * @return UniDynArray representing the deleted field from the array
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray remove(int aField) {
        return remove(aField, 0, 0);
    }

    /**
     * Replaces the field/value/subvalue specified with the new data value
     * 
     * @param aField
     *            integer representing the field to replace
     * @param aValue
     *            integer representing the value to replace
     * @param aSubValue
     *            representing the subvalue to replace
     * @param aString
     *            Object representing the new data value
     * @since UNICLIENTLIBS 1.0
     */
    public void replace(int aField, int aValue, int aSubValue, Object aString) {
        Vector fieldVector, valueVector;
        byte[] replaceBytes;
        
        replaceBytes = getByteValue(aString);
        if (replaceBytes == null) return;
        
        // if we are doing any appending,
        if ((aField < 0) || (aValue < 0) || (aSubValue < 0)) {
            insert(aField, aValue, aSubValue, aString);
            return;
        }

        // if we are going to prepend
        if (aField == 0) {
            insert(1, aValue, aSubValue, aString);
            return;
        }

        // check to see if we need to construct the array
        checkBytesChanged();

        // if we need to pad things out
        if (aField > dynArray.size()) {
            for (int i = dynArray.size(); i < aField; i++) {
                fieldVector = new Vector();
                valueVector = new Vector();
                dynArray.addElement(fieldVector);
                fieldVector.addElement(valueVector);
                valueVector.addElement(new byte[0]);
            }
        }

        // Get the field array
        fieldVector = (Vector) dynArray.elementAt(aField - 1);

        // if we need to prepend the value
        if (aValue == 0) {
            fieldVector = new Vector();
            valueVector = new Vector();
            dynArray.setElementAt(fieldVector, aField - 1);
            fieldVector.addElement(valueVector);
            valueVector.addElement(replaceBytes);

            dynArrayChanged = true;

            // This is required to assure that if we add a string with mark
            // characters in it,
            // it will be properly generated
            if (hasMarkBytes(replaceBytes))
                regenerateDynArray();

            return;
        } else {
            // if we need to pad out the value field
            if (aValue > fieldVector.size()) {
                for (int i = fieldVector.size(); i < aValue; i++) {
                    valueVector = new Vector();
                    fieldVector.addElement(valueVector);
                    valueVector.addElement(new byte[0]);
                }
            }

            valueVector = (Vector) fieldVector.elementAt(aValue - 1);

            // if we need to pad out the subvalue fields
            if (aSubValue > valueVector.size()) {
                for (int i = valueVector.size(); i < aSubValue; i++) {
                    valueVector.addElement(new byte[0]);
                }
            }
            // if we are going to prepend a value
            if (aSubValue == 0) {
                valueVector = new Vector();
                fieldVector.setElementAt(valueVector, aValue - 1);
                valueVector.addElement(replaceBytes);
            } else {
                valueVector.setElementAt(replaceBytes, aSubValue - 1);
            }
        }

        dynArrayChanged = true;

        // This is required to assure that if we add a string with mark
        // characters in it,
        // it will be properly generated
        if (hasMarkBytes(replaceBytes))
            regenerateDynArray();
    }

    /**
     * Replaces the field/value specified with the new data value
     * 
     * @param aField
     *            integer representing the field to replace
     * @param aValue
     *            integer representing the value to replace
     * @param aString
     *            Object representing the new data value
     * @since UNICLIENTLIBS 1.0
     */
    public void replace(int aField, int aValue, Object aString) {
        replace(aField, aValue, 0, aString);
    }

    /**
     * Replaces the field specified with the new data value
     * 
     * @param aField
     *            integer representing the field to replace
     * @param aString
     *            Object representing the new data value
     * @since UNICLIENTLIBS 1.0
     */
    public void replace(int aField, Object aString) {
        replace(aField, 0, 0, aString);
    }

    //    /**
    //     * replaces the contents of the dynamic array with the given newValue
    //     * 
    //     * param newValue a String object representing the dynamic array
    //     * 
    //     * @since UNICLIENTLIBS 1.0
    //     */
    //    public void setValue(Object newValue) {
    //        super.setValue(newValue.toString());
    //    }
    //
    //    /**
    //     * replaces the contents of the dynamic array with the given newValue
    //     * 
    //     * param newValue a String object representing the dynamic array
    //     * 
    //     * @since UNICLIENTLIBS 1.0
    //     */
    //    public void setValue(String newValue) {
    //        super.setValue(newValue);
    //    }

    // /**
    // * Converts the given UniDynArray into a base String
    // *
    // * @return a String object representing the dynamic array
    // * @since UNICLIENTLIBS 1.0
    // */
    // public String toString()
    // {
    // Vector anAttribute, aValue;
    // StringBuffer Result = new StringBuffer();
    //		
    // // If the string form is currently good, just return it
    // // GTAR 28926 - return only valid portion of char array
    // if ( isStringActive )
    // return new String( this.byteValue, 0, count );
    //		
    //	
    // checkBytesChanged( );
    //	
    // int numFields = dynArray.size();
    // for ( int i = 0; i < numFields; i++ )
    // {
    // anAttribute = (Vector)dynArray.elementAt(i);
    // int numValues = anAttribute.size();
    // for(int j = 0; j < numValues; j++ )
    // {
    // aValue = (Vector)anAttribute.elementAt(j);
    // int numSubValues = aValue.size();
    // for (int k = 0; k < numSubValues; k++ )
    // {
    // Result.append( (String)aValue.elementAt(k) );
    // if ( k != numSubValues - 1 )
    // {
    // Result.append(getMarkByte( UniTokens.SVM ) );
    // }
    // }
    // if ( j != numValues - 1 )
    // {
    // Result.append(getMarkByte( UniTokens.VM) );
    // }
    // }
    // if ( i < numFields - 1 )
    // {
    // Result.append(getMarkByte( UniTokens.FM ) );
    // }
    // }
    //	
    // // Now that we have formed the new string, set the string as active
    // boolean tmpState = isArrayActive;
    // this.setValue( Result );
    // isArrayActive = tmpState;
    // isStringActive = true;
    //		
    // return( Result.toString() );
    // }

    /**
     * Converts the given String into a Vector array
     * 
     * @param a
     *            String object representing the dynamic array
     * @since UNICLIENTLIBS 1.0
     */
    // private void constructDynArray( char[] itemArray )
    // {
    // Vector aFieldVector, aValueVector; // temporary vectors to fill main in
    // String field, value, subvalue; // temporary strings
    //
    // int indexVal = 0, tmpIndexVal = 0; // index markers into parsed string
    // int fieldVal = 0, tmpFieldVal = 0;
    // int valueVal = 0, tmpValueVal = 0;
    //		
    // String item = new String( itemArray );
    //
    // dynArray = new Vector(); // primary storage vector for UniDynArray
    //		
    // if (( item == null ) || ( item.equals("") )) return;
    //		
    // while ( indexVal != -1 )
    // {
    // aFieldVector = new Vector();
    // dynArray.addElement( aFieldVector );
    // tmpIndexVal = item.indexOf( getMarkByte( UniTokens.FM ), indexVal );
    //			
    // if ( tmpIndexVal != -1 ) field = item.substring( indexVal, tmpIndexVal );
    // else field = item.substring( indexVal, item.length() );
    //	
    // fieldVal = 0;
    //			
    // while ( fieldVal != -1 )
    // {
    // aValueVector = new Vector();
    // aFieldVector.addElement(aValueVector);
    // tmpFieldVal = field.indexOf( getMarkByte( UniTokens.VM ), fieldVal );
    //		
    // if ( tmpFieldVal != -1 ) value = field.substring( fieldVal, tmpFieldVal
    // );
    // else value = field.substring( fieldVal, field.length() );
    //					
    // valueVal = 0;
    // while ( valueVal != -1 )
    // {
    // tmpValueVal = value.indexOf( getMarkByte( UniTokens.SVM ), valueVal );
    // if ( tmpValueVal != -1 ) subvalue = value.substring( valueVal,
    // tmpValueVal );
    // else
    // subvalue = value.substring( valueVal, value.length() );
    //					
    // aValueVector.addElement( subvalue );
    //					
    // if ( tmpValueVal != -1 ) tmpValueVal++;
    // valueVal = tmpValueVal;
    // }
    //				
    // if ( tmpFieldVal != -1 ) tmpFieldVal++;
    // fieldVal = tmpFieldVal;
    // }
    //			
    // if ( tmpIndexVal != -1 ) tmpIndexVal++;
    // indexVal = tmpIndexVal;
    // }
    // }
    
    
    private boolean hasMarkBytes(byte[] bytes) {
        // Check to see if the string has any of the given mark characters
        if (indexOf(bytes, getMarkByte(UniTokens.FM), 0) != -1)
            return true;
        if (indexOf(bytes, getMarkByte(UniTokens.VM), 0) != -1)
            return true;
        if (indexOf(bytes, getMarkByte(UniTokens.SVM), 0) != -1)
            return true;

        return false;
    }

    //  private void checkBytesChanged( boolean changeStringState )
    //  {
    //  	// only need to construct the string if it isn't already active
    //  	if ( !isArrayActive )
    //  	{
    //  //		constructDynArray( this.byteValue );
    //  		isArrayActive = true;
    //  	}
    //  	
    //  	// if the action is destructive, change string state to false
    //  	if ( changeStringState )
    //  	{
    //  		isStringActive = false;
    //  	}
    //  }

    /**
     * count the mark characters, using except_val to determine what to return
     *  
     * @since   UNICLIENTLIBS 1.1
     */
    private int count_marks(int aField, int aValue, int aSubValue,
            int except_val) {
        Vector fieldVector, valueVector;
        int fieldMarks, valueMarks, subValueMarks;
        String tmpVal = this.toString();

        // check to see if we need to construct the array
        checkBytesChanged();

        // Check case with empty dynarray
        if (tmpVal.equals(""))
            return 0;

        // Get the number of field marks in the UniDynArray
        fieldMarks = dynArray.size();

        // Deal with boundary conditions
        // if requesting a negative field value, return 0
        // if requesting field '0', counts the overall number of field marks
        // if we are requesting a field outside the realm of what exists, return 0
        if ((aField < 0) || (aField > fieldMarks))
            return 0;
        if (aField == 0)
            return fieldMarks - 1;

        // Get the requested field.  
        // Note, as UniDynArrays are '1' based while the Vector's are '0' based, remember
        // to take away 1
        fieldVector = (Vector) dynArray.elementAt(aField - 1);

        // get the number of value marks within this field
        valueMarks = fieldVector.size();

        // Deal with boundary conditions
        // if requesting a negative  value, return 0
        // if requesting value '0', counts the overall number of value marks
        // if we are requesting a value outside the realm of what exists, return 0
        if ((aValue < 0) || (aValue > valueMarks))
            return except_val;
        if (aValue == 0) {
            if (valueMarks == 1) {
                String tmp_val = fieldVector.firstElement().toString();
                if (tmp_val.equals("[]")) {
                    return except_val;
                }
            }
            return valueMarks - 1;
        }

        // Get the requested field.  
        // Note, as UniDynArrays are '1' based while the Vector's are '0' based, remember
        // to take away 1
        valueVector = (Vector) fieldVector.elementAt(aValue - 1);

        // get the number of subvalue marks within this value
        subValueMarks = valueVector.size();

        // Deal with boundary conditions
        // if requesting a negative subvalue, return 0
        // if requesting subvalue '0', counts the overall number of subvalue marks
        // if we are requesting a subvalue outside the realm of what exists, return 0
        if ((aSubValue < 0) || (aSubValue > subValueMarks))
            return except_val;
        if (aSubValue == 0) {
            if (subValueMarks == 1) {
                String tmpObj = valueVector.firstElement().toString();
                if (tmpObj.equals(""))
                    return except_val;
            }
            return subValueMarks - 1;
        }

        return subValueMarks;
    }
    
    /**
     * replaces the contents of the dynamic array with the given newValue
     *  
     * param    newValue a String object representing the dynamic array
     * @since   UNICLIENTLIBS 1.0
     */
    public void setValue( Object newValue )
    {
        super.setValue( newValue);
    }
    
    /**
     * replaces the contents of the dynamic array with the given newValue
     *  
     * param    newValue a String object representing the dynamic array
     * @since   UNICLIENTLIBS 1.0
     */
    public void setValue( String newValue )
    {
        super.setValue( newValue );
    }
    
    /**
     * Converts the given UniDynArray into a base String
     *  
     * @return  a String object representing the dynamic array
     * @since   UNICLIENTLIBS 1.0
     */
    public String toString()
    {
        return super.toString();
    }
}
