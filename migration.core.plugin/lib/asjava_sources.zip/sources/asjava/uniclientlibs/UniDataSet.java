/*************************************************************************
 *
 * UniDataSet.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 01/30/01 PTS(145729) JFM
 * 01/03/01 PTS(145274) JFM 
 * 11/05/98 23699 DTM Initial Creation
 *************************************************************************/
package asjava.uniclientlibs;

import java.io.*;
import java.util.*;
import java.lang.Integer;

public class UniDataSet implements Serializable {
    /**
     * A UniDataSet object is a collection object. It provides a collection
     * interface for sets of <code>UniRecord</code> objects, which can then be
     * used to perform bulk or batch style operations with one network
     * operation.
     * 
     * @since UNICLIENTLIBS 1.0
     */
    public UniDataSet() {
        // First element is actually going to be the column definitions. By
        // default, it will be:
        // recordID: @FM : record. If this is the case, the formatType property
        // will be set to
        // DEFAULT_FORMAT.
        formatType = DEFAULT_FORMAT;
    }

    /**
     * A UniDataSet object is a collection object. It provides a collection
     * interface for sets of <code>UniRecord</code> objects, which can then be
     * used to perform bulk or batch style operations with one network
     * operation.
     * 
     * @param initVal
     *            string representing the initial recordIDs to be stored in the
     *            dataset, which are separated by the UniTokens.AT_FM character
     * @since UNICLIENTLIBS 1.0
     */
    public UniDataSet(Object initVal) {
        this(initVal, UniTokens.AT_FM);
    }

    /**
     * A UniDataSet object is a collection object. It provides a collection
     * interface for sets of <code>UniRecord</code> objects, which can then be
     * used to perform bulk or batch style operations with one network
     * operation.
     * 
     * @param initVal
     *            string representing the initial recordIDs to be stored in the
     *            dataset
     * @param delimiter
     *            string representing the delimiter to use to separate the
     *            recordID string
     * @since UNICLIENTLIBS 1.0
     */
    public UniDataSet(Object initVal, String delimiter) {
        // Properly initialize things
        this();

        String setString;
        if (initVal == null)
            setString = new String();
        else
            setString = initVal.toString();

        UniStringTokenizer setTok = new UniStringTokenizer(setString, delimiter);
        int numTokens = setTok.countTokens();

        for (int i = 0; i < numTokens; i++) {
            UniRecord newRec = new UniRecord(setTok.nextToken());
            this.append(newRec);
        }
    }

    /**
     * A UniDataSet object is a collection object. It provides a collection
     * interface for sets of <code>UniRecord</code> objects, which can then be
     * used to perform bulk or batch style operations with one network
     * operation. *FOR INTERNAL USE ONLY*
     * 
     * @param origSet
     *            UniDataSet object containing the recordIDs that will be copied
     *            into the new dataset object
     * @param newSet
     *            delimited string containing the data for the new collection
     * @param retSet
     *            delimited string containing the return values for the new
     *            collection
     * @param statSet
     *            delimited string containing the status values for the new
     *            collection
     * @param returnCode
     *            integer representing the overall dataset status
     * @param delimiter
     *            string representing the delimiter to use to separate the
     *            strings
     * @since UNICLIENTLIBS 1.0
     */
//    private UniDataSet(UniDataSet origSet, Object newSet, Object retSet,
//            Object statSet, int returnCode, String delimiter) {
//        // set up new data set element with the same format as the original
//        this.formatType = origSet.formatType;
//
//        if (newSet == null)
//            newSet = new String();
//        if (retSet == null)
//            retSet = new String();
//        if (statSet == null)
//            statSet = new String();
//
//        // Now, we need to parse through the return data and create the elements
//        // of the dataSet
//        UniStringTokenizer origSetok = new UniStringTokenizer(origSet
//                .getIDSet(), delimiter);
//        UniStringTokenizer newSettok = new UniStringTokenizer(
//                newSet.toString(), delimiter);
//        UniStringTokenizer retSettok = new UniStringTokenizer(
//                retSet.toString(), delimiter);
//        UniStringTokenizer statSettok = new UniStringTokenizer(statSet
//                .toString(), delimiter);
//
//        // should use the original count
//        // int numTokens = newSettok.countTokens();
//        int numTokens = origSetok.countTokens();
//        for (int i = 0; i < numTokens; i++) {
//            // First we should set up the UniRecord to insert into the new
//            // dataset
//            try {
//                int status, retCode;
//                String recVal;
//                UniRecord newRec;
//
//                // changed to fix pts 145729
//                recVal = retSettok.nextToken();
//                if (recVal == null)
//                    retCode = returnCode;
//                else
//                    retCode = Integer.parseInt(recVal);
//
//                recVal = statSettok.nextToken();
//                if (recVal == null)
//                    status = 0;
//                else
//                    status = Integer.parseInt(recVal);
//
//                // because newSet may not be of the same length as the origSet
//                // need to check it before creating a new record
//                // UniRecord newRec = new UniRecord( origSetok.nextToken(),
//                // newSettok.nextToken(),
//                // status );
//
//                recVal = newSettok.nextToken();
//                if (recVal == null)
//                    newRec = new UniRecord(origSetok.nextToken(), "", status);
//                else
//                    newRec = new UniRecord(origSetok.nextToken(), recVal,
//                            status);
//
//                newRec.setReturnCode(retCode);
//                this.append(newRec);
//            } catch (java.util.NoSuchElementException e) {
//                UniRecord newRec = new UniRecord("", "", -1);
//                this.append(newRec);
//            }
//        }
//    }
//
    public UniDataSet(UniConnection aConn) {
        formatType = DEFAULT_FORMAT;
        uniConnection = aConn;
    }

    public UniDataSet(UniDynArray dyn) {
        int nFields = dyn.dcount();

        for (int i = 0; i < nFields; i++) {
            UniRecord newRec = new UniRecord(dyn.extract(i + 1));
            this.append(newRec);
        }
    }

    public UniDataSet(UniDataSet origSet, UniDynArray newSet,
            UniDynArray retSet, UniDynArray statSet, int returnCode) {

        // set up new data set element with the same format as the original
        this.formatType = origSet.formatType;
        this.uniConnection = origSet.uniConnection;

        if (newSet == null)
            newSet = new UniDynArray(origSet.uniConnection);
        if (retSet == null)
            retSet = new UniDynArray(origSet.uniConnection);
        if (statSet == null)
            statSet = new UniDynArray(origSet.uniConnection);

        UniString origIdSet = origSet.getIDSetUniDynArray();

        // should use the original count
        // int numTokens = newSettok.countTokens();
        byte delimiter = newSet.getMarkByte(UniTokens.IM);

        UniByteArrayTokenizer origSetok = new UniByteArrayTokenizer(
                origIdSet.getBytes(), delimiter);
        UniByteArrayTokenizer newSettok = new UniByteArrayTokenizer(
                newSet.getBytes(), delimiter);
        UniByteArrayTokenizer retSettok = new UniByteArrayTokenizer(
                retSet.getBytes(), delimiter);
        UniByteArrayTokenizer statSettok = new UniByteArrayTokenizer(
                statSet.getBytes(), delimiter);

        int numTokens = origSet.getRowCount();
        for (int i = 0; i < numTokens; i++) {
            // First we should set up the UniRecord to insert into the new
            // dataset
            try {
                int status, retCode;
                UniString recVal;
                UniRecord newRec;

                // changed to fix pts 145729
                recVal = new UniString(uniConnection, retSettok.nextToken());
                if (recVal == null)
                    retCode = returnCode;
                else
                    retCode = Integer.parseInt(recVal.toString());

                recVal = new UniString(uniConnection, statSettok.nextToken());
                if (recVal == null)
                    status = 0;
                else
                    status = Integer.parseInt(recVal.toString());

                // because newSet may not be of the same length as the origSet
                // need to check it before creating a new record
                // UniRecord newRec = new UniRecord( origSetok.nextToken(),
                // newSettok.nextToken(),
                // status );

                recVal = new UniString(uniConnection, newSettok.nextToken());
                if (recVal == null)
                    newRec = new UniRecord(new UniString(uniConnection,
                            origSetok.nextToken()),
                            new UniString(uniConnection), status);
                else
                    newRec = new UniRecord(new UniString(uniConnection,
                            origSetok.nextToken()), recVal, status);

                newRec.setReturnCode(retCode);
                this.append(newRec);
            } catch (java.util.NoSuchElementException e) {
                UniRecord newRec = new UniRecord("", "", -1);
                this.append(newRec);
            }
        }
    }

    /**
     * specifies the absolute position within the <code>UniDataSet</code> that
     * the cursor should point to
     * 
     * @param rowNum
     *            integer which specifies the absolute position within the
     *            UniDataSet
     * @return boolean specifying whether the operation was successful.
     * @see #relative
     * @since UNICLIENTLIBS 1.0
     */
    public boolean absolute(int rowNum) {
        // if rowNum is negative, count from the last row back
        if (rowNum < 0)
            currentRow = this.getRowCount() + rowNum;
        else
            currentRow = rowNum;

        // Ok, now let's ensure it's set correctly
        if (currentRow < 0) {
            // trying to set before beginning, set to beforeFirst
            this.first();
            return false;
        }

        if (currentRow >= this.getRowCount()) {
            // trying to set beyond end, set to afterLast()
            this.afterLast();
            return false;
        }

        return true;
    }

    /**
     * moves the internal <code>UniDataSet</code> cursor to point to the end
     * of the data set.
     * 
     * @see #isBeforeFirst
     * @since UNICLIENTLIBS 1.0
     */
    public void afterLast() {
        currentRow = this.getRowCount();
    }

    /**
     * appends a new data element at the end of the existing data set
     * 
     * @param rowID
     *            Object that specifies the data to be added
     * @return boolean representing whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean append(Object rowID) {
        return append(rowID, "");
    }

    /**
     * appends a new data element at the end of the existing data set
     * 
     * @param rowID
     *            object that identifies the data added
     * @param rowData
     *            object that specifies the data to be added
     * @return boolean representing whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean append(Object rowID, Object rowData) {
        UniRecord recordSet = new UniRecord(rowID, rowData);
        return append(recordSet);
    }

    /**
     * appends a new data element at the end of the existing data set
     * 
     * @param recordSet
     *            UniRecord object that specifies the data to be added
     * @return boolean representing whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean append(UniRecord recordSet) {
        return insert(this.getRowCount() + 1, recordSet);
    }

    /**
     * closes the dataset, resetting internal values to their initial state
     * 
     * @since UNICLIENTLIBS 1.0
     */
    public void close() {
        this.first();
        formatType = DEFAULT_FORMAT;
        LAST_ROW = 0;
        rowSet.removeAllElements();
    }

    /**
     * deletes the current row from the dataset
     * 
     * @return boolean denoting whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean deleteRow() {
        return deleteRow(currentRow);
    }

    /**
     * deletes the <code>indexLoc</code> row from the dataset
     * 
     * @param indexLoc
     *            integer repesenting which row to be deleted
     * @return boolean denoting whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean deleteRow(int indexLoc) {
        // have to protect against trying to delete before the dummy row
        if (this.getRowCount() == 0)
            return false;

        if (indexLoc < 0)
            indexLoc = 0;
        if (indexLoc >= this.getRowCount())
            indexLoc = this.getRowCount() - 1;

        rowSet.removeElementAt(indexLoc);
        LAST_ROW--;
        return true;
    }

    /**
     * deletes the row referenced by the recordID specified. If the recordID
     * does not exist in the dataset, it will return <code>false</code>
     * 
     * @param recordID
     *            integer repesenting which row to be deleted
     * @return boolean denoting whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean deleteRow(String recordID) {
        // first we need to find which record they requested
        int rowID = findRow(recordID);

        // if the column wasn't found, we need to return an error
        if (rowID < 0)
            return false;
        // otherwise, let's try and delete it
        return deleteRow(rowID);
    }

    /**
     * identifies the cursor position of a given row, based on the recordID
     * passed in. If the recordID is found, the index value is passed back. If
     * it is not found, a -1 is returned
     * 
     * @param aRowVal
     *            name of the field to reference
     * @return integer denoting the cursor position of the requested recordID
     *         name. If the recordID was not found, -1 is returned.
     * @since UNICLIENTLIBS 1.0
     */
    public int findRow(String aRowVal) {
        int rowPos;

        for (rowPos = 0; rowPos < this.getRowCount(); rowPos++) {
            UniRecord recordSet = (UniRecord) rowSet.elementAt(rowPos);
            UniDynArray recID = recordSet.getRecordID();
            if (recID.equals(aRowVal))
                break;
        }

        if (rowPos >= this.getRowCount())
            return NOT_FOUND;

        return rowPos;
    }

    /**
     * moves the internal <code>UniDataSet</code> cursor to point to the
     * beginning of the data set.
     * 
     * @see #isBeforeFirst
     * @since UNICLIENTLIBS 1.0
     */
    public void first() {
        currentRow = 0;
    }

    /**
     * returns the current cursor position within the dataset.
     * 
     * @return integer representing the current cursor positions
     * @since UNICLIENTLIBS 1.0
     */
    public int getCurrentRow() {
        return currentRow;
    }

    /**
     * returns the data contained in the dataset as a
     * 
     * @IM separated String
     * 
     * @return String representing an
     * @IM separated String of the dataset data
     * @since UNICLIENTLIBS 1.0
     */
    public String getDataSet() {
        StringBuffer x = new StringBuffer();

        int rowCount = this.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            UniRecord y = (UniRecord) rowSet.elementAt(i);

            x.append(y.getRecord());
            // We take one away from the end because we are 0 based
            if (i != rowCount - 1)
                x.append(UniTokens.AT_IM);
        }

        return x.toString();
    }

    public UniDynArray getDataSetUniDynArray() {
        UniDynArray x = new UniDynArray(uniConnection);

        int rowCount = this.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            UniRecord y = (UniRecord) rowSet.elementAt(i);

            x.append(y.getRecord());
            // We take one away from the end because we are 0 based
            if (i != rowCount - 1)
                x.append(x.getMarkByte(UniTokens.IM));
        }

        return x;
    }

    /**
     * returns the IDs contained in the dataset as a
     * 
     * @IM separated String
     * 
     * @return String representing an
     * @IM separated String of the dataset IDs
     * @since UNICLIENTLIBS 1.0
     */
    public String getIDSet() {
        StringBuffer x = new StringBuffer();

        int rowCount = this.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            UniRecord y = (UniRecord) rowSet.elementAt(i);

            x.append(y.getRecordID());
            // We take one away from the end because we are 0 based
            if (i != rowCount - 1)
                x.append(UniTokens.AT_IM);
        }

        return x.toString();
    }

    public UniDynArray getIDSetUniDynArray() {
        UniDynArray x = new UniDynArray(uniConnection);

        int rowCount = this.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            UniRecord y = (UniRecord) rowSet.elementAt(i);

            x.append(y.getRecordID());
            // We take one away from the end because we are 0 based
            if (i != rowCount - 1)
                x.append(x.getMarkByte(UniTokens.IM));
        }

        return x;

    }

    /**
     * returns the dataset row represented by <code>currentRow</code> as a
     * String
     * 
     * @return String representing the requested dataset row
     * @since UNICLIENTLIBS 1.0
     */
    String getString() {
        return getString(currentRow);
    }

    /**
     * returns the dataset row represented by <code>columnIndex</code> as a
     * String
     * 
     * @param columnIndex
     *            integer representing which dataset row to retrieve
     * @return String representing the requested dataset row
     * @since UNICLIENTLIBS 1.0
     */
    public String getString(int columnIndex) {
        if (columnIndex < 0)
            columnIndex = 0;
        // if requesting past the end, set it to the last element
        if (columnIndex >= this.getRowCount())
            columnIndex = this.getRowCount() - 1;

        UniRecord recordSet = (UniRecord) rowSet.elementAt(currentRow);
        return recordSet.toString();
    }

    /**
     * returns the dataset row represented by <code>columnName</code> as a
     * String
     * 
     * @param columnName
     *            String representing the recordID to be retrieved.
     * @return String representing the requested dataset row
     * @since UNICLIENTLIBS 1.0
     */
    public String getString(String columnName) {
        int columnIndex = findRow(columnName);
        return getString(columnIndex);
    }

    /**
     * Extracts the row currently pointed to by the cursor position and returns
     * it as a <code>UniDynArray</code> object
     * 
     * @return UniDynArray representing the current row of the dataset as a
     *         UniDynArray
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray getUniDynArray() {
        return getUniDynArray(currentRow);
    }

    /**
     * Extracts the row referenced by <code>indexLoc</code> and returns it as
     * a <code>UniDynArray</code> object
     * 
     * @param indexLoc
     *            integer representing the cursor row to return
     * @return UniDynArray representing the current row of the dataset as a
     *         UniDynArray
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray getUniDynArray(int indexLoc) {
        if (indexLoc < 0)
            indexLoc = 0;
        // if requesting past the end, set it to the last element
        if (indexLoc >= this.getRowCount())
            indexLoc = this.getRowCount() - 1;

        UniRecord recordSet = (UniRecord) rowSet.elementAt(indexLoc);
        return recordSet.toUniDynArray();
    }

    /**
     * Extracts the row referenced by <code>columnName</code> and returns it
     * as a <code>UniDynArray</code> object
     * 
     * @param columnName
     *            string representing the record ID of the row to return
     * @return UniDynArray representing the current row of the dataset as a
     *         UniDynArray
     * @since UNICLIENTLIBS 1.0
     */
    public UniDynArray getUniDynArray(String columnName) {
        int columnIndex = findRow(columnName);
        return getUniDynArray(columnIndex);
    }

    /**
     * Extracts the row currently pointed to by the cursor position and returns
     * it as a <code>UniRecord</code> object
     * 
     * @return UniRecord representing the current row of the dataset as a
     *         UniString
     * @since UNICLIENTLIBS 1.0
     */
    public UniRecord getUniRecord() {
        return getUniRecord(currentRow);
    }

    /**
     * Extracts the row currently pointed to by the cursor position and returns
     * it as a <code>getUniRecord</code> object
     * 
     * @return UniRecord representing the current row of the dataset as a
     *         UniString
     * @since UNICLIENTLIBS 1.0
     */
    public UniRecord getUniRecord(int indexLoc) {
        if (indexLoc < 0)
            indexLoc = 0;
        // if requesting past the end, set it to the last element
        if (indexLoc >= this.getRowCount())
            indexLoc = this.getRowCount() - 1;

        UniRecord recordSet = (UniRecord) rowSet.elementAt(indexLoc);
        return recordSet;
    }

    /**
     * Extracts the row currently pointed to by the cursor name and returns it
     * as a <code>getUniRecord</code> object
     * 
     * @return UniRecord representing the current row of the dataset as a
     *         UniString
     * @since UNICLIENTLIBS 1.0
     */
    public UniRecord getUniRecord(String columnName) {
        int columnIndex = findRow(columnName);
        return getUniRecord(columnIndex);
    }

    /**
     * Extracts the row currently pointed to by the cursor position and returns
     * it as a <code>UniString</code> object
     * 
     * @return UniDynArray representing the current row of the dataset as a
     *         UniString
     * @since UNICLIENTLIBS 1.0
     */
    public UniString getUniString() {
        return getUniString(currentRow);
    }

    /**
     * Extracts the row currently pointed to by the cursor position and returns
     * it as a <code>UniString</code> object
     * 
     * @param indexLoc
     *            integer representing the cursor row to return
     * @return UniDynArray representing the current row of the dataset as a
     *         UniString
     * @since UNICLIENTLIBS 1.0
     */
    public UniString getUniString(int indexLoc) {
        if (indexLoc < 0)
            indexLoc = 0;
        // if requesting past the end, set it to the last element
        if (indexLoc >= this.getRowCount())
            indexLoc = this.getRowCount() - 1;

        UniRecord recordSet = (UniRecord) rowSet.elementAt(indexLoc);
        return recordSet.toUniString();
    }

    /**
     * Extracts the row currently pointed to by the cursor position and returns
     * it as a <code>UniString</code> object
     * 
     * @param columnName
     *            String representing the record ID of the cursor row to return
     * @return UniDynArray representing the current row of the dataset as a
     *         UniString
     * @since UNICLIENTLIBS 1.0
     */
    public UniString getUniString(String columnName) {
        int columnIndex = findRow(columnName);
        return getUniString(columnIndex);
    }

    /**
     * returns the dataset size
     * 
     * @return integer representing the size of the dataset
     * @since UNICLIENTLIBS 1.0
     */
    public int getRowCount() {
        return LAST_ROW;
    }

    /**
     * inserts a new row into the dataset, inserting the row at the current
     * cursor position.
     * 
     * @param rowVal
     *            the rowID of the row being inserted
     * @return boolean representing whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean insert(Object rowVal) {
        return insert(currentRow, rowVal);
    }

    /**
     * inserts a new row into the dataset, inserting the row at the given cursor
     * position
     * 
     * @param indexLoc
     *            the location where the row should be inserted
     * @param rowID
     *            the rowID of the row being inserted
     * @return boolean representing whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean insert(int indexLoc, Object rowID) {
        return insert(indexLoc, rowID, "");
    }

    /**
     * inserts a new row into the dataset, inserting the row at the current
     * cursor position
     * 
     * @param rowID
     *            the recordID of this row
     * @param rowVal
     *            the data value of this row
     * @return boolean representing whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean insert(Object rowID, Object rowVal) {
        return insert(currentRow, rowID, rowVal);
    }

    /**
     * inserts a new row into the dataset, inserting the row at the given cursor
     * position
     * 
     * @param indexLoc
     *            location in the dataset to insert this row
     * @param rowID
     *            the recordID of this row
     * @param rowVal
     *            the data value of this row
     * @return boolean representing whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean insert(int indexLoc, Object rowID, Object rowVal) {
        UniRecord recordSet = new UniRecord(rowID, rowVal);
        return insert(indexLoc, recordSet);
    }

    /**
     * inserts a new row into the dataset, inserting the row at the current
     * cursor position
     * 
     * @param recordSet
     *            UniRecord representing the entire row to be inserted
     * @return boolean representing whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean insert(UniRecord recordSet) {
        return insert(currentRow, recordSet);
    }

    /**
     * inserts a new row into the dataset, inserting the row at the current
     * cursor position
     * 
     * @param indexLoc
     *            the location where the row should be inserted
     * @param recordSet
     *            UniRecord representing the entire row to be inserted
     * @return boolean representing whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean insert(int indexLoc, UniRecord recordSet) {
        // have to protect against trying to insert before dummy row
        if (indexLoc < 0)
            indexLoc = 0;
        if (indexLoc > this.getRowCount())
            rowSet.addElement(recordSet);
        else
            rowSet.insertElementAt(recordSet, indexLoc);
        LAST_ROW++;
        return true;
    }

    /**
     * determines whether or not cursor is positioned past the last row in the
     * dataset. It can be used for the determination of when the list is
     * exhausted.
     * 
     * @return boolean denoting whether the cursor is past the last row or not
     * @since UNICLIENTLIBS 1.0
     */
    public boolean isAfterLast() {
        if (currentRow >= this.getRowCount())
            return true;
        else
            return false;
    }

    /**
     * determines whether or not cursor is positioned before the first row in
     * the dataset.
     * 
     * @return boolean denoting whether the cursor is before the first row or
     *         not
     * @since UNICLIENTLIBS 1.0
     */
    public boolean isBeforeFirst() {
        if (currentRow < 0)
            return true;
        else
            return false;
    }

    /**
     * determines whether or not cursor is positioned at the first row in the
     * dataset.
     * 
     * @return boolean denoting whether the cursor is at the first row or not
     * @since UNICLIENTLIBS 1.0
     */
    public boolean isFirst() {
        if (currentRow == 0)
            return true;
        else
            return false;
    }

    /**
     * determines whether or not cursor is positioned at the last row in the
     * dataset.
     * 
     * @return boolean denoting whether the cursor is at the last row or not
     * @since UNICLIENTLIBS 1.0
     */
    public boolean isLast() {
        if (currentRow == this.getRowCount() - 1)
            return true;
        else
            return false;
    }

    /**
     * sets the cursor to the last row in the dataset
     * 
     * @since UNICLIENTLIBS 1.0
     */
    public void last() {
        currentRow = this.getRowCount() - 1;
    }

    /**
     * increments the dataset cursor by one. Returns true if the cursor position
     * could be moved. If it is already at the end of the dataset, it returns a
     * false.
     * 
     * @return boolean denoting whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean next() {
        currentRow++;

        if (currentRow >= this.getRowCount()) {
            afterLast();
            return false;
        } else
            return true;
    }

    /**
     * decrements the dataset cursor by one. Returns true if the cursor position
     * could be moved. If it is already at the beginning of the dataset, it
     * returns a false.
     * 
     * @return boolean denoting whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean previous() {
        currentRow--;

        if (currentRow < 0) {
            first();
            return false;
        }
        return true;
    }

    /**
     * positions the dataset cursor to a position <code>numRows</code> away
     * from the current position. For example, if the cursor is already set to
     * the third row, and UniDataSet.relative( 5 ) is referenced, it will set
     * the cursor to the eighth position within the set. If an operation is
     * successful, it returns a <code>true</code>. If the operation attempts
     * to move the cursor past the end or before the beginning, the cursor will
     * be set to the last row or first row respectively and the operation will
     * return <code>false</code>.
     * 
     * @param numRows
     *            integer representing the number of rows the cursor should be
     *            moved
     * @return boolean denoting whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean relative(int numRows) {
        currentRow = currentRow + numRows;

        // Ok, now let's ensure it's set correctly

        if (currentRow < 0) {
            this.first();
            return false;
        }

        if (currentRow >= this.getRowCount()) {
            this.afterLast();
            return false;
        }

        return true;
    }

    /**
     * sets the cursor position to the <code>indexLoc</code> value referenced.
     * Returns <code>true</code
     * if the operation was successful and <code>false</code> if the operation attempted to position the
     * cursor outside the dataset
     *
     * @param indexLoc the index location to be used for the dataset.
     * @return boolean denoting whether the operation was successful
     * @since UNICLIENTLIBS 1.0
     */
    public boolean setIndex(int indexLoc) {
        if ((indexLoc < 0) || (indexLoc >= this.getRowCount()))
            return false;

        currentRow = indexLoc;

        return true;
    }

    /**
     * Converts the dataset into it's <code>String</code> representation. It
     * will add a UniVerse
     * 
     * @IM mark inbetween each row of the dataset.
     * 
     * @return String representing the dataset as a String
     * @since UNICLIENTLIBS 1.0
     */
    public String toString() {
        StringBuffer x = new StringBuffer();
        int rowCount = this.getRowCount();

        for (int i = 0; i < rowCount; i++) {
            UniRecord recordSet = (UniRecord) rowSet.elementAt(i);
            x.append(recordSet.toString());

            // shouldn't do this because UniRecord.toString() already appended a
            // AT_IM
            // if ( i != (rowCount-1) )
            // x.append( UniTokens.AT_IM );
            //
        }
        return x.toString();
    }

    private static final int DEFAULT_FORMAT = 0;

    private static final int NOT_FOUND = -1;

    private int currentRow = 0;

    private int LAST_ROW = 0;

    protected int formatType = DEFAULT_FORMAT;

    protected Vector rowSet = new Vector();

    protected UniConnection uniConnection = null;

}
