/*************************************************************************
 *
 * UniString.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 *       IBM Confidential
 *       OCO Source Materials
 *       Copyright (C) IBM Corp.  1993, 2009
 *
 * ? Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition.......................................... 
 * 09/07/10 UCC-715 JFM getByteValue() should return byte[0] instead of null
 * 07/10/09 40310 JFM more NLS enhancement dealing with Object type parameter
 * 07/31/07 36413 JFM check if passed-in UniString is null in append(UniString)
 * 01/12/07 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 09/10/04 32722 WMY change several @see to avoid javadoc warning.
 * 12/05/03 E3912 JFM GB18030, add getBytes(enc) 
 * 10/14/02 2607,2609,2984 RKK NLS Stuff
 * 05/15/00 28853 DTM Fixed equals() method
 * 05/05/99 24995 DTM Fixed to be more thread safe
 * 03/22/99 24738 DTM Fixed count/dcount
 * 03/01/99 24607 DTM Fixed iconv/oconv
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniclientlibs;

import java.io.*;
import java.util.*;
import java.lang.Character;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;

import asjava.unirpc.*;

/**
 * <code>UniString</code> is the primary class used for handling UniObjects
 * Java string operations. It is an extension of the general String and
 * StringBuffer classes, with numerous UniVerse specific additions. Unlike those
 * classes, however, operations performed on the object, such as
 * <code>insert</code>, change the internal data element and do not return a
 * new object.
 * 
 * @version Version 1.0
 * @author David T. Meeks
 * @since UNICLIENTLIBS 1.0
 */

public class UniString extends Object implements Serializable {

    /**
     * Constructs a UniString with no characters in it and an initial capacity
     * of 16 characters.
     * 
     * @since UNICLIENTLIBS 1.0
     */
    public UniString() {
        this(16);
    }

    /**
     * Constructs a UniString with no characters in it and an initial capacity
     * specified by the <code>length</code> argument.
     * 
     * @param length
     *            the initial capacity.
     * @since UNICLIENTLIBS 1.0
     */
    public UniString(int length) {
        if (length < 0)
            length = 0;

        byteValue = new byte[length];
    }

    /**
     * Constructs a UniString with the value set to the supplied argument
     * 
     * @param aString
     *            initial string to set the object to
     * @since UNICLIENTLIBS 1.0
     */
    public UniString(String aString) {
        ByteBuffer bb = charset.encode(aString);
        count = bb.limit();
        byteValue = new byte[count];
        bb.get(byteValue);
    }

    /**
     * Constructs a UniString (copy constructor)
     * 
     * @param aString
     *            initial string to set the object to
     * @throws UniConnectionException
     * @since UNICLIENTLIBS 1.0
     */
    public UniString(UniString aString) {

        if (aString != null) {
            uniConnection = aString.uniConnection;
            if (uniConnection != null) {
                setMarks(uniConnection.getByteMarks());
                setEncoding(uniConnection.getEncoding());
            }
            byteValue = aString.getBytes();
            count = byteValue.length;
        }
    }

    /**
     * Constructs a UniString with the value set to the supplied argument
     * 
     * @param aString
     *            initial string to set the object to
     * @since UNICLIENTLIBS 1.0
     */
    public UniString(Object aString) {
        if (aString instanceof byte[]) {
            byte[] bytes = (byte[]) aString;
            if (bytes == null) {
                byteValue = new byte[16];
                count = 0;
            } else {
                byteValue = new byte[bytes.length];
                System.arraycopy(bytes, 0, byteValue, 0, bytes.length);
                count = byteValue.length;
            }
        } else if (aString instanceof UniString) {
        	UniString uString = (UniString)aString;
            uniConnection = uString.uniConnection;
            if (uniConnection != null) {
                setMarks(uniConnection.getByteMarks());
                setEncoding(uniConnection.getEncoding());
            }
            byteValue = uString.getBytes();
            count = byteValue.length;
        } else  {
            ByteBuffer bb = charset.encode(aString.toString());
            count = bb.limit();
            byteValue = new byte[count];
            bb.get(byteValue);
        }

    }

    /**
     * Constructs a UniString with no characters in it and an initial capacity
     * of 16 characters, binds it to the given UniConnection object which will
     * cause it to perform certain operations on the server
     * 
     * @param aNewSession
     *            UniConnection object to bind the string to
     * @throws UniConnectionException
     * @since UNICLIENTLIBS 1.0
     */
    public UniString(UniConnection aNewSession) {
        byteValue = new byte[16];
        if (aNewSession != null) {
            uniConnection = aNewSession;
            setMarks(aNewSession.getByteMarks());
            setEncoding(aNewSession.getEncoding());
        }

    }

    /**
     * Constructs a UniString with no characters in it and an 
     * initial capacity of 16 characters. 
     *
     * @param aNewSession UniConnection object to bind the string to
     * @param aString initial string to set the object to.
     * @since   UNICLIENTLIBS 1.0
     */
    public UniString(UniConnection aNewSession, Object aString) {
        if (aString instanceof byte[]) {
            byte[] bytes = (byte[]) aString;
            if (aNewSession != null) {
                uniConnection = aNewSession;
                setMarks(aNewSession.getByteMarks());
                setEncoding(aNewSession.getEncoding());
            }
            if (bytes == null) {
                byteValue = new byte[16];
                count = 0;
            } else {
                byteValue = new byte[bytes.length];
                System.arraycopy(bytes, 0, byteValue, 0, bytes.length);
                count = byteValue.length;
            }
        } else if (aString instanceof UniString) {
        	UniString uString = (UniString)aString;
            uniConnection = uString.uniConnection;
            if (uniConnection != null) {
                setMarks(uniConnection.getByteMarks());
                setEncoding(uniConnection.getEncoding());
            }
            byteValue = uString.getBytes();
            count = byteValue.length;
        
        }else {
            if (aNewSession != null) {
                uniConnection = aNewSession;
                setMarks(aNewSession.getByteMarks());
                setEncoding(aNewSession.getEncoding());
            }
            ByteBuffer bb = charset.encode(aString.toString());
            count = bb.limit();
            byteValue = new byte[count];
            bb.get(byteValue);
        }   
    }

    public UniString(UniConnection aNewSession, byte[] aString) {
 
        byte[]  bytes = aString;
        
        if (aNewSession != null) {
            uniConnection = aNewSession;
            setMarks(aNewSession.getByteMarks());
            setEncoding(aNewSession.getEncoding());
        }
        if (bytes == null) {
            byteValue = new byte[16];
            count = 0;
        } else {
            byteValue = new byte[bytes.length];
            System.arraycopy(bytes, 0, byteValue, 0, bytes.length);
            count = byteValue.length;
        }
    }

    /**
     * Determines whether a given session contains only alphabetic characters
     * 
     * @return <code>boolean</code> to indicate whether string is all
     *         alphabetic or not
     * @exception UniStringException
     *                is thrown if an error occurs
     * @since UNICLIENTLIBS 1.0
     */
    public boolean alpha() throws UniStringException {
        // If we have established a UniConnection object, and that UniConnection
        // is NLS aware..
        if ((uniConnection != null) && (uniConnection.isNLSEnabled()))
            return alpha(uniConnection);

        // Otherwise, just check it out locally...
        checkChanged();
        for (int i = 0; i < charValue.length; i++) {
            if (!Character.isLetter(charValue[i]))
                return false;
        }
        return true;
    }

    /**
     * Determines whether a given session contains only alphabetic characters.
     * This version uses the defined <code>UniConnection</code> reference to
     * perform the operation on the defined connection. This is primarily done
     * for NLS purposes.
     * 
     * @param aConnection
     *            UniConnection object representing the server we should contact
     *            to ensure this string is alphabetic
     * @return <code>boolean</code> to indicate whether string is all
     *         alphabetic or not
     * @exception UniStringException
     *                is thrown if an error occurs
     * @since UNICLIENTLIBS 1.0
     */
    public boolean alpha(UniConnection aConnection) throws UniStringException {
        // If the session is not NLS aware, no need to do server side check
        if (!aConnection.isNLSEnabled())
            return alpha();

        synchronized (this) {
            try {
                uniConnection = aConnection;

                // If we have not yet established our packets
                if ((inPacket == null) || (outPacket == null)) {
                    inPacket = new UniRPCPacket(uniConnection.connection);
                    outPacket = new UniRPCPacket(uniConnection.connection);
                }
                outPacket.write(0, UniTokens.EIC_ALPHA);
                outPacket.write(1, getBytes());
                uniConnection.connection.call(outPacket, inPacket,
                        (byte) uniConnection.getDefaultEncryptionType());

                if (inPacket.readInteger(0) == 0)
                    return false;
                else
                    return true;
            } catch (UniRPCException e) {
                throw new UniStringException(e.getErrorCode());
            }
        } // synch this
    }

    /**
     * Appends the string representation of the <code>Object</code> argument
     * to this string buffer.
     * 
     * @param aString
     *            string to append
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(String aString) {
        byte[] ba = encode(aString);
        append(ba);
    }

    /**
     * Appends the string representation of the <code>Object</code> argument
     * to this string buffer.
     * 
     * @param aString
     *            string to append
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(Object aString) {
    	byte[] appendBytes = getByteValue(aString);
        this.append(appendBytes);
    }

    protected synchronized void append(UniString aString) {
        if (aString != null)
            this.append(aString.getBytes());
    }

    /**
     * Appends the string representation of the <code>char</code> array
     * argument to this string buffer.
     * 
     * @param str
     *            the characters to be appended.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(char str[]) {
        this.append(str, 0, str.length);
    }

    /**
     * Appends the string representation of a subarray of the <code>char</code>
     * array argument to this string buffer.
     * 
     * @param str
     *            the characters to be appended.
     * @param offset
     *            the index of the first character to append.
     * @param len
     *            the number of characters to append.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(char str[], int offset, int len) {
        byte[] ba = encode(str, offset, len);
        append(ba);
    }

    /**
     * Appends the string representation of the <code>boolean</code> argument
     * to the string buffer.
     * 
     * @param b
     *            a <code>boolean</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(boolean b) {
        append(String.valueOf(b));
    }

    /**
     * Appends the string representation of the <code>char</code> argument to
     * this string buffer.
     * 
     * @param c
     *            a <code>char</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(char c) {
        char[] ca = new char[1];
        ca[0] = c;
        append(ca);
    }

    public synchronized void append(byte ba) {
        checkDynChanged();
        byte[] bytes = new byte[1];
        bytes[0] = ba;

        append(bytes);
    }

    public synchronized void append(byte[] ba) {
        checkDynChanged();

        ensureCapacity(count + ba.length);
        for (int i = 0; i < ba.length; i++)
            byteValue[count++] = ba[i];

        valueChanged = true;

    }

    /**
     * Appends the string representation of the <code>int</code> argument to
     * this string buffer.
     * 
     * @param i
     *            an <code>int</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(int i) {
        append(String.valueOf(i));
    }

    /**
     * Appends the string representation of the <code>long</code> argument to
     * this string buffer.
     * 
     * @param l
     *            a <code>long</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(long l) {
        append(String.valueOf(l));
    }

    /**
     * Appends the string representation of the <code>float</code> argument to
     * this string buffer.
     * 
     * @param f
     *            a <code>float</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(float f) {
        append(String.valueOf(f));
    }

    /**
     * Appends the string representation of the <code>double</code> argument
     * to this string buffer.
     * 
     * @param d
     *            a <code>double</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void append(double d) {
        append(String.valueOf(d));
    }

    protected static int indexOf(byte[] src, byte[] target, int start) {
        if (start < 0)
            start = 0;
        int subCount = target.length;
        if (subCount > 0) {
            if (subCount + start > src.length)
                return -1;
            byte firstByte = target[0];
            int end = subCount;
            while (true) {
                int i = indexOf(src, firstByte, start);
                if (i == -1 || subCount + i > src.length)
                    return -1; // handles subCount > count || start >= count
                int o1 = i, o2 = 0;
                while (++o2 < end && src[++o1] == target[o2])
                    ;
                if (o2 == end)
                    return i;
                start = i + 1;
            }
        } else
            return start < src.length ? start : src.length;
    }

    protected static int indexOf(byte[] src, byte b, int start) {
        int count = src.length;
        if (start < count) {
            if (start < 0)
                start = 0;
            for (int i = start; i < count; i++) {
                if (src[i] == b)
                    return i;
            }
        }
        return -1;
    }

    /**
     * Changes the current string by replacing a given substring expression with
     * the replacement substring specified
     * 
     * @param aSubString
     *            String representing the substring to be replaced
     * @param aReplacementString
     *            String representing what the <code>aSubString</code> should
     *            be replaced with
     * @since UNICLIENTLIBS 1.0
     */
    public void change(Object aSubString, Object aReplacementString) {
        change(aSubString, aReplacementString, 0, 0);
    }

    /**
     * Changes the current string by replacing a given substring expression with
     * the replacement substring specified
     * 
     * @param aSubString
     *            String representing the substring to be replaced
     * @param aReplacementString
     *            String representing what the <code>aSubString</code> should
     *            be replaced with
     * @param aOccurance
     *            integer representing the number of occurance to change. A
     *            number less than 1 refers to replacing all occurrances of the
     *            substring
     * @since UNICLIENTLIBS 1.0
     */
    public void change(Object aSubString, Object aReplacementString,
            int aOccurance) {
        change(aSubString, aReplacementString, aOccurance, 0);
    }

    /**
     * Changes the current string by replacing a given substring expression with
     * the replacement substring specified
     * 
     * @param aSubString
     *            String representing the substring to be replaced
     * @param aReplacementString
     *            String representing what the <code>aSubString</code> should
     *            be replaced with
     * @param aOccurance
     *            integer representing the number of occurance to change. A
     *            number less than 1 refers to replacing all occurrances of the
     *            substring
     * @param aStart
     *            integer referring to the first occurance to start replacing. A
     *            number less than 1 refers to starting from the beginning
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void change(Object aSubString,
            Object aReplacementString, int aOccurance, int aStart) {
        // calculate the new start position in byes
        char[] ca = decode(byteValue, 0, count);

        if (aStart < 0) 
            aStart = 0;
        
        byte[] ba = encode(ca, 0, aStart);

        byte[] subBa, repBa;
        if (aSubString instanceof byte[])
            subBa = (byte[]) aSubString;
        else
            subBa = encode(aSubString.toString());

        if (aReplacementString instanceof byte[])
            repBa = (byte[]) aReplacementString;
        else
            repBa = encode(aReplacementString.toString());

        change(subBa, repBa, aOccurance, ba.length);
    }

    private synchronized void change(byte[] subBytes, byte[] replaceBytes,
            int aOccurance, int aStart) {
        boolean continueFlag = true;
        int currentOccurance = 0;
        int curLoc = 0, oldCurLoc = 0;
        byte[] newValue;
      //  byte[] oldValue = new byte[count];

        checkDynChanged();

 //       System.arraycopy(byteValue, 0, oldValue, 0, count);

        // Handle special case of a null substring
        if (subBytes.length == 0) {
            return;
        }

        // Handle boundary conditions
        if (aOccurance < 0)
            aOccurance = 0;
        if (aStart < 0)
            aStart = 0;

        // cycle through to the first occurrance to test
        while ((currentOccurance != aStart) && (oldCurLoc != -1)) {
            oldCurLoc = indexOf(byteValue, subBytes, oldCurLoc);
            if (oldCurLoc != -1) {
                currentOccurance++;
                curLoc = oldCurLoc;
                oldCurLoc = oldCurLoc + subBytes.length;
            }
        }

        // Handle case where we have tried to get the correct occurance, but
        // we've cycled past
        // the end of the string
        if ((aStart != currentOccurance) && (oldCurLoc == -1))
            return;

        // Ok, now we should be positions at the appropriate spot
        while (continueFlag) {
            // find the next occurance
            curLoc = indexOf(byteValue, subBytes, curLoc);

            // If we have not found anything, stop trying
            if (curLoc == -1) {
                continueFlag = false;
            } else {
                // need to replace this occurance
                int newSize = count - subBytes.length + replaceBytes.length;
                ensureCapacity(newSize);

                newValue = new byte[newSize];
                // If first occurance is after the first character, copy all
                // those characters into new array
                if (curLoc > 0) {
                    System.arraycopy(byteValue, 0, newValue, 0, curLoc);
                }
                // Now, copy the replacement string in
                System.arraycopy(replaceBytes, 0, newValue, curLoc,
                        replaceBytes.length);

                // Now, copy the remainder of the string in
                System.arraycopy(byteValue, curLoc + subBytes.length, newValue,
                        curLoc + replaceBytes.length, count - subBytes.length
                                - curLoc);

                // Re-adjust the count/size of the string
                count = count - subBytes.length + replaceBytes.length;
                byteValue = newValue;

                curLoc = curLoc + replaceBytes.length;
                // if we have found all of our occurances
                currentOccurance++;
                if ((currentOccurance == aOccurance) && (aOccurance != 0))
                    continueFlag = false;

                valueChanged = true;
            }
        }

    }

    /*
     * regenerate charValue if either the byteValue or the dyn structure has
     * been changed
     */
    protected void checkChanged() {
        if (valueChanged == true) {
            // reconstruct the dyn array structure
            constructDynArray();
 
        } else if (dynArrayChanged == true) {
            // update the bytevalue from the changed dyn array structure
            collapseDynArray();
        }
        // always update the charValue to keep it up to date
        charValue = decode(byteValue, 0, count);
    }

    protected void checkDynChanged() {
        if (dynArrayChanged == true) {
            // update the bytevalue from the changed dyn array structure
            collapseDynArray();
        }
    }

    protected void checkBytesChanged() {
        if (valueChanged == true) {
            // reconstruct the dyn array structure
            constructDynArray();
        }
    }

    /**
     * Returns the character at a specific index in this string buffer.
     * 
     * @param index
     *            the index of the desired character.
     * @return the character at the specified index of this string buffer.
     * @exception UniStringException
     *                is thrown if an error occurs
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized char charAt(int index) throws UniStringException {
        if ((index < 0) || (index >= count)) {
            throw new UniStringException(UniTokens.UVE_EINVAL);
        }

        checkChanged();

        return charValue[index];

    }

    /**
     * Returns the lexicographical comparison of this string against the string
     * passed in as an argument. Will return a 0 if the strings are
     * lexicographically equivalent, a value less than 0 if this string is less
     * than the argument string, or a value greater than 0 if this string is
     * lexicographically greater.
     * 
     * @param aCompareString
     *            Object to compare against
     * @return integer representing the lexicographical comparison. 0 denotes
     *         equivalence, < 0 denotes this string is less than the argument
     *         string, and > 0 denotes that it compares greater than the
     *         argument string.
     * @since UNICLIENTLIBS 1.0
     */
    public int compareTo(Object aCompareString) {

        return this.toString().compareTo(aCompareString.toString());
    }

    /*
     * return a sub array containing the bytes from start to end - 1 in the source array
     */
    protected static byte[] subByteArray(byte[] bytes, int start, int end) {

        int length = end - start;
        if (length < 0)
            length = 0;
        byte[] subBytes = new byte[length];
        System.arraycopy(bytes, start, subBytes, 0, length);
        return subBytes;
    }

    protected void constructDynArray() {
        Vector aFieldVector, aValueVector; // temporary vectors to fill main in
        byte[] field, value, subvalue; // temporary strings

        byte[] item = new byte[count];

        int indexVal = 0, tmpIndexVal = 0; // index markers into parsed string
        int fieldVal = 0, tmpFieldVal = 0;
        int valueVal = 0, tmpValueVal = 0;

        System.arraycopy(byteValue, 0, item, 0, count);

        valueChanged = false;
        dynArrayChanged = false;

        dynArray = new Vector(); // primary storage vector for UniDynArray

        if ((item == null) || (item.length == 0))
            return;

        while (indexVal != -1) {
            aFieldVector = new Vector();
            dynArray.addElement(aFieldVector);
            tmpIndexVal = indexOf(item, getMarkByte(UniTokens.FM), indexVal);

            if (tmpIndexVal != -1)
                field = subByteArray(item, indexVal, tmpIndexVal);
            else
                field = subByteArray(item, indexVal, item.length);

            fieldVal = 0;

            while (fieldVal != -1) {
                aValueVector = new Vector();
                aFieldVector.addElement(aValueVector);
                tmpFieldVal = indexOf(field, getMarkByte(UniTokens.VM),
                        fieldVal);

                if (tmpFieldVal != -1)
                    value = subByteArray(field, fieldVal, tmpFieldVal);
                else
                    value = subByteArray(field, fieldVal, field.length);

                valueVal = 0;
                while (valueVal != -1) {
                    tmpValueVal = indexOf(value, getMarkByte(UniTokens.SVM),
                            valueVal);
                    if (tmpValueVal != -1)
                        subvalue = subByteArray(value, valueVal, tmpValueVal);
                    else
                        subvalue = subByteArray(value, valueVal, value.length);

                    aValueVector.addElement(subvalue);

                    if (tmpValueVal != -1)
                        tmpValueVal++;
                    valueVal = tmpValueVal;
                }

                if (tmpFieldVal != -1)
                    tmpFieldVal++;
                fieldVal = tmpFieldVal;
            }

            if (tmpIndexVal != -1)
                tmpIndexVal++;
            indexVal = tmpIndexVal;
        }

    }

    /**
     * Converts a set of characters with a new set
     * 
     * @param aConnection
     *            UniConnection object used to establish which server to perform
     *            operation
     * @param aReplaceChars
     *            String of characters to be replaced
     * @param aReplaceWithChars
     *            characters to replace the others with.
     * @exception UniStringException
     *                is thrown if an error occurs
     * @since UNICLIENTLIBS 1.0
     */
    public void convert(UniConnection aConnection, Object aReplaceChars,
            Object aReplaceWithChars) throws UniStringException {
        synchronized (this) {
            // If this session is not NLS aware, no need to go to server
            if (!aConnection.isNLSEnabled()) {
                convert(aReplaceChars, aReplaceWithChars);
            }

            String replaceChars = aReplaceChars.toString();
            String replaceWithChars = aReplaceWithChars.toString();

            try {
                uniConnection = aConnection;

                if ((inPacket == null) || (outPacket == null)) {
                    inPacket = new UniRPCPacket(uniConnection.connection);
                    outPacket = new UniRPCPacket(uniConnection.connection);
                }
                outPacket.write(0, UniTokens.EIC_CONVERT);
                outPacket.write(1, encode(replaceChars));
                outPacket.write(2, encode(replaceWithChars));
                outPacket.write(3, getBytes());

                uniConnection.connection.call(outPacket, inPacket,
                        (byte) uniConnection.getDefaultEncryptionType());

                int returnCode = inPacket.readInteger(0);
                // operation was successful
                if (returnCode == 0) {
                    byte[] tmpValue = inPacket.readBytes(1);
                    checkChanged();
                    count = 0;
                    append(tmpValue);
                } else {
                    throw new UniStringException(returnCode);
                }
                ;
            } catch (UniRPCException e) {
                throw new UniStringException(e.getErrorCode());
            }
        } // synch this
    }

    /**
     * Converts a set of characters with a new set
     * 
     * @param aReplaceChars
     *            String of characters to be replaced
     * @param aReplaceWithChars
     *            characters to replace the others with.
     * @exception UniStringException
     *                is thrown if an error occurs
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void convert(Object aReplaceChars,
            Object aReplaceWithChars) throws UniStringException {
        char replaceChars[] = aReplaceChars.toString().toCharArray();
        char replaceWithChars[] = aReplaceWithChars.toString().toCharArray();
        int replaceLen = aReplaceChars.toString().length();
        int replaceWithLen = aReplaceWithChars.toString().length();
        boolean replaced = false;

        checkBytesChanged();

        Vector anAttribute, aValue;
        int numFields = dynArray.size();
        for (int i = 0; i < numFields; i++) {
            anAttribute = (Vector) dynArray.elementAt(i);
            int numValues = anAttribute.size();
            for (int j = 0; j < numValues; j++) {
                aValue = (Vector) anAttribute.elementAt(j);
                int numSubValues = aValue.size();
                for (int k = 0; k < numSubValues; k++) {
                    byte[] bytes = (byte[]) aValue.elementAt(k);
                    char[] chars = decode(bytes);
                    char[] newchars = new char[chars.length];
                    int newsize=0;
                    boolean changedFlag = false;
                    replaced = false;
                    for (int j1 = 0; j1 < chars.length; j1++) {
                        for (int i1 = 0; i1 < replaceLen; i1++) {
                            if (chars[j1] == replaceChars[i1]) {
                                if (i1 < replaceWithLen) {
                                    newchars[newsize++] = replaceWithChars[i1];
                                    replaced = true;
                                   
                                }
                                changedFlag = true;
                                break;
                            }
                        }
                        if ( !changedFlag )
                            newchars[ newsize++ ] = chars[ j1 ];
                        
                        changedFlag = false;
                    }
                    if (replaced) {
                        bytes = encode(newchars,0,newsize);
                        aValue.set(k, bytes);
                        dynArrayChanged = true;
                    }
                }
            }
        }

    }

    protected void collapseDynArray() {

        Vector anAttribute, aValue;
        int numFields = dynArray.size();

        UniString newstring = new UniString();

        for (int i = 0; i < numFields; i++) {
            anAttribute = (Vector) dynArray.elementAt(i);
            int numValues = anAttribute.size();
            for (int j = 0; j < numValues; j++) {
                aValue = (Vector) anAttribute.elementAt(j);
                int numSubValues = aValue.size();
                for (int k = 0; k < numSubValues; k++) {
                    byte[] bytes = (byte[]) aValue.elementAt(k);
                    newstring.append(bytes);
                    if (k != numSubValues - 1) {
                        newstring.append(getMarkByte(UniTokens.SVM));
                    }
                }
                if (j != numValues - 1) {
                    newstring.append(getMarkByte(UniTokens.VM));
                }
            }
            if (i < numFields - 1) {
                newstring.append(getMarkByte(UniTokens.FM));
            }
        }

        byteValue = newstring.getBytes();
        count = byteValue.length;

        valueChanged = false;
        dynArrayChanged = false;
    }

    /**
     * Count the number of
     * 
     * @FM marks existing in the string
     * 
     * @return integer representing the number of occurances
     * @since UNICLIENTLIBS 1.0
     */
    public int count() {
        return count(getMarkByte(UniTokens.FM));

    }

    private int count(byte mark) {
        checkDynChanged();
        int counter = 0;
        for (int i = 0; i < count; i++) {
            if (byteValue[i] == mark)
                counter++;
        }
        return counter;
    }

    /**
     * Count the number of occurances of the given substring
     * 
     * @param aSubString
     *            String representing the substring to check for
     * @return integer representing the number of occurances
     * @since UNICLIENTLIBS 1.0
     */
    public int count(Object aSubString) {
        String subString = aSubString.toString();
        String stringVal = toString();
        int subStringLen = subString.length();
        int curIndex = stringVal.indexOf(subString);
        int curCount = 0;

        // Handle special case where string is empty
        if (stringVal.equals(""))
            return 0;

        // Handle special case where substring is empty
        if (subStringLen == 0)
            return stringVal.length();

        // We've found at least one match
        if (curIndex != -1) {
            curCount++;

            // Cycle through, finding all the matches
            while (curIndex != -1) {
                curIndex = stringVal
                        .indexOf(subString, curIndex + subStringLen);
                curCount++;
            }

            // must take away one, because we added one too many earlier.
            curCount--;
        }

        return curCount;
    }

    /**
     * Count the number of occurances of the
     * 
     * @FM mark character, adding one to it
     * 
     * @return integer representing the number of occurances
     * @since UNICLIENTLIBS 1.0
     */
    public int dcount() {
        return count() + 1;
    }

    /**
     * Count the number of occurances of the given substring, adding one to it
     * 
     * @param aSubString
     *            String representing the substring to check for
     * @return integer representing the number of occurances
     * @since UNICLIENTLIBS 1.0
     */
    public int dcount(Object aSubString) {
        String stringVal = toString();

        // Handle special case where string is empty
        if (stringVal.equals(""))
            return 0;

        return count(aSubString) + 1;
    }

    /**
     * Determine whether this UniString is equivalent to another Object. Will
     * return <code>true</code> only if the two objects represent the same
     * sequence of characters.
     * 
     * @param anObject
     *            Object to compare against
     * @return boolean representing <code>true</code> if the sequence of
     *         characters represented by both is equivalent
     * @since UNICLIENTLIBS 1.0
     */
    public boolean equals(Object anObject) {
        if (this == anObject) {
            return true;
        }
        if (anObject != null) {
            if (anObject instanceof String)
                return (anObject.toString().equals(this.toString()));

            if ((anObject instanceof UniString)
                    || (anObject instanceof UniDynArray)) {
                byte[] ba1 = this.getBytes();
                byte[] ba2 = ((UniString) anObject).getBytes();
                if (ba1.length != ba2.length)
                    return false;
                for (int i = 0; i < ba1.length; i++)
                    if (ba1[i] != ba2[i])
                        return false;

                return true;

            }
        }
        return false;
    }

    /**
     * Determine whether this UniString is equivalent to another Object, when
     * case is ignored. Will return <code>true</code> only if the two objects
     * represent the same sequence of characters.
     * 
     * @param anObject
     *            Object to compare against
     * @return boolean representing <code>true</code> if the sequence of
     *         characters represented by both is equivalent
     * @since UNICLIENTLIBS 1.0
     */
    public boolean equalsIgnoreCase(Object anObject) {
        if (this == anObject) {
            return true;
        }
        if ((anObject != null)
                && ((anObject instanceof String)
                        || (anObject instanceof UniString) || (anObject instanceof UniDynArray))) {
            return (anObject.toString().equalsIgnoreCase(this.toString()));
        }
        return false;
    }

    /**
     * return the current string as a byte[] array
     * 
     * @return byte[] representing the current string
     * @since UNICLIENTLIBS 1.0
     */
    public byte[] getBytes() {
        checkDynChanged();
        byte[] ba = new byte[count];
        System.arraycopy(byteValue, 0, ba, 0, count);
        return ba;
    }

    /**
     * Characters are copied from this string buffer into the destination
     * character array <code>dst</code>. The first character to be copied is
     * at index <code>srcBegin</code>; the last character to be copied is at
     * index <code>srcEnd-1.</code> The total number of characters to be
     * copied is <code>srcEnd-srcBegin</code>. The characters are copied into
     * the subarray of <code>dst</code> starting at index
     * <code>dstBegin</code> and ending at index:
     * <p>
     * <blockquote>
     * 
     * <pre>
     * dstbegin + (srcEnd - srcBegin) - 1
     * </pre>
     * 
     * </blockquote>
     * 
     * @param srcBegin
     *            start copying at this offset in the string buffer.
     * @param srcEnd
     *            stop copying at this offset in the string buffer.
     * @param dst
     *            the array to copy the data into.
     * @param dstBegin
     *            offset into <code>dst</code>.
     * @exception UniStringException
     *                if there is an invalid index into the buffer.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void getChars(int srcBegin, int srcEnd, char dst[],
            int dstBegin) throws UniStringException {
        if ((srcBegin < 0) || (srcBegin >= count)) {
            throw new UniStringException(UniTokens.UVE_EINVAL);
        }
        if ((srcEnd < 0) || (srcEnd > count)) {
            throw new UniStringException(UniTokens.UVE_EINVAL);
        }
        checkChanged();
        if (srcBegin < srcEnd) {
            System.arraycopy(charValue, srcBegin, dst, dstBegin, srcEnd
                    - srcBegin);
        }
    }

    /**
     * Returns the requested mark character. Valid input values are:
     * <ul>
     * <li> UniTokens.IM (0) - Item Mark
     * <li> UniTokens.FM (1) - Field Mark
     * <li> UniTokens.VM (2) - Value Mark
     * <li> UniTokens.SVM(3) - SubValue Mark
     * <li> UniTokens.TM (4) - Text Mark
     * </ul>
     * 
     * @return String representing the requested mark value
     * @exception UniStringException
     *                is thrown if the input value is invalid
     * @since UNICLIENTLIBS 1.0
     */
    public String getMarkCharacter(int aTokenVal) throws UniStringException {
        if ((aTokenVal < UniTokens.IM) || (aTokenVal > UniTokens.TM))
            throw new UniStringException(UniTokens.UVE_EINVAL);

        if (uniConnection != null) {
            try {
                return uniConnection.getMarkCharacter(aTokenVal);

            } catch (UniConnectionException e) {
                throw new UniStringException(e.getErrorCode());
            }
        } else {
            return UniTokens.defaultMarkArray[aTokenVal];
        }
    }

    /**
     * Returns the requested mark value in byte. Valid input values are:
     * <ul>
     * <li> UniTokens.IM (0) - Item Mark
     * <li> UniTokens.FM (1) - Field Mark
     * <li> UniTokens.VM (2) - Value Mark
     * <li> UniTokens.SVM(3) - SubValue Mark
     * <li> UniTokens.TM (4) - Text Mark
     * </ul>
     * 
     * @return String representing the requested mark value
     * @exception UniStringException
     *                is thrown if the input value is invalid
     * @since UNICLIENTLIBS 2.0
     */

    public byte getMarkByte(int aTokenVal) {

        return marks[aTokenVal];

    }

    /**
     * Performs a conversion of the current string into an internal
     * representation, which depends on the given conversion code
     * 
     * @param aConnection
     *            UniConnection object representing which server to use to
     *            perform the conversion
     * @param aConvCode
     *            String representing the conversion that is to take place
     * @return UniString new string object representing the new value
     * @exception UniStringException
     *                is thrown if an error occurs
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized UniString iconv(UniConnection aConnection,
            Object aConvCode) throws UniStringException {
        uniStatus = 0;
        try {
            uniConnection = aConnection;
            if ((inPacket == null) || (outPacket == null)) {
                inPacket = new UniRPCPacket(uniConnection.connection);
                outPacket = new UniRPCPacket(uniConnection.connection);
            }
            outPacket.write(0, UniTokens.EIC_ICONV);
            outPacket.write(1, getBytes());
            outPacket.write(2, encode(aConvCode.toString()));

            uniConnection.connection.call(outPacket, inPacket,
                    (byte) uniConnection.getDefaultEncryptionType());

            // If no error has occurred
            if (inPacket.readInteger(0) == 0) {
                uniStatus = inPacket.readInteger(1);
                if (uniStatus == 0) {
                    UniString tmpString = new UniString(aConnection, inPacket
                            .readBytes(2));
                    tmpString.uniStatus = uniStatus;
                    return tmpString;
                }
            }
            return this;
        } catch (UniException e) {
            throw new UniStringException(e.getErrorCode());
        }
    }

    /**
     * Inserts the string into this string buffer.
     * <p>
     * The characters of the <code>String</code> argument are inserted, in
     * order, into this string buffer at the indicated offset. The length of
     * this string buffer is increased by the length of the argument.
     * <p>
     * The offset argument must be greater than or equal to <code>0</code>,
     * and less than or equal to the length of this string buffer.
     * 
     * @param offset
     *            the offset.
     * @param obj
     *            a Object.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void insert(int offset, Object obj) {
    	 byte[] insertBytes;
         
         insertBytes = getByteValue(obj);
         if (insertBytes == null) return;
         
         insert(offset,insertBytes);
    }

    private void insert(int byteOffset, byte[] bytes) {
        checkDynChanged();

        ensureCapacity(count + bytes.length);
        System.arraycopy(byteValue, byteOffset, byteValue, byteOffset
                + bytes.length, count - byteOffset);
        System.arraycopy(bytes, 0, byteValue, byteOffset, bytes.length);
        count += bytes.length;

        valueChanged = true;
    }

    /**
     * Inserts the string representation of the <code>char</code> array
     * argument into this string buffer.
     * <p>
     * The characters of the array argument are inserted into the contents of
     * this string buffer at the position indicated by <code>offset</code>.
     * The length of this string buffer increases by the length of the argument.
     * 
     * @param offset
     *            the offset.
     * @param str
     *            a character array.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void insert(int offset, char str[]) {

        byte[] ba;

        if (offset < 0)
            offset = 0;
        else {
            char[] ca = decode(byteValue, 0, count);
            if (offset >= ca.length)
                offset = count;
            else {
                ba = encode(ca, 0, offset);
                offset = ba.length;
            }
        }

        ba = encode(str);

        insert(offset, ba);
    }

    /**
     * Inserts the string representation of the <code>boolean</code> argument
     * into this string buffer.
     * <p>
     * The second argument is converted to a string as if by the method
     * <code>String.valueOf</code>, and the characters of that string are
     * then inserted into this string buffer at the indicated offset.
     * <p>
     * The offset argument must be greater than or equal to <code>0</code>,
     * and less than or equal to the length of this string buffer.
     * 
     * @param offset
     *            the offset.
     * @param b
     *            a <code>boolean</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public void insert(int offset, boolean b) {
        insert(offset, String.valueOf(b));
    }

    /**
     * Inserts the string representation of the <code>char</code> argument
     * into this string buffer.
     * <p>
     * The second argument is inserted into the contents of this string buffer
     * at the position indicated by <code>offset</code>. The length of this
     * string buffer increases by one.
     * <p>
     * The offset argument must be greater than or equal to <code>0</code>,
     * and less than or equal to the length of this string buffer.
     * 
     * @param offset
     *            the offset.
     * @param c
     *            a <code>char</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void insert(int offset, char c) {

        char[] chars = new char[1];
        chars[0] = c;
        insert(offset, chars);
    }

    /**
     * Inserts the string representation of the second <code>int</code>
     * argument into this string buffer.
     * <p>
     * The second argument is converted to a string as if by the method
     * <code>String.valueOf</code>, and the characters of that string are
     * then inserted into this string buffer at the indicated offset.
     * <p>
     * The offset argument must be greater than or equal to <code>0</code>,
     * and less than or equal to the length of this string buffer.
     * 
     * @param offset
     *            the offset.
     * @param i
     *            an <code>int</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void insert(int offset, int i) {
        insert(offset, String.valueOf(i));
    }

    /**
     * Inserts the string representation of the <code>long</code> argument
     * into this string buffer.
     * <p>
     * The second argument is converted to a string as if by the method
     * <code>String.valueOf</code>, and the characters of that string are
     * then inserted into this string buffer at the indicated offset.
     * <p>
     * The offset argument must be greater than or equal to <code>0</code>,
     * and less than or equal to the length of this string buffer.
     * 
     * @param offset
     *            the offset.
     * @param l
     *            a <code>long</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void insert(int offset, long l) {
        insert(offset, String.valueOf(l));
    }

    /**
     * Inserts the string representation of the <code>float</code> argument
     * into this string buffer.
     * <p>
     * The second argument is converted to a string as if by the method
     * <code>String.valueOf</code>, and the characters of that string are
     * then inserted into this string buffer at the indicated offset.
     * <p>
     * The offset argument must be greater than or equal to <code>0</code>,
     * and less than or equal to the length of this string buffer.
     * 
     * @param offset
     *            the offset.
     * @param f
     *            a <code>float</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void insert(int offset, float f) {
        insert(offset, String.valueOf(f));
    }

    /**
     * Inserts the string representation of the <code>double</code> argument
     * into this string buffer.
     * <p>
     * The second argument is converted to a string as if by the method
     * <code>String.valueOf</code>, and the characters of that string are
     * then inserted into this string buffer at the indicated offset.
     * <p>
     * The offset argument must be greater than or equal to <code>0</code>,
     * and less than or equal to the length of this string buffer.
     * 
     * @param offset
     *            the offset.
     * @param d
     *            a <code>double</code>.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void insert(int offset, double d) {
        insert(offset, String.valueOf(d));
    }

    /**
     * Returns the leftmost <code>aNumChars</code> characters of the string.
     * 
     * @param aNumChars
     *            integer representing the leftmost N characters of the string
     * @return the requested number of characters from the left handside of the
     *         string
     * @since UNICLIENTLIBS 1.0
     */
    public UniString left(int aNumChars) {

        checkChanged();

        // Test boundary conditions
        if (aNumChars < 0)
            return new UniString("");
        if (aNumChars > charValue.length)
            return new UniString(this);

        // Otherwise, let's go get the selected characters

        char tmpValue[] = new char[aNumChars];
        System.arraycopy(charValue, 0, tmpValue, 0, aNumChars);

        return new UniString(uniConnection, encode(tmpValue));
    }

    /**
     * Returns the length (character count) of this string buffer.
     * 
     * @return the number of characters in this string buffer.
     * @since UNICLIENTLIBS 1.0
     */
    public int length() {

        if (count <= 0)
            return 0;
        checkChanged();

        return charValue.length;
    }

    /**
     * Performs a conversion of the current string into an external
     * representation, which depends on the given conversion code
     * 
     * @param aConnection
     *            UniConnection object representing which server to use to
     *            perform the conversion
     * @param aConvCode
     *            String representing the conversion that is to take place
     * @return UniString new string object representing the new value
     * @exception UniStringException
     *                is thrown if an error occurs
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized UniString oconv(UniConnection aConnection,
            Object aConvCode) throws UniStringException {
        uniStatus = 0;
        try {
            uniConnection = aConnection;
            if ((inPacket == null) || (outPacket == null)) {
                inPacket = new UniRPCPacket(uniConnection.connection);
                outPacket = new UniRPCPacket(uniConnection.connection);
            }

            outPacket.write(0, UniTokens.EIC_OCONV);
            outPacket.write(1, getBytes());
            outPacket.write(2, encode(aConvCode.toString()));

            uniConnection.connection.call(outPacket, inPacket,
                    (byte) uniConnection.getDefaultEncryptionType());

            uniReturnCode = inPacket.readInteger(0);

            if (uniReturnCode == 0) {
                uniStatus = inPacket.readInteger(1);
                UniString tmpString = new UniString(aConnection, inPacket
                        .readBytes(2));
                tmpString.uniStatus = uniStatus;
                return tmpString;
            }
            return this;
        } catch (UniRPCException e) {
            throw new UniStringException(e.getErrorCode());
        }
    }

    /**
     * Quotes the given string with the "'" character (single quote)
     * 
     * @since UNICLIENTLIBS 1.0
     */
    public void quote() {
        quote("'");
    }

    /**
     * Quotes the given string with the given quote character
     * 
     * @param aChar
     *            character to quote string with
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void quote(Object aChar) {
        String quoteString = aChar.toString();

        this.insert(0, quoteString);
        this.append(quoteString);
    }

    /**
     * Returns the rightmost <code>aNumChars</code> characters of the string.
     * 
     * @param aNumChars
     *            integer representing the rightmost N characters of the string
     * @return the requested number of characters from the rightmost handside of
     *         the string
     * @since UNICLIENTLIBS 1.0
     */
    public UniString right(int aNumChars) {

        checkChanged();

        // Test boundary conditions
        if (aNumChars < 0)
            return new UniString("");
        if (aNumChars > charValue.length)
            return new UniString(this);

        char tmpValue[] = new char[aNumChars];
        System.arraycopy(charValue, charValue.length - aNumChars, tmpValue, 0,
                aNumChars);
        return new UniString(uniConnection, encode(tmpValue));
    }

    /**
     * The character at the specified index of this string buffer is set to
     * <code>ch</code>.
     * <p>
     * The offset argument must be greater than or equal to <code>0</code>,
     * and less than the length of this string buffer.
     * 
     * @param index
     *            the index of the character to modify.
     * @param ch
     *            the new character.
     * @exception UniStringException
     *                if the index is invalid.
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void setCharAt(int index, char ch)
            throws UniStringException {

        if ((index < 0) || (index >= charValue.length)) {
            throw new UniStringException(UniTokens.UVE_EINVAL);
        }

        checkChanged();

        charValue[index] = ch;
        count = 0;
        append(encode(charValue));

    }

    /**
     * Sets the current values of the string buffer and it's size
     * 
     * @return current status value
     * @since UNICLIENTLIBS 1.0
     */
    public synchronized void setValue(String newValue) {
        checkChanged();
        count = 0;
        append(encode(newValue));
    }

    /**
     * Sets the current values of the string buffer and it's size
     * 
     * @return current status value
     * @since UNICLIENTLIBS 1.0
     */
    public void setValue(Object newValue) {
        if (newValue instanceof UniString)
            setValue((UniString) newValue);
        else if (newValue instanceof byte[]) {
            setValue((byte[]) newValue);
        } else
            this.setValue(newValue.toString());
    }

    private void setValue(UniString aString) {
        uniConnection = aString.uniConnection;
        if (uniConnection != null) {
            setMarks(uniConnection.getByteMarks());
            setEncoding(uniConnection.getEncoding());
        }
        byteValue = aString.getBytes();
        count = byteValue.length;
    }

    private void setValue(byte[] bytes) {
        checkChanged();
        count = 0;
        append(bytes);
    }

    /**
     * Returns the current status of the last operation
     * 
     * @return current status value
     * @since UNICLIENTLIBS 1.0
     */
    public int status() {
        return uniStatus;
    }

    /**
     * return a substring of the current UniString, starting at the given index
     * 
     * @param aBeginIndex
     *            beginning index to take the substring from
     * @exception UniStringException
     *                is thrown if an error occurs
     * @return UniString representing the substring requested
     * @since UNICLIENTLIBS 1.0
     */
    public UniString substring(int aBeginIndex) throws UniStringException {
        checkChanged();
        return substring(aBeginIndex, charValue.length);
    }

    /**
     * return a substring of the current UniString, starting at the given index
     * and ending at the given endpoint
     * 
     * @param aBeginPoint
     *            beginning index to take the substring from
     * @param aEndPoint
     *            where to end the substring operation
     * @exception UniStringException
     *                is thrown if an error occurs
     * @return UniString representing the substring requested
     * @since UNICLIENTLIBS 1.0
     */
    public UniString substring(int aBeginPoint, int aEndPoint)
            throws UniStringException {
        checkChanged();
        if ((aBeginPoint > charValue.length) || (aEndPoint < 0)
                || (aBeginPoint > aEndPoint))
            throw new UniStringException(UniTokens.UVE_EINVAL);
        if (aBeginPoint < 0)
            aBeginPoint = 0;
        if (aEndPoint > charValue.length)
            aEndPoint = charValue.length;

        return new UniString(uniConnection, new String(charValue, aBeginPoint,
                aEndPoint - aBeginPoint));
    }

    /**
     * return the current string as a char[] array
     * 
     * @return char[] representing the current string
     * @since UNICLIENTLIBS 1.0
     */
    public char[] toCharArray() {
        checkChanged();
        return charValue;
    }

    /**
     * change the given string to all lower case characters
     * 
     * @return UniString representing the current string in all lower case
     * @since UNICLIENTLIBS 1.0
     */
    public UniString toLowerCase() {
        return new UniString(uniConnection, this.toString().toLowerCase());
    }

    /**
     * change the given string to all upper case characters
     * 
     * @return UniString representing the current string in all upper case
     * @since UNICLIENTLIBS 1.0
     */
    public UniString toUpperCase() {
        return new UniString(uniConnection, this.toString().toUpperCase());
    }

    /**
     * Converts to a string representing the data in this string buffer. A new
     * <code>String</code> object is allocated and initialized to contain the
     * character sequence currently represented by this string buffer. This
     * <code>String</code> is then returned. Subsequent changes to the string
     * buffer do not affect the contents of the <code>String</code>.
     * 
     * @return a string representation of the string buffer.
     * @since UNICLIENTLIBS 1.0
     */
    public String toString() {
        checkChanged();
        return new String(charValue);
    }

    /**
     * Ensures that the capacity of the buffer is at least equal to the
     * specified minimum. If the current capacity of this string buffer is less
     * than the argument, then a new internal buffer is allocated with greater
     * capacity. The new capacity is the larger of:
     * <ul>
     * <li>The <code>minimumCapacity</code> argument.
     * <li>Twice the old capacity, plus <code>2</code>.
     * </ul>
     * If the <code>minimumCapacity</code> argument is nonpositive, this
     * method takes no action and simply returns.
     * 
     * @param minimumCapacity
     *            the minimum desired capacity.
     * @since UNICLIENTLIBS 1.0
     */
    private synchronized void ensureCapacity(int minimumCapacity) {
        int maxCapacity = byteValue.length;

        if (minimumCapacity > maxCapacity) {
            int newCapacity = (maxCapacity + 1) * 2;
            if (minimumCapacity > newCapacity) {
                newCapacity = minimumCapacity;
            }

            byte[] newValue = new byte[newCapacity];
            System.arraycopy(byteValue, 0, newValue, 0, maxCapacity);
            byteValue = newValue;
        }
    }

    protected byte[] byteValue; // The value is used for bytes storage.

    protected int count; // The count is the number of bytes in the buffer.

    protected char[] charValue;

    protected boolean valueChanged = true;

    protected boolean dynArrayChanged = false;

    protected int uniStatus = 0;

    protected int uniReturnCode = 0;

    protected UniConnection uniConnection = null; // UniConnection object this

    // string is bound to

    protected UniRPCPacket inPacket = null;

    protected UniRPCPacket outPacket = null;

    protected Vector dynArray = null;

    private byte[] marks = UniTokens.b_marks;

    protected Charset charset = Charset
            .forName(System.getProperty("file.encoding"));

    protected String encoding = System.getProperty("file.encoding");

    protected void setEncoding(String encoding) {
        if (encoding.compareToIgnoreCase(this.encoding) != 0) {
            if (Charset.isSupported(encoding)) {
                this.charset = Charset.forName(encoding);
                this.encoding = encoding;
            }
        }
    }

    protected void setMarks(byte[] marks) {
        this.marks = marks;
    }

    /**
     * recreate the dynArray structure
     * 
     * @since UNICLIENTLIBS 1.0
     */
    protected void regenerateDynArray() {
        collapseDynArray();
        constructDynArray();

    }

    protected char[] decode(byte[] bytes) {
        return decode(bytes, 0, bytes.length);
    }

    protected char[] decode(byte[] bytes, int offset, int len) {
        CharBuffer cb = charset.decode(ByteBuffer.wrap(bytes, offset, len));
        char[] ca = new char[cb.limit()];
        cb.get(ca);
        return ca;
    }

    protected byte[] encode(String string) {
        return encode(string.toCharArray());
    }

    protected byte[] encode(char[] str) {
        return encode(str, 0, str.length);
    }

    protected byte[] encode(char[] str, int offset, int len) {
        ByteBuffer bb = charset.encode(CharBuffer.wrap(str, offset, len));
        byte[] ba = new byte[bb.limit()];
        bb.get(ba);
        return ba;
    }
    
	byte[] getByteValue(Object aString) {
		if (aString instanceof byte[])
            return (byte[])aString;
        else if (aString instanceof UniString)
        	return ((UniString)aString).getBytes();
        else {
            String insertString = aString.toString();
            // Deal with boundary conditions
            if (insertString.equals(""))
            	return new byte[0];
                //return null;
            return encode(insertString);
        }
	}
}
