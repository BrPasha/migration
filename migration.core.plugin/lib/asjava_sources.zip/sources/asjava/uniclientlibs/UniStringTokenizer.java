/*************************************************************************
 *
 * UniStringTokenizer.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 11/15/98 23699 DTM Initial Creation
 *************************************************************************/
package asjava.uniclientlibs;

/**
 * <code>UniStringTokenizer</code> is a virtual extension of the java.util.StringTokenizer
 * class with one key difference.  Using the base java model, delimiters are treated
 * as 'white space', and a sequential series of delimiters is treated as a single delimiter.
 * for many of our needs, using UniVerse mark characters as delimiters, we need to treat 
 * each delimiter as separating a new token, and the <code>nextToken</code> method will
 * reflect that difference
 *
 * @version Version 1.0
 * @author David T. Meeks
 * @since UNICLIENTLIBS 1.0
 */
public class UniStringTokenizer
{
	/*
	 * constructor that instantiates the object with the given stringVal.  Uses a ' ' as the delimiter
	 *
	 * @param stringVal String representing the data to parse
	 * @since UNICLIENTLIBS 1.0
	 */
	public UniStringTokenizer( Object stringVal )
	{
		this( stringVal, " " );
	}
	
	/*
	 * constructor that instantiates the object with the given stringVal, using the delimiterVal
	 * passed in as the delimiter for the tokenizer to use
	 *
	 * @param stringVal String representing the data to parse
	 * @param delimiterVal String representing the delimiter to use for parsing
	 * @since UNICLIENTLIBS 1.0
	 */
	public UniStringTokenizer( Object stringVal, Object delimiterVal )
	{
		this.resetTokenizer();
		if ( stringVal != null )
			uniString = stringVal.toString();
		else
			uniString = new String();
			
		if ( delimiterVal == null )
			delimiter = new String(" ");
		else
			delimiter = delimiterVal.toString();
		maxPos = uniString.length();
	}
	
	/**
	 * used to count the number of tokens in any given string
	 *
	 * @return integer representing the number of tokens available in this string
	 * @since UNICLIENTLIBS 1.0
	 */
	public int countTokens()
	{
		int currpos = 0;
		int count = 1;
		while ( currpos < maxPos )
		{
			if ( delimiter.indexOf( uniString.charAt( currpos ) ) >= 0 )
				count++;
			currpos++;
		}
		return count;
	}
	
	/**
	 * used to determine if any tokens remain in the string
	 *
	 * @return boolean representing whether tokens still remain in the string
	 * @since UNICLIENTLIBS 1.0
	 */
	public boolean hasMoreTokens()
	{
		if ( curPos == -1 ) return false;
		return (curPos <= maxPos);
	}
	
	/**
	 * parses off the next token in the string.  Will extract the next string (token)
	 * that is separated by the given delimiter character.  It will return a <code>null</code>
	 * if no more tokens exist
	 *
	 * @return String representing the next token or a <code>null</code> if no more tokens exist
	 * @since UNICLIENTLIBS 1.0
	 */
	public String nextToken()
	{		
		String subvalue;
		
		if ( !this.hasMoreTokens() ) {
		    return null;
		}

		// Parse through
		// find first occurance of the delimiter string
		int startPos = curPos;
		while ( (curPos < maxPos)
				 && delimiter.indexOf( uniString.charAt( curPos )) < 0 )
			curPos++;
		
		subvalue = uniString.substring( startPos, curPos );
		curPos++;
		return subvalue;
	}
	
	/**
	 * resets the string tokenizer to look at the very beginning of the string, to allow
	 * reparsing of the string.
	 *
	 * @since UNICLIENTLIBS 1.0
	 */
	public void resetTokenizer()
	{
		curPos = 0;
	}
	
	String uniString 	= "";
	String delimiter  = "";
	int    curPos			= 0;
	int		 maxPos			= 0;
}