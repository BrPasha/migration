/*************************************************************************
 *
 * UniConnection.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR# WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 12/13/04 32565 JFM modified serveral setXXX() method to allow change of 
 *                    connection properties (host, port, username,..) only when
 *                    connection hasn't been established yet
 * 11/18/04 32565 RKK Connection Pooling
 * 09/10/04 32722 WMY change @see to avoid javadoc warning
 * 10/14/02 2607,2609,2984 RKK NLS Stuff
 * 05/04/99 24995 DTM Changed to use DEFCS
 * 03/22/99 24735 DTM Fixed problem with encrypt not working against old 
 *                    servers
 * 11/05/98 23699 DTM Initial Creation
 *************************************************************************/

package asjava.uniclientlibs;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;

import asjava.uniobjects.UniJava;
import asjava.unirpc.UniRPCConnection;
import asjava.unirpc.UniRPCConnectionException;
import asjava.unirpc.UniRPCPacket;
import asjava.unirpc.UniRPCTokens;

/**
 * <code>UniConnection</code> acts as the central object for any database
 * connection, controlling access to any network related elements. It controls
 * information regarding the connection. It cannot be instantiated by itself,
 * but instead is used as the foundation for other connection/session objects,
 * such as the UniSession object.
 * 
 * @version Version 1.0
 * @author David T. Meeks
 * @since UNICLIENTLIBS 1.0
 */
public abstract class UniConnection {
    public static final String clientEncoding=System.getProperty("clientencoding");
    
    public UniConnection() {
        
        if (clientEncoding != null)
            try {
                setEncoding(clientEncoding);
            } catch (UniConnectionException e) {
            }
    };

    /**
     * returns the account path being used for the connection
     * 
     * @return String representing the account path being used for the current
     *         connection.
     * @see #setAccountPath
     * @since UNICLIENTLIBS 1.0
     */
    public String getAccountPath() {
        return accountPath;
    }

    /**
     * returns the current <code>CompressionThreshold</code>. Whenever a data
     * packet is transferred that exceeds the <code>CompressionThreshold</code>,
     * it will be compressed using an internal compression algorithm. This will
     * be done for performance reasons. By default, it is set to 0, which
     * represents no compression is to be done. Any non-zero value will enable
     * compression.
     * 
     * @return integer representing the compression threshold, in bytes
     * @since UNICLIENTLIBS 1.0
     */
    public int getCompressionThreshold() {
        return compressionThreshold;
    }

    /**
     * returns the current connection string, which is the string used to
     * connect to a particular database type. By default, this will be "DEFCS".
     * This value relates to what is in the uvrpcservices file on the server.
     * 
     * @return String representing the current connection string
     * @see #setConnectionString
     * @since UNICLIENTLIBS 1.0
     */
    public String getConnectionString() {
        return uniConnectionString;
    }

    /**
     * returns the current data source type, which can be either "UNIVERSE" or
     * "UNIDATA".
     * 
     * @return String representing the current data source type
     * @see #setDataSourceType
     * @since UNICLIENTLIBS 1.0
     */
    public String getDataSourceType() {
        return uniDataSourceType;
    }

    /**
     * returns the current default encryption type to be used for this session.
     * All subobjects will inherit this value unless specifically overriden. It
     * controls the type of encryption that is to be used for data transfer.
     * Valid values are:
     * <ul>
     * <li> NO_ENCRYPTION (0) - no encryption is to be done. This is the default
     * value.
     * <li> INTERNAL_ENCRYPTION (1) - use UniVerse internal encryption. /ul>
     * 
     * @return integer representing the current default encryption type
     * @see #setDefaultEncryptionTypeInt
     * @since UNICLIENTLIBS 1.0
     */
    public int getDefaultEncryptionType() {
        return encryptionType;
    }

    /**
     * gets the device subkey used in client-side licensing. This is used to
     * establish differentiation between multiple applications running on the
     * same device, making connections to the same server. It allows a level of
     * connection pooling.
     * 
     * @return String representing the subkey to be used
     * @see #setDeviceSubkey
     * @since UNICLIENTLIBS 1.0
     */
    public String getDeviceSubkey() {
        return uniSubKey;
    }

    /**
     * returns the name of the host we are connecting to. It will return the
     * value as specified in either the <code>setHostName</code> or
     * <code>connect</code> methods.
     * 
     * @return String representing the host name we are connected to.
     * @see #setHostName
     * @since UNICLIENTLIBS 1.0
     */
    public String getHostName() {
        return hostName;
    }

    /**
     * returns the port number used for this connection.
     * 
     * @return integer representing the port number for this connection
     * @see #setHostPort
     * @since UNIBOJECTS 1.0
     */
    public int getHostPort() {
        return hostPort;
    }

    /**
     * returns a value representing the type of host the session is connected
     * to. Valid values are:
     * <ul>
     * <li> UVT_NONE (0) - The host system cannot be determined, the session is
     * not connected.
     * <li> UVT_UNIX (1) - The host is a UNIX system
     * <li> UVT_NT (2) - The host is a Windows NT system.
     * </ul>
     * 
     * @return integer representing the type of host we are connected to.
     * @since UNICLIENTLIBS 1.0
     */
    public int getHostType() {
        return hostType;
    }

    /**
     * returns the current version of the host RPC version
     * 
     * @return integer representing the current RPC version.
     *         <ul>
     *         <li> a value of 1 represents an old server, where
     *         <li> a value of 2 or greater represents a new server
     *         <li> a value of -1 represents an error condition
     *         </ul>
     * @since UNICLIENTLIBS 1.0
     */
    public int getServerVersion() {
        if (connection != null)
            return connection.getVersionCurrent();
        else
            return -1;
    }

    /**
     * returns the specified mark characters. It will return the specified mark
     * character based on the following list:
     * <ul>
     * <li> IM - Item Mark
     * <li> FM - Field Mark
     * <li> VM - Value Mark
     * <li> SVM - SubValue Mark
     * <li> TM - Text Mark
     * <li> SQLNULL - SQL Null Mark
     * </ul>
     * 
     * @param aMarkChar
     *            integer representing which character to obtain
     * @exception UniConnectionException
     *                is thrown if an error occurs
     * @return String representing the requested mark character
     * @since UNICLIENTLIBS 1.0
     */
    public String getMarkCharacter(int aMarkChar) throws UniConnectionException {
        if ((aMarkChar < UniTokens.IM) || (aMarkChar > UniTokens.SQLNULL))
            throw new UniConnectionException(
                    "Mark Character  must be between IM-SQLNULL",
                    UniTokens.UVE_EINVAL);
        return uniMarkCharacters[aMarkChar];
    }

    /**
     * returns the password used to establish the connection to the host system
     * 
     * @return String representing the password being used for the connection
     * @see #setPassword
     * @since UNICLIENTLIBS 1.0
     */
    public String getPassword() {
        return password;
    }

    /**
     * returns the name of the <code>ProxyHost</code> being used for this
     * connection
     * 
     * @return String representing the name of the <code>ProxyHost</code>
     * @see #setProxyHost
     * @since UNICLIENTLIBS 1.0
     */
    public String getProxyHost() {
        return proxyHost;
    }

    /**
     * returns the port number that the <code>ProxyHost</code> resides on
     * 
     * @return integer representing the ProxyHost port number
     * @see #setProxyPort
     * @since UNICLIENTLIBS 1.0
     */
    public int getProxyPort() {
        return proxyPort;
    }

    /**
     * returns the security string (password) used for validation on the
     * <code>ProxyHost</code>
     * 
     * @return String representing the password used for ProxyHost validation
     * @see #setProxyToken
     * @since UNICLIENTLIBS 1.0
     */
    public String getProxyToken() {
        return proxySecurityToken;
    }

    /**
     * returns the current RPC timeout period. This value is used to timeout RPC
     * requests. The default value is 0, which means no timeout period.
     * 
     * @return integer representing the current timeout interval for the RPC
     * @since UNICLIENTLIBS 1.0
     */
    public int getTimeout() {
        return timeout;
    }

    /**
     * returns the type of network transport being used. Currently, only TCP/IP
     * is supported.
     * 
     * @return integer representing the type of network transport being used.
     * @see #setTransport
     * @since UNICLIENTLIBS 1.0
     */
    public int getTransport() {
        return transport;
    }

    /**
     * returns the current user name used for this connection
     * 
     * @return String representing the user name used for this connection
     * @see #setUserName
     * @since UNICLIENTLIBS 1.0
     */
    public String getUserName() {
        return userName;
    }

    /**
     * boolean method that indicates <code>true</code> if a connection has
     * been successfully established. It is <code>false</code> if the
     * connection has not been established.
     * 
     * @return boolean representing the state of the connection
     * @since UNICLIENTLIBS 1.0
     */
    public boolean isActive() {
        return isActive;
    }

    /**
     * boolean method that indicates <code>true</code> if a data compression
     * is available for this <code>UniSession</code>. It is
     * <code>false</code> if the connection does not support data compression.
     * 
     * @return boolean representing the availability of data compression
     * @since UNICLIENTLIBS 1.0
     */
    public boolean isCompressionEnabled() {
        if (connection != null)
            return connection.isCompressionSupported();
        else
            return false;
    }

    /**
     * boolean method that indicates <code>true</code> if data encryption is
     * available for this <code>UniSession</code>. It is <code>false</code>
     * if this session does not support encryption.
     * 
     * @return boolean representing the availability of data encryption
     * @since UNICLIENTLIBS 1.0
     */
    public boolean isEncryptionEnabled() {
        if (connection != null)
            return connection.isEncryptionSupported();
        else
            return false;
    }

    /**
     * boolean method that indicates <code>true</code> if the server this
     * object is connected to is currently NLS enabled. It will return
     * <code>false</code> if the server is not NLS aware.
     * 
     * @return boolean representing the state of NLS on the server
     * @since UNICLIENTLIBS 1.0
     */
    public boolean isNLSEnabled() {
        return isNLSEnabled;
    }

    /**
     * boolean method that indicates <code>true</code> if the server this
     * object is connected to is currently NLS locales enabled. It will return
     * <code>false</code> if the server is not NLS locales aware.
     * 
     * @return boolean representing the state of NLS locales on the server
     * @since UNICLIENTLIBS 1.0
     */
    public boolean isNLSLocalesEnabled() {
        return isNLSLocalesEnabled;
    }

    /**
     * sets the account path to be used for the connection
     * 
     * @param aAccountPath
     *            object representing which account to connect to
     * @see #getAccountPath
     * @since UNICLIENTLIBS 1.0
     */
    public void setAccountPath(Object aAccountPath) {
        if (aAccountPath != null && !isActive)
            accountPath = aAccountPath.toString();
    }

    /**
     * sets the account path to be used for the connection
     * 
     * @param aAccountPath
     *            String representing which account to connect to
     * @see #getAccountPath
     * @since UNICLIENTLIBS 1.0
     */
    public void setAccountPath(String aAccountPath) {
        if (aAccountPath != null && !isActive)
            accountPath = aAccountPath;
    }

    /**
     * sets the current <code>CompressionThreshold</code> value.
     * 
     * @param aCompressionThresholdVal
     *            integer representing the amount, in bytes, to set the
     *            compression threshold to
     * @exception UniConnectionException
     *                is thrown if an invalid aCompressionThresholdVal is passed
     *                in
     * @since UNICLIENTLIBS 1.0
     */
    public void setCompressionThresholdInt(int aCompressionThresholdVal)
            throws UniConnectionException {
        if (!isCompressionEnabled())
            throw new UniConnectionException(
                    UniRPCTokens.UNIRPC_NO_COMPRESSION_SUPPORT);

        if (aCompressionThresholdVal < 0) {
            throw new UniConnectionException(
                    "Compression threshold must be a positive value",
                    UniTokens.UVE_EINVAL);
        }
        compressionThreshold = aCompressionThresholdVal;
    }

    /**
     * sets connection string to be used for server connection
     * 
     * @param connString
     *            object representing the connection string to be used.
     * @see #getConnectionString
     * @since UNICLIENTLIBS 1.0
     */
    public void setConnectionString(Object connString) {
        if (connString != null && !isActive)
            setConnectionString(connString.toString());
    }

    /**
     * sets connection string to be used for server connection
     * 
     * @param connString
     *            string representing the connection string to be used.
     * @see #getConnectionString
     * @since UNICLIENTLIBS 1.0
     */
    public void setConnectionString(String connString) {
        if (connString != null && !isActive)
            uniConnectionString = connString;
    }

    /**
     * sets data source type to connect to. By default, it's UNIVERSE. Changing
     * this value will also change the default connection string
     * 
     * @param dataSourceType
     *            object representing the datasource type.
     * @exception UniConnectionException
     *                is thrown is an invalid data source type is specified
     * @see #getDataSourceType
     * @since UNICLIENTLIBS 1.0
     */
    public void setDataSourceType(Object dataSourceType)
            throws UniConnectionException {
        if (dataSourceType == null)
            return;

        setDataSourceType(dataSourceType.toString());
    }

    /**
     * sets data source type to connect to. By default, it's UNIVERSE. Changing
     * this value will also change the default connection string
     * 
     * @param dataSourceType
     *            string representing the datasource type.
     * @exception UniConnectionException
     *                is thrown is an invalid data source type is specified
     * @see #getDataSourceType
     * @since UNICLIENTLIBS 1.0
     */
    public void setDataSourceType(String dataSourceType)
            throws UniConnectionException {
        if (dataSourceType == null)
            return;

        if (dataSourceType.equalsIgnoreCase("UNIVERSE")) {
            setConnectionString(UniTokens.UVCS_SERVICE);
            uniDataSourceType = dataSourceType.toUpperCase();
        } else if (dataSourceType.equalsIgnoreCase("UNIDATA")) {
            setConnectionString(UniTokens.UDCS_SERVICE);
            uniDataSourceType = dataSourceType.toUpperCase();
        } else {
            throw new UniConnectionException(dataSourceType
                    + " is an invalid DataSourceType.", UniTokens.UVE_EINVAL);
        }
    }

    /**
     * sets the current default encryption type to be used for this session. All
     * subobjects will inherit this value unless specifically overriden. It
     * controls the type of encryption that is to be used for data transfer.
     * Valid values are:
     * <ul>
     * <li> NO_ENCRYPTION (0) - no encryption is to be done. This is the default
     * value.
     * <li> INTERNAL_ENCRYPTION (1) - use UniVerse internal encryption. /ul>
     * 
     * @param aType
     *            integer representing the type of encryption that is to be
     *            used.
     * @exception UniConnectionException
     *                is thrown if an invalid aType is passed in
     * @since UNICLIENTLIBS 1.0
     */
    public void setDefaultEncryptionTypeInt(int aType)
            throws UniConnectionException {
        if (!isEncryptionEnabled())
            throw new UniConnectionException(
                    UniRPCTokens.UNIRPC_NO_ENCRYPTION_SUPPORT);

        switch (aType) {
        case UniRPCTokens.UNIRPC_ENCRYPTION_NONE:
        case UniRPCTokens.UNIRPC_ENCRYPTION_XOR:
            encryptionType = aType;
            break;
        default:
            throw new UniConnectionException("Invalid Encryption Type",
                    UniTokens.UVE_EINVAL);
        }
    }

    /**
     * sets up the device subkey for use in client-side licensing. This is used
     * to establish differentiation between multiple applications running on the
     * same device, making connections to the same server. It allows a level of
     * connection pooling.
     * 
     * @param subKey
     *            String representing the subkey to be used
     * @see #getDeviceSubkey
     * @since UNICLIENTLIBS 1.0
     */
    public void setDeviceSubkey(Object subKey) {
        if (subKey != null)
            uniSubKey = subKey.toString();
    }

    /**
     * sets the host name to establish the connection to.
     * 
     * @param aHostName
     *            String representing the name of the host to connect to
     * @see #getHostName
     * @since UNICLIENTLIBS 1.0
     */
    public void setHostName(String aHostName) {
        if (aHostName != null && !isActive)
            hostName = aHostName;
    }

    /**
     * sets the host name to establish the connection to.
     * 
     * @param aHostName
     *            object representing the name of the host to connect to
     * @see #getHostName
     * @since UNICLIENTLIBS 1.0
     */
    public void setHostName(Object aHostName) {
        if (aHostName != null && !isActive)
            hostName = aHostName.toString();
    }

    /**
     * sets the port number the connection should connect to on the server side.
     * 
     * @param aHostPort
     *            integer representing the hostside port number to connect to
     * @see #getHostPort
     * @since UNICLIENTLIBS 1.0
     */
    public void setHostPort(int aHostPort) {
        if (!isActive)
            hostPort = aHostPort;
    }

    /**
     * sets the password to be used for the server-side connection
     * 
     * @param aPassword
     *            object representing the password to be used for the connection
     * @see #getPassword
     * @since UNICLIENTLIBS 1.0
     */
    public void setPassword(Object aPassword) {
        if (aPassword != null && !isActive)
            password = aPassword.toString();
    }

    /**
     * sets the password to be used for the server-side connection
     * 
     * @param aPassword
     *            String representing the password to be used for the connection
     * @see #getPassword
     * @since UNICLIENTLIBS 1.0
     */
    public void setPassword(String aPassword) {
        if (aPassword != null && !isActive)
            password = aPassword;
    }

    /**
     * sets the host name of the ProxyServer to connect to
     * 
     * @param aProxyHost
     *            object representing the name of the ProxyServer to connect to
     * @see #getProxyHost
     * @since UNICLIENTLIBS 1.0
     */
    public void setProxyHost(Object aProxyHost) {
        if (aProxyHost != null)
            proxyHost = aProxyHost.toString();
    }

    /**
     * sets the host name of the ProxyServer to connect to
     * 
     * @param aProxyHost
     *            String representing the name of the ProxyServer to connect to
     * @see #getProxyHost
     * @since UNICLIENTLIBS 1.0
     */
    public void setProxyHost(String aProxyHost) {
        if (aProxyHost != null)
            proxyHost = aProxyHost;
    }

    /**
     * sets the port number on the ProxyServer that should be used for the
     * connection
     * 
     * @param aProxyPort
     *            integer reprenting the port number that should be used for the
     *            connection to the ProxyServer.
     * @see #getProxyPort
     * @since UNICLIENTLIBS 1.0
     */
    public void setProxyPort(int aProxyPort) {
        proxyPort = aProxyPort;
    }

    /**
     * sets the ProxyServer security token (password) to be used for connection
     * validation
     * 
     * @param aProxyToken
     *            String representing the secutiry token (password) to be used
     *            for connection validation
     * @see #getProxyToken
     * @since UNICLIENTLIBS 1.0
     */
    public void setProxyToken(Object aProxyToken) {
        if (aProxyToken != null)
            proxySecurityToken = aProxyToken.toString();
    }

    /**
     * Sets the UniRPC timeout value. Initially, it is set to 0, indicating no
     * timeout is to occur. If it is set to a value > 0, the UniRPC will timeout
     * after that many seconds.
     * 
     * @param aTimeoutVal
     *            integer representing the number of seconds the UniRPC should
     *            wait until it times out.
     * @exception UniConnectionException
     *                is thrown if the timeout cannot be set
     * @since UNICLIENTLIBS 1.0
     */
    public void setTimeoutInt(int aTimeoutVal) throws UniConnectionException {
        if (aTimeoutVal < 0) {
            throw new UniConnectionException(
                    "Timeout value must be a positive value",
                    UniTokens.UVE_EINVAL);
        }

        timeout = aTimeoutVal;
        // If we have established a connection, set the new timeout value
        if (connection != null) {
            try {
                connection.setTimeoutSeconds(timeout);
            } catch (UniRPCConnectionException e) {
                throw new UniConnectionException(e.getErrorCode());
            }
        }
    }

    /**
     * Used to establish which type of network transport should be used. The
     * only currently supported network transport mechanism is TCP/IP
     * 
     * @param aTransportType
     *            integer representing the type of network transport should be
     *            used.
     * @see #getTransport
     * @since UNICLIENTLIBS 1.0
     */
    public void setTransport(int aTransportType) {
        transport = UniRPCTokens.UNIRPC_TRANSPORT_TCPIP;
    }

    /**
     * sets the user name that is to be used in the connection to the remote
     * server
     * 
     * @param aUserName
     *            String representing the server-side username used for
     *            connection purposes.
     * @see #getUserName
     * @see asjava.uniobjects.UniSession#connect
     * @since UNICLIENTLIBS 1.0
     */
    public void setUserName(Object aUserName) {
        if (aUserName != null && !isActive)
            userName = aUserName.toString();
    }

    /**
     * This method is used to encrypt a given string into an internal format
     * that is understood by the server
     * 
     */
    protected String encrypt(String aString) {
        if (aString == null)
            return new String();

        byte[] byteArray = aString.getBytes();

        for (int i = 0; i < byteArray.length; i++) {
            // if we are connecting to 9.4 server, use old COMMS VER
            if (getServerVersion() == UniTokens.OLD_SERVER)
                byteArray[i] = (byte) (byteArray[i] ^ ((byte) UniTokens.OLD_COMMS_VERSION));
            else
                byteArray[i] = (byte) (byteArray[i] ^ ((byte) UniTokens.COMMS_VERSION));
        }

        return new String(byteArray);
    }

    public UniRPCPacket getInPacket() {
        return inPacket;
    }

    public UniRPCPacket getOutPacket() {
        return outPacket;
    }

    /**
     * @return Returns the isRPCError.
     */
    public boolean getRPCError() {
        return isRPCError;
    }

    /**
     * @param isRPCError
     *            The isRPCError to set.
     */
    public void setRPCError(boolean isRPCError) {
        this.isRPCError = isRPCError;
    }

    // Public instance variables
    public UniRPCConnection connection; // our RPC connection Object

    // Private instance variables
    protected UniRPCPacket inPacket;

    protected UniRPCPacket outPacket;

    protected String accountPath = null; // account path for this session

    protected String hostName = null; // host name for this session

    protected String password = null; // password for this session

    protected String userName = null; // user name for this session

    protected String[] uniMarkCharacters;

    protected byte[] uniMarkBytes = UniTokens.b_marks;

    protected String uniConnectionString = UniTokens.UNI_SERVICE;

    protected String uniDataSourceType = UniTokens.UNIVERSE;

    protected String proxyHost = null;

    protected String proxySecurityToken = "";

    protected String licenseToken = ""; // license token for UniVerse

    protected String uniSubKey = "";

    protected int hostPort = UniRPCTokens.UNIRPC_DEFAULT_PORT;

    protected int proxyPort = UniRPCTokens.UNIRPC_DEFAULT_PROXY_PORT;

    protected int transport = UniRPCTokens.UNIRPC_TRANSPORT_TCPIP;

    protected int compressionThreshold = UniTokens.NO_COMPRESSION;

    protected int timeout = UniJava.getSocketTimeout();// rajan
                                                        // //.UniTokens.DEFAULT_TIMEOUT;
                                                        // // Timeout value, in
                                                        // seconds

    protected int encryptionType = UniTokens.NO_ENCRYPTION;

    protected int hostType = UniTokens.UVT_NONE;

    protected boolean isNLSEnabled = false;

    protected boolean isNLSLocalesEnabled = false;

    protected boolean isActive = false;

    protected boolean isRPCError = false;

    protected boolean isNLSUnidataSession = false;

    protected Charset charset = Charset.forName(System.getProperty("file.encoding"));

    protected String encoding = System.getProperty("file.encoding");

    
    /**
     * 
     * @return encoding used by this connection
     * @since UNICLIENTLIBS 2.0
     */
    protected String getEncoding() {
        return encoding;
    }

    /**
     * set the encoding to be used by this connection
     * @param encoding
     * @throws UniConnectionException
     * @since UNICLIENTLIBS 2.0
     */
    protected void setEncoding(String encoding) throws UniConnectionException {

        if (encoding.compareToIgnoreCase(this.encoding) != 0) {
            if (Charset.isSupported(encoding))
                this.charset = Charset.forName(encoding);
            else
                throw new UniConnectionException(
                        UniTokens.UVE_ENCODING_NOTSUPPORTED);
            this.encoding = encoding;
        }
    }

    public void setByteMarks(byte[] nlsMarkBytes) {
        uniMarkBytes = nlsMarkBytes;
    }
    
    protected byte[] getByteMarks()
    {
        return uniMarkBytes;
    }

    
    public byte getMarkByte(int markIndex) throws UniConnectionException {
        if ((markIndex < UniTokens.IM) || (markIndex > UniTokens.SQLNULL))
            throw new UniConnectionException(
                    "Mark Byte must be between IM-SQLNULL",
                    UniTokens.UVE_EINVAL);
        return uniMarkBytes[markIndex];
    }
    
    public String decode(byte[] bytes)
    {
        CharBuffer cb = charset.decode(ByteBuffer.wrap(bytes));
        return cb.toString();
    }
    
    public byte[] encode(String string)
    {
        ByteBuffer bb = charset.encode(CharBuffer.wrap(string));
        byte[] ba = new byte[bb.limit()];
        bb.get(ba);
        return ba;
    }

}
