/*************************************************************************
 *
 * UniErrorMessage.java
 *
 * Module	%M%	Version	%I%	Date	%H%
 *
 * � Copyright 1998 Ardent Software, Inc. - All Rights Reserved
 * This is unpublished proprietary source code of Ardent Software, Inc.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 *************************************************************************
 *
 * Maintenance Log - Insert most recent change descriptions at top
 *
 * Date.... GTAR#  WHO Descrition..........................................
 * 01/12/06 35667 JFM add changes for NLS enhancement (UTF8 suport, session-based
 * encoding support)
 * 08/11/05 E33998 RKK Proxy not supported when Connection Pooling is ON.
 * 06/22/05 E33849 RKK New message when min pool size is greater than number of pooled licenses. 
 * 05/10/05        MBM Fixed compilation error. Java does not allow to assign value
 *		             to the varibale with +=. 
 * 04/22/05 E33623 RKK Generate correct message if connecting to older version of U2
 * 11/18/04 e32565 RKK Connection Pooling
 * 11/15/98 23699  DTM Initial Creation
 * 09/10/04 32722  WMY add UVE_QUERY_SYNTAX message.
 *************************************************************************/


package asjava.uniclientlibs;

import asjava.unirpc.*;
/**
 * <code>UniErrorMessage</code> is a class used to determine a given error message
 * given an ErrorCode to be displayed
 * 
 * @version	Version 1.0
 * @author	David T. Meeks
 * @since		UNICLIENTLIBS 1.0
 */
public abstract class UniErrorMessage 
{
	/**
	 * Creates the UniBase object.  
	 *
	 * @since	UNICLIENTLIBS 1.0
	 */
	 private  UniErrorMessage()
	 {
	 }
	 
	/**
	 * returns the appropriate error message, depending on the error code passed in
	 *  
	 * @param aErrorCode integer representing which error message to display
	 * @return String representing the error message to be displayed
	 * @since	UNICLIENTLIBS 1.0
	 */
	 public static String getErrorMessage( int aErrorCode )
	 {
	 		String errMsg = new String();
	 		return getErrorMessage( aErrorCode, errMsg );
	 }

  /**
	 * returns the appropriate error message, depending on the error code passed in
	 *  
	 * @param aErrorCode integer representing which error message to display
	 * @param aExtraInfo String used to represent additional information that might be 
	 *                      relevant (file name, record name, etc...)
	 * @return String representing the error message to be displayed
	 * @since	UNICLIENTLIBS 1.0
	 */
	 public static String getErrorMessage( int aErrorCode, String aExtraInfo )
	 {
	 		String errMsg;
	 		
	 		switch( aErrorCode )
	 		{
	 			case UniTokens.UVE_NOERROR:
	 				errMsg = "No Error";
	 				break;
	 			case UniTokens.UVE_ENOENT:
	 				errMsg = "File: ["+aExtraInfo+"] No such file or directory";
	 				break;
				case UniTokens.UVE_EACCESS:
	 				errMsg = "Permission denied";
	 				break;
	 			case UniTokens.UVE_EINVAL:
	 				errMsg = "Invalid Argument";
	 				break;
	 			case UniTokens.UVE_ENFILE:
	 				errMsg = "Invalid File";
	 				break;
	 			case UniTokens.UVE_EMFILE:
	 				errMsg = "Too many open files";
	 				break;
				case UniTokens.UVE_ENOSPC:
	 				errMsg = "No space left on device";
	 				break;
	 			case UniTokens.UVE_NETUNREACH:
	 				errMsg = "Network is unreachable";
	 				break;
	 			case UniTokens.UVE_USC:
	 				errMsg = "Unsupported Server Operation.  This operation is not supported at this release of the server.";
	 				break;
				case UniTokens.UVE_LRR:
	 				errMsg = "The last record in the select list has been read";
	 				break;
	 			case UniTokens.UVE_RNF:
	 				errMsg = "This Record was not found";
	 				break;
	 			case UniTokens.UVE_LCK:
	 				errMsg = "This file or record is locked by another user";
	 				break;
	 			case UniTokens.UVE_SELFAIL:
	 				errMsg = "The select operation failed";
	 				break;
	 			case UniTokens.UVE_LOCKINVALID:
	 				errMsg = "The task lock number specified is invalid";
	 				break;
				case UniTokens.UVE_SEEKFAILED:
	 				errMsg = "The fileSeek() operation failed";
	 				break;
	 			case UniTokens.UVE_TX_ACTIVE:
	 				errMsg = "Cannot perform this operation while a transaction is active";
	 				break;
	 			case UniTokens.UVE_INVALIDATKEY:
	 				errMsg = "The key used to set or retrieve an @variable is invalid";
	 				break;
	 			case UniTokens.UVE_UNABLETOLOADSUB:
	 				errMsg = "Unable to load the subroutine on the server";
	 				break;
	 			case UniTokens.UVE_BADNUMARGS:
	 				errMsg = "Wrong number of arguments supplied to the subroutine";
	 				break;
				case UniTokens.UVE_SUBERROR:
	 				errMsg = "The subroutine failed to complete successfully";
	 				break;
	 			case UniTokens.UVE_ITYPEFTC:
	 				errMsg = "The I-type operation failed to complete successfully";
	 				break;
	 			case UniTokens.UVE_ITYPEFAILEDTOLOAD:
	 				errMsg = "The I-type failed to load";
	 				break;
	 			case UniTokens.UVE_ITYPENOTCOMPILED:
	 				errMsg = "The I-type has not been compiled";
	 				break;
				case UniTokens.UVE_BADITYPE:
	 				errMsg = "This is not an I-Type or the I-type is corrupt";
	 				break;
	 			case UniTokens.UVE_INVALIDFILENAME:
	 				errMsg = "The specified filename is null";
	 				break;
				case UniTokens.UVE_WEOFFAILED:
	 				errMsg = "writeEOF() failed";
	 				break;
	 			case UniTokens.UVE_EXECUTEISACTIVE:
	 				errMsg = "An Execute is currently active on the server";
	 				break;
				case UniTokens.UVE_EXECUTENOTACTIVE:
	 				errMsg = "No Execute is currently active on the server";
	 				break;
	 			case UniTokens.UVE_CANT_ACCESS_PF:
	 				errMsg = "Cannot access part files";
	 				break;
	 			case UniTokens.UVE_FAIL_TO_CANCEL:
	 				errMsg = "Failed to cancel an execute";
	 				break;
	 			case UniTokens.UVE_INVALID_INFO_KEY:
	 				errMsg = "Bad key for the hostType method";
	 				break;
				case UniTokens.UVE_CREATE_FAILED:
	 				errMsg = "The creation of the sequential file failed";
	 				break;
	 			case UniTokens.UVE_DUPHANDLE_FAILED:
	 				errMsg = "Failed to duplicate a pipe handle";
	 				break;
				case UniTokens.UVE_NVR:
	 				errMsg = "No VOC record";
	 				break;
	 			case UniTokens.UVE_NPN:
	 				errMsg = "No pathname in VOC record";
	 				break;
				case UniTokens.UVE_NODATA:
	 				errMsg = "The server is not responding";
	 				break;
	 			case UniTokens.UVE_AT_INPUT:
	 				errMsg = "The server is waiting for input to a command";
	 				break;
	 			case UniTokens.UVE_SESSION_NOT_OPEN:
	 				errMsg = "The session is not open";
	 				break;
	 			case UniTokens.UVE_UVEXPIRED:
	 				errMsg = "The UniVerse license has expired";
	 				break;
	 			case UniTokens.UVE_BADDIR:
	 				errMsg = "The directory does not exist, or is not a UniVerse account";
	 				break;
				case UniTokens.UVE_BAD_UVHOME:
	 				errMsg = "Cannot find the UV account directory";
	 				break;
	 			case UniTokens.UVE_INVALIDPATH:
	 				errMsg = "An invalid pathname was found in the UV.ACCOUNT file";
	 				break;
	 			case UniTokens.UVE_INVALIDACCOUNT:
	 				errMsg = "The account name supplied is not a valid account";
	 				break;
	 			case UniTokens.UVE_BAD_UVACCOUNT_FILE:
	 				errMsg = "The UV.ACCOUNT file could not be found or opened";
	 				break;
				case UniTokens.UVE_FTA_NEW_ACCOUNT:
	 				errMsg = "Failed to attach to the specified account";
	 				break;
	 			case UniTokens.UVE_ULR:
	 				errMsg = "The user limit has been reached on the server";
	 				break;
	 			case UniTokens.UVE_IID:
	 				errMsg = "Illegal record ID";
	 				break;
	 			case UniTokens.UVE_BFN:
	 				errMsg = "Bad Field Number";
	 				break;
	 			case UniTokens.UVE_BTS:
	 				errMsg = "Buffer size too small";
	 				break;
				case UniTokens.UVE_NO_NLS:
	 				errMsg = "NLS is not available";
	 				break;
	 			case UniTokens.UVE_MAP_NOT_FOUND:
	 				errMsg = "NLS Map not found";
	 				break;
				case UniTokens.UVE_NO_LOCALE:
	 				errMsg = "NLS Locale support is not available";
	 				break;
	 			case UniTokens.UVE_LOCALE_NOT_FOUND:
	 				errMsg = "NLS Locale not found";
	 				break;
	 			case UniTokens.UVE_CATEGORY_NOT_FOUND:
	 				errMsg = "NLS Locale category not found";
	 				break;
	 			case UniTokens.UVE_INVALIDFIELD:
	 				errMsg = "Pointer error in a sequential file operation";
	 				break;
				case UniTokens.UVE_SESSIONEXISTS:
	 				errMsg = "The session is already open";
	 				break;
	 			case UniTokens.UVE_BADPARAM:
	 				errMsg = "Invalid parameter supplied to the subroutine";
	 				break;
				case UniTokens.UVE_NOMORE:
	 				errMsg = "nextBlock() was used, but no more blocks available";
	 				break;
	 			case UniTokens.UVE_NOTATINPUT:
	 				errMsg = "reply() method called without being at a UVS_REPLY state";
	 				break;
	 			case UniTokens.UVE_INVALID_DATAFIELD:
	 				errMsg = "The dictionary entry does not have a valid TYPE field";
	 				break;
	 			case UniTokens.UVE_BAD_DICTIONARY_ENTRY:
	 				errMsg = "The dictionary entry is invalid";
	 				break;
				case UniTokens.UVE_BAD_CONVERSION_DATA:
	 				errMsg = "Unable to convert the data in the field";
	 				break;
	 			case UniTokens.UVE_BAD_LOGINNAME:
	 				errMsg = "The user name provided is incorrect";
	 				break;
	 			case UniTokens.UVE_BAD_PASSWORD:
	 				errMsg = "The password provided is incorrect";
	 				break;
	 			case UniTokens.UVE_ACCOUNT_EXPIRED:
	 				errMsg = "The account has expired";
	 				break;
				case UniTokens.UVE_RUN_REMOTE_FAILED:
	 				errMsg = "Unable to run as the given user";
	 				break;
	 			case UniTokens.UVE_UPDATE_USER_FAILED:
	 				errMsg = "Unable to update user details";
	 				break;
	 			case UniRPCTokens.UNIRPC_BAD_CONNECTION:
	 				errMsg = "The connection is bad, and may be passing corrupt data";
	 				break;
	 			case UniRPCTokens.UNIRPC_NO_CONNECTION:
	 				errMsg = "No RPC Connection active.";
	 				break;
				case UniRPCTokens.UNIRPC_WRONG_VERSION:
	 				errMsg = "The version of the RPC is different between the client and server";
	 				break;
	 			case UniTokens.UNIRPC_NO_MORE_CONNECTIONS:
	 				errMsg = "No more connections available";
	 				break;
				case UniRPCTokens.UNIRPC_FAILED:
	 				errMsg = "The RPC failed";
	 				break;
	 			case UniRPCTokens.UNIRPC_UNKNOWN_HOST:
	 				errMsg = "The host name is not valid, or the host is not responding";
	 				break;
				case UniTokens.UNIRPC_CANT_FIND_SERVICE:
	 				errMsg = "Cannot find the requested service in the uvrpcservices file";
	 				break;
	 			case UniTokens.UNIRPC_TIMEOUT:
	 				errMsg = "The connection has timed out";
	 				break;
	 			case UniTokens.UNIRPC_REFUSED:
	 				errMsg = "The connection was refused as the RPC daemon is not running";
	 				break;
	 			case UniRPCTokens.UNIRPC_BAD_TRANSPORT:
	 				errMsg = "An invalid transport type has been used";
	 				break;
	 			case UniRPCTokens.UNIRPC_NO_MULTIPLEX_SUPPORT:
	 				errMsg = "You can only multiplex proxy connections.";
	 				break;
	 			case UniRPCTokens.UNIRPC_NO_ENCRYPTION_SUPPORT:
	 				errMsg = "Encryption is not supported on this connection.";
	 				break;
	 			case UniRPCTokens.UNIRPC_NO_COMPRESSION_SUPPORT:
	 				errMsg = "Compression is not supported on this connection.";
	 				break;
	 			case UniRPCTokens.UNIRPC_CONNECTION:
	 				errMsg = "These packets were created with a different connection.";
	 				break;
	 			case UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN:
	 				errMsg = "The proxy server login failed";
	 				break;
	 			case UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_AUTH:
	 				errMsg = "The proxy server login authentication failed";
	 				break;
	 			case UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSIONS:
	 				errMsg = "This connection exceeded the maximum number of sessions supported by the proxy server.";
	 				break;
	 			case UniRPCTokens.UNIRPC_FAILED_PROXY_LOGIN_MAX_SESSION_CONNECTIONS:
	 				errMsg = "This connection exceeded the maximum number of multiplexed server connections supported by the proxy server";
	 				break;
				case UniRPCTokens.UNIRPC_NOT_PROXY_CONNECTION:
					errMsg = "Specified security mode requires a proxy connection";
					break;
	 			case UniTokens.UVE_FILE_NOT_OPEN:
	 				errMsg = "File [" + aExtraInfo + "] was previously closed.  Must reopen to perform this operation";
	 				break;
	 			case UniTokens.UVE_OPENSESSION_ERR:
	 				errMsg = "Maximum number of UniJava sessions already open";
	 				break;
	 			case UniTokens.UVE_NONNULL_RECORDID:
	 				errMsg = "Cannot perform operation on a null recordID";
	 				break;
	 			case UniRPCTokens.UNIRPC_INVALID_ARG_TYPE:
	 				errMsg = "An argument was requested from the RPC that was of an invalid type";
	 				break;
	 			case UniTokens.UVE_SR_SLAVE_READ_FAIL:

	 				errMsg = "Error ["+aErrorCode+"] occurred on server.  Possible client-side licensing failure.";
	 				break;
	 			case UniTokens.UVE_CSVERSION:
	 				errMsg = "The client and the server are not running at the same release level";
	 				break;
	 			case UniTokens.UVE_COMMSVERSION:
	 				errMsg = "The client or server is not running at the same release level as the communications support";
	 				break;
	 			case UniTokens.UVE_MUST_USE_SESSION:
	 				errMsg = "Cannot instantiate this object in this manner.  Must use the UniSession object";
	 				break;
				case UniTokens.UVE_MLTPLEX_SECURE_SESSION:
					errMsg = "Cannon multuplex this connection";
					break;
				case UniTokens.UVE_NOT_A_PROXY_SESSION:
					errMsg = "Specified security mode requires a proxy connection";
					break;
				case UniTokens.UVE_BAD_SSL_MODE:
					errMsg = "Bad SSL mode";
					break;
				case UniTokens.UVE_QUERY_SYNTAX:
					errMsg = "Query/sql syntax error or no result";
					break;
					
				case UniTokens.EIC_POOLOFF: 
					errMsg = "Connection Pooling is OFF.";
					break;
					
				case UniTokens.UVE_UNISESSION_TIMEOUT: 
					errMsg = "The connection has timed out.";
					break;
				case UniTokens.UVE_CP_NOTSUPPORTED: 
					errMsg = "Connection Pooling is OFF. Please verify UniVerse or UniData Version. This feature may not be supported in older UniVerse or UniData version.";
					break;
				
				case UniTokens.UVE_XML_VERIFY_U2VERSION:
					errMsg = " Please verify UniVerse or UniData Version. This feature may not be supported in older UniVerse or UniData version.";
					break;

				case UniTokens.UVE_MINPOOL_MORETHAN_LICENSE:
					errMsg = " MinPoolSize cannot exceed authorized number of Connection Pooling licenses.";
					break;
				case UniTokens.UVE_PROXY_NOTSUPPORTED_WHEN_CP_ON:
					errMsg = " Proxy not supported when Connection Pooling is ON";
					break;
                case UniTokens.UVE_ENCODING_NOTSUPPORTED:
                    errMsg = " Specified encoding is not supported by the current JRE";
                    break;
                    
                default:
	 				errMsg = "Unknown Error [" + aErrorCode + "]  Occurred";
	 				break;
	 		}
	 		return errMsg;
	 }
}
