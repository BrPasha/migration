/*
 * Created on Aug 31, 2006
 *
 * IBM Confidential
 * OCO Source Materials
 * Copyright (C) IBM Corp.  2005
 */
/*
 * Modification History
 *
 *
 */
package asjava.uniclientlibs;

public class UniByteArrayTokenizer {

    public UniByteArrayTokenizer(byte[] bytes, byte delimiter) {
        this.bytes = bytes;
        this.delimiter = delimiter;
        maxPos = bytes.length;
    }

    public int countTokens() {
        int currpos = 0;
        int count = 1;
        while (currpos < maxPos) {
            if (bytes[currpos++] == delimiter)
                count++;
        }
        return count;
    }



    public boolean hasMoreTokens() {
        if (curPos == -1)
            return false;
        return (curPos <= maxPos);
    }


    public byte[] nextToken() {
        byte[] subvalue;

        if (!this.hasMoreTokens()) {
            return null;
        }

        // Parse through
        // find first occurance of the delimiter string
        int startPos = curPos;
        while ((curPos < maxPos) && bytes[curPos]!= delimiter)
            curPos++;

        subvalue = UniString.subByteArray(bytes, startPos, curPos);
        curPos++;
        return subvalue;
    }
    

    /**
     * resets the string tokenizer to look at the very beginning of the string, to allow
     * reparsing of the string.
     *
     * @since UNICLIENTLIBS 1.0
     */
    public void resetTokenizer() {
        curPos = 0;
    }

    byte[] bytes = null;

    byte delimiter = 32;

    int curPos = 0;

    int maxPos = 0;

}
